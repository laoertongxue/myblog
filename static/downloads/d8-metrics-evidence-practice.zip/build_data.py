"""Deterministic, hand-designed D8-v1 teaching fixtures; no random generator."""
import csv
from pathlib import Path
from datetime import date,timedelta
ROOT=Path(__file__).resolve().parent

def write(name,header,rows):
    with (ROOT/'data'/f'{name}.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)

def main():
    (ROOT/'data').mkdir(exist_ok=True)
    write('stores',['store_id','name'],[['A','禾味甲店（虚构）'],['B','禾味乙店（虚构）']])
    write('skus',['sku_id','name','unit'],[[f'sku{i:02}','食材'+str(i),'kg'] for i in range(1,9)])
    write('orders',['order_id','store_id','ordered_at','promised_at','status'],[[f'O{i}','A','2026-10-18T08:00:00','2026-11-01T12:00:00' if i==6 else '2026-10-20T12:00:00','cancelled' if i==5 else 'active'] for i in range(1,8)])
    lines=[[f'L{i}',f'O{i}','sku01',10] for i in range(1,8)]+[['L8','O7','sku02',10]]
    write('order_lines',['line_id','order_id','sku_id','ordered_qty'],lines)
    receipts=[['R1','L1','2026-10-20T12:00:00',10],['R2','L2','2026-10-20T11:00:00',7],['R3','L3','2026-10-20T11:00:00',7],['R4','L3','2026-10-21T12:00:00',3],['R5','L4','2026-10-19T12:00:00',4],['R6','L4','2026-10-20T11:00:00',6],['R7','L5','2026-10-20T11:00:00',10],['R8','L7','2026-10-20T11:00:00',12],['R9','L8','2026-10-20T11:00:00',8]]
    write('delivery_receipts',['receipt_id','line_id','accepted_at','qualified_qty'],receipts)
    days=[(date(2026,10,18)+timedelta(days=i)).isoformat() for i in range(14)]
    write('inventory_snapshots',['snapshot_date','store_id','sku_id','on_hand_qty'],[[d,s,f'sku{k:02}',0 if s=='A' and k==1 and j in (3,8) else 20+k] for j,d in enumerate(days) for s in ['A','B'] for k in range(1,9)])
    closing=[95,90,85,80,75,70,65,60,55,50,45,80,73,68]; opening=100;ledger=[]
    for j,(d,c) in enumerate(zip(days,closing)):
        receipt=40 if j==11 else 0;loss=2 if j==12 else 0;use=opening+receipt-loss-c
        ledger.append([d,opening,receipt,use,loss,c,20]);opening=c
    write('apparel_ledger',['date','opening','receipt','use','loss','closing','unit_cost'],ledger)
    write('apparel_availability',['on_hand','reserved','quarantine'],[[100,20,10]])
    write('apparel_future_demand',['date','qty'],[['2026-11-01',30],['2026-11-02',40],['2026-11-03',50]])
if __name__=='__main__':main()
