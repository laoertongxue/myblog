"""D8-v1: validated CSV -> SQLite three metrics + independent apparel arithmetic."""
import csv,json,re,sqlite3
from pathlib import Path
from datetime import datetime,date,timedelta
ROOT=Path(__file__).resolve().parent
PARAMS={'start':'2026-10-18T00:00:00','end':'2026-11-01T00:00:00','cutoff':'2026-10-31T23:59:59','start_date':'2026-10-18','end_date':'2026-11-01'}
HEADERS={
 'stores':['store_id','name'],'skus':['sku_id','name','unit'],
 'orders':['order_id','store_id','ordered_at','promised_at','status'],
 'order_lines':['line_id','order_id','sku_id','ordered_qty'],
 'delivery_receipts':['receipt_id','line_id','accepted_at','qualified_qty'],
 'inventory_snapshots':['snapshot_date','store_id','sku_id','on_hand_qty'],
 'apparel_ledger':['date','opening','receipt','use','loss','closing','unit_cost'],
 'apparel_availability':['on_hand','reserved','quarantine'],
 'apparel_future_demand':['date','qty']}
NUMS={'ordered_qty','qualified_qty','on_hand_qty','opening','receipt','use','loss','closing','unit_cost','on_hand','reserved','quarantine','qty'}

def integer(s):
    if not isinstance(s,str) or not re.fullmatch(r'0|[1-9][0-9]*',s,flags=re.ASCII):raise ValueError('noncanonical nonnegative integer: '+repr(s))
    v=int(s)
    if v>10**9:raise ValueError('quantity outside teaching range')
    return v

def timestamp(s,day=False):
    fmt='%Y-%m-%d' if day else '%Y-%m-%dT%H:%M:%S'
    pattern=r'[0-9]{4}-[0-9]{2}-[0-9]{2}' + ('' if day else r'T[0-9]{2}:[0-9]{2}:[0-9]{2}')
    if not re.fullmatch(pattern,s,flags=re.ASCII):raise ValueError('noncanonical date')
    datetime.strptime(s,fmt)
    return s

def load(data_dir=None):
    data={}
    for name,fields in HEADERS.items():
        with ((data_dir or ROOT/'data')/(name+'.csv')).open(encoding='utf-8',newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=fields:raise ValueError('bad header: '+name)
            rows=list(reader)
        for row in rows:
            if set(row)!=set(fields) or any(v is None or v=='' for v in row.values()):raise ValueError('missing/extra fields: '+name)
            for k,v in row.items():
                if k in NUMS:row[k]=integer(v)
                elif k.endswith('_at'):timestamp(v)
                elif k in ('date','snapshot_date'):timestamp(v,True)
        data[name]=rows
    validate(data)
    return data

def unique(rows,fields):
    keys=[tuple(r[k] for k in fields) for r in rows]
    if len(keys)!=len(set(keys)):raise ValueError('duplicate key '+str(fields))

def validate(d):
    for t,key in [('stores',['store_id']),('skus',['sku_id']),('orders',['order_id']),('order_lines',['line_id']),('order_lines',['order_id','sku_id']),('delivery_receipts',['receipt_id']),('inventory_snapshots',['snapshot_date','store_id','sku_id']),('apparel_ledger',['date']),('apparel_future_demand',['date'])]:unique(d[t],key)
    stores={r['store_id'] for r in d['stores']};skus={r['sku_id'] for r in d['skus']};orders={r['order_id']:r for r in d['orders']};lines={r['line_id']:r for r in d['order_lines']}
    if stores!={'A','B'} or skus!={f'sku{i:02}' for i in range(1,9)}:raise ValueError('D8 fixture requires 2 stores / 8 SKUs')
    for o in orders.values():
        if o['store_id'] not in stores or o['status'] not in ('active','cancelled') or o['ordered_at']>o['promised_at']:raise ValueError('invalid order')
        if not any(l['order_id']==o['order_id'] for l in lines.values()):raise ValueError('order without lines')
    for l in lines.values():
        if l['order_id'] not in orders or l['sku_id'] not in skus or l['ordered_qty']<=0:raise ValueError('invalid line')
    for r in d['delivery_receipts']:
        if r['line_id'] not in lines:raise ValueError('orphan receipt')
        if r['accepted_at']<orders[lines[r['line_id']]['order_id']]['ordered_at']:raise ValueError('receipt before order')
    days={(date(2026,10,18)+timedelta(days=i)).isoformat() for i in range(14)}
    expected={(day,s,k) for day in days for s in stores for k in skus}
    actual={(r['snapshot_date'],r['store_id'],r['sku_id']) for r in d['inventory_snapshots']}
    if actual!=expected:raise ValueError('missing/extra snapshot grid cells')
    ledger=sorted(d['apparel_ledger'],key=lambda r:r['date'])
    if {r['date'] for r in ledger}!=days:raise ValueError('apparel ledger missing days')
    for i,r in enumerate(ledger):
        if r['opening']+r['receipt']-r['use']-r['loss']!=r['closing']:raise ValueError('inventory conservation')
        if i and r['opening']!=ledger[i-1]['closing']:raise ValueError('ledger continuity')
    if len({r['unit_cost'] for r in ledger})!=1:raise ValueError('toy assumes fixed cost')
    if len(d['apparel_availability'])!=1:raise ValueError('one availability row required')
    a=d['apparel_availability'][0]
    if a['reserved']+a['quarantine']>a['on_hand']:raise ValueError('overlapping/unavailable stock')
    if sorted(r['date'] for r in d['apparel_future_demand'])!=['2026-11-01','2026-11-02','2026-11-03']:raise ValueError('future demand horizon')

def database(d):
    c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row
    for t,fields in HEADERS.items():
        c.execute('CREATE TABLE '+t+' ('+','.join(k+(' INTEGER' if k in NUMS else ' TEXT') for k in fields)+')')
        c.executemany('INSERT INTO '+t+' VALUES ('+','.join('?' for _ in fields)+')',[[r[k] for k in fields] for r in d[t]])
    return c

def calculate(d):
    c=database(d);out={}
    for key,file in [('otif','01_otif.sql'),('quantity_fill','02_quantity_fill.sql'),('snapshot_stockout','03_snapshot_stockout.sql')]:out[key]=[dict(r) for r in c.execute((ROOT/'sql'/file).read_text(encoding='utf-8'),PARAMS)]
    c.close();ledger=sorted(d['apparel_ledger'],key=lambda r:r['date']);cost=ledger[0]['unit_cost'];avg=sum(r['closing'] for r in ledger)/len(ledger);used=sum(r['use'] for r in ledger);loss=sum(r['loss'] for r in ledger);resource=ledger[0]['opening']+sum(r['receipt'] for r in ledger)
    a=d['apparel_availability'][0];available=a['on_hand']-a['reserved']-a['quarantine'];remaining=available;covered=0
    for row in sorted(d['apparel_future_demand'],key=lambda r:r['date']):
        if remaining<row['qty']:break
        remaining-=row['qty'];covered+=1
    out['apparel']={'opening':ledger[0]['opening'],'receipts':sum(r['receipt'] for r in ledger),'use':used,'loss':loss,'closing':ledger[-1]['closing'],'daily_closing_sum':sum(r['closing'] for r in ledger),'average_inventory_qty':avg,'consumption_cost':used*cost,'average_inventory_cost':avg*cost,'turnover':used*cost/(avg*cost) if avg*cost else None,'turnover_days':len(ledger)*(avg*cost)/(used*cost) if avg*cost and used*cost else None,'loss_cost':loss*cost,'resource_cost':resource*cost,'loss_rate':loss*cost/(resource*cost) if resource*cost else None,'available':available,'full_days_covered':covered,'horizon_days':len(d['apparel_future_demand']),'coverage_is_lower_bound':covered==len(d['apparel_future_demand'])}
    return out

def boundaries(d):
    expected={'O1':True,'O2':False,'O3':False,'O4':True,'O5':None,'O6':None,'O7':False};labels=['准时足量（恰好等于承诺）','准时部分','迟到补齐','分批按时到齐','整单取消','未到期','多SKU超量不可抵缺'];result=[]
    for o,label in zip(d['orders'],labels):
        included=o['status']=='active' and PARAMS['start']<=o['promised_at']<PARAMS['end'] and o['promised_at']<=PARAMS['cutoff'];detail=[]
        for l in d['order_lines']:
            if l['order_id']!=o['order_id']:continue
            timely=sum(r['qualified_qty'] for r in d['delivery_receipts'] if r['line_id']==l['line_id'] and r['accepted_at']<=min(o['promised_at'],PARAMS['cutoff']))
            detail.append({'line_id':l['line_id'],'sku_id':l['sku_id'],'ordered':l['ordered_qty'],'timely':timely,'capped':min(timely,l['ordered_qty'])})
        actual=all(x['timely']>=x['ordered'] for x in detail) if included else None
        result.append({'order_id':o['order_id'],'case':label,'included':included,'expected':expected[o['order_id']],'actual':actual,'pass':actual==expected[o['order_id']],'lines':detail})
    return result

def main():
    d=load();out={'version':'D8-v1-independent','timezone':'UTC+08:00','parameters':PARAMS,'metrics':calculate(d),'boundary_tests':boundaries(d)}
    if not all(r['pass'] for r in out['boundary_tests']):raise AssertionError('boundary mismatch')
    (ROOT/'results').mkdir(exist_ok=True);(ROOT/'results'/'metrics.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
