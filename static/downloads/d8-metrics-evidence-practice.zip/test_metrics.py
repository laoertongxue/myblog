import copy,tempfile,unittest,csv
from pathlib import Path
import run

class MetricsTests(unittest.TestCase):
    def setUp(self):self.data=run.load()
    def test_01_six_boundaries_and_multiitem_against_sql(self):
        for b in run.boundaries(self.data):
            with self.subTest(case=b['case']):
                d=copy.deepcopy(self.data);d['orders']=[o for o in d['orders'] if o['order_id']==b['order_id']];d['order_lines']=[l for l in d['order_lines'] if l['order_id']==b['order_id']];ids={l['line_id'] for l in d['order_lines']};d['delivery_receipts']=[r for r in d['delivery_receipts'] if r['line_id'] in ids]
                a=run.calculate(d)['otif'][0]
                self.assertEqual(a['denominator'],int(b['included']))
                self.assertEqual(a['numerator'],int(b['expected'] is True))
                self.assertEqual(a['ratio'],None if b['expected'] is None else int(b['expected']))
    def test_02_totals_and_zero_denominators(self):
        m=run.calculate(self.data)
        self.assertEqual(m['otif'][0],{'store_id':'A','numerator':2,'denominator':5,'ratio':.4})
        self.assertEqual(m['otif'][1],{'store_id':'B','numerator':0,'denominator':0,'ratio':None})
        self.assertEqual((m['quantity_fill'][0]['numerator'],m['quantity_fill'][0]['denominator'],m['quantity_fill'][0]['ratio']),(44,50,.88))
        self.assertEqual(m['quantity_fill'][1]['ratio'],.8)
        self.assertIsNone(m['quantity_fill'][2]['ratio'])
        self.assertEqual((m['snapshot_stockout'][0]['numerator'],m['snapshot_stockout'][0]['denominator']),(2,14))
        self.assertEqual(sum(r['numerator'] for r in m['snapshot_stockout']),2)
    def test_03_apparel_hand_calculations(self):
        m=run.calculate(self.data)['apparel'];self.assertEqual((m['opening'],m['receipts'],m['use'],m['loss'],m['closing']),(100,40,70,2,68));self.assertEqual(m['daily_closing_sum'],991);self.assertAlmostEqual(m['turnover'],980/991);self.assertAlmostEqual(m['turnover_days'],991/70);self.assertAlmostEqual(m['loss_rate'],1/70);self.assertEqual(m['full_days_covered'],2);self.assertFalse(m['coverage_is_lower_bound'])
    def test_04_lexical_rejections(self):
        for value in ['1_0','１','١','NaN','nan','inf','1.0','1e2','-1','+1',' 1','01','','NULL','1\n']:
            with self.subTest(value=value),self.assertRaises(ValueError):run.integer(value)
        for value in ['0','1','100']:self.assertEqual(run.integer(value),int(value))
    def test_05_bad_dates(self):
        for value in ['2026-02-30T12:00:00','2026-1-01T12:00:00','2026-10-20 12:00:00','2026-10-20T12:00:00Z','２０２６-10-20T12:00:00']:
            with self.subTest(value=value),self.assertRaises(ValueError):run.timestamp(value)
    def test_06_duplicate_sku_rejected(self):
        d=copy.deepcopy(self.data);d['order_lines'].append(dict(d['order_lines'][0],line_id='LX'))
        with self.assertRaises(ValueError):run.validate(d)
    def test_07_duplicate_primary_key(self):
        d=copy.deepcopy(self.data);d['delivery_receipts'].append(d['delivery_receipts'][0])
        with self.assertRaises(ValueError):run.validate(d)
    def test_08_orphan_rejected(self):
        d=copy.deepcopy(self.data);d['delivery_receipts'][0]['line_id']='absent'
        with self.assertRaises(ValueError):run.validate(d)
    def test_09_missing_snapshot_rejected(self):
        d=copy.deepcopy(self.data);d['inventory_snapshots'].pop()
        with self.assertRaises(ValueError):run.validate(d)
    def test_10_null_inventory_not_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            for p in (run.ROOT/'data').glob('*.csv'): (dest/p.name).write_bytes(p.read_bytes())
            p=dest/'inventory_snapshots.csv';txt=p.read_text();p.write_text(txt.replace('2026-10-18,A,sku01,21','2026-10-18,A,sku01,',1))
            with self.assertRaises(ValueError):run.load(dest)
    def test_11_late_receipt_cannot_repair_timely_result(self):
        d=copy.deepcopy(self.data);d['delivery_receipts']=[r for r in d['delivery_receipts'] if r['receipt_id']!='R4'];self.assertEqual(run.calculate(d)['otif'],run.calculate(self.data)['otif']);self.assertEqual(run.calculate(d)['quantity_fill'],run.calculate(self.data)['quantity_fill'])
    def test_12_future_receipt_ignored(self):
        d=copy.deepcopy(self.data);d['delivery_receipts'].append({'receipt_id':'RX','line_id':'L2','accepted_at':'2026-11-02T12:00:00','qualified_qty':3});self.assertEqual(run.calculate(d)['otif'],run.calculate(self.data)['otif'])
    def test_13_period_boundary(self):
        d=copy.deepcopy(self.data);d['orders'][0]['promised_at']=run.PARAMS['end'];self.assertEqual(run.calculate(d)['otif'][0]['denominator'],4)
    def test_14_ledger_failure_blocks(self):
        d=copy.deepcopy(self.data);d['apparel_ledger'][0]['closing']+=1
        with self.assertRaises(ValueError):run.validate(d)
    def test_15_apparel_zero_denominators_and_horizon(self):
        d=copy.deepcopy(self.data)
        for r in d['apparel_ledger']:
            for k in ('opening','receipt','use','loss','closing'):r[k]=0
        d['apparel_availability'][0]={'on_hand':0,'reserved':0,'quarantine':0}
        for r in d['apparel_future_demand']:r['qty']=0
        run.validate(d);a=run.calculate(d)['apparel']
        self.assertIsNone(a['turnover']);self.assertIsNone(a['turnover_days']);self.assertIsNone(a['loss_rate']);self.assertEqual(a['full_days_covered'],3);self.assertTrue(a['coverage_is_lower_bound'])
    def test_16_zero_consumption_with_inventory(self):
        d=copy.deepcopy(self.data)
        for r in d['apparel_ledger']:
            r.update(opening=10,closing=10,receipt=0,use=0,loss=0)
        run.validate(d);a=run.calculate(d)['apparel']
        self.assertEqual(a['turnover'],0);self.assertIsNone(a['turnover_days']);self.assertEqual(a['loss_rate'],0)
    def test_17_positive_flow_zero_daily_closing_cost(self):
        d=copy.deepcopy(self.data)
        for r in d['apparel_ledger']:
            r.update(opening=0,receipt=10,use=10,loss=0,closing=0)
        run.validate(d);a=run.calculate(d)['apparel']
        self.assertGreater(a['consumption_cost'],0)
        self.assertEqual(a['average_inventory_cost'],0)
        self.assertIsNone(a['turnover']);self.assertIsNone(a['turnover_days'])
    def test_18_zero_unit_cost_does_not_cancel_zero_denominators(self):
        d=copy.deepcopy(self.data)
        for r in d['apparel_ledger']:r['unit_cost']=0
        run.validate(d);a=run.calculate(d)['apparel']
        self.assertEqual(a['average_inventory_cost'],0);self.assertEqual(a['resource_cost'],0)
        self.assertIsNone(a['turnover']);self.assertIsNone(a['turnover_days']);self.assertIsNone(a['loss_rate'])
if __name__=='__main__' :unittest.main(verbosity=2)
