-- 输入必须先通过完整网格检查；无记录不自动补零。固定日末状态并非全天缺货时长。
SELECT store_id,sku_id,SUM(on_hand_qty=0) AS numerator,COUNT(*) AS denominator,
 1.0*SUM(on_hand_qty=0)/NULLIF(COUNT(*),0) AS ratio
FROM inventory_snapshots WHERE snapshot_date>=:start_date AND snapshot_date<:end_date
GROUP BY store_id,sku_id ORDER BY store_id,sku_id;
