-- 到期有效订单：左闭右开承诺期；统计截止同时限制收货。
WITH line_totals AS (
 SELECT o.store_id,o.order_id,l.line_id,l.ordered_qty,
 COALESCE(SUM(CASE WHEN r.accepted_at<=o.promised_at AND r.accepted_at<=:cutoff THEN r.qualified_qty ELSE 0 END),0) AS timely
 FROM orders o JOIN order_lines l USING(order_id)
 LEFT JOIN delivery_receipts r USING(line_id)
 WHERE o.status='active' AND o.promised_at>=:start AND o.promised_at<:end AND o.promised_at<=:cutoff
 GROUP BY o.store_id,o.order_id,l.line_id,l.ordered_qty
), order_flags AS (
 SELECT store_id,order_id,MIN(timely>=ordered_qty) AS passed FROM line_totals GROUP BY store_id,order_id
)
SELECT s.store_id,COALESCE(SUM(f.passed),0) AS numerator,COUNT(f.order_id) AS denominator,
 1.0*SUM(f.passed)/NULLIF(COUNT(f.order_id),0) AS ratio
FROM stores s LEFT JOIN order_flags f USING(store_id) GROUP BY s.store_id ORDER BY s.store_id;
