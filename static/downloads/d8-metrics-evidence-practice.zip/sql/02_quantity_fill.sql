-- 先按行汇总分批验收，再逐行封顶，禁止跨SKU抵缺。
WITH line_totals AS (
 SELECT l.line_id,l.sku_id,l.ordered_qty,
 COALESCE(SUM(CASE WHEN r.accepted_at<=o.promised_at AND r.accepted_at<=:cutoff THEN r.qualified_qty ELSE 0 END),0) AS timely
 FROM orders o JOIN order_lines l USING(order_id) LEFT JOIN delivery_receipts r USING(line_id)
 WHERE o.status='active' AND o.promised_at>=:start AND o.promised_at<:end AND o.promised_at<=:cutoff
 GROUP BY l.line_id,l.sku_id,l.ordered_qty
)
SELECT s.sku_id,s.unit,COALESCE(SUM(MIN(t.timely,t.ordered_qty)),0) AS numerator,
 COALESCE(SUM(t.ordered_qty),0) AS denominator,
 1.0*SUM(MIN(t.timely,t.ordered_qty))/NULLIF(SUM(t.ordered_qty),0) AS ratio
FROM skus s LEFT JOIN line_totals t USING(sku_id) GROUP BY s.sku_id,s.unit ORDER BY s.sku_id;
