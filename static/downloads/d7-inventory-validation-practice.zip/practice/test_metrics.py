"""Executable expected-versus-actual boundary tests and mutation checks."""
import copy,json,unittest,math
from pathlib import Path
from run import read,inventory,fulfillment,coverage
P=Path(__file__).resolve().parent
class MetricsTests(unittest.TestCase):
    def inv(self,ledger=None,snaps=None,skus=None):
        return inventory(read('ledger') if ledger is None else ledger,read('inventory_snapshots') if snaps is None else snaps,read('skus') if skus is None else skus,read('stores'))
    def ful(self,receipts=None,orders=None,lines=None):
        return fulfillment(read('orders') if orders is None else orders,read('order_lines') if lines is None else lines,read('delivery_receipts') if receipts is None else receipts)
    def test_01_six_fulfillment_cases(self):
        r=self.ful(); actual={x['order_id']:x['passed'] for x in r['order_results']}; timely={x['order_id']:x['on_time_qty'] for x in r['line_results']}
        cases=[('准时足量','O1',1,10),('准时部分','O2',0,7),('迟到补齐','O3',0,7),('分批按时到齐','O4',1,10),('整单取消','O5',None,None),('未到期','O6',None,None)]
        report=[]
        for name,oid,expected,qty in cases:
            with self.subTest(case=name):self.assertEqual(actual.get(oid),expected);self.assertEqual(timely.get(oid),qty)
            report.append({'case':name,'order_id':oid,'expected_otif':expected,'actual_otif':actual.get(oid),'expected_timely_qty':qty,'actual_timely_qty':timely.get(oid),'pass':actual.get(oid)==expected and timely.get(oid)==qty})
        (P/'results').mkdir(exist_ok=True);(P/'results'/'boundary-tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        self.assertEqual(r['otif'],{'numerator':2,'denominator':4,'ratio':0.5});self.assertEqual(r['quantity_result'][0]['ratio'],.85)
    def test_02_late_receipt_cannot_rewrite_history(self):
        rows=read('delivery_receipts');base=self.ful(rows)
        rows.append({'receipt_id':'R9','line_id':'L3','accepted_at':'2026-10-30 15:00:00','accepted_qty':'100'})
        self.assertEqual(self.ful(rows),base)
    def test_03_split_receipt_keeps_results(self):
        rows=read('delivery_receipts');base=self.ful(rows);rows[0]['accepted_qty']='4';new=copy.deepcopy(rows[0]);new.update(receipt_id='R9',accepted_qty='6');rows.append(new)
        self.assertEqual(self.ful(rows),base)
    def test_04_overdelivery_capped(self):
        rows=read('delivery_receipts');rows[0]['accepted_qty']='100'
        self.assertEqual(self.ful(rows)['quantity_result'][0]['ratio'],.85)
    def test_05_inventory_hand_calculation(self):
        rows=self.inv();self.assertEqual(len(rows),16);r=rows[0]
        self.assertAlmostEqual(r['average_inventory_cost'],(6*1000+7*980+960)/14)
        self.assertAlmostEqual(r['turnover_times'],1400/(13820/14))
        self.assertAlmostEqual(r['turnover_days'],13820/1400)
        self.assertEqual(r['ending_qty'],96);self.assertAlmostEqual(r['loss_ratio'],40/2400)
    def test_06_missing_snapshot_not_zero(self):
        with self.assertRaises(ValueError):self.inv(snaps=read('inventory_snapshots')[1:])
    def test_07_broken_conservation_rejected(self):
        rows=read('ledger');rows[0]['usage_qty']='11'
        with self.assertRaises(ValueError):self.inv(ledger=rows)
    def test_08_cost_mismatch_rejected(self):
        rows=read('inventory_snapshots');rows[0]['unit_cost']='20'
        with self.assertRaises(ValueError):self.inv(snaps=rows)
    def test_09_coverage_path(self):
        r=coverage(90,[10,20,30,40,10,20,10]);self.assertEqual(r['average_days'],4.5);self.assertEqual(r['full_days'],3);self.assertEqual(r['first_shortage_day'],4);self.assertEqual(r['shortage_qty'],10)
    def test_10_zero_demand_is_not_infinity(self):
        r=coverage(90,[0]*7);self.assertIsNone(r['average_days']);self.assertEqual(r['status'],'no-demand-in-horizon');self.assertEqual(r['full_days'],7)
    def test_11_unknown_demand_rejected(self):
        for p in [[],[10,None],[10,-1],[float('nan')]]:
            with self.subTest(p=p),self.assertRaises((ValueError,TypeError)):coverage(90,p)
    def test_12_future_receipt_rejected(self):
        rows=read('delivery_receipts');rows[0]['accepted_at']='2026-11-01 00:00:00'
        with self.assertRaises(ValueError):self.ful(rows)
    def test_13_zero_cost_denominator_not_zero_ratio(self):
        ledger=read('ledger');snaps=read('inventory_snapshots');skus=read('skus')
        for row in ledger+snaps+skus:row['unit_cost']='0'
        r=self.inv(ledger,snaps,skus)[0]
        self.assertIsNone(r['turnover_times']);self.assertIsNone(r['turnover_days']);self.assertIsNone(r['loss_ratio'])
    def test_14_no_usage_turnover_days_undefined(self):
        ledger=read('ledger');snaps=read('inventory_snapshots')
        for r in ledger:r.update(opening_qty='100',accepted_qty='0',usage_qty='0',loss_qty='0',closing_qty='100')
        for r in snaps:r['qty']='100'
        r=self.inv(ledger,snaps)[0];self.assertEqual(r['turnover_times'],0);self.assertIsNone(r['turnover_days']);self.assertEqual(r['loss_ratio'],0)
    def test_15_empty_order_denominator(self):
        r=self.ful(orders=[],lines=[],receipts=[]);self.assertIsNone(r['otif']['ratio']);self.assertEqual(r['quantity_result'],[])
    def test_16_invalid_duplicate_receipt(self):
        rows=read('delivery_receipts');rows.append(copy.deepcopy(rows[0]))
        with self.assertRaises(ValueError):self.ful(rows)
    def test_17_duplicate_sku_primary_key_rejected(self):
        for unit in ['kg','L']:
            rows=read('skus');duplicate=copy.deepcopy(rows[0]);duplicate['unit']=unit;rows.insert(0,duplicate)
            with self.subTest(unit=unit),self.assertRaisesRegex(ValueError,'Duplicate SKU primary key'):self.inv(skus=rows)
    def test_18_invalid_master_unit_and_name_rejected(self):
        for field,value in [('unit',''),('unit','L'),('unit','box'),('name',' '),('sku_id',''),('sku_id',' K01')]:
            rows=read('skus');rows[0][field]=value
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):self.inv(skus=rows)
    def test_19_invalid_store_master_rejected(self):
        for kind in ['duplicate','blank','unknown','missing_name']:
            rows=read('stores')
            if kind=='duplicate':rows.append(copy.deepcopy(rows[0]))
            elif kind=='blank':rows[0]['store_id']=''
            elif kind=='unknown':rows[0]['store_id']='S99'
            else:rows[0]['name']=' '
            with self.subTest(kind=kind),self.assertRaises(ValueError):inventory(read('ledger'),read('inventory_snapshots'),read('skus'),rows)
    def test_20_missing_or_unknown_sku_rejected(self):
        rows=read('skus')
        with self.assertRaises(ValueError):self.inv(skus=rows[1:])
        rows[0]['sku_id']='K99'
        with self.assertRaises(ValueError):self.inv(skus=rows)
    def test_21_fulfillment_numeric_lexical_contract(self):
        invalid=['1_0','１０','١٠','1,0','1e1','+10',' 10','10 ','','NaN','Infinity','-0','00','1.']
        for field in ['ordered_qty','accepted_qty']:
            for value in invalid:
                lines=read('order_lines');receipts=read('delivery_receipts')
                (lines if field=='ordered_qty' else receipts)[0][field]=value
                with self.subTest(field=field,value=value),self.assertRaises(ValueError):self.ful(lines=lines,receipts=receipts)
    def test_22_normalized_decimal_sql_values(self):
        expected=self.ful();lines=read('order_lines');receipts=read('delivery_receipts')
        lines[0]['ordered_qty']='10.0';receipts[0]['accepted_qty']='10.00'
        self.assertEqual(self.ful(lines=lines,receipts=receipts),expected)
if __name__=='__main__':unittest.main(verbosity=2)
