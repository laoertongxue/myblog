"""Explicitly regenerate deterministic fictional fixtures (no random seed needed)."""
import csv
from pathlib import Path
from datetime import date,timedelta
P=Path(__file__).resolve().parent/'data'; P.mkdir(exist_ok=True)
def write(name,fields,rows):
    with (P/(name+'.csv')).open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f); w.writerow(fields); w.writerows(rows)
write('stores',['store_id','name'],[['S01','禾味一店（虚构）'],['S02','禾味二店（虚构）']])
names=['大米','鸡肉','番茄','鸡蛋','土豆','牛奶','食用油','面粉']; units=['kg','kg','kg','个','kg','L','L','kg']
write('skus',['sku_id','name','unit','unit_cost'],[[f'K{i+1:02}',n,units[i],10+i] for i,n in enumerate(names)])
ledger=[]; snapshots=[]
for s in ['S01','S02']:
    for i in range(8):
        stock=100
        for d in range(14):
            day=(date(2026,10,17)+timedelta(days=d)).isoformat(); loss=2 if d in [6,13] else 0
            opening=stock; stock=opening+10-10-loss
            ledger.append([day,s,f'K{i+1:02}',opening,10,10,loss,stock,10+i])
            snapshots.append([day+' 23:59:00',s,f'K{i+1:02}',stock,10+i])
write('ledger',['day','store_id','sku_id','opening_qty','accepted_qty','usage_qty','loss_qty','closing_qty','unit_cost'],ledger)
write('inventory_snapshots',['snapshot_at','store_id','sku_id','qty','unit_cost'],snapshots)
write('future_demand',['day','store_id','sku_id','scenario_demand_qty'],[[(date(2026,10,31)+timedelta(days=i)).isoformat(),'S01','K01',q] for i,q in enumerate([10,20,30,40,10,20,10])])
write('availability',['as_of','store_id','sku_id','reserved_qty'],[['2026-10-30 23:59:00','S01','K01',6]])
write('orders',['order_id','promise_at','status'],[[f'O{i}','2026-10-30 12:00:00' if i<6 else '2026-11-01 12:00:00','cancelled' if i==5 else 'active'] for i in range(1,7)])
write('order_lines',['line_id','order_id','sku_id','ordered_qty'],[[f'L{i}',f'O{i}','K01',10] for i in range(1,7)])
receipts=[['R1','L1','2026-10-30 12:00:00',10],['R2','L2','2026-10-30 10:00:00',7],['R3','L3','2026-10-30 11:00:00',7],['R4','L3','2026-10-30 12:00:01',3],['R5','L4','2026-10-29 10:00:00',4],['R6','L4','2026-10-30 12:00:00',6],['R7','L5','2026-10-29 10:00:00',10],['R8','L6','2026-10-30 10:00:00',5]]
write('delivery_receipts',['receipt_id','line_id','accepted_at','accepted_qty'],receipts)
print('Regenerated simulated data: 2 stores, 8 SKUs, 224 ledger rows and snapshots; fulfillment fixtures independent of ledger.')
