-- All timestamps are validated fixed-format local UTC+08:00 strings.
-- Fulfillment fixtures are independent from the inventory exercise.
CREATE VIEW eligible_orders AS
SELECT * FROM orders WHERE status='active'
AND promise_at >= '2026-10-17 00:00:00'
AND promise_at < '2026-10-31 00:00:00'
AND promise_at <= '2026-10-30 23:59:00';
CREATE VIEW line_results AS
SELECT l.line_id,l.order_id,l.sku_id,l.ordered_qty,
       COALESCE(SUM(CASE WHEN r.accepted_at <= o.promise_at
                        THEN r.accepted_qty ELSE 0 END),0) AS on_time_qty
FROM eligible_orders o JOIN order_lines l ON l.order_id=o.order_id
LEFT JOIN delivery_receipts r ON r.line_id=l.line_id
GROUP BY l.line_id,l.order_id,l.sku_id,l.ordered_qty;
CREATE VIEW order_results AS
SELECT order_id,MIN(CASE WHEN on_time_qty>=ordered_qty THEN 1 ELSE 0 END) AS passed
FROM line_results GROUP BY order_id;
CREATE VIEW quantity_result AS
SELECT sku_id,SUM(MIN(on_time_qty,ordered_qty)) AS numerator,
SUM(ordered_qty) AS denominator,
1.0*SUM(MIN(on_time_qty,ordered_qty))/NULLIF(SUM(ordered_qty),0) AS ratio
FROM line_results GROUP BY sku_id;
