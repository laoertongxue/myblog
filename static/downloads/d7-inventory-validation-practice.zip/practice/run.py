"""Read supplied CSVs, validate before computing, write reproducible results. Standard library only."""
import csv,json,sqlite3,math,re
from pathlib import Path
from datetime import datetime,date,timedelta
P=Path(__file__).resolve().parent
START=date(2026,10,17); DAYS=14

def read(name):
    with (P/'data'/f'{name}.csv').open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def number(x):
    # CSV contract: unsigned ASCII decimal; no grouping, underscores, exponent or whitespace.
    if isinstance(x,str):
        if not re.fullmatch(r'(?:0|[1-9][0-9]*)(?:\.[0-9]+)?',x):raise ValueError('Invalid numeric lexical form')
    elif isinstance(x,bool) or not isinstance(x,(int,float)):
        raise ValueError('Numeric value required')
    n=float(x)
    if not math.isfinite(n) or n<0:raise ValueError('Quantity/cost must be finite nonnegative')
    return n
def timestamp(s):
    d=datetime.strptime(s,'%Y-%m-%d %H:%M:%S')
    if d.strftime('%Y-%m-%d %H:%M:%S')!=s:raise ValueError('Timestamp format')
    return d

def coverage(available,path):
    if available is None or not path:raise ValueError('Missing stock or demand horizon')
    a=number(available); ds=[number(x) for x in path]
    avg=sum(ds)/len(ds)
    if avg==0:return {'average_days':None,'status':'no-demand-in-horizon','full_days':len(ds),'first_shortage_day':None,'shortage_qty':0}
    stock=a; full=0; first=None; shortage=0
    for i,d in enumerate(ds,1):
        if d>stock:
            first=i; shortage=d-stock; break
        stock-=d; full+=1
    return {'average_days':a/avg,'status':'scenario-only','full_days':full,'first_shortage_day':first,'shortage_qty':shortage}

def inventory(ledger,snaps,skus,stores):
    # Validate primary keys BEFORE constructing maps: dicts must not hide duplicates.
    expected_units={'K01':'kg','K02':'kg','K03':'kg','K04':'个','K05':'kg','K06':'L','K07':'L','K08':'kg'}
    costs={}; sku_map={}; storeids=set()
    seen_skus=set()
    for r in skus:
        k=r.get('sku_id')
        if not isinstance(k,str) or not k.strip() or k!=k.strip():raise ValueError('Invalid SKU primary key')
        if k in seen_skus:raise ValueError('Duplicate SKU primary key')
        seen_skus.add(k)
    for r in skus:
        k=r.get('sku_id')
        if not isinstance(k,str) or not k.strip() or k!=k.strip():raise ValueError('Invalid SKU primary key')
        if k in sku_map:raise ValueError('Duplicate SKU primary key')
        if k not in expected_units:raise ValueError('Unexpected fixture SKU')
        if r.get('unit')!=expected_units[k]:raise ValueError('SKU base unit mismatch')
        if not isinstance(r.get('name'),str) or not r['name'].strip():raise ValueError('Missing SKU name')
        costs[k]=number(r['unit_cost']);sku_map[k]=r
    if set(sku_map)!=set(expected_units):raise ValueError('Missing fixture SKU')
    for r in stores:
        k=r.get('store_id')
        if not isinstance(k,str) or not k.strip() or k!=k.strip():raise ValueError('Invalid store primary key')
        if k in storeids:raise ValueError('Duplicate store primary key')
        if not isinstance(r.get('name'),str) or not r['name'].strip():raise ValueError('Missing store name')
        storeids.add(k)
    if storeids!={'S01','S02'}:raise ValueError('Expected fixture stores S01 and S02')
    dates=[(START+timedelta(days=i)).isoformat() for i in range(DAYS)]
    expected={(d,s,k) for d in dates for s in storeids for k in costs}
    mapped={}; smap={}
    for r in ledger:
        key=(r['day'],r['store_id'],r['sku_id'])
        if key in mapped:raise ValueError('Duplicate ledger row')
        mapped[key]=r
    for r in snaps:
        timestamp(r['snapshot_at'])
        if not r['snapshot_at'].endswith(' 23:59:00'):raise ValueError('Snapshot timing mismatch')
        key=(r['snapshot_at'][:10],r['store_id'],r['sku_id'])
        if key in smap:raise ValueError('Duplicate snapshot')
        smap[key]=r
    if set(mapped)!=expected or set(smap)!=expected:raise ValueError('Missing or extra ledger/snapshot grid')
    results=[]
    for s in sorted(storeids):
        for k,c in sorted(costs.items()):
            prev=None; usage=loss=receipts=0; vals=[]; opening=None
            for d in dates:
                r=mapped[d,s,k]; z=smap[d,s,k]
                o,a,u,l,e=[number(r[f]) for f in ['opening_qty','accepted_qty','usage_qty','loss_qty','closing_qty']]
                if number(r['unit_cost'])!=c or number(z['unit_cost'])!=c:raise ValueError('Cost basis mismatch')
                if not math.isclose(o+a-u-l,e,abs_tol=1e-9):raise ValueError('Stock conservation failed')
                if prev is not None and o!=prev:raise ValueError('Opening does not equal prior close')
                if number(z['qty'])!=e:raise ValueError('Snapshot disagrees with close')
                if opening is None:opening=o*c
                prev=e; usage+=u*c; loss+=l*c; receipts+=a*c; vals.append(e*c)
            avg=sum(vals)/DAYS; turnover=usage/avg if avg else None
            results.append({'store_id':s,'sku_id':k,'unit':sku_map[k]['unit'],'days':DAYS,'opening_cost':opening,'accepted_cost':receipts,'usage_cost':usage,'loss_cost':loss,'ending_qty':prev,'average_inventory_cost':avg,'turnover_times':turnover,'turnover_days':DAYS/turnover if turnover else None,'loss_denominator_cost':opening+receipts,'loss_ratio':loss/(opening+receipts) if opening+receipts else None})
    return results

def fulfillment(orders,lines,receipts):
    oid={}; lid={}; rid=set()
    for r in orders:
        if r['order_id'] in oid:raise ValueError('Duplicate order')
        timestamp(r['promise_at'])
        if r['status'] not in ['active','cancelled']:raise ValueError('Unknown order status')
        oid[r['order_id']]=r
    for r in lines:
        if r['line_id'] in lid or r['order_id'] not in oid:raise ValueError('Duplicate/orphan line')
        if number(r['ordered_qty'])<=0 or r['sku_id']!='K01':raise ValueError('Fixture line invalid')
        lid[r['line_id']]=r
    if set(oid)!=set(r['order_id'] for r in lines):raise ValueError('Order has no lines')
    for r in receipts:
        if r['receipt_id'] in rid or r['line_id'] not in lid:raise ValueError('Duplicate/orphan receipt')
        rid.add(r['receipt_id']); timestamp(r['accepted_at']); number(r['accepted_qty'])
        if r['accepted_at']>'2026-10-30 23:59:00':raise ValueError('Receipt after statistical cutoff')
    con=sqlite3.connect(':memory:'); con.row_factory=sqlite3.Row
    con.executescript('CREATE TABLE orders(order_id TEXT,promise_at TEXT,status TEXT); CREATE TABLE order_lines(line_id TEXT,order_id TEXT,sku_id TEXT,ordered_qty REAL); CREATE TABLE delivery_receipts(receipt_id TEXT,line_id TEXT,accepted_at TEXT,accepted_qty REAL);')
    for name,rows,fields in [('orders',orders,['order_id','promise_at','status']),('order_lines',lines,['line_id','order_id','sku_id','ordered_qty']),('delivery_receipts',receipts,['receipt_id','line_id','accepted_at','accepted_qty'])]:
        con.executemany(f'INSERT INTO {name} VALUES ({",".join("?" for _ in fields)})',[[number(r[f]) if f in ('ordered_qty','accepted_qty') else r[f] for f in fields] for r in rows])
    con.executescript((P/'metrics.sql').read_text())
    result={name:[dict(x) for x in con.execute('SELECT * FROM '+name+' ORDER BY 1')] for name in ['line_results','order_results','quantity_result']}
    result['otif']={'numerator':sum(x['passed'] for x in result['order_results']),'denominator':len(result['order_results'])}
    result['otif']['ratio']=result['otif']['numerator']/result['otif']['denominator'] if result['otif']['denominator'] else None
    return result

def main():
    inv=inventory(read('ledger'),read('inventory_snapshots'),read('skus'),read('stores'))
    fut=read('future_demand'); avail=read('availability')
    if len(avail)!=1 or avail[0]['as_of']!='2026-10-30 23:59:00' or (avail[0]['store_id'],avail[0]['sku_id'])!=('S01','K01'):raise ValueError('Availability origin mismatch')
    expect=[(date(2026,10,31)+timedelta(days=i)).isoformat() for i in range(7)]
    if [r['day'] for r in fut]!=expect or any((r['store_id'],r['sku_id'])!=('S01','K01') for r in fut):raise ValueError('Incomplete future scenario grid')
    selected=next(r for r in inv if (r['store_id'],r['sku_id'])==('S01','K01'))
    available=selected['ending_qty']-number(avail[0]['reserved_qty'])
    cov=coverage(available,[r['scenario_demand_qty'] for r in fut]);cov.update({'available_qty':available,'horizon_days':7,'average_daily_demand':sum(number(r['scenario_demand_qty']) for r in fut)/7})
    result={'simulation':True,'observation_period':'2026-10-17 through 2026-10-30 inclusive, UTC+08:00','snapshot_at':'23:59:00 after all daily movements','inventory':inv,'coverage_S01_K01':cov,'fulfillment':fulfillment(read('orders'),read('order_lines'),read('delivery_receipts'))}
    (P/'results').mkdir(exist_ok=True);(P/'results'/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'S01_K01':selected,'coverage':cov,'otif':result['fulfillment']['otif'],'quantity':result['fulfillment']['quantity_result']},ensure_ascii=False,indent=2))
    return result
if __name__=='__main__':main()
