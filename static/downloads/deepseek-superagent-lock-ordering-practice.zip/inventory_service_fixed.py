"""Teaching example only: one process, one event loop, in-memory balances."""
import asyncio


class SafeAccountInventoryService:
    def __init__(self):
        self.balances = {"account_A": 1000, "account_B": 1000}
        self.locks = {key: asyncio.Lock() for key in self.balances}

    async def transfer_funds_safe(self, from_acc: str, to_acc: str, amount: int):
        if type(amount) is not int or amount <= 0:
            raise ValueError("amount must be a positive integer")
        if from_acc not in self.balances or to_acc not in self.balances:
            raise ValueError("unknown account")
        if from_acc == to_acc:
            raise ValueError("source and destination must differ")
        first_key, second_key = sorted((from_acc, to_acc))
        async with self.locks[first_key]:
            await asyncio.sleep(0)  # Allow interleaving in the demonstration.
            async with self.locks[second_key]:
                if self.balances[from_acc] < amount:
                    return False
                # No await between the two writes in this toy event-loop model.
                self.balances[from_acc] -= amount
                self.balances[to_acc] += amount
                return True
