Teaching example: Python asyncio lock ordering

Scope: one process, one event loop, fixed in-memory accounts, every balance
writer follows this lock protocol. Not a banking/payment/stock service.

Files:
  inventory_service_fixed.py  Example implementation
  test_transfer.py           Seven standard-library unittest test methods
  test-results.txt            Captured local test output (Python 3.12.14)

From this directory:
  python -m unittest -v

Cross-transfer test launches 200 calls, not 200 independent test methods.
Timeouts are test guards, not performance guarantees. The tests are limited
examples, not proof of absence of every race/deadlock in arbitrary systems.
The defective pytest example displayed in the article was not run here.
