import asyncio
import unittest
from inventory_service_fixed import SafeAccountInventoryService


class TransferTests(unittest.IsolatedAsyncioTestCase):
    async def test_transfer(self):
        s = SafeAccountInventoryService()
        self.assertTrue(await s.transfer_funds_safe('account_A', 'account_B', 50))
        self.assertEqual(s.balances, {'account_A': 950, 'account_B': 1050})

    async def test_cross_transfers(self):
        s = SafeAccountInventoryService()
        results = await asyncio.wait_for(asyncio.gather(*[
            s.transfer_funds_safe(a, b, 1)
            for _ in range(100)
            for a, b in [('account_A', 'account_B'), ('account_B', 'account_A')]
        ]), timeout=2)
        self.assertTrue(all(results))
        self.assertEqual(s.balances, {'account_A': 1000, 'account_B': 1000})

    async def test_insufficient_funds(self):
        s = SafeAccountInventoryService()
        self.assertFalse(await s.transfer_funds_safe('account_A', 'account_B', 1001))
        self.assertEqual(s.balances, {'account_A': 1000, 'account_B': 1000})

    async def test_self_transfer_rejected(self):
        s = SafeAccountInventoryService()
        with self.assertRaises(ValueError):
            await asyncio.wait_for(s.transfer_funds_safe('account_A', 'account_A', 1), 1)

    async def test_invalid_amounts(self):
        s = SafeAccountInventoryService()
        for amount in [-1, 0, True, 1.5, '1', None]:
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                await s.transfer_funds_safe('account_A', 'account_B', amount)
        self.assertEqual(s.balances, {'account_A': 1000, 'account_B': 1000})

    async def test_unknown_accounts(self):
        s = SafeAccountInventoryService()
        for a, b in [('missing', 'account_B'), ('account_A', 'missing')]:
            with self.subTest(accounts=(a, b)), self.assertRaises(ValueError):
                await s.transfer_funds_safe(a, b, 1)

    async def test_cancel_releases_first_lock(self):
        s = SafeAccountInventoryService()
        await s.locks['account_B'].acquire()
        task = asyncio.create_task(s.transfer_funds_safe('account_A', 'account_B', 1))
        try:
            async def wait_first_locked():
                while not s.locks['account_A'].locked():
                    await asyncio.sleep(0)
            await asyncio.wait_for(wait_first_locked(), 1)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
            self.assertFalse(s.locks['account_A'].locked())
        finally:
            s.locks['account_B'].release()
        self.assertTrue(await asyncio.wait_for(s.transfer_funds_safe('account_A', 'account_B', 1), 1))


if __name__ == '__main__':
    unittest.main()
