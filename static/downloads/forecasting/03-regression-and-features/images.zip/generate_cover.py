#!/usr/bin/env python3
"""Native 900×383 publication cover. No resizing/cropping/padding of old art.
SVG text remains editable; PNG is rendered directly from this SVG.
"""
from pathlib import Path
from html import escape
import subprocess
import xml.etree.ElementTree as ET
from PIL import Image

OUT = Path(__file__).resolve().parent

def text(x,y,s,size=20,weight=400):
    return f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}">{escape(s)}</text>'

def rect(x,y,w,h):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="white" stroke="black" stroke-width="2"/>'

def arrow(x1,y1,x2,y2):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="black" stroke-width="2.4" marker-end="url(#arrow)"/>'

b=text(36,56,'从一条直线到多特征预测',35,700)
b+=text(36,90,'供应链预测与计划 03  /  禾味 2 店 × 8 SKU（虚构教学）',17)
for x,title,row1,row2 in [
    (36,'已知输入','预订、周末、促销','只用起点前信息'),
    (330,'拟合规则','从直线到多个特征','用历史数据估系数'),
    (624,'未来核验','按时间留出以后','比较预测与真实值')
]:
    b+=rect(x,122,240,148)
    b+=text(x+18,160,title,28,700)
    b+=text(x+18,201,row1,20)
    b+=text(x+18,236,row2,20)
b+=arrow(284,196,316,196)+arrow(578,196,610,196)
b+=text(36,317,'预测净耗用 ≠ 采购量',25,700)
b+=text(36,351,'全部为教学模拟；采购仍需结合库存、在途与订货约束另作决定。',18)
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="900" height="383" viewBox="0 0 900 383" role="img" aria-labelledby="title desc">
<title id="title">从一条直线到多特征预测</title>
<desc id="desc">原生900乘383像素出版封面。虚构禾味两店八SKU教学案例：已知输入、拟合规则、未来核验。预测净耗用不等于采购量。</desc>
<defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L7,3.5 L0,7" fill="none" stroke="black" stroke-width="1.8"/></marker></defs>
<rect width="900" height="383" fill="white"/>
<g font-family="Noto Sans CJK SC, sans-serif" fill="black" stroke-linecap="round" stroke-linejoin="round">{b}</g>
</svg>'''
root=ET.fromstring(svg)
assert root.attrib['viewBox']=='0 0 900 383'
svg_path=OUT/'p03-01_cover.svg'
png_path=OUT/'p03-01_cover.png'
svg_path.write_text(svg,encoding='utf-8')
subprocess.run(['inkscape',str(svg_path),'--export-type=png','--export-filename='+str(png_path),'--export-width=900','--export-height=383'],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
im=Image.open(png_path).convert('RGB')
assert im.size==(900,383),im.size
assert all(r==g==b for r,g,b in im.get_flattened_data())
print(f'{png_path}: {im.size[0]}×{im.size[1]}, black/white/grayscale only')
print(f'{svg_path}: editable text, native 900×383 viewBox')
