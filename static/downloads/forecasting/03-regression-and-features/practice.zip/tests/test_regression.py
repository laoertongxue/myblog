"""执行：python -m unittest discover -s tests -v。"""
from copy import deepcopy
from datetime import timedelta
import math
import tempfile
from pathlib import Path
import unittest
from demo_temporal_controls import run_exercise
from reglab.clothing import examples, quantity
from reglab.checks import compare_temporal_controls
from reglab.core import (
    DataError, END, FREEZE, MODEL_COLUMNS, MODEL_NAMES, PARAMETERS, START, TEST_START,
    OLS, asof_features, day, dt, features, fit_ols, fit_simple, generate,
    hand_calculation, load_data, make_predictions, metrics, origin,
    score_rows, train_models, validate_data,
)


class HandMathTests(unittest.TestCase):
    def test_four_points(self):
        r = hand_calculation()
        for key, expected in (("intercept", 2.9), ("slope", .17), ("prediction_at_150", 28.4),
                              ("sse", .2), ("train_mae", .2)):
            self.assertAlmostEqual(r[key], expected, places=10)
        self.assertEqual(r["fitted"], [19.9, 23.3, 26.7, 30.1])

    def test_qr_matches_closed_form(self):
        x, y = [100, 120, 140, 160], [20, 23, 27, 30]
        a, b = fit_simple(x, y)
        model = fit_ols([[v] for v in x], y, ["booking"])
        self.assertAlmostEqual(model.coefficients[0], a, places=10)
        self.assertAlmostEqual(model.coefficients[1], b, places=10)

    def test_exact_multiple_regression(self):
        x = [[float(i), float(j)] for i in range(5) for j in range(3)]
        y = [3 + 2 * row[0] - 4 * row[1] for row in x]
        model = fit_ols(x, y, ["x1", "x2"])
        for estimated, expected in zip(model.coefficients, [3, 2, -4]):
            self.assertAlmostEqual(estimated, expected, places=10)

    def test_constant_x_rejected(self):
        with self.assertRaises(DataError):
            fit_simple([130] * 4, [20, 23, 27, 30])
        with self.assertRaises(DataError):
            fit_ols([[130]] * 4, [20, 23, 27, 30], ["booking"])

    def test_rank_deficiency_rejected(self):
        x = [[1, 0], [0, 1], [1, 0], [0, 1]]  # 截距=门店A+门店B。
        with self.assertRaises(DataError):
            fit_ols(x, [1, 2, 3, 4], ["store_A", "store_B"])
        with self.assertRaises(DataError):
            fit_ols([[i, 2 * i] for i in range(5)], list(range(5)), ["x", "twice_x"])

    def test_missing_nonfinite_and_shape_rejected(self):
        with self.assertRaises(DataError):
            fit_ols([[1], [2], [math.nan]], [1, 2, 3], ["x"])
        with self.assertRaises(DataError):
            fit_ols([[1], [2], [3]], [1, 2], ["x"])
        with self.assertRaises(DataError):
            fit_simple([1, 2], [1, math.inf])

    def test_negative_and_extrapolation_are_explicit(self):
        model = OLS(["x"], [-10, 1], [10], [20], 4)
        value, raw, clipped, flags = model.predict([8])
        self.assertEqual((value, raw, clipped, flags), (0, -2, True, ["x"]))
        value, raw, clipped, flags = model.predict([25])
        self.assertEqual((value, raw, clipped, flags), (15, 15, False, ["x"]))

    def test_given_multivariate_is_not_fitted(self):
        r = hand_calculation()["hypothetical_multivariate_not_fitted"]
        self.assertEqual(r["booking150_weekend1_promo1_storeB1"], 29)
        self.assertEqual(r["plus_hypothetical_1_5_promo_store_B"], 30.5)


class DataContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.versions, cls.labels = generate()

    def test_complete_skeleton_and_reproducibility(self):
        validate_data(self.versions, self.labels)
        self.assertEqual(len(self.labels), 1344)
        self.assertEqual(len(self.versions), 336)
        self.assertEqual((self.versions, self.labels), generate())
        self.assertEqual(len({(r["store"], r["sku"]) for r in self.labels}), 16)

    def test_shipped_csv_reproduces_generator(self):
        shipped = load_data(Path(__file__).resolve().parents[1] / "data")
        self.assertEqual(shipped, (self.versions, self.labels))

    def test_plan_and_final_selection(self):
        target = TEST_START.isoformat()
        snap = asof_features(self.versions, target, "A", origin(target))
        self.assertEqual(snap["stage"], "plan")
        later = asof_features(self.versions, target, "A", origin(target) + timedelta(days=2))
        self.assertEqual(later["stage"], "final")

    def test_unknown_category_and_unavailable_version(self):
        target = TEST_START.isoformat()
        with self.assertRaises(DataError):
            asof_features(self.versions, target, "C", origin(target))
        with self.assertRaises(DataError):
            asof_features(self.versions, target, "A", origin(target) - timedelta(hours=2))
        with self.assertRaises(DataError):
            features({"store": "C", "booking": 100, "promo": 0, "target_date": target}, "multivariate")

    def test_duplicate_or_missing_label_rejected(self):
        with self.assertRaises(DataError):
            validate_data(self.versions, self.labels + [self.labels[0]])
        with self.assertRaises(DataError):
            validate_data(self.versions, self.labels[1:])
        # 总行数相同的“缺一条+重复一条”也不能过关。
        with self.assertRaises(DataError):
            validate_data(self.versions, self.labels[1:] + [self.labels[-1]])

    def test_missing_stockout_closed_or_wrong_unit_rejected(self):
        for field, value in (("net_usage_kg", None), ("stockout", 1), ("is_open", 0),
                             ("unit", "pieces"), ("label_status", "missing")):
            with self.subTest(field=field):
                changed = deepcopy(self.labels)
                changed[0][field] = value
                with self.assertRaises(DataError):
                    validate_data(self.versions, changed)

    def test_wrong_time_and_duplicate_version_rejected(self):
        changed = deepcopy(self.labels)
        changed[0]["label_known_at"] = changed[0]["target_date"] + "T17:00:00+08:00"
        with self.assertRaises(DataError):
            validate_data(self.versions, changed)
        with self.assertRaises(DataError):
            validate_data(self.versions + [self.versions[0]], self.labels)
        with self.assertRaises(DataError):
            dt("2026-03-01T18:00:00")


class ChronologicalEvaluationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.versions, cls.labels = generate()
        cls.models, cls.audit = train_models(cls.versions, cls.labels)
        cls.predictions = make_predictions(cls.versions, cls.labels, cls.models)
        cls.scored = score_rows(cls.predictions, cls.labels)

    def test_freeze_counts_and_current_day_exclusion(self):
        self.assertEqual(len(self.models), 24)
        self.assertEqual(len(self.audit), 880)
        self.assertTrue(all(m.n_train == 110 for m in self.models.values()))
        self.assertEqual(max(r["target_date"] for r in self.audit), "2026-02-28")
        self.assertNotIn("2026-03-01", {r["target_date"] for r in self.audit})
        self.assertTrue(all(dt(r["label_known_at"]) <= FREEZE for r in self.audit))
        self.assertTrue(all(dt(r["feature_known_at"]) <= dt(r["historical_origin"]) for r in self.audit))

    def test_identical_evaluation_rows_for_all_models(self):
        keys = {}
        for model in MODEL_NAMES:
            rows = [r for r in self.predictions if r["model"] == model]
            self.assertEqual(len(rows), 448)
            keys[model] = {(r["target_date"], r["store"], r["sku"]) for r in rows}
            self.assertEqual(len(keys[model]), 448)
        self.assertTrue(all(k == keys["last_week"] for k in keys.values()))
        self.assertEqual(len(self.predictions), 1792)

    def test_forecast_cutoffs_and_baseline_visibility(self):
        for r in self.predictions:
            self.assertLessEqual(dt(r["feature_known_at"]), dt(r["forecast_origin"]))
            self.assertEqual(dt(r["forecast_origin"]), origin(r["target_date"]))
            if r["model"] == "last_week":
                self.assertLessEqual(dt(r["baseline_source_known_at"]), dt(r["forecast_origin"]))
                self.assertEqual(day(r["target_date"]) - day(r["baseline_source_date"]), timedelta(days=7))

    def test_estimated_coefficients_satisfy_normal_equations(self):
        # 独立检验OLS残差与截距/每一列正交，而非只复用拟合器内部代码。
        for (sku, model), fit in self.models.items():
            selected = [r for r in self.labels if r["sku"] == sku and dt(r["label_known_at"]) <= FREEZE]
            x = [features(asof_features(self.versions, r["target_date"], r["store"], origin(r["target_date"])), model)
                 for r in selected]
            residuals = [r["net_usage_kg"] - (fit.coefficients[0] + sum(a*b for a,b in zip(fit.coefficients[1:], xx)))
                         for r, xx in zip(selected, x)]
            self.assertAlmostEqual(sum(residuals), 0, places=8)
            for j in range(len(fit.names)):
                self.assertAlmostEqual(sum(e * xx[j] for e, xx in zip(residuals, x)), 0, places=6)

    def test_actual_future_mutations_and_known_feature_control(self):
        controls = compare_temporal_controls(self.versions, self.labels)
        self.assertTrue(controls["all_passed"])
        self.assertEqual(controls["final_versions_perturbed"], 168)
        self.assertEqual(controls["future_labels_perturbed"], 464)
        self.assertAlmostEqual(controls["observed_delta_kg"], controls["estimated_slope_times_10_kg"], places=8)
        with tempfile.TemporaryDirectory(prefix=".test-exercise-", dir=Path(__file__).resolve().parents[1]) as folder:
            report = run_exercise(Path(folder))
            self.assertTrue(report["all_passed"])
            self.assertTrue(report["original_data_unchanged"])
            self.assertEqual(report["changed_data_rows"]["final_features"], 168)
            self.assertEqual(report["changed_data_rows"]["future_labels"], 464)
            self.assertEqual(report["changed_data_rows"]["known_plan"], 1)
            self.assertEqual((Path(folder) / "baseline" / "predictions.csv").read_bytes(),
                             (Path(folder) / "final_features" / "predictions.csv").read_bytes())

    def test_metrics_sign_and_zero_denominator(self):
        r = metrics([{"prediction_kg": 12, "actual_kg": 10}, {"prediction_kg": 6, "actual_kg": 8}])
        self.assertEqual(r["mae_kg"], 2)
        self.assertEqual(r["bias_actual_minus_pred_kg"], 0)
        self.assertEqual(r["rmse_kg"], 2)
        self.assertEqual(metrics([{"prediction_kg": 8, "actual_kg": 10}])["bias_actual_minus_pred_kg"], 2)
        self.assertAlmostEqual(r["wape_pct"], 100 * 4 / 18, places=5)
        self.assertIsNone(metrics([{"prediction_kg": 1, "actual_kg": 0}])["wape_pct"])

    def test_residual_sign_and_extrapolation_retained(self):
        self.assertTrue(all(abs(r["residual_actual_minus_pred_kg"] + r["error_pred_minus_actual_kg"]) < 1e-12
                            for r in self.scored))
        for model in MODEL_COLUMNS:
            rows = [r for r in self.scored if r["model"] == model]
            self.assertEqual(sum(bool(r["extrapolation_features"]) for r in rows), 16)
            self.assertEqual(sum(r["negative_clipped"] for r in rows), 0)


class ClothingTests(unittest.TestCase):
    def test_stated_examples_and_units(self):
        self.assertEqual(quantity("T恤", .20), 46)
        self.assertEqual(quantity("外套", .20), 68)
        self.assertEqual(quantity("外套", .30), 72)
        self.assertEqual(quantity("T恤", .15), 44.5)  # 数量预测不强行取整。
        self.assertEqual(len(examples()["excluded_targets"]), 5)

    def test_unknown_category_or_wrong_discount_rejected(self):
        with self.assertRaises(DataError):
            quantity("新类别", .2)
        with self.assertRaises(DataError):
            quantity("T恤", 20)
        with self.assertRaises(DataError):
            quantity("外套", -.1)


if __name__ == "__main__":
    unittest.main()
