"""可直接运行的时间泄漏反事实检查；不仅检查时间戳文字。"""
from copy import deepcopy
from .core import FREEZE, TEST_START, asof_features, dt, make_predictions, train_models


def compare_temporal_controls(versions, labels) -> dict:
    models, _ = train_models(versions, labels)
    predictions = make_predictions(versions, labels, models)
    # 所有事后最终特征翻转，即使历史标签已经成熟，也不可替换原点的计划。
    changed = deepcopy(versions)
    for row in changed:
        if row["stage"] == "final":
            row["booking"] += 777
            row["promo"] = 1 - row["promo"]
    models_final, _ = train_models(changed, labels)
    predictions_final = make_predictions(changed, labels, models_final)
    final_invariant = models == models_final and predictions == predictions_final

    # 在第一个评估原点仍不可见的标签被改写，原点前可读基线/训练均不应受影响。
    changed_labels = deepcopy(labels)
    future_changed_count = 0
    for row in changed_labels:
        if dt(row["label_known_at"]) > FREEZE:
            row["net_usage_kg"] += 999
            future_changed_count += 1
    future_models, _ = train_models(versions, changed_labels)
    future_predictions = make_predictions(versions, changed_labels, future_models)
    at_first_origin = lambda rows: [r for r in rows if dt(r["forecast_origin"]) <= FREEZE]
    labels_invariant = models == future_models and at_first_origin(predictions) == at_first_origin(future_predictions)

    # 未来计划版本同样不能改变已经发出的第一批预测。
    future_versions = deepcopy(versions)
    for row in future_versions:
        if dt(row["known_at"]) > FREEZE:
            row["booking"] += 333
    future_version_models, _ = train_models(future_versions, labels)
    future_version_predictions = make_predictions(future_versions, labels, future_version_models)
    future_versions_invariant = models == future_version_models and at_first_origin(predictions) == at_first_origin(future_version_predictions)

    # 反向控制：只改截止前可见计划；一元模型应按估计斜率乘10确实变化。
    known_changed = deepcopy(versions)
    target = TEST_START.isoformat()
    for row in known_changed:
        if row["target_date"] == target and row["store"] == "A" and row["stage"] == "plan":
            row["booking"] += 10
    changed_predictions = make_predictions(known_changed, labels, models)
    selected = lambda rows: next(r for r in rows if r["target_date"] == target and r["store"] == "A"
                                 and r["sku"] == "SKU01" and r["model"] == "univariate")
    before, after = selected(predictions), selected(changed_predictions)
    observed_delta = after["prediction_kg"] - before["prediction_kg"]
    expected_delta = models[("SKU01", "univariate")].coefficients[1] * 10
    positive_control = abs(observed_delta - expected_delta) < 2e-9 and abs(observed_delta) > 1e-6
    result = {
        "final_versions_perturbed": sum(r["stage"] == "final" for r in versions),
        "all_late_final_features_leave_all_predictions_unchanged": final_invariant,
        "future_labels_perturbed": future_changed_count,
        "future_labels_leave_first_origin_predictions_and_frozen_models_unchanged": labels_invariant,
        "future_feature_versions_leave_first_origin_predictions_and_frozen_models_unchanged": future_versions_invariant,
        "known_plan_booking_delta": 10,
        "known_plan_changes_first_univariate_prediction": positive_control,
        "before_kg": before["prediction_kg"], "after_kg": after["prediction_kg"],
        "observed_delta_kg": round(observed_delta, 9), "estimated_slope_times_10_kg": round(expected_delta, 9),
        "scope_note": "未来标签变更仅要求不改变此前已发预测。之后标签成熟，可合法影响之后的上周同日基线。",
    }
    result["all_passed"] = all((final_invariant, labels_invariant, future_versions_invariant, positive_control))
    if not result["all_passed"]:
        raise AssertionError(result)
    return result
