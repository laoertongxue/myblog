"""数据生成、时点取数、QR 最小二乘及冻结模型评估，Python 3.10+。"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from statistics import mean

TZ = timezone(timedelta(hours=8))
START = date(2026, 1, 5)
N_DAYS = 84
FREEZE = datetime(2026, 3, 1, 18, tzinfo=TZ)
TEST_START = date(2026, 3, 2)
END = START + timedelta(days=N_DAYS - 1)
SEED = 20261110
STORES = ("A", "B")
# a, booking, weekend, promo, store_B, promo*store_B, noise_scale
PARAMETERS = {
    "SKU01": ("鸡腿肉", (2.9, .17, 1.4, 2.3, 1.2, 1.6, .9)),
    "SKU02": ("大米", (7.5, .21, 2.0, 1.0, 2.0, .8, 1.1)),
    "SKU03": ("小麦粉", (3.0, .10, .8, 2.2, 1.8, 1.2, .8)),
    "SKU04": ("食用油", (2.0, .075, 1.8, .7, .8, .5, 1.0)),
    "SKU05": ("鸡蛋液", (5.0, .12, 1.2, 1.1, .5, -.5, .9)),
    "SKU06": ("土豆", (4.0, .105, .6, 1.6, 1.0, 0.0, 1.0)),
    "SKU07": ("胡萝卜", (3.0, .08, 0.0, 0.0, 0.0, 0.0, 1.4)),
    "SKU08": ("白菜", (3.5, .065, .3, .2, .2, 0.0, 1.5)),
}
MODEL_COLUMNS = {
    "univariate": ("booking",),
    "multivariate": ("booking", "weekend", "promo", "store_B"),
    "interaction": ("booking", "weekend", "promo", "store_B", "promo_x_store_B"),
}
MODEL_NAMES = ("last_week", *MODEL_COLUMNS)


class DataError(ValueError):
    """不满足数据或模型合同，拒绝静默修补。"""


def stamp(day: date, hour: int, minute: int = 0) -> str:
    return datetime.combine(day, time(hour, minute), TZ).isoformat()


def dt(value: str) -> datetime:
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise DataError("时间戳必须包含时区")
    return result


def day(value: str) -> date:
    return date.fromisoformat(value)


def origin(target: str) -> datetime:
    return datetime.combine(day(target) - timedelta(days=1), time(18), TZ)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise DataError(f"拒绝写出无列定义的空表: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def generate() -> tuple[list[dict], list[dict]]:
    """未来最终量只构造 y，不提供给拟合和预测函数。"""
    rng = random.Random(SEED)
    versions, labels = [], []
    for index in range(N_DAYS):
        target = START + timedelta(days=index)
        weekend = int(target.weekday() >= 5)
        for store in STORES:
            b = int(store == "B")
            plan_booking = 105 + round(24 * math.sin(2 * math.pi * index / 14))
            plan_booking += 18 * weekend + 12 * b + rng.randint(-16, 16)
            plan_promo = int((index + 3 * b) % 9 in (0, 1))
            final_booking = plan_booking + rng.randint(-8, 8)
            if (index + b) % 17 == 4:
                final_booking += 18
            final_promo = 1 - plan_promo if (index + 2 * b) % 19 == 7 else plan_promo
            common_noise = rng.randint(-6, 6) / 10
            for stage, booking, promo, known_at in (
                ("plan", plan_booking, plan_promo, stamp(target - timedelta(days=1), 17)),
                ("final", final_booking, final_promo, stamp(target + timedelta(days=1), 9)),
            ):
                versions.append({
                    "target_date": target.isoformat(), "store": store,
                    "version_id": f"{target.isoformat()}_{store}_{stage}_v1",
                    "stage": stage, "booking": booking, "promo": promo,
                    "known_at": known_at, "simulated": 1,
                })
            for sku, (name, p) in PARAMETERS.items():
                a, booking_coef, w, promo_coef, store_coef, interaction, noise_scale = p
                independent_noise = rng.randint(-20, 20) / 10 * noise_scale
                y = (a + booking_coef * final_booking + w * weekend + promo_coef * final_promo
                     + store_coef * b + interaction * final_promo * b + common_noise + independent_noise)
                if y <= 0:
                    raise DataError("生成器产生非正数量，应检查生成机制")
                labels.append({
                    "target_date": target.isoformat(), "store": store, "sku": sku,
                    "sku_name": name, "net_usage_kg": round(y, 3),
                    "label_known_at": stamp(target + timedelta(days=1), 9),
                    "is_open": 1, "stockout": 0, "label_status": "complete",
                    "unit": "kg_net", "specification_version": "SIM-V1", "simulated": 1,
                })
    return versions, labels


def load_data(directory: Path) -> tuple[list[dict], list[dict]]:
    with (directory / "feature_versions.csv").open(encoding="utf-8-sig", newline="") as handle:
        versions = list(csv.DictReader(handle))
    with (directory / "labels.csv").open(encoding="utf-8-sig", newline="") as handle:
        labels = list(csv.DictReader(handle))
    for row in versions:
        for key in ("booking", "promo", "simulated"):
            row[key] = int(row[key])
    for row in labels:
        row["net_usage_kg"] = float(row["net_usage_kg"])
        for key in ("is_open", "stockout", "simulated"):
            row[key] = int(row[key])
    validate_data(versions, labels)
    return versions, labels


def validate_data(versions: list[dict], labels: list[dict]) -> None:
    expected_labels = {(str(START + timedelta(days=i)), s, k)
                       for i in range(N_DAYS) for s in STORES for k in PARAMETERS}
    label_keys = [(r["target_date"], r["store"], r["sku"]) for r in labels]
    if len(label_keys) != len(set(label_keys)) or set(label_keys) != expected_labels:
        raise DataError("标签日期骨架不完整或主键重复")
    expected_versions = {(str(START + timedelta(days=i)), s, v)
                         for i in range(N_DAYS) for s in STORES for v in ("plan", "final")}
    version_keys = [(r["target_date"], r["store"], r["stage"]) for r in versions]
    if len(version_keys) != len(set(version_keys)) or set(version_keys) != expected_versions:
        raise DataError("特征版本日期骨架不完整或主键重复")
    ids = [r["version_id"] for r in versions]
    if len(ids) != len(set(ids)):
        raise DataError("特征版本ID重复")
    for r in labels:
        if r["stockout"] != 0 or r["is_open"] != 1 or r["label_status"] != "complete":
            raise DataError("此主实验仅接受全营业、完整且无缺货的标签；异常情景须另行处理")
        if r["specification_version"] != "SIM-V1" or r["simulated"] != 1 or r["sku_name"] != PARAMETERS[r["sku"]][0]:
            raise DataError("SKU名称、规格版本或模拟标记不符")
        y = r["net_usage_kg"]
        if not isinstance(y, (int, float)) or not math.isfinite(y) or y < 0 or r["unit"] != "kg_net":
            raise DataError("标签缺失、非法或单位不符，不能以0替代")
        expected_known = stamp(day(r["target_date"]) + timedelta(days=1), 9)
        if r["label_known_at"] != expected_known:
            raise DataError("本实验标签可读时间必须为次日09:00")
    for r in versions:
        if r["simulated"] != 1:
            raise DataError("本包只接受标明为教学模拟的特征数据")
        if r["promo"] not in (0, 1) or not isinstance(r["booking"], int) or r["booking"] < 0:
            raise DataError("预订必须是非负整数，促销必须为0/1")
        t = day(r["target_date"])
        expected_known = stamp(t - timedelta(days=1), 17) if r["stage"] == "plan" else stamp(t + timedelta(days=1), 9)
        if r["known_at"] != expected_known:
            raise DataError("版本可读时间不符合模拟合同")


def asof_features(versions: list[dict], target: str, store: str, cutoff: datetime) -> dict:
    if store not in STORES:
        raise DataError(f"未知门店 {store}，不能静默映射到A店")
    candidates = [r for r in versions if r["target_date"] == target and r["store"] == store
                  and dt(r["known_at"]) <= cutoff]
    if not candidates:
        raise DataError(f"{target}/{store} 在 {cutoff.isoformat()} 前没有可用版本")
    result = max(candidates, key=lambda r: dt(r["known_at"]))
    latest = [r for r in candidates if r["known_at"] == result["known_at"]]
    if len(latest) != 1:
        raise DataError("最新可见版本出现同时间并列，需明确版本顺序")
    return result


def features(row: dict, model: str) -> list[float]:
    if row["store"] not in STORES:
        raise DataError("未知门店")
    if row["promo"] not in (0, 1) or row["booking"] < 0:
        raise DataError("非法特征")
    values = {
        "booking": float(row["booking"]),
        "weekend": float(day(row["target_date"]).weekday() >= 5),
        "promo": float(row["promo"]), "store_B": float(row["store"] == "B"),
        "promo_x_store_B": float(row["promo"] * (row["store"] == "B")),
    }
    return [values[name] for name in MODEL_COLUMNS[model]]


def fit_simple(x: list[float], y: list[float]) -> tuple[float, float]:
    if len(x) != len(y) or len(x) < 2 or not all(math.isfinite(v) for v in x + y):
        raise DataError("一元回归至少需要两个有效配对观测")
    xm, ym = mean(x), mean(y)
    denominator = sum((v - xm) ** 2 for v in x)
    if denominator <= 1e-18:
        raise DataError("x全相同，无法唯一估计斜率")
    slope = sum((a - xm) * (b - ym) for a, b in zip(x, y)) / denominator
    return ym - slope * xm, slope


@dataclass
class OLS:
    names: list[str]
    coefficients: list[float]
    minima: list[float]
    maxima: list[float]
    n_train: int

    def predict(self, row: list[float]) -> tuple[float, float, bool, list[str]]:
        if len(row) != len(self.names) or not all(math.isfinite(v) for v in row):
            raise DataError("预测特征维度错误或含非有限值")
        raw = self.coefficients[0] + sum(b * x for b, x in zip(self.coefficients[1:], row))
        if not math.isfinite(raw):
            raise DataError("预测结果溢出或非有限")
        outside = [name for name, x, lo, hi in zip(self.names, row, self.minima, self.maxima)
                   if x < lo - 1e-12 or x > hi + 1e-12]
        # 预先声明的简单数量约束，不把负数当采购建议；同时保留原始输出。
        return max(0.0, raw), raw, raw < 0, outside


def fit_ols(x: list[list[float]], y: list[float], names: list[str]) -> OLS:
    """带截距 OLS；训练集中心化缩放，双遍正交化QR，拒绝秩亏。非统计推断库。"""
    n, p = len(y), len(names)
    if len(x) != n or n <= p or any(len(row) != p for row in x):
        raise DataError("训练样本数须大于特征数，且X/y维度一致")
    if not all(math.isfinite(v) for row in x for v in row) or not all(math.isfinite(v) for v in y):
        raise DataError("OLS不接受缺失或非有限数值")
    centers = [mean(row[j] for row in x) for j in range(p)]
    scales = [math.sqrt(sum((row[j] - centers[j]) ** 2 for row in x) / n) for j in range(p)]
    if any(s < 1e-12 for s in scales):
        raise DataError("常数特征与截距共线，无法唯一估计参数")
    cols = [[1.0] * n] + [[(row[j] - centers[j]) / scales[j] for row in x] for j in range(p)]
    q, r = [], [[0.0] * (p + 1) for _ in range(p + 1)]
    for j, col in enumerate(cols):
        v = list(col)
        for _ in range(2):
            for i, qi in enumerate(q):
                projection = sum(a * b for a, b in zip(qi, v))
                r[i][j] += projection
                v = [a - projection * b for a, b in zip(v, qi)]
        norm = math.sqrt(sum(a * a for a in v))
        if norm < 1e-10 * math.sqrt(n):
            raise DataError("设计矩阵秩亏或近秩亏，拒绝输出任意一组系数")
        r[j][j] = norm
        q.append([a / norm for a in v])
    qty = [sum(a * b for a, b in zip(qi, y)) for qi in q]
    gamma = [0.0] * (p + 1)
    for j in reversed(range(p + 1)):
        gamma[j] = (qty[j] - sum(r[j][k] * gamma[k] for k in range(j + 1, p + 1))) / r[j][j]
    slopes = [gamma[j + 1] / scales[j] for j in range(p)]
    intercept = gamma[0] - sum(s * c for s, c in zip(slopes, centers))
    return OLS(names, [intercept, *slopes], [min(row[j] for row in x) for j in range(p)],
               [max(row[j] for row in x) for j in range(p)], n)


def train_models(versions: list[dict], labels: list[dict]) -> tuple[dict, list[dict]]:
    # 双重时间条件：标签现已可读；训练特征仍只能取各自历史预测起点的版本。
    training = [r for r in labels if dt(r["label_known_at"]) <= FREEZE]
    models, audit = {}, []
    for sku in PARAMETERS:
        rows = sorted([r for r in training if r["sku"] == sku], key=lambda r: (r["target_date"], r["store"]))
        snapshots = [asof_features(versions, r["target_date"], r["store"], origin(r["target_date"])) for r in rows]
        y = [r["net_usage_kg"] for r in rows]
        for r, snap in zip(rows, snapshots):
            audit.append({"sku": sku, "target_date": r["target_date"], "store": r["store"],
                          "historical_origin": origin(r["target_date"]).isoformat(),
                          "feature_version_id": snap["version_id"], "feature_known_at": snap["known_at"],
                          "label_known_at": r["label_known_at"], "model_frozen_at": FREEZE.isoformat(),
                          "booking": snap["booking"], "weekend": int(day(r["target_date"]).weekday() >= 5),
                          "promo": snap["promo"], "store_B": int(r["store"] == "B"),
                          "promo_x_store_B": snap["promo"] * int(r["store"] == "B"),
                          "net_usage_kg": r["net_usage_kg"]})
        for model, cols in MODEL_COLUMNS.items():
            models[(sku, model)] = fit_ols([features(snap, model) for snap in snapshots], y, list(cols))
    return models, audit


def make_predictions(versions: list[dict], labels: list[dict], models: dict) -> list[dict]:
    """只生成预测；不读取目标y。评估在另一个函数里与标签连接。"""
    lookup = {(r["target_date"], r["store"], r["sku"]): r for r in labels}
    rows = []
    for i in range((END - TEST_START).days + 1):
        target = TEST_START + timedelta(days=i)
        cutoff = origin(target.isoformat())
        for store in STORES:
            snap = asof_features(versions, target.isoformat(), store, cutoff)
            for sku in PARAMETERS:
                prior = lookup[(str(target - timedelta(days=7)), store, sku)]
                if dt(prior["label_known_at"]) > cutoff:
                    raise DataError("上周同日标签在预测时不可见")
                for model in MODEL_NAMES:
                    if model == "last_week":
                        prediction = raw = prior["net_usage_kg"]
                        clipped, outside = False, []
                        source_date, source_known = prior["target_date"], prior["label_known_at"]
                    else:
                        prediction, raw, clipped, outside = models[(sku, model)].predict(features(snap, model))
                        source_date = source_known = ""
                    rows.append({
                        "target_date": target.isoformat(), "store": store, "sku": sku, "model": model,
                        "forecast_origin": cutoff.isoformat(), "model_frozen_at": FREEZE.isoformat(),
                        "feature_version_id": snap["version_id"], "feature_known_at": snap["known_at"],
                        "booking": snap["booking"], "weekend": int(target.weekday() >= 5),
                        "promo": snap["promo"], "store_B": int(store == "B"),
                        "prediction_kg": round(prediction, 9), "raw_prediction_kg": round(raw, 9),
                        "negative_clipped": int(clipped), "extrapolation_features": "|".join(outside),
                        "baseline_source_date": source_date, "baseline_source_known_at": source_known,
                    })
    return rows


def score_rows(predictions: list[dict], labels: list[dict]) -> list[dict]:
    lookup = {(r["target_date"], r["store"], r["sku"]): r for r in labels}
    results = []
    for prediction in predictions:
        key = (prediction["target_date"], prediction["store"], prediction["sku"])
        actual = lookup[key]
        error = prediction["prediction_kg"] - actual["net_usage_kg"]
        results.append({**prediction, "actual_kg": actual["net_usage_kg"],
                        "label_known_at": actual["label_known_at"],
                        "error_pred_minus_actual_kg": round(error, 9),
                        "residual_actual_minus_pred_kg": round(-error, 9),
                        "absolute_error_kg": round(abs(error), 9)})
    return results


def metrics(rows: list[dict]) -> dict:
    if not rows:
        raise DataError("不能评估空样本")
    errors = [r["prediction_kg"] - r["actual_kg"] for r in rows]
    total = sum(r["actual_kg"] for r in rows)
    return {"n": len(rows), "mae_kg": round(mean(abs(e) for e in errors), 6),
            "rmse_kg": round(math.sqrt(mean(e * e for e in errors)), 6),
            "bias_actual_minus_pred_kg": round(-mean(errors), 6),
            "wape_pct": round(100 * sum(abs(e) for e in errors) / total, 6) if total else None,
            "actual_sum_kg": round(total, 6),
            "n_extrapolated": sum(bool(r.get("extrapolation_features", "")) for r in rows),
            "n_negative_clipped": sum(r.get("negative_clipped", 0) for r in rows)}


def metric_tables(scored: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    by_sku, overall, diagnostics = [], [], []
    for model in MODEL_NAMES:
        model_rows = [r for r in scored if r["model"] == model]
        overall.append({"model": model, **metrics(model_rows)})
        for sku in PARAMETERS:
            selected = [r for r in model_rows if r["sku"] == sku]
            by_sku.append({"sku": sku, "sku_name": PARAMETERS[sku][0], "model": model, **metrics(selected)})
            for group_field in ("store", "weekend", "promo"):
                for group_value in sorted({r[group_field] for r in selected}):
                    group = [r for r in selected if r[group_field] == group_value]
                    diagnostics.append({"sku": sku, "model": model, "group_field": group_field,
                                        "group_value": group_value, **metrics(group)})
    return by_sku, overall, diagnostics


def coefficient_rows(models: dict) -> list[dict]:
    result = []
    for (sku, model), fit in models.items():
        for term, coefficient in zip(["intercept", *fit.names], fit.coefficients):
            result.append({"sku": sku, "model": model, "term": term, "coefficient": round(coefficient, 12),
                           "unit": "kg/份" if term == "booking" else "kg",
                           "n_train": fit.n_train, "model_frozen_at": FREEZE.isoformat(),
                           "coefficient_source": "estimated_from_training_labels"})
    return result


def hand_calculation() -> dict:
    x, y = [100, 120, 140, 160], [20, 23, 27, 30]
    a, b = fit_simple(x, y)
    fitted = [a + b * v for v in x]
    residuals = [actual - pred for actual, pred in zip(y, fitted)]
    return {"data_source": "独立四点教学数据，非84天样本", "x": x, "y": y,
            "x_mean": mean(x), "y_mean": mean(y), "cross_product_sum": 340,
            "x_squared_deviation_sum": 2000, "intercept": round(a, 12), "slope": round(b, 12),
            "prediction_at_150": round(a + b * 150, 12), "fitted": [round(v, 12) for v in fitted],
            "residual_actual_minus_fit": [round(v, 12) for v in residuals],
            "sse": round(sum(v * v for v in residuals), 12),
            "train_mae": round(mean(abs(v) for v in residuals), 12),
            "hypothetical_multivariate_not_fitted": {"formula": "8+0.08*booking+2*weekend+3*promo+4*store_B",
                                                       "booking150_weekend1_promo1_storeB1": 29.0,
                                                       "plus_hypothetical_1_5_promo_store_B": 30.5}}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
