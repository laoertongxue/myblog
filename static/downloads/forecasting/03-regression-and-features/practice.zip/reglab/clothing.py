"""匿名服装：给定规则的类别/交互编码练习，绝非已拟合模型。"""
from .core import DataError


def quantity(category: str, discount: float) -> float:
    if category not in ("T恤", "外套"):
        raise DataError("未知品类；不能把新类别自动当成T恤")
    if not 0 <= discount <= 1:
        raise DataError("折扣深度须为0至1的小数，.20表示优惠20%，不是输入20或八折价格系数.8")
    coat = int(category == "外套")
    return 40 + 30 * discount + 20 * coat + 10 * discount * coat


def examples() -> dict:
    return {
        "simulated": True,
        "coefficient_source": "人为给定，仅练习代入和编码；不声称已训练或回测",
        "target": "预测起点之后、下一个自然日内新增确认的商品件数，件/日",
        "excluded_targets": ["预测时已经待发的存量", "取消事件件数", "退货事件件数", "净留存件数", "概率"],
        "feature_contract": {
            "category": "T恤为参考组；外套为1；未知品类拒绝",
            "discount": "截单前已经冻结的次日计划折扣深度，0至1，.20表示优惠20%",
            "discount_version": "保存原点前可得版本；实际执行折扣不能替换历史计划",
            "granularity": "一次预测只对应一个品类、同一计划折扣情景和一个目标日",
        },
        "formula": "yhat=40+30*d+20*I_coat+10*d*I_coat",
        "coefficient_units": "输出均为件/日；30和10是每1.0折扣深度对应的件/日系数",
        "rows": [{"category": category, "discount": discount, "coat_indicator": int(category == "外套"),
                  "discount_x_coat": discount * int(category == "外套"),
                  "prediction_pieces_per_day": quantity(category, discount)}
                 for category, discount in (("T恤", .20), ("外套", .20), ("外套", .30))],
        "boundary": "数量预测可以是非整数，不是概率；不自动转成采购、裁剪或排产指令。回归关系不自动是折扣的因果收益。",
    }
