# 数据合同与逐行可追溯说明

数据均为教学模拟；业务时区固定UTC+08:00。日期字符串是当地营业日；时间戳必须含偏移量。CSV使用UTF-8 BOM，可直接由常见电子表格读取。数值小数点为`.`，单位不写入数值单元格。

## 输入1：data/products.csv

8行，主键sku。字段：sku、sku_name、unit（固定kg_net）、specification_version（SIM-V1）、simulated（1）。

|SKU|食材|单位|
|---|---|---|
|SKU01|鸡腿肉|kg净耗用|
|SKU02|大米|kg净耗用|
|SKU03|小麦粉|kg净耗用|
|SKU04|食用油|kg净耗用|
|SKU05|鸡蛋液|kg净耗用|
|SKU06|土豆|kg净耗用|
|SKU07|胡萝卜|kg净耗用|
|SKU08|白菜|kg净耗用|

## 输入2：data/labels.csv

1,344行；联合主键`target_date,store,sku`；完整骨架2×8×84，日期2026-01-05至03-29。

|字段|类型/单位|含义与约束|
|---|---|---|
|target_date|ISO日期|净耗用发生的营业日|
|store|A/B|A参考组、B标记1；未知类别拒绝|
|sku / sku_name|文本|食品SKU与名称，不能跨SKU当同一个回归目标|
|net_usage_kg|非负有限实数/kg|目标日实际净耗用；不是最终销量、毛料、采购量或潜在未受限需求|
|label_known_at|含时区的ISO时间|固定目标日次日09:00，即系统可读且核验完成时间|
|is_open|固定1|主实验假定每天营业；0由验证器拒绝|
|stockout|固定0|主实验无缺货；1由验证器拒绝|
|label_status|固定complete|标签完整；missing等拒绝|
|unit|固定kg_net|统一净料口径|
|specification_version|SIM-V1|教学规格版本|
|simulated|固定1|不是真实营业数据|

空白不等于0。闭店、缺货是不同事件，不能仅靠一个0合并处理。若读者自行修改这些假设，必须先改任务和验证规则，不要为了跑通而丢弃标记。

## 输入3：data/feature_versions.csv

336行=84天×2店×2版本；每个店日只存一套预订/促销，再被同店8个SKU共享使用。

- 主键：`target_date,store,stage`。`version_id`也要求唯一。
- `target_date`：计划影响的目标营业日。
- `store`：A或B。
- `version_id`：可追踪版本，例如2026-03-02_A_plan_v1。
- `stage`：plan（截单前计划）或final（事后最终确认值）。
- `booking`：该店目标日套餐预订份数，非负整数。plan表示原点前已经确认的预订；final表示后来变化后的最终值。本包的生成器使用final构造y，模型禁止使用目标日final。
- `promo`：0/1。plan表示当时确认的次日促销安排，final表示最终执行状态。
- `known_at`：plan在目标日前一日17:00，final在目标日后一日09:00；这是可读时间，不只是业务发生时间。
- `simulated`：1。

预测选择：先按target_date、store找版本，再保留known_at≤forecast_origin，最后选最新版本。同一最新时间有多个版本而无排序依据时拒绝。缺少可见版本时拒绝。

**训练的双重截止点**：标签可读时间≤统一模型冻结时刻；特征可读时间≤该样本自己的历史预测起点。不是把训练时已经知道的所有历史字段都塞进去。

## 派生列

不从未来标签推导这些列。

|字段|定义|单位/范围|
|---|---|---|
|weekend|目标日是否周六/周日|0/1；只依赖日历|
|store_B|store是否B|0/1|
|promo_x_store_B|原点可读的promo×store_B|0/1|

已知字段未必适合线性，也不代表因果。本包仅检验固定候选规则。

## 输入4：data/generation_parameters.csv

8行。它列出生成器使用的截距、最终预订/周末/最终促销/B店/最终促销×B店系数与noise_scale。source始终是`simulator_only_not_fitted`。

此表是教学公开答案的一部分，不作为拟合函数的系数输入。训练输出只在`output/coefficients.csv`，source明确写`estimated_from_training_labels`。

## 输出表关系

`training_time_audit.csv`的每一行是一条可用于训练的店货日；保存历史起点、计划版本、特征值、标签值与两类可读时间。每SKU110行，总880行。

`predictions.csv`主键为`target_date,store,sku,model`，共1,792行。模型冻结后对03-02至03-29逐日重建原点输入，四候选拥有完全相同的448个店货日。

- forecast_origin：目标日前一天18:00。
- model_frozen_at：固定模拟冻结时间03-01 18:00。基线无估计系数，此列表示同一次实验配置冻结时间，不把基线说成拟合模型。
- feature_version_id / feature_known_at / booking / weekend / promo / store_B：实际取用的可见版本与特征值。基线虽留相同审计上下文，计算只使用baseline_source字段的标签。
- prediction_kg：实际评分用预测，负原始输出预先截0。
- raw_prediction_kg：未施加非负约束的模型值。
- negative_clipped：是否截0。
- extrapolation_features：超出训练逐列范围的特征名，以`|`连接；空串不代表各种外推风险均已排除。
- baseline_source_date / baseline_source_known_at：基线引用的t−7标签；回归行为空。

`scored_predictions.csv`在以上列外添加actual_kg、label_known_at、error_pred_minus_actual_kg、residual_actual_minus_pred_kg和absolute_error_kg。该连接只用于事后评分，不传回已冻结模型。

`metrics_by_sku.csv`、`metrics_overall.csv`、`residual_diagnostics.csv`的bias_actual_minus_pred_kg统一为实际−预测；正值低估，负值高估。WAPE按百分数输出，不是0至1比例。n是店货日行数，不是独立受试者数。

`frozen_models.json`保存原单位系数、特征顺序、训练范围与行数。minima/maxima仅从训练数据计算。预测时不重新归一化，也不借用评估期统计量。

## 缺货与异常如何处理

主样本不存在缺货、闭店和缺失。测试另构造并验证：缺失值拒绝；缺货行拒绝；闭店行拒绝；错误单位拒绝；重复或缺少日期拒绝。它们不覆盖主样本，也不进入主指标。

这不表示真实业务应该永远删掉缺货/闭店，而是表明当前最小实验未实现这些情况下的目标重建。缺货下的实际耗用只能说明观测发生多少，未受限需要量仍未知；不做武断补数。
