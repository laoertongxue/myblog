#!/usr/bin/env python3
"""python run.py [--out output] [--generate]；仅使用Python标准库。"""
from __future__ import annotations
import argparse
import platform
from dataclasses import asdict
from pathlib import Path
from reglab.clothing import examples
from reglab.checks import compare_temporal_controls
from reglab.core import (
    END, FREEZE, MODEL_NAMES, N_DAYS, PARAMETERS, SEED, START, TEST_START,
    coefficient_rows, generate, hand_calculation, load_data, make_predictions,
    metric_tables, score_rows, sha256, train_models, write_csv, write_json,
)

ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--generate", action="store_true", help="按公开规则重建data中的模拟CSV")
    parser.add_argument("--out", type=Path, default=ROOT / "output")
    args = parser.parse_args()
    out = args.out.resolve()
    if args.generate or not (ROOT / "data" / "labels.csv").exists():
        versions, labels = generate()
        write_csv(ROOT / "data" / "feature_versions.csv", versions)
        write_csv(ROOT / "data" / "labels.csv", labels)
        write_csv(ROOT / "data" / "products.csv", [
            {"sku": sku, "sku_name": name, "unit": "kg_net", "specification_version": "SIM-V1", "simulated": 1}
            for sku, (name, _) in PARAMETERS.items()])
        write_csv(ROOT / "data" / "generation_parameters.csv", [
            {"sku": sku, "intercept": p[0], "final_booking_coef": p[1], "weekend_coef": p[2],
             "final_promo_coef": p[3], "store_B_coef": p[4], "final_promo_x_store_B_coef": p[5],
             "noise_scale": p[6], "source": "simulator_only_not_fitted"}
            for sku, (_, p) in PARAMETERS.items()])
    versions, labels = load_data(ROOT / "data")
    models, audit = train_models(versions, labels)
    predictions = make_predictions(versions, labels, models)
    scored = score_rows(predictions, labels)
    by_sku, overall, diagnostic = metric_tables(scored)
    write_csv(out / "training_time_audit.csv", audit)
    write_csv(out / "coefficients.csv", coefficient_rows(models))
    write_csv(out / "predictions.csv", predictions)
    write_csv(out / "scored_predictions.csv", scored)
    write_csv(out / "metrics_by_sku.csv", by_sku)
    write_csv(out / "metrics_overall.csv", overall)
    write_csv(out / "residual_diagnostics.csv", diagnostic)
    write_json(out / "frozen_models.json", {f"{sku}/{model}": asdict(fit) for (sku, model), fit in models.items()})
    write_json(out / "hand_calculation.json", hand_calculation())
    write_json(out / "clothing_given_rule.json", examples())
    write_csv(out / "clothing_encoding.csv", examples()["rows"])
    controls = compare_temporal_controls(versions, labels)
    write_json(out / "leakage_controls.json", controls)
    manifest = {
        "experiment": "禾味84天教学模拟v1，不是前篇14天或教程180天数据",
        "python": platform.python_version(), "dependencies": "Python 3.10+ standard library only",
        "seed": SEED, "date_start": START.isoformat(), "date_end": END.isoformat(),
        "timezone": "+08:00 (北京时间)", "days": N_DAYS, "stores": 2, "skus": 8,
        "label_rows": len(labels), "feature_version_rows": len(versions),
        "simulated_model_freeze": FREEZE.isoformat(),
        "training_target_dates": ["2026-01-05", "2026-02-28"],
        "training_rows_per_sku": 110, "excluded_current_target_date": "2026-03-01",
        "evaluation_target_dates": [TEST_START.isoformat(), END.isoformat()],
        "evaluation_rows_per_sku_per_model": 56, "evaluation_rows_per_model": 448,
        "prediction_rows": len(predictions), "models": list(MODEL_NAMES),
        "coefficient_fit": "center/scale using training only; twice-reorthogonalized QR; back-transform",
        "evaluation_type": "固定系数、逐日原点取输入的时间顺序比较；不称独立盲测、无数据驱动调参或胜者部署",
        "freeze_note": "冻结时刻是模拟业务时点，不是声称代码在该历史日期实际运行。",
        "rules": {"unknown_category": "reject", "constant_column": "reject", "rank_deficiency": "reject",
                  "negative_prediction": "clip to0, retain raw and flag", "extrapolation": "allow with feature-range flag, not production approval"},
        "data_sha256": {p.name: sha256(p) for p in sorted((ROOT / "data").glob("*.csv"))},
        "source_sha256": {str(p.relative_to(ROOT)): sha256(p) for p in sorted(ROOT.rglob("*.py"))},
        "all_temporal_controls_passed": controls["all_passed"],
    }
    write_json(out / "experiment_manifest.json", manifest)
    summary = [
        "# 运行结果（完全模拟）", "", f"Python {platform.python_version()}，仅标准库。",
        "共1,344条标签；336条特征版本；24个OLS模型；1,792条逐行评估预测。",
        "训练：01-05至02-28；03-01 18:00冻结；评估目标：03-02至03-29。",
        "这是公开生成机制下的时间顺序比较，不是独立盲测，不代表真实业务收益。", "",
        "|模型|n|MAE kg|RMSE kg|偏差(实际−预测) kg|WAPE %|外推行数|",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for r in overall:
        summary.append(f'|{r["model"]}|{r["n"]}|{r["mae_kg"]:.4f}|{r["rmse_kg"]:.4f}|{r["bias_actual_minus_pred_kg"]:.4f}|{r["wape_pct"]:.4f}|{r["n_extrapolated"]}|')
    summary += ["", "MAE和偏差是店货日平均值，不是每天全公司总量误差。WAPE按实际kg加权，不能代表所有SKU同等重要。",
                "残差定义为实际−预测；指标偏差同样定义为实际−预测，正值表示低估。样本共享日期/门店，不假装相互独立，不做显著性或因果推断。",
                "", "时间扰动检查全部通过。已知计划预订加10份时，SKU01一元预测变化为 "
                f'{controls["observed_delta_kg"]:.9f} kg，与训练估计斜率×10一致。',
                "", "单元测试另运行：python -m unittest discover -s tests -v。"]
    (out / "results_summary.md").write_text("\n".join(summary) + "\n", encoding="utf-8")
    print("\n".join(summary))


if __name__ == "__main__":
    main()
