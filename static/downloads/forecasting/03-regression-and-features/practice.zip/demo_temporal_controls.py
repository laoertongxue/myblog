#!/usr/bin/env python3
"""把时间扰动真的写入exercise/副本，再从磁盘读回训练/预测。不会改data/。"""
from __future__ import annotations
import argparse
from copy import deepcopy
from pathlib import Path
import shutil
from reglab.core import (
    FREEZE, TEST_START, coefficient_rows, dt, load_data, make_predictions,
    sha256, train_models, write_csv, write_json,
)

ROOT = Path(__file__).resolve().parent
SCENARIOS = ("baseline", "final_features", "future_labels", "future_features", "known_plan")


def run_exercise(destination: Path) -> dict:
    destination = destination.resolve()
    original_hashes = {p.name: sha256(p) for p in sorted((ROOT / "data").glob("*.csv"))}
    base_versions, base_labels = load_data(ROOT / "data")
    worlds, changes, evidence = {}, [], []
    for scenario in SCENARIOS:
        folder = destination / scenario
        folder.mkdir(parents=True, exist_ok=True)
        versions, labels = deepcopy(base_versions), deepcopy(base_labels)
        # 副本各自携带完整四张输入表，方便读者单独检查。
        for source in sorted((ROOT / "data").glob("*.csv")):
            shutil.copyfile(source, folder / source.name)
        scenario_changes = []

        def change(table, row, key, value):
            before = row[key]
            row[key] = value
            scenario_changes.append({
                "scenario": scenario, "file": table,
                "target_date": row["target_date"], "store": row["store"],
                "sku_or_stage": row.get("sku", row.get("stage", "")),
                "field": key, "before": before, "after": value,
            })

        if scenario == "final_features":
            for row in versions:
                if row["stage"] == "final":
                    change("feature_versions.csv", row, "booking", row["booking"] + 777)
                    change("feature_versions.csv", row, "promo", 1 - row["promo"])
        elif scenario == "future_labels":
            for row in labels:
                if dt(row["label_known_at"]) > FREEZE:
                    change("labels.csv", row, "net_usage_kg", row["net_usage_kg"] + 999)
        elif scenario == "future_features":
            for row in versions:
                if dt(row["known_at"]) > FREEZE:
                    change("feature_versions.csv", row, "booking", row["booking"] + 333)
        elif scenario == "known_plan":
            for row in versions:
                if row["target_date"] == TEST_START.isoformat() and row["store"] == "A" and row["stage"] == "plan":
                    change("feature_versions.csv", row, "booking", row["booking"] + 10)
        write_csv(folder / "feature_versions.csv", versions)
        write_csv(folder / "labels.csv", labels)
        if scenario_changes:
            write_csv(folder / "changes.csv", scenario_changes)
        changes.extend(scenario_changes)

        # 关键：删除用于修改的内存对象，再从该副本路径读入。读取器验证完整合同。
        del versions, labels
        disk_versions, disk_labels = load_data(folder)
        models, _ = train_models(disk_versions, disk_labels)
        predictions = make_predictions(disk_versions, disk_labels, models)
        write_csv(folder / "coefficients.csv", coefficient_rows(models))
        write_csv(folder / "predictions.csv", predictions)
        worlds[scenario] = (models, predictions)
        for file in sorted(folder.glob("*.csv")):
            evidence.append({
                "scenario": scenario, "path_relative_to_exercise": str(file.relative_to(destination)),
                "sha256": sha256(file), "bytes": file.stat().st_size,
                "changed_field_cells": sum(r["file"] == file.name for r in scenario_changes),
                "is_input_table_copy": int(file.name in original_hashes),
                "original_data_sha256": original_hashes.get(file.name, ""),
            })
    models, predictions = worlds["baseline"]
    before_first = lambda rows: [r for r in rows if dt(r["forecast_origin"]) <= FREEZE]
    select = lambda rows: next(r for r in rows if r["target_date"] == TEST_START.isoformat()
                              and r["store"] == "A" and r["sku"] == "SKU01" and r["model"] == "univariate")
    all_final_same = worlds["final_features"][0] == models and worlds["final_features"][1] == predictions
    future_labels_same = worlds["future_labels"][0] == models and before_first(worlds["future_labels"][1]) == before_first(predictions)
    future_features_same = worlds["future_features"][0] == models and before_first(worlds["future_features"][1]) == before_first(predictions)
    first_before, first_after = select(predictions), select(worlds["known_plan"][1])
    observed = first_after["prediction_kg"] - first_before["prediction_kg"]
    expected = models[("SKU01", "univariate")].coefficients[1] * 10
    known_plan_effect = abs(observed - expected) < 2e-9 and abs(observed) > 1e-6
    control_rows = [
        {"scenario": "final_features", "scope": "all 1792 predictions and all 24 frozen OLS models unchanged", "passed": all_final_same},
        {"scenario": "future_labels", "scope": "first-origin 64 predictions and frozen models unchanged", "passed": future_labels_same},
        {"scenario": "future_features", "scope": "first-origin 64 predictions and frozen models unchanged", "passed": future_features_same},
        {"scenario": "known_plan", "scope": "SKU01/A first univariate delta equals estimated slope times10", "passed": known_plan_effect},
    ]
    final_hashes = {p.name: sha256(p) for p in sorted((ROOT / "data").glob("*.csv"))}
    unchanged_inputs = final_hashes == original_hashes
    report = {
        "exercise": "写入CSV副本、从副本读回后的时间泄漏控制",
        "original_data_unchanged": unchanged_inputs,
        "original_data_sha256_before": original_hashes,
        "original_data_sha256_after": final_hashes,
        "scenarios": list(SCENARIOS),
        "changed_field_cells": {s: sum(r["scenario"] == s for r in changes) for s in SCENARIOS},
        "changed_data_rows": {s: len({(r["file"], r["target_date"], r["store"], r["sku_or_stage"])
                                      for r in changes if r["scenario"] == s}) for s in SCENARIOS},
        "controls": control_rows,
        "known_plan_example": {"before_kg": first_before["prediction_kg"], "after_kg": first_after["prediction_kg"],
                               "observed_delta_kg": round(observed, 9), "expected_delta_kg": round(expected, 9)},
        "all_passed": unchanged_inputs and all(r["passed"] for r in control_rows),
        "scope_note": "未来标签后来成熟，可以改变之后的基线；只要求此前已发预测不变。副本生成参数保留原版用于溯源，扰动副本不再声称遵循原随机生成机制。",
    }
    write_csv(destination / "all_changes.csv", changes)
    write_csv(destination / "file_evidence.csv", evidence)
    write_csv(destination / "control_results.csv", control_rows)
    write_json(destination / "exercise_report.json", report)
    if not report["all_passed"]:
        raise AssertionError("文件化时间控制失败，检查exercise_report.json")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "exercise",
                        help="输出目录。重复运行会覆盖该目录中的同名副本/报告，不会改data/")
    args = parser.parse_args()
    destination = args.out.resolve()
    # 防止误把练习目录指定成原始输入目录。
    if destination == (ROOT / "data").resolve() or (ROOT / "data").resolve() in destination.parents:
        raise ValueError("练习输出不能放在原始data目录内")
    report = run_exercise(destination)
    print(f"全部通过；原始data/未改动。练习副本目录：{destination}")
    for name in ("exercise_report.json", "all_changes.csv", "file_evidence.csv", "control_results.csv"):
        path = destination / name
        print(f"{path}\n  sha256={sha256(path)}")
    print("每个情景的具体CSV路径、SHA256与变化单元格数见file_evidence.csv；逐字段前后值见all_changes.csv。")
    print("已知计划反向控制：", report["known_plan_example"])


if __name__ == "__main__":
    main()
