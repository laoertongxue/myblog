#!/usr/bin/env python3
"""一键验收：真实运行、非零测试、第二次运行逐字节一致。只使用标准库。"""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def main():
    subprocess.run([sys.executable, str(ROOT / "run.py")], cwd=ROOT, check=True)
    out = ROOT / "output"
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    expected_count = suite.countTestCases()
    if expected_count < 24:
        raise RuntimeError(f"应至少发现24项测试，实际{expected_count}项；不能接受零测试通过")
    with (out / "test_results.txt").open("w", encoding="utf-8") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    if not result.wasSuccessful() or result.testsRun != expected_count or result.testsRun == 0:
        raise RuntimeError("测试未通过或执行数量不符，详见output/test_results.txt")
    with tempfile.TemporaryDirectory(prefix=".verify-", dir=ROOT) as folder:
        temporary = Path(folder)
        subprocess.run([sys.executable, str(ROOT / "run.py"), "--out", str(temporary)],
                       cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
        files = sorted(p.name for p in temporary.iterdir() if p.is_file())
        different = [name for name in files if not (out / name).exists()
                     or (out / name).read_bytes() != (temporary / name).read_bytes()]
        if different:
            raise RuntimeError(f"重复运行输出不一致：{different}")
    report = {
        "python": sys.version.split()[0], "tests_discovered": expected_count,
        "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "all_tests_passed": True, "repeated_run_files_compared": len(files),
        "repeated_run_byte_identical": True, "files_compared": files,
        "shipped_data_matches_generator": "verified by test_shipped_csv_reproduces_generator",
    }
    (out / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"验证通过：{result.testsRun}项实际测试，{len(files)}个文件重复运行逐字节一致。")


if __name__ == "__main__":
    main()
