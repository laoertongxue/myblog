"""Deterministic, standard-library-only teaching fixtures. Python 3.10+."""
import csv
import json
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = date(2026, 11, 2)
ZONE = timezone(timedelta(hours=8))  # Asia/Shanghai in November 2026; no tzdata dependency.
CUTOFF = '2026-11-08T18:00:00+08:00'
SERIES = [20,22,21,23,30,34,28,22,24,23,25,32,36,30]
NAMES = ['鸡腿肉','大米','小麦粉','食用油','鸡蛋液','土豆','胡萝卜','白菜']


def stamp(value):
    result = datetime.fromisoformat(value)
    if result.utcoffset() is None:
        raise ValueError('Timestamp must have an explicit timezone offset')
    return result


def products():
    return [dict(sku_id=f'SKU{i:02}', sku_name=name, unit='kg',
                 specification_version='SIM-V1') for i, name in enumerate(NAMES, 1)]


def main_rows():
    rows = []
    for d, value in enumerate(SERIES):
        day = START + timedelta(days=d)
        for store in ['A', 'B']:
            for sku in range(1, 9):
                # Other series are only a reproducible date-key scaffold, not analytical evidence.
                used = value if store == 'A' and sku == 1 else 5 + ((d * 3 + sku * 2 + (store == 'B') * 5) % 19)
                known = datetime.combine(day + timedelta(days=1), datetime.min.time(), ZONE).replace(hour=10)
                if store == 'A' and sku == 1 and day == date(2026,11,8):
                    known = datetime(2026,11,8,23,tzinfo=ZONE)
                rows.append(dict(business_date=day.isoformat(), weekday_iso=day.isoweekday(),
                                 store_id=store, sku_id=f'SKU{sku:02}', used_kg=used, unit='kg',
                                 is_open=1, stockout_flag=0, known_at=known.isoformat()))
    return rows


def anomalies():
    return [dict(case_id=case, business_date='2026-11-09', store_id='A', sku_id='SKU01',
                 used_kg=used, unit='kg', is_open=is_open, stockout_flag=stockout, reason=reason)
            for case, used, is_open, stockout, reason in [
                ('true_zero',0,1,0,'正常营业且完整记录，实际净耗用为零'),
                ('closed_zero',0,0,0,'闭店实际耗用为零，保留闭店标记'),
                ('missing',None,1,0,'接口缺失，未知值，不填零'),
                ('stockout',2,1,1,'缺货下仅观测到2kg，不代表潜在需求')]]


def availability():
    data = [
        ('2026-11-07','used_kg',34,'kg','2026-11-08T10:00:00+08:00'),
        ('2026-11-08','used_kg',28,'kg','2026-11-08T23:00:00+08:00'),
        ('2026-11-09','reservations',100,'份','2026-11-08T17:30:00+08:00'),
        ('2026-11-09','reservations',120,'份','2026-11-08T18:30:00+08:00'),
        ('2026-11-09','actual_temperature_c',18,'摄氏度','2026-11-09T23:00:00+08:00'),
        ('2026-11-09','forecast_temperature_c',19,'摄氏度','2026-11-08T17:00:00+08:00')]
    return [dict(business_date=day,store_id='A',sku_id='SKU01',field=field,value=value,
                 unit=unit,known_at=known) for day,field,value,unit,known in data]


def asof(rows, cutoff):
    """Filter before selecting latest version per entity/date/field; ties are rejected."""
    latest, seen = {}, set()
    for row in rows:
        known = stamp(row['known_at'])
        if known > stamp(cutoff):
            continue
        key = tuple(row[k] for k in ('business_date','store_id','sku_id','field'))
        version_key = (key,known)
        if version_key in seen:
            raise ValueError('Ambiguous duplicate field version')
        seen.add(version_key)
        if key not in latest or known > stamp(latest[key]['known_at']):
            latest[key] = dict(row)
    return [latest[key] for key in sorted(latest)]


def order_events():
    # Unit IDs make pre-shipment cancellation constraints testable, not merely aggregate claims.
    return [dict(event_id='SIM-E01',order_id='SIM-ORDER-001',sku_id='S01-M',event_type='confirm',
                 occurred_at='2026-11-02T09:00:00+08:00',unit_ids=list(range(1,101))),
            dict(event_id='SIM-E02',order_id='SIM-ORDER-001',sku_id='S01-M',event_type='cancel_before_shipment',
                 occurred_at='2026-11-03T09:00:00+08:00',unit_ids=list(range(1,11))),
            dict(event_id='SIM-E03',order_id='SIM-ORDER-001',sku_id='S01-M',event_type='ship',
                 occurred_at='2026-11-04T09:00:00+08:00',unit_ids=list(range(11,71))),
            dict(event_id='SIM-E04',order_id='SIM-ORDER-001',sku_id='S01-M',event_type='return_reported',
                 occurred_at='2026-11-06T09:00:00+08:00',unit_ids=[11,12,13])]


def reconcile(events):
    states, returned, event_ids = {}, set(), set()
    identities = {(event.get('order_id'), event.get('sku_id')) for event in events}
    if len(identities) != 1 or any(not order or not sku for order, sku in identities):
        raise ValueError('This single-order example requires one consistent order ID and SKU')
    for event in sorted(events, key=lambda x: (stamp(x['occurred_at']), x['event_id'])):
        if event['event_id'] in event_ids:
            raise ValueError('Duplicate event ID')
        event_ids.add(event['event_id'])
        ids = event['unit_ids']
        if len(ids) != len(set(ids)) or not ids:
            raise ValueError('Invalid event units')
        for unit in ids:
            key = (event['order_id'], unit)
            current = states.get(key)
            kind = event['event_type']
            if kind == 'confirm' and current is None:
                states[key] = 'pending'
            elif kind == 'cancel_before_shipment' and current == 'pending':
                states[key] = 'cancelled'
            elif kind == 'ship' and current == 'pending':
                states[key] = 'shipped'
            elif kind == 'return_reported' and current == 'shipped' and key not in returned:
                returned.add(key)
            else:
                raise ValueError(f'Invalid transition: {kind}, previous={current}')
    result = dict(confirmed_units=len(states), cancelled_before_shipment_units=list(states.values()).count('cancelled'),
                  shipped_units=list(states.values()).count('shipped'), pending_shipment_units=list(states.values()).count('pending'),
                  reported_return_units=len(returned), returned_stock_available_units=None)
    if result['confirmed_units'] != sum(result[k] for k in ('cancelled_before_shipment_units','shipped_units','pending_shipment_units')):
        raise ValueError('Quantity conservation failed')
    return result


def write_json(path, data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2) + '\n', encoding='utf-8', newline='\n')


def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def build(output_dir=ROOT / 'output'):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    main, versions = main_rows(), availability()
    snapshot = asof(versions,CUTOFF)
    for name, rows in [('demand',main),('products',products()),('anomalies',anomalies()),
                       ('availability_versions',versions),('asof_snapshot',snapshot)]:
        write_csv(output_dir / (name + '.csv'),rows)
        write_json(output_dir / (name + '.json'),rows)
    events = order_events()
    totals = reconcile(events)
    write_json(output_dir / 'order_events.json',events)
    write_json(output_dir / 'order_reconciliation.json',totals)
    summary = dict(simulated=True,source='https://12lab.cn/forecast/legacy-1/',
                   timezone='Asia/Shanghai',forecast_origin=CUTOFF,
                   first_date=START.isoformat(),last_date=(START+timedelta(days=13)).isoformat(),
                   stores=2,skus=8,series_count=16,days=14,main_row_count=len(main),
                   teaching_series=dict(store_id='A',sku_id='SKU01',unit='kg',values=SERIES,
                                        total_kg=sum(SERIES),week1_total_kg=sum(SERIES[:7]),week2_total_kg=sum(SERIES[7:])),
                   corrected_date_values={'2026-11-07':34,'2026-11-08':28,'2026-11-09':22},
                   available_fields=snapshot,independent_anomaly_count=4,orders=totals,
                   temperature_definition='actual_temperature_c为2026-11-09 23:00实测气温；forecast_temperature_c为同一时刻的预报温度，两者均非日均温。',
                   caveat='完全虚构教学样本；不估计潜在真实需求，不训练模型，不声称业务收益。')
    write_json(output_dir / 'summary.json',summary)
    return summary


def main():
    build()
    print('Wrote deterministic teaching files to output/')


if __name__ == '__main__':
    main()
