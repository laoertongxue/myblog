"""Lightweight entry point for the article practice package."""
from build import main

if __name__ == "__main__":
    main()
