"""Create separate practice copies, then test future and past perturbations."""
import argparse
import copy
import json
from pathlib import Path
from build import ROOT, CUTOFF, stamp, write_json
from check_asof import snapshot_file


def run_demo(source, destination, cutoff=CUTOFF):
    source, destination = Path(source), Path(destination)
    # Never overwrite source or prior user experiments: choose a fresh directory.
    destination.mkdir(parents=True, exist_ok=False)
    original = destination / '01_original.json'
    original.write_bytes(source.read_bytes())
    rows = json.loads(original.read_text(encoding='utf-8'))
    baseline = snapshot_file(original, cutoff)
    future = copy.deepcopy(rows)
    changed = 0
    for row in future:
        if stamp(row['known_at']) > stamp(cutoff) and row['field'] in ('reservations','actual_temperature_c'):
            row['value'] = 999
            changed += 1
    if changed != 2:
        raise ValueError('Expected two future reservation/actual-temperature records')
    future_path = destination / '02_future_999.json'
    write_json(future_path, future)
    future_snapshot = snapshot_file(future_path, cutoff)
    past = copy.deepcopy(future)
    eligible = [r for r in past if r['field']=='reservations' and stamp(r['known_at']) <= stamp(cutoff)]
    if not eligible:
        raise ValueError('No known reservation version to perturb')
    latest = max(eligible, key=lambda r: stamp(r['known_at']))
    if latest['value'] != 100:
        raise ValueError('Expected the original known reservation value to be 100')
    latest['value'] = 101
    past_path = destination / '03_known_reservation_101.json'
    write_json(past_path, past)
    past_snapshot = snapshot_file(past_path, cutoff)
    checks = dict(future_changes_leave_snapshot_unchanged=baseline == future_snapshot,
                  known_change_alters_snapshot=baseline != past_snapshot)
    if not all(checks.values()):
        raise AssertionError(checks)
    report = dict(cutoff=cutoff, original_snapshot=baseline, future_999_snapshot=future_snapshot,
                  known_101_snapshot=past_snapshot, checks=checks)
    write_json(destination / 'comparison.json', report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=ROOT/'output'/'availability_versions.json')
    parser.add_argument('--directory', type=Path, default=ROOT/'exercise')
    parser.add_argument('--cutoff', default=CUTOFF)
    args = parser.parse_args(argv)
    report = run_demo(args.input, args.directory, args.cutoff)
    for label in ['original_snapshot','future_999_snapshot','known_101_snapshot']:
        values = ', '.join(f"{r['business_date']} {r['field']}={r['value']}" for r in report[label])
        print(f'{label}: {values}')
    print('PASS: future 999 changes do not change the snapshot')
    print('PASS: known reservation 100 -> 101 changes the snapshot')
    print(f'Comparison and editable copies: {args.directory}')


if __name__ == '__main__':
    main()
