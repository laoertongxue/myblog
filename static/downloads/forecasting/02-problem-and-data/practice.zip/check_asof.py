"""Read an existing JSON version file without regenerating or modifying it."""
import argparse
import json
from pathlib import Path
from build import CUTOFF, asof


def snapshot_file(path, cutoff=CUTOFF):
    with Path(path).open(encoding='utf-8') as stream:
        rows = json.load(stream)
    if not isinstance(rows, list):
        raise ValueError('Expected a JSON array of version records')
    return asof(rows, cutoff)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--cutoff', default=CUTOFF)
    args = parser.parse_args(argv)
    print(json.dumps(snapshot_file(args.input, args.cutoff), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
