import copy
import csv
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path
import build as b

class TeachingDataTests(unittest.TestCase):
    def test_01_row_count(self): self.assertEqual(len(b.main_rows()),224)
    def test_02_unique_keys(self):
        self.assertEqual(len({(r['business_date'],r['store_id'],r['sku_id']) for r in b.main_rows()}),224)
    def test_03_continuous_calendar_per_series(self):
        for store in ['A','B']:
            for sku in range(1,9):
                dates=[r['business_date'] for r in b.main_rows() if r['store_id']==store and r['sku_id']==f'SKU{sku:02}']
                self.assertEqual(dates,[(b.START+timedelta(days=i)).isoformat() for i in range(14)])
    def test_04_nonnegative(self): self.assertTrue(all(r['used_kg']>=0 for r in b.main_rows()))
    def test_05_teaching_values(self): self.assertEqual([r['used_kg'] for r in b.main_rows() if r['store_id']=='A' and r['sku_id']=='SKU01'],b.SERIES)
    def test_06_weekdays(self):
        self.assertEqual(b.START.isoweekday(),1)
        for r in b.main_rows(): self.assertEqual(b.date.fromisoformat(r['business_date']).isoweekday(),r['weekday_iso'])
    def test_07_product_dictionary(self):
        self.assertEqual({r['sku_id'] for r in b.main_rows()},{r['sku_id'] for r in b.products()})
        self.assertTrue(all(r['unit']=='kg' for r in b.products()+b.main_rows()))
    def test_08_missing_not_zero(self): self.assertIsNone(next(r for r in b.anomalies() if r['case_id']=='missing')['used_kg'])
    def test_09_anomalies_not_in_main(self):
        self.assertTrue(all('case_id' not in r and r['is_open']==1 and r['stockout_flag']==0 for r in b.main_rows()))
        self.assertEqual(len(b.anomalies()),4)
    def test_10_asof_selection(self):
        snapshot=b.asof(b.availability(),b.CUTOFF)
        self.assertEqual(len(snapshot),3)
        self.assertEqual({r['field']:r['value'] for r in snapshot},{'used_kg':34,'reservations':100,'forecast_temperature_c':19})
    def test_11_future_actuals_excluded(self):
        self.assertFalse(any(r['field']=='actual_temperature_c' or (r['field']=='used_kg' and r['business_date']=='2026-11-08') for r in b.asof(b.availability(),b.CUTOFF)))
    def test_12_latest_known_version(self):
        x=b.asof(b.availability(),'2026-11-08T19:00:00+08:00')
        self.assertEqual(next(r for r in x if r['field']=='reservations')['value'],120)
    def test_13_future_perturbation_invariant(self):
        rows=copy.deepcopy(b.availability())
        for r in rows:
            if b.stamp(r['known_at'])>b.stamp(b.CUTOFF): r['value']=999999
        self.assertEqual(b.asof(rows,b.CUTOFF),b.asof(b.availability(),b.CUTOFF))
    def test_14_date_value_consistency(self):
        for r in b.availability():
            if r['field']=='used_kg':
                main=next(x for x in b.main_rows() if all(x[k]==r[k] for k in ['business_date','store_id','sku_id']))
                self.assertEqual((r['value'],r['known_at']),(main['used_kg'],main['known_at']))
    def test_15_quantity_conservation(self):
        x=b.reconcile(b.order_events())
        self.assertEqual((x['confirmed_units'],x['cancelled_before_shipment_units'],x['shipped_units'],x['pending_shipment_units']),(100,10,60,30))
    def test_16_returns_do_not_reduce_pending(self):
        before=b.reconcile(b.order_events()[:-1]); after=b.reconcile(b.order_events())
        self.assertEqual(before['pending_shipment_units'],after['pending_shipment_units'])
        self.assertEqual(after['reported_return_units'],3)
        self.assertIsNone(after['returned_stock_available_units'])
    def test_17_cannot_cancel_shipped_unit(self):
        rows=b.order_events(); rows.append(dict(event_id='BAD',order_id='SIM-ORDER-001',sku_id='S01-M',event_type='cancel_before_shipment',occurred_at='2026-11-07T09:00:00+08:00',unit_ids=[11]))
        with self.assertRaises(ValueError): b.reconcile(rows)
    def test_18_cannot_ship_cancelled_unit(self):
        rows=b.order_events(); rows[2]['unit_ids']=[1]
        with self.assertRaises(ValueError): b.reconcile(rows)
    def test_19_cannot_return_unshipped_unit(self):
        rows=b.order_events(); rows[3]['unit_ids']=[100]
        with self.assertRaises(ValueError): b.reconcile(rows)
    def test_20_duplicates_rejected(self):
        rows=b.order_events(); rows.append(copy.deepcopy(rows[0]))
        with self.assertRaises(ValueError): b.reconcile(rows)
        rows=b.availability(); rows.append(copy.deepcopy(rows[0]))
        with self.assertRaises(ValueError): b.asof(rows,b.CUTOFF)
    def test_21_byte_determinism_and_missing_csv(self):
        with tempfile.TemporaryDirectory() as directory:
            a,bpath=Path(directory)/'a',Path(directory)/'b'
            b.build(a); b.build(bpath)
            self.assertEqual({p.name:p.read_bytes() for p in a.iterdir()},{p.name:p.read_bytes() for p in bpath.iterdir()})
            self.assertTrue(all(b'\r' not in p.read_bytes() for p in a.iterdir()))
            with (a/'anomalies.csv').open(encoding='utf-8',newline='') as stream:
                rows=list(csv.DictReader(stream))
            self.assertEqual(next(r for r in rows if r['case_id']=='missing')['used_kg'],'')
    def test_22_cutoff_inclusive(self):
        rows=b.availability(); rows[2]['known_at']=b.CUTOFF
        self.assertEqual(next(r for r in b.asof(rows,b.CUTOFF) if r['field']=='reservations')['value'],100)
    def test_23_version_order_independent(self): self.assertEqual(b.asof(list(reversed(b.availability())),b.CUTOFF),b.asof(b.availability(),b.CUTOFF))
    def test_24_timezone_required(self):
        with self.assertRaises(ValueError): b.asof(b.availability(),'2026-11-08T18:00:00')

    def test_25_file_snapshot_reads_edits_without_overwrite(self):
        from check_asof import snapshot_file
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'edited.json'
            rows=b.availability(); rows[2]['value']=101
            b.write_json(path,rows); before=path.read_bytes()
            self.assertEqual(next(r['value'] for r in snapshot_file(path) if r['field']=='reservations'),101)
            self.assertEqual(path.read_bytes(),before)
    def test_26_file_cli_cutoff(self):
        import contextlib, io, json
        from check_asof import main
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'versions.json'; b.write_json(path,b.availability())
            output=io.StringIO()
            with contextlib.redirect_stdout(output):
                main(['--input',str(path),'--cutoff','2026-11-08T19:00:00+08:00'])
            self.assertEqual(next(r['value'] for r in json.loads(output.getvalue()) if r['field']=='reservations'),120)
    def test_27_file_perturbation_demo(self):
        from demo_future_perturbation import run_demo
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'source.json'; b.write_json(path,b.availability()); before=path.read_bytes()
            target=Path(directory)/'experiment'
            report=run_demo(path,target)
            self.assertTrue(all(report['checks'].values()))
            self.assertEqual(path.read_bytes(),before)
            self.assertEqual((target/'01_original.json').read_bytes(),before)
            with self.assertRaises(FileExistsError): run_demo(path,target)
    def test_28_order_and_sku_consistency(self):
        for field in ['order_id','sku_id']:
            rows=b.order_events(); rows[2][field]='OTHER'
            with self.assertRaises(ValueError): b.reconcile(rows)
        rows=b.order_events(); del rows[0]['sku_id']
        with self.assertRaises(ValueError): b.reconcile(rows)

if __name__=='__main__': unittest.main()
