"""Labels are reconstructed from event ledgers at an explicit as-of cutoff."""
from common import group_events

def labels(project, features, events, cutoff, scenario=None):
    by_id=group_events(events,cutoff,scenario)
    rows=[]
    for r in features:
        created=int(r["created_day"])
        if created>cutoff: continue
        es=by_id.get(r["entity_id"],[])
        times={e["event_type"]:int(e["event_day"]) for e in es}
        row={"entity_id":r["entity_id"],"split":r["split"],"as_of_day":cutoff,
             "observed_age":cutoff-created}
        if project=="presale":
            terminal=next((e for e in es if e["event_type"] in ("cancelled","shipped","forced_cancel")),None)
            row.update(scenario=scenario,status=terminal["event_type"] if terminal else "pending",
                       exit_age=int(terminal["event_day"])-created if terminal else "",
                       censored=int(terminal is None))
        elif project=="returns":
            mature=cutoff-created>=30
            row.update(label_mature=int(mature),
                returned=1 if "return_requested" in times else 0 if mature else "",
                restocked=1 if "restocked" in times else 0 if mature or "quality_failed" in times else "",
                status=es[-1]["event_type"] if es else "not_seen")
            for key in ("return_requested","warehouse_received","quality_passed","quality_failed","restocked"):
                row[key+"_age"]=times[key]-created if key in times else ""
        elif project=="cod":
            row.update(label_mature=int(cutoff-created>=30),
                refused=1 if "refused" in times else 0 if "delivered_paid" in times else "",
                restocked=1 if "restocked" in times else 0 if "delivered_paid" in times or "quality_failed" in times else "",
                status=es[-1]["event_type"] if es else "not_seen")
        elif project=="po":
            qty=int(r["ordered_units"]); received=0; complete_day=None
            for e in es:
                if e["event_type"]=="received":
                    received+=int(e["units"])
                    if received==qty: complete_day=int(e["event_day"])
            row.update(ordered_units=qty,received_units=received,outstanding_units=qty-received,
                       completed=int(complete_day is not None),
                       complete_age=complete_day-created if complete_day is not None else "",
                       censored=int(complete_day is None))
        else: raise ValueError(project)
        rows.append(row)
    return rows

def join_labels(features, label_rows):
    lookup={r["entity_id"]:r for r in label_rows}
    return [{**f,**lookup[f["entity_id"]]} for f in features if f["entity_id"] in lookup]

def get_split(features,name):
    return [f for f in features if f["split"]==name]
