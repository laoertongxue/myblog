"""Shared, standard-library-only utilities. All dates and quantities are synthetic."""
from __future__ import annotations
import csv
import hashlib
import json
import math
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
START = date(2025, 1, 1)
SEED = 20261106
SPECS = {
    "presale": {"n": 20000, "creation_days": 360, "cutoff": 419,
        "train": [0, 119], "fit_cutoff": 179, "validation": [180, 209],
        "validation_cutoff": 269, "test": [270, 359], "maturity": 60},
    "returns": {"n": 12000, "creation_days": 180, "cutoff": 209,
        "train": [0, 59], "fit_cutoff": 89, "validation": [90, 109],
        "validation_cutoff": 139, "test": [140, 179], "maturity": 30},
    "cod": {"n": 10000, "creation_days": 180, "cutoff": 209,
        "train": [0, 59], "fit_cutoff": 89, "validation": [90, 109],
        "validation_cutoff": 139, "test": [140, 179], "maturity": 30},
    "po": {"n": 2000, "creation_days": 360, "cutoff": 449,
        "train": [0, 89], "fit_cutoff": 179, "validation": [180, 209],
        "validation_cutoff": 299, "test": [300, 359], "maturity": None},
}

def iso(day):
    return (START + timedelta(days=int(day))).isoformat()

def split_for(project, day):
    for name in ("train", "validation", "test"):
        lo, hi = SPECS[project][name]
        if lo <= day <= hi:
            return name
    return "gap_not_used_for_model_selection"

def write_csv(path, rows, fieldnames=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    if fieldnames is None:
        if not rows:
            raise ValueError("Empty CSV needs explicit field names")
        fieldnames = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

def read_csv(path):
    with Path(path).open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def mean(values):
    values = list(values)
    return sum(values) / len(values) if values else None

def sigmoid(x):
    return 1 / (1 + math.exp(-max(-35, min(35, x))))

def quantile(values, q):
    values = sorted(values)
    return values[max(0, math.ceil(q * len(values)) - 1)] if values else None

def brier(ps, ys):
    return mean((p - y) ** 2 for p, y in zip(ps, ys))

def binary_metrics(ps, ys):
    assert len(ps) == len(ys)
    return {"n": len(ys), "observed_rate": mean(ys), "mean_probability": mean(ps),
            "brier": brier(ps, ys),
            "log_loss": mean(-(y * math.log(max(p, 1e-12)) + (1-y) * math.log(max(1-p, 1e-12)))
                             for p, y in zip(ps, ys))}

def group_events(events, cutoff, scenario=None):
    out = defaultdict(list)
    for e in events:
        if int(e["event_day"]) <= cutoff and (scenario is None or e.get("scenario") == scenario):
            out[e["entity_id"]].append(e)
    for key in out:
        out[key].sort(key=lambda x: (int(x["event_day"]), int(x["sequence"])))
    return out

def add_event(events, entity, day, event_type, qty, sequence=0, scenario="base"):
    events.append({"entity_id": entity, "scenario": scenario, "event_day": day,
                   "event_date": iso(day), "sequence": sequence,
                   "event_type": event_type, "units": qty})

def frozen_event_view(events, cutoff):
    """Explicit as-of access. Never join the whole future ledger into features."""
    return [e for e in events if int(e["event_day"]) <= cutoff]

def calibration_rows(ps, ys, bins=10):
    rows = []
    for i in range(bins):
        ix = [j for j, p in enumerate(ps) if min(bins-1, int(p*bins)) == i]
        rows.append({"bin_lower": i/bins, "bin_upper": (i+1)/bins, "n": len(ix),
                     "mean_prediction": mean(ps[j] for j in ix),
                     "observed_fraction": mean(ys[j] for j in ix)})
    return rows

def plot_svg(path, series, title, x_label, y_label, xmax=None, ymax=None):
    """Small dependency-free SVG. Series: [(label, [(x,y), ...]), ...]."""
    import html
    colors = ["#2563eb", "#dc2626", "#059669", "#7c3aed", "#d97706"]
    points = [p for _, ps in series for p in ps if p[1] is not None]
    xmax = xmax or max((p[0] for p in points), default=1) or 1
    ymax = ymax or max((p[1] for p in points), default=1) * 1.1 or 1
    def xy(p): return 70+p[0]/xmax*640, 410-p[1]/ymax*320
    chunks = ['<svg xmlns="http://www.w3.org/2000/svg" width="800" height="520" viewBox="0 0 800 520">',
              '<rect width="800" height="520" fill="white"/>',
              '<g font-family="sans-serif" font-size="13" fill="#111827">',
              f'<text x="70" y="30" font-size="18">{html.escape(title)}</text>',
              '<path d="M70 90V410H710" fill="none" stroke="#374151"/>']
    for k in range(6):
        xx = 70+640*k/5; yy = 410-320*k/5
        chunks += [f'<text x="{xx:.1f}" y="430" text-anchor="middle">{xmax*k/5:.1f}</text>',
                   f'<text x="60" y="{yy+4:.1f}" text-anchor="end">{ymax*k/5:.2f}</text>']
    for i, (label, ps) in enumerate(series):
        color = colors[i % len(colors)]
        coords = " ".join(f"{xy(p)[0]:.2f},{xy(p)[1]:.2f}" for p in ps if p[1] is not None)
        chunks += [f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="2"/>',
                   f'<text x="{70+(i%3)*230}" y="{465+(i//3)*22}" fill="{color}">{html.escape(label)}</text>']
    chunks += [f'<text x="390" y="450" text-anchor="middle">{html.escape(x_label)}</text>',
               f'<text x="10" y="65">{html.escape(y_label)}</text>', '</g></svg>']
    Path(path).write_text("\n".join(chunks), encoding="utf-8")
