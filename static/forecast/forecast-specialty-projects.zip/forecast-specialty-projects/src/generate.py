"""Generate four explicitly synthetic datasets; no external data or network calls."""
from __future__ import annotations
import random
from collections import Counter
from common import ROOT, SEED, SPECS, iso, split_for, add_event, write_csv, write_json, sha256, sigmoid

def base_row(project, i, day, prefix):
    return {"entity_id": f"{prefix}{i:06d}", "created_day": day, "created_date": iso(day),
            "feature_available_day": day, "score_day": day,
            "feature_available_at":iso(day)+"T08:00:00Z", "score_at":iso(day)+"T09:00:00Z",
            "split": split_for(project, day), "synthetic": 1}

def generate_presale(rng):
    spec = SPECS["presale"]; features=[]; events=[]; oracle=[]
    for i in range(spec["n"]):
        day = rng.randrange(spec["creation_days"]); sku=rng.randrange(20)
        units=rng.randint(1,3); frailty=0.45 if rng.random()<0.65 else 2.2
        row=base_row("presale", i, day, "PRE")
        row.update(sku=f"SKU{sku:02d}", campaign=f"C{rng.randrange(4)}", units=units,
                   listed_price=99+sku*5, promised_ship_days=45)
        features.append(row)
        natural=999
        for age in range(1, 60):
            base=(0.05 if age==1 else 0.015 if age<=7 else 0.006)
            hazard=min(0.6, base*(0.7+sku/25)*frailty)
            if rng.random()<hazard:
                natural=age; break
        independent_ship=rng.randint(3,80)
        informative_ship=max(1, round(independent_ship/(1+2.5*max(0, frailty-0.45))))
        for scenario, ship_age in (("independent",independent_ship),("informative",informative_ship)):
            age=min(natural,ship_age,60)
            event_type="cancelled" if natural==age else "forced_cancel" if age==60 else "shipped"
            add_event(events,row["entity_id"],day,"created",units,0,scenario)
            if day+age<=spec["cutoff"]:
                add_event(events,row["entity_id"],day+age,event_type,units,1,scenario)
            oracle.append({"entity_id":row["entity_id"],"scenario":scenario,
                "latent_natural_cancel_age":natural if natural<999 else "",
                "latent_frailty":frailty,"latent_ship_age":ship_age,
                "notice":"SIMULATION_ORACLE_NEVER_A_MODEL_FEATURE"})
    return features,events,oracle

def generate_returns(rng):
    spec=SPECS["returns"]; features=[]; events=[]; oracle=[]
    for i in range(spec["n"]):
        day=rng.randrange(180); category=rng.randrange(4); route=rng.randrange(3)
        row=base_row("returns",i,day,"RET")
        row.update(category=f"CAT{category}",route=f"R{route}",units=1,listed_price=80+40*category)
        features.append(row)
        add_event(events,row["entity_id"],day,"shipped",1,0)
        delivered=day+rng.randint(1,4)
        add_event(events,row["entity_id"],delivered,"delivered",1,1)
        p=[0.08,0.15,0.24,0.32][category]
        returned=rng.random()<p
        if returned:
            requested=delivered+rng.randint(1,15)
            received=requested+rng.randint(1,6)
            qc=received+rng.randint(1,3)
            good=rng.random()<[0.92,0.85,0.76,0.65][category]
            add_event(events,row["entity_id"],requested,"return_requested",1,2)
            add_event(events,row["entity_id"],received,"warehouse_received",1,3)
            add_event(events,row["entity_id"],qc,"quality_passed" if good else "quality_failed",1,4)
            if good: add_event(events,row["entity_id"],qc+1,"restocked",1,5)
        oracle.append({"entity_id":row["entity_id"],"true_return_probability":p,
                       "notice":"SIMULATION_ORACLE_NEVER_A_MODEL_FEATURE"})
    return features,[e for e in events if e["event_day"]<=spec["cutoff"]],oracle

def generate_cod(rng):
    spec=SPECS["cod"]; features=[]; events=[]; oracle=[]
    for i in range(spec["n"]):
        day=rng.randrange(180); route=rng.randrange(3); units=rng.randint(1,4)
        distance=rng.randint(5,250); promised=2+route*2+rng.randrange(3)
        row=base_row("cod",i,day,"COD")
        row.update(route=f"R{route}",distance_km=distance,units=units,
                   cod_amount_yuan=79*units,planned_delivery_days=promised)
        features.append(row)
        # A synthetic post-day-140 risk drift is intentional, not a business claim.
        p=sigmoid(-3.5+0.006*distance+0.23*units+0.27*route+(0.25 if day>=140 else 0))
        refused=rng.random()<p
        ship=day+1; terminal=ship+rng.randint(2,12)
        add_event(events,row["entity_id"],day,"created",units,0)
        add_event(events,row["entity_id"],ship,"shipped",units,1)
        add_event(events,row["entity_id"],terminal,"refused" if refused else "delivered_paid",units,2)
        if refused:
            received=terminal+rng.randint(2,7); qc=received+rng.randint(1,3)
            good=rng.random()<0.88
            add_event(events,row["entity_id"],received,"warehouse_received",units,3)
            add_event(events,row["entity_id"],qc,"quality_passed" if good else "quality_failed",units,4)
            if good: add_event(events,row["entity_id"],qc+1,"restocked",units,5)
        oracle.append({"entity_id":row["entity_id"],"true_refusal_probability":p,
                       "notice":"SIMULATION_ORACLE_NEVER_A_MODEL_FEATURE"})
    return features,[e for e in events if e["event_day"]<=spec["cutoff"]],oracle

def generate_po(rng):
    spec=SPECS["po"]; features=[]; events=[]; oracle=[]
    for i in range(spec["n"]):
        day=rng.randrange(360); supplier=rng.randrange(10); material=rng.randrange(20)
        qty=rng.randint(50,500); promised=12+2*supplier
        row=base_row("po",i,day,"PO")
        row.update(supplier=f"SUP{supplier:02d}",material=f"MAT{material:02d}",
                   ordered_units=qty,promised_lead_days=promised)
        features.append(row); add_event(events,row["entity_id"],day,"ordered",qty,0)
        unfilled=rng.random()<0.07
        lead=max(4,round(rng.gauss(promised+material%4,4+supplier/3)))
        if rng.random()<0.12: lead+=rng.randint(80,140)
        first=max(1,int(lead*0.42)); second=max(first+1,int(lead*0.72)); lead=max(second+1,lead)
        q1=rng.randint(max(1,qty//5),max(2,qty//2))
        q2=rng.randint(1,qty-q1-1); q3=qty-q1-q2
        schedule=[(first,q1)] if unfilled else [(first,q1),(second,q2),(lead,q3)]
        for seq,(age,q) in enumerate(schedule,1):
            if day+age<=spec["cutoff"]:
                add_event(events,row["entity_id"],day+age,"received",q,seq)
        oracle.append({"entity_id":row["entity_id"],"latent_complete_age":lead if not unfilled else "",
                       "structurally_unfilled":int(unfilled),
                       "notice":"SIMULATION_ORACLE_NEVER_A_MODEL_FEATURE"})
    return features,events,oracle

def generate(root=ROOT,seed=SEED):
    manifest={"synthetic":True,"seed":seed,"calendar_start":iso(0),
              "warning":"Entirely simulated. No production connection. No personal data.","projects":{}}
    generators={"presale":generate_presale,"returns":generate_returns,"cod":generate_cod,"po":generate_po}
    for j,(project,func) in enumerate(generators.items()):
        features,events,oracle=func(random.Random(seed+100*j))
        features.sort(key=lambda x:x["entity_id"])
        events.sort(key=lambda x:(x["event_day"],x["entity_id"],x["scenario"],x["sequence"]))
        folder=root/"data"/project
        write_csv(folder/"features.csv",features)
        write_csv(folder/"events.csv",events)
        write_csv(folder/"ORACLE_DO_NOT_TRAIN.csv",oracle)
        spec=SPECS[project].copy()
        spec.update(feature_rows=len(features),event_rows=len(events),
            split_counts=dict(Counter(r["split"] for r in features)),
            first_event_date=events[0]["event_date"],last_event_date=events[-1]["event_date"],
            hashes={name:sha256(folder/name) for name in ("features.csv","events.csv","ORACLE_DO_NOT_TRAIN.csv")})
        manifest["projects"][project]=spec
        print(f"Generated {project}: {len(features):,} entities, {len(events):,} events")
    write_json(root/"data"/"manifest.json",manifest)
    return manifest

if __name__=="__main__": generate()
