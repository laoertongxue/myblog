"""Transparent baselines, not a production library. Only Python standard library."""
import math
from collections import Counter,defaultdict
from common import mean, sigmoid, quantile

def presale_risk(rows):
    """Day starts at risk; cancellation has priority, then shipment, then day-60 rule."""
    stats=defaultdict(lambda:[0,0,0,0,0])
    for r in rows:
        last=int(r["exit_age"]) if r["exit_age"]!="" else min(int(r["observed_age"]),60)
        for age in range(1,min(last,60)+1):
            for group in ("ALL",r["sku"]):
                s=stats[group,age]; s[0]+=1
                if age==last:
                    status=r["status"]
                    if status=="cancelled": s[1]+=1
                    elif status=="shipped": s[2]+=1
                    elif status=="forced_cancel": s[3]+=1
                    elif status=="pending": s[4]+=1
    return stats

def hazard_model(stats,m=100,grouped=True):
    groups=sorted({g for g,_ in stats})
    out={}
    for g in groups:
        surv=[1.0]; hazards=[None]
        for age in range(1,60):
            nr,nc,*_=stats.get(("ALL",age),[0]*5)
            prior=nc/nr if nr else None
            r,c,*_=stats.get((g,age),[0]*5)
            h=(c+m*prior)/(r+m) if prior is not None and r+m>0 and grouped else prior
            hazards.append(h)
            surv.append(surv[-1]*(1-h) if h is not None and surv[-1] is not None else None)
        out[g]={"hazard":hazards,"survival":surv}
    return out

def hazard_brier(model,stats):
    errors=0.; n=0
    for (g,age),(r,c,_,_,_) in stats.items():
        if g=="ALL" or age==60: continue
        p=model.get(g,model["ALL"])["hazard"][age]
        if p is None: continue
        errors+=c*(1-p)**2+(r-c)*p*p; n+=r
    return errors/n if n else None,n

class GroupRate:
    def __init__(self,key,target,m=100): self.key=key; self.target=target; self.m=m
    def fit(self,rows):
        self.global_rate=mean(float(r[self.target]) for r in rows)
        self.counts=defaultdict(lambda:[0,0.])
        for r in rows:
            s=self.counts[r[self.key]]; s[0]+=1; s[1]+=float(r[self.target])
        return self
    def predict(self,row):
        n,c=self.counts.get(row[self.key],[0,0])
        return (c+self.m*self.global_rate)/(n+self.m) if n+self.m else self.global_rate

COD_FEATURES=["intercept","distance_km/100","units/4","planned_delivery_days/10","route_R1","route_R2"]
def cod_vector(row):
    return [1.,int(row["distance_km"])/100,int(row["units"])/4,
            int(row["planned_delivery_days"])/10,float(row["route"]=="R1"),float(row["route"]=="R2")]

class LogisticBaseline:
    def __init__(self,l2=0.01,steps=500,learning_rate=0.15):
        self.l2=l2; self.steps=steps; self.learning_rate=learning_rate
    def fit(self,rows):
        xs=[cod_vector(r) for r in rows]; ys=[int(r["refused"]) for r in rows]; n=len(xs)
        rate=min(.999,max(.001,mean(ys)))
        self.weights=[math.log(rate/(1-rate))]+[0.]*(len(xs[0])-1)
        for _ in range(self.steps):
            grad=[0.]*len(self.weights)
            for x,y in zip(xs,ys):
                err=sigmoid(sum(w*v for w,v in zip(self.weights,x)))-y
                for j,v in enumerate(x): grad[j]+=err*v
            for j in range(len(self.weights)):
                self.weights[j]-=self.learning_rate*(grad[j]/n+(self.l2*self.weights[j] if j else 0))
        return self
    def logit(self,row): return sum(w*x for w,x in zip(self.weights,cod_vector(row)))
    def predict(self,row,offset=0.): return sigmoid(self.logit(row)+offset)

def fit_calibration_intercept(model,rows):
    """Adjust only the intercept on held-out validation A, not full Platt calibration."""
    offset=0.
    for _ in range(40):
        ps=[model.predict(r,offset) for r in rows]
        grad=sum(p-int(r["refused"]) for p,r in zip(ps,rows))
        hess=sum(p*(1-p) for p in ps)
        if hess<1e-12: break
        change=max(-1.,min(1.,grad/hess)); offset-=change
        if abs(change)<1e-10: break
    return offset

def review_cost(rows,probs,threshold,review_yuan=2.,loss_per_unit_yuan=25.,effectiveness=.60):
    n_review=0; total=0.; refused_units=0
    for r,p in zip(rows,probs):
        flag=p>=threshold; units=int(r["units"]); y=int(r["refused"])
        n_review+=int(flag); refused_units+=y*units
        total+=review_yuan*flag+loss_per_unit_yuan*units*y*(1-effectiveness*flag)
    return {"threshold":threshold,"n":len(rows),"review_count":n_review,
            "review_fraction":n_review/len(rows),"simulated_cost_yuan":total,
            "cost_per_parcel_yuan":total/len(rows),"actual_refused_units":refused_units}

def km_fit(rows):
    """Kaplan-Meier time-to-full-receipt, with right censoring and event-before-censor ties."""
    counts=defaultdict(lambda:[0,0])
    for r in rows:
        event=int(r["completed"])
        age=int(r["complete_age"]) if event else int(r["observed_age"])
        counts[age][0 if event else 1]+=1
    n=len(rows); survival=1.; curve=[]
    for age,(completed,censored) in sorted(counts.items()):
        if n:
            survival*=1-completed/n
            curve.append({"age":age,"at_risk":n,"completed":completed,"censored":censored,
                          "survival_not_fully_received":survival})
        n-=completed+censored
    return curve

def km_cdf(curve,day):
    survival=1.
    for r in curve:
        if r["age"]>day: break
        survival=r["survival_not_fully_received"]
    return 1-survival

def km_quantile(curve,q):
    return next((r["age"] for r in curve if 1-r["survival_not_fully_received"]>=q),None)

def quantile_evaluation(rows,predictions,q):
    valid=[(r,p) for r,p in zip(rows,predictions) if p is not None]
    if not valid:
        return {"n":len(rows),"predictions_available":0,"coverage_lower":None,"coverage_upper":None,
                "pinball_completed_only":None,"pinball_n":0,"unknown_due_to_censoring":0,
                "warning":"No quantile prediction is available; coverage cannot be estimated."}
    yes=0; unknown=0; pinballs=[]
    for r,p in valid:
        if int(r["completed"]):
            y=int(r["complete_age"]); yes+=y<=p
            err=y-p; pinballs.append(max(q*err,(q-1)*err))
        elif int(r["observed_age"])<p: unknown+=1
    return {"n":len(rows),"predictions_available":len(valid),"coverage_lower":yes/len(valid),
            "coverage_upper":(yes+unknown)/len(valid),"unknown_due_to_censoring":unknown,
            "pinball_completed_only":mean(pinballs),"pinball_n":len(pinballs),
            "warning":"Coverage denominator excludes unavailable predictions. Completed-only pinball is selection-biased."}

def path_tuple(row):
    """Complete historical return paths, for a transparent state-conditioned baseline."""
    def optional(name): return int(row[name]) if row[name]!="" else None
    return {"req":optional("return_requested_age"),"receipt":optional("warehouse_received_age"),
            "qc":optional("quality_passed_age") if row["quality_passed_age"]!="" else optional("quality_failed_age"),
            "restock":optional("restocked_age")}

def expected_return_by_state(current,training_rows,origin,horizon=7):
    """Analogue paths condition on current stage and waiting age; never read future events.

    Current row is reconstructed at origin-1. Origin is the start of a day.
    Each comparable historical path contributes at most one future usable unit.
    """
    if (current["restocked"]==1 or current["quality_failed_age"]!="" or
            (current.get("label_mature")==1 and current["returned"]==0)):
        return [0.]*horizon,"terminal",0
    age=origin-1-int(current["created_day"])
    pcur=path_tuple(current)
    if pcur["qc"] is not None: stage="putaway"; elapsed=age-pcur["qc"]
    elif pcur["receipt"] is not None: stage="qc"; elapsed=age-pcur["receipt"]
    elif pcur["req"] is not None: stage="in_transit"; elapsed=age-pcur["req"]
    else: stage="no_request"; elapsed=age
    eligible=[]
    for r in training_rows:
        p=path_tuple(r)
        if stage=="no_request":
            ok=p["req"] is None or p["req"]>elapsed
            rest=p["restock"]
        elif stage=="in_transit":
            ok=p["req"] is not None and p["receipt"]-p["req"]>elapsed
            rest=p["restock"]-p["req"] if p["restock"] is not None else None
        elif stage=="qc":
            ok=p["receipt"] is not None and p["qc"]-p["receipt"]>elapsed
            rest=p["restock"]-p["receipt"] if p["restock"] is not None else None
        else:
            ok=p["restock"] is not None and p["restock"]-p["qc"]>elapsed
            rest=p["restock"]-p["qc"] if p["restock"] is not None else None
        if ok: eligible.append(rest)
    if not eligible: return [None]*horizon,stage,0
    forecast=[sum(rest is not None and rest-elapsed==k for rest in eligible)/len(eligible)
              for k in range(1,horizon+1)]
    return forecast,stage,len(eligible)
