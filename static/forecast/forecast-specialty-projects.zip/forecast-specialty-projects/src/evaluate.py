"""Run honest chronological baselines and save forecasts, metrics, and diagnostics."""
from __future__ import annotations
import json
from collections import defaultdict,Counter
from common import (ROOT,SPECS,iso,read_csv,write_csv,write_json,sha256,mean,brier,binary_metrics,
                    calibration_rows,plot_svg,quantile)
from labels import labels,join_labels,get_split
from models import (presale_risk,hazard_model,hazard_brier,GroupRate,LogisticBaseline,
                    COD_FEATURES,fit_calibration_intercept,review_cost,km_fit,km_cdf,
                    km_quantile,quantile_evaluation,expected_return_by_state)

def inputs(project,root):
    folder=root/"data"/project
    return read_csv(folder/"features.csv"),read_csv(folder/"events.csv")

def chronological_rows(project,features,events,scenario=None):
    spec=SPECS[project]
    train=join_labels(get_split(features,"train"),labels(project,features,events,spec["fit_cutoff"],scenario))
    val=join_labels(get_split(features,"validation"),labels(project,features,events,spec["validation_cutoff"],scenario))
    test=join_labels(get_split(features,"test"),labels(project,features,events,spec["cutoff"],scenario))
    return train,val,test

def presale(root):
    folder=root/"outputs"/"presale"; folder.mkdir(parents=True,exist_ok=True)
    features,events=inputs("presale",root); all_metrics={}; diagnostic=[]; pending=[]; curves=[]
    # The oracle is loaded ONLY here, for explicitly labelled simulation diagnostics, never model fitting.
    oracle=read_csv(root/"data"/"presale"/"ORACLE_DO_NOT_TRAIN.csv")
    oracle_lookup={(r["entity_id"],r["scenario"]):r for r in oracle}
    for scenario in ("independent","informative"):
        train,val,test=chronological_rows("presale",features,events,scenario)
        trisk,vrisk,terisk=map(presale_risk,(train,val,test))
        candidate=[]
        for m in (0,20,100,500):
            model=hazard_model(trisk,m=m)
            score,n=hazard_brier(model,vrisk)
            candidate.append({"m":m,"validation_brier":score,"validation_risk_days":n})
        best=min(candidate,key=lambda x:x["validation_brier"])["m"]
        model=hazard_model(trisk,m=best); global_model=hazard_model(trisk,grouped=False)
        write_json(folder/f"{scenario}_model_selection.json",{
            "train_event_cutoff":SPECS["presale"]["fit_cutoff"],"candidates":candidate,"chosen_m":best,
            "features":["sku","order_age"],"test_used_for_selection":False,
            "warning":"Natural cancellation survival under no shipping requires independent censoring. Day 60 is a policy event."})
        riskrows=[]
        for (group,age),(r,c,sh,forced,censored) in sorted(trisk.items()):
            values=model[group]
            raw=c/r if r and age<60 else None
            riskrows.append({"scenario":scenario,"group":group,"age":age,"at_risk_start":r,
                "natural_cancelled":c,"shipped":sh,"forced_cancelled":forced,"right_censored":censored,
                "at_risk_next":r-c-sh-forced-censored,"raw_hazard":raw,
                "smoothed_hazard":values["hazard"][age] if age<60 else None,
                "no_shipping_natural_survival":values["survival"][age] if age<60 else None})
        write_csv(folder/f"{scenario}_risk_table.csv",riskrows)
        test_score,test_n=hazard_brier(model,terisk); base_score,_=hazard_brier(global_model,terisk)
        train_ids=[r["entity_id"] for r in train]
        truth=[]
        for age in range(60):
            s_true=mean(oracle_lookup[(i,scenario)]["latent_natural_cancel_age"]=="" or
                        int(oracle_lookup[(i,scenario)]["latent_natural_cancel_age"])>age for i in train_ids)
            estimate=model["ALL"]["survival"][age]
            diagnostic.append({"scenario":scenario,"age":age,"estimated_no_shipping_survival":estimate,
                "oracle_empirical_latent_survival":s_true,"estimation_minus_oracle":estimate-s_true if estimate is not None else None,
                "purpose":"diagnostic_only_not_test_metric_not_model_input"})
            truth.append((age,s_true))
        curves.append((scenario,[(a,model["ALL"]["survival"][a]) for a in range(60)]))
        if scenario=="independent": curves.append(("oracle latent truth",truth))
        snap=join_labels(features,labels("presale",features,events,359,scenario))
        for r in snap:
            if r["status"]!="pending": continue
            age=int(r["observed_age"]); target=age+7; supported=min(59,target)
            surv=model.get(r["sku"],model["ALL"])["survival"]
            ratio=surv[supported]/surv[age] if surv[age] and surv[supported] is not None else None
            forced=target>=60
            pending.append({"entity_id":r["entity_id"],"scenario":scenario,"origin_day":360,
                "current_age_end_previous_day":age,"units":r["units"],"horizon_days":7,
                "natural_survival_supported_through_age":supported,"conditional_natural_survival":ratio,
                "day60_policy_applies":int(forced),
                "expected_waiting_units_if_no_shipping":0 if forced else int(r["units"])*ratio if ratio is not None else None,
                "warning":"Scenario only; not physical stock or a prediction of actual shipping."})
        all_metrics[scenario]={"n_train_orders":len(train),"n_validation_orders":len(val),"n_test_orders":len(test),
            "selected_m":best,"test_at_risk_order_days":test_n,"test_smoothed_hazard_brier":test_score,
            "test_pooled_hazard_brier":base_score,
            "oracle_age59_estimation_error":diagnostic[-1]["estimation_minus_oracle"]}
        write_csv(folder/f"{scenario}_live_labels_asof359.csv",snap)
    write_csv(folder/"oracle_diagnostic_survival.csv",diagnostic)
    write_csv(folder/"conditional_pending_demand_scenario.csv",pending)
    plot_svg(folder/"survival.svg",curves,"Synthetic cancellation: shipping assumptions matter","Order age (days)","Survival",59,1)
    # Actual calendar-day order states. Counts and units never overlap.
    ledgers=[]
    for scenario in ("independent","informative"):
        byday=defaultdict(list)
        for e in events:
            if e["scenario"]==scenario: byday[int(e["event_day"])].append(e)
        counts=Counter(); units=Counter()
        for day in range(420):
            for e in byday[day]:
                typ=e["event_type"]; q=int(e["units"])
                if typ=="created": counts["created"]+=1; units["created"]+=q; counts["pending"]+=1; units["pending"]+=q
                else: counts["pending"]-=1;units["pending"]-=q;counts[typ]+=1;units[typ]+=q
            row={"scenario":scenario,"day":day,"date":iso(day)}
            for key in ("created","pending","cancelled","shipped","forced_cancel"):
                row[key+"_orders"]=counts[key];row[key+"_units"]=units[key]
            ledgers.append(row)
    write_csv(folder/"actual_state_ledger.csv",ledgers)
    write_json(folder/"metrics.json",all_metrics)
    return all_metrics

def return_fit(train,m):
    p_return=GroupRate("category","returned",m).fit(train)
    returned=[r for r in train if int(r["returned"])==1]
    yield_model=GroupRate("category","restocked",m).fit(returned)
    good=[r for r in returned if int(r["restocked"])==1]
    lags=defaultdict(Counter)
    for r in good:
        lag=int(r["restocked_age"]); lags[r["category"]][lag]+=1;lags["ALL"][lag]+=1
    def predict(row,pooled=False):
        p=p_return.global_rate if pooled else p_return.predict(row)
        y=yield_model.global_rate if pooled else yield_model.predict(row)
        hist=lags["ALL"] if pooled or not lags[row["category"]] else lags[row["category"]]
        total=sum(hist.values()); pmf={k:v/total for k,v in hist.items()}
        return p,y,pmf
    return predict

def returns(root):
    folder=root/"outputs"/"returns";folder.mkdir(parents=True,exist_ok=True)
    features,events=inputs("returns",root);train,val,test=chronological_rows("returns",features,events)
    candidates=[]
    for m in (0,20,100,500):
        pred=return_fit(train,m)
        candidates.append({"m":m,"validation_return_brier":brier([pred(r)[0] for r in val],[int(r["returned"]) for r in val])})
    best=min(candidates,key=lambda x:x["validation_return_brier"])["m"]
    predict=return_fit(train,best)
    write_json(folder/"model_selection.json",{"candidates":candidates,"chosen_m":best,
        "train_event_cutoff":89,"features":["category"],"test_used_for_selection":False,
        "return_maturity_rule":"All simulated paths end within 29 days; wait 30 days for a negative label."})
    cohort=[];daily=defaultdict(lambda:[0.,0.,0]);retps=[];goodps=[];baseps=[]
    for r in test:
        p,y,pmf=predict(r);bp,by,bpmf=predict(r,True);day=int(r["created_day"])
        retps.append(p);goodps.append(p*y);baseps.append(bp)
        cohort.append({"entity_id":r["entity_id"],"ship_day":day,"category":r["category"],"units":1,
            "p_return":p,"conditional_quality_yield":y,"p_eventual_restock":p*y,
            "actual_returned":r["returned"],"actual_restocked":r["restocked"],
            "actual_restock_age":r["restocked_age"],"expected_supply_not_on_hand":p*y})
        for lag,prob in pmf.items(): daily[day+lag][0]+=p*y*prob
        for lag,prob in bpmf.items(): daily[day+lag][1]+=bp*by*prob
        if r["restocked_age"]!="": daily[day+int(r["restocked_age"])][2]+=1
    flow=[]
    for day in range(140,210):
        pred,base,actual=daily[day]
        flow.append({"day":day,"date":iso(day),"grouped_expected_restock_units":pred,
            "pooled_expected_restock_units":base,"actual_test_cohort_restock_units":actual})
    total_actual=sum(r["actual_test_cohort_restock_units"] for r in flow)
    errs=[abs(r["grouped_expected_restock_units"]-r["actual_test_cohort_restock_units"]) for r in flow]
    metrics={"n_train":len(train),"n_validation":len(val),"n_test":len(test),"selected_m":best,
        "test_return_grouped":binary_metrics(retps,[int(r["returned"]) for r in test]),
        "test_return_pooled":binary_metrics(baseps,[int(r["returned"]) for r in test]),
        "test_restock_grouped":binary_metrics(goodps,[int(r["restocked"]) for r in test]),
        "test_cohort_daily_restock_mae":mean(errs),"test_cohort_restock_wape":sum(errs)/total_actual if total_actual else None,
        "test_cohort_expected_restock_units":sum(r["grouped_expected_restock_units"] for r in flow),
        "test_cohort_actual_restock_units":total_actual,
        "zero_restock_daily_mae":total_actual/len(flow),
        "pooled_daily_restock_mae":mean(abs(r["pooled_expected_restock_units"]-r["actual_test_cohort_restock_units"]) for r in flow)}
    write_csv(folder/"test_cohort_predictions.csv",cohort);write_csv(folder/"test_cohort_daily_restock.csv",flow)
    plot_svg(folder/"daily_restock.svg",[("Grouped expected",[(r["day"]-140,r["grouped_expected_restock_units"]) for r in flow]),
        ("Actual",[(r["day"]-140,r["actual_test_cohort_restock_units"]) for r in flow])],
        "Test cohorts only: daily usable returns","Days since test cohort start","Units")
    current=join_labels(features,labels("returns",features,events,179))
    write_csv(folder/"live_labels_asof179.csv",current)
    bycat=defaultdict(list)
    for r in train:bycat[r["category"]].append(r)
    forecasts=[];summed=[0.]*7;unsupported=0
    for r in current:
        values,stage,n=expected_return_by_state(r,bycat[r["category"]],180,7)
        fallback=0
        if values[0] is None:
            values,stage,n=expected_return_by_state(r,train,180,7);fallback=1
        if values[0] is None: unsupported+=1
        for k,value in enumerate(values):
            if value is not None:summed[k]+=value
            forecasts.append({"entity_id":r["entity_id"],"origin_day":180,"target_day":180+k,
                "stage":stage,"analogue_count":n,"pooled_fallback":fallback,"expected_restock_units":value,
                "expected_supply_not_on_hand":value,"fresh_food_no_resale_scenario_units":0})
    actual_byday=Counter()
    for e in events:
        if e["event_type"]=="restocked" and 180<=int(e["event_day"])<187:
            actual_byday[int(e["event_day"])]+=int(e["units"])
    operational=[{"origin_day":180,"target_day":180+k,"expected_restock_units":summed[k],
        "actual_restock_units":actual_byday[180+k],"unsupported_entities":unsupported,
        "fresh_food_no_resale_scenario_units":0} for k in range(7)]
    write_csv(folder/"state_conditioned_next7_entity_forecast.csv",forecasts)
    write_csv(folder/"state_conditioned_next7_daily.csv",operational)
    metrics["next7_unsupported_entities"]=unsupported
    metrics["next7_daily_mae"]=mean(abs(r["expected_restock_units"]-r["actual_restock_units"]) for r in operational)
    ledger=[];byday=defaultdict(list)
    for e in events:byday[int(e["event_day"])].append(e)
    state=Counter(on_hand=12000)
    for day in range(210):
        for e in byday[day]:
            typ=e["event_type"]
            if typ=="shipped":state["on_hand"]-=1;state["customer_or_outbound"]+=1
            elif typ=="return_requested":state["customer_or_outbound"]-=1;state["return_in_transit"]+=1
            elif typ=="warehouse_received":state["return_in_transit"]-=1;state["in_qc"]+=1
            elif typ=="quality_failed":state["in_qc"]-=1;state["scrapped"]+=1
            elif typ=="restocked":state["in_qc"]-=1;state["on_hand"]+=1
        ledger.append({"day":day,"date":iso(day),**{k:state[k] for k in ("on_hand","customer_or_outbound","return_in_transit","in_qc","scrapped")}})
    write_csv(folder/"actual_physical_stock_ledger.csv",ledger)
    write_json(folder/"metrics.json",metrics)
    return metrics

def cod(root):
    folder=root/"outputs"/"cod";folder.mkdir(parents=True,exist_ok=True)
    features,events=inputs("cod",root);train,val,test=chronological_rows("cod",features,events)
    validation_a=[r for r in val if int(r["created_day"])<=99]
    validation_b=[r for r in val if int(r["created_day"])>=100]
    model=LogisticBaseline().fit(train);offset=fit_calibration_intercept(model,validation_a)
    vps=[model.predict(r,offset) for r in validation_b]
    costs=[review_cost(validation_b,vps,k/20) for k in range(21)]
    best=min(costs,key=lambda r:r["simulated_cost_yuan"])["threshold"]
    selection={"train_event_cutoff":89,"feature_allowlist":COD_FEATURES,"weights":model.weights,
        "logistic_steps":model.steps,"l2":model.l2,"intercept_calibration_offset":offset,
        "calibration_created_days":[90,99],"threshold_selection_created_days":[100,109],
        "selected_threshold":best,"test_used_for_selection":False,
        "cost_assumptions":{"review_yuan_per_parcel":2,"missed_refusal_loss_yuan_per_unit":25,
                            "assumed_review_effectiveness":0.6},
        "warning":"Review effectiveness is a hypothetical constant, not an identified causal effect. No orders are changed."}
    write_json(folder/"model_selection.json",selection)
    selection_hash=sha256(folder/"model_selection.json")
    ps=[model.predict(r,offset) for r in test];rawps=[model.predict(r) for r in test]
    ys=[int(r["refused"]) for r in test];base=mean(int(r["refused"]) for r in train)
    testrows=[]
    for r,p,raw in zip(test,ps,rawps):
        testrows.append({"entity_id":r["entity_id"],"created_day":r["created_day"],"units":r["units"],
            "raw_probability":raw,"calibrated_probability":p,"baseline_probability":base,
            "actual_refused":r["refused"],"review_suggestion_only":int(p>=best),
            "expected_net_sales_units":int(r["units"])*(1-p),"model_selection_sha256":selection_hash})
    calibration=calibration_rows(ps,ys)
    write_csv(folder/"probability_ledger.csv",testrows)
    write_csv(folder/"validation_threshold_costs.csv",costs)
    write_csv(folder/"test_calibration.csv",calibration)
    plot_svg(folder/"calibration.svg",[("Perfect calibration",[(0,0),(1,1)]),
        ("Test (see CSV for bin counts)",[(r["mean_prediction"],r["observed_fraction"]) for r in calibration if r["n"]])],
        "Synthetic COD: test calibration","Mean prediction","Observed refusal",1,1)
    plot_svg(folder/"threshold_cost.svg",[("Validation B",[(r["threshold"],r["cost_per_parcel_yuan"]) for r in costs])],
        "Hypothetical review cost: validation only","Threshold","Yuan per parcel",1)
    metrics={"n_train":len(train),"n_validation_calibration":len(validation_a),"n_validation_threshold":len(validation_b),"n_test":len(test),
        "test_global_mean":binary_metrics([base]*len(test),ys),"test_raw_logistic":binary_metrics(rawps,ys),
        "test_intercept_calibrated_logistic":binary_metrics(ps,ys),"frozen_threshold":best,
        "test_selected_threshold_cost":review_cost(test,ps,best),
        "test_no_review_cost":review_cost(test,ps,1.01),"test_review_all_cost":review_cost(test,ps,0),
        "model_selection_sha256":selection_hash}
    live=join_labels(features,labels("cod",features,events,179));write_csv(folder/"live_labels_asof179.csv",live)
    byday=defaultdict(list)
    for e in events:byday[int(e["event_day"])].append(e)
    predicted_byday=defaultdict(float)
    for r in testrows:predicted_byday[int(r["created_day"])]+=r["expected_net_sales_units"]
    state=Counter(on_hand=40000);ledger=[];expected_cum=0.
    for day in range(210):
        for e in byday[day]:
            typ=e["event_type"];q=int(e["units"])
            if typ=="shipped":state["on_hand"]-=q;state["outbound"]+=q;state["shipped_cumulative"]+=q
            elif typ=="delivered_paid":state["outbound"]-=q;state["delivered_paid"]+=q
            elif typ=="refused":state["outbound"]-=q;state["refused_returning"]+=q
            elif typ=="warehouse_received":state["refused_returning"]-=q;state["in_qc"]+=q
            elif typ=="quality_failed":state["in_qc"]-=q;state["scrapped"]+=q
            elif typ=="restocked":state["in_qc"]-=q;state["on_hand"]+=q;state["restocked_cumulative"]+=q
        expected_cum+=predicted_byday[day]
        ledger.append({"day":day,"date":iso(day),**{k:state[k] for k in ("on_hand","outbound","delivered_paid","refused_returning","in_qc","scrapped","shipped_cumulative","restocked_cumulative")},
            "test_cohorts_expected_net_sales_cumulative":expected_cum})
    write_csv(folder/"actual_inventory_and_expected_sales.csv",ledger)
    # Separate panels are deliberate: expected sales is a cohort total, not stock.
    for field,title in (("on_hand","Physical on-hand units"),("outbound","Outbound units"),
                         ("test_cohorts_expected_net_sales_cumulative","Expected retained sales: test cohorts")):
        plot_svg(folder/f"{field}.svg",[(title,[(r["day"],r[field]) for r in ledger])],title,"Calendar day","Units")
    write_json(folder/"metrics.json",metrics)
    return metrics

def po(root):
    folder=root/"outputs"/"po";folder.mkdir(parents=True,exist_ok=True)
    features,events=inputs("po",root);train,val,test=chronological_rows("po",features,events)
    pooled=km_fit(train);by_supplier=defaultdict(list)
    for r in train:by_supplier[r["supplier"]].append(r)
    groups={key:km_fit(rows) for key,rows in by_supplier.items()}
    y30=[int(r["completed"]) and int(r["complete_age"])<=30 for r in val]
    valscores={"pooled":brier([km_cdf(pooled,30)]*len(val),y30),
        "supplier":brier([km_cdf(groups.get(r["supplier"],pooled),30) for r in val],y30)}
    choice=min(valscores,key=valscores.get)
    naive50=quantile([int(r["complete_age"]) for r in train if int(r["completed"])],.5)
    naive90=quantile([int(r["complete_age"]) for r in train if int(r["completed"])],.9)
    write_json(folder/"model_selection.json",{"train_event_cutoff":179,"candidate_validation_brier_complete_by30":valscores,
        "chosen_km_grouping":choice,"test_used_for_selection":False,
        "features":["supplier"],"selection_endpoint":"full receipt by 30 days, observed for every validation PO",
        "warning":"KM assumes censoring independent of event time within strata. Undefined tail quantiles remain blank."})
    curve_rows=[]
    for key,curve in {"ALL":pooled,**groups}.items():
        for r in curve:curve_rows.append({"supplier":key,**r})
    write_csv(folder/"training_km_curve.csv",curve_rows)
    forecast=[];p50s=[];p90s=[]
    for r in test:
        curve=pooled if choice=="pooled" else groups.get(r["supplier"],pooled)
        p50=km_quantile(curve,.5);p90=km_quantile(curve,.9);p50s.append(p50);p90s.append(p90)
        forecast.append({"entity_id":r["entity_id"],"supplier":r["supplier"],"created_day":r["created_day"],
            "predicted_full_receipt_p50_days":p50,"predicted_full_receipt_p90_days":p90,
            "p90_estimable":int(p90 is not None),"fixed_p50_days":21,"fixed_p90_days":35,
            "completed_only_naive_p50_days":naive50,"completed_only_naive_p90_days":naive90,
            "completed":r["completed"],"observed_complete_age":r["complete_age"],
            "observed_followup_days":r["observed_age"],"received_units":r["received_units"],
            "outstanding_units":r["outstanding_units"],"censored":r["censored"]})
    metrics={"n_train":len(train),"n_validation":len(val),"n_test":len(test),
        "train_right_censored":sum(int(r["censored"]) for r in train),
        "test_right_censored":sum(int(r["censored"]) for r in test),"selected_model":choice,
        "km_p50":quantile_evaluation(test,p50s,.5),"km_p90":quantile_evaluation(test,p90s,.9),
        "fixed_p50":quantile_evaluation(test,[21]*len(test),.5),"fixed_p90":quantile_evaluation(test,[35]*len(test),.9),
        "completed_only_naive_p50":quantile_evaluation(test,[naive50]*len(test),.5),
        "completed_only_naive_p90":quantile_evaluation(test,[naive90]*len(test),.9)}
    write_csv(folder/"test_po_predictions.csv",forecast)
    coverage=[]
    for name in ("km_p50","km_p90","fixed_p50","fixed_p90","completed_only_naive_p50","completed_only_naive_p90"):
        coverage.append({"model":name,**metrics[name]})
    # All records share an explicit schema; absent values in an unavailable model remain blank.
    keys=list(dict.fromkeys(k for r in coverage for k in r))
    write_csv(folder/"coverage_bounds.csv",coverage,keys)
    all_labels=labels("po",features,events,449);write_csv(folder/"all_po_final_status.csv",all_labels)
    write_csv(folder/"training_labels_asof179.csv",train)
    byday=defaultdict(list)
    for e in events:byday[int(e["event_day"])].append(e)
    ordered=received=0;ledger=[]
    for day in range(450):
        for e in byday[day]:
            if e["event_type"]=="ordered":ordered+=int(e["units"])
            else:received+=int(e["units"])
        ledger.append({"day":day,"date":iso(day),"ordered_units_cumulative":ordered,
            "received_units_cumulative":received,"outstanding_units":ordered-received})
    write_csv(folder/"partial_receipt_ledger.csv",ledger)
    plot_svg(folder/"km_survival.svg",[("Pooled KM",[(r["age"],r["survival_not_fully_received"]) for r in pooled])],
        "Training PO: not yet fully received","Days since PO creation","Survival",None,1)
    plot_svg(folder/"po_coverage.svg",[("Coverage lower",[(i+1,r["coverage_lower"]) for i,r in enumerate(coverage)]),
        ("Coverage upper",[(i+1,r["coverage_upper"]) for i,r in enumerate(coverage)])],
        "PO coverage bounds; model index follows CSV row order","Model row index","Coverage",6,1)
    write_json(folder/"metrics.json",metrics)
    return metrics

def run(root=ROOT):
    all_metrics={}
    for name,func in (("presale",presale),("returns",returns),("cod",cod),("po",po)):
        print(f"Evaluating {name} ...")
        all_metrics[name]=func(root)
    write_json(root/"outputs"/"all_metrics.json",all_metrics)
    write_results_summary(root,all_metrics)
    return all_metrics

def write_results_summary(root,m):
    p=m["presale"];r=m["returns"];c=m["cod"];o=m["po"]
    po90=o["km_p90"]
    def number(value,digits=3): return "无定义/不可估计" if value is None else f"{value:.{digits}f}"
    def percent(value): return "无定义/不可估计" if value is None else f"{value:.2%}"
    def lower(a,b): return "不可比较于" if a is None or b is None else "低于" if a<b else "不低于"
    presale_comparison=lower(p["informative"]["test_smoothed_hazard_brier"],p["informative"]["test_pooled_hazard_brier"])
    return_comparison=lower(r["test_cohort_daily_restock_mae"],r["pooled_daily_restock_mae"])
    calibration_comparison={"低于":"改善","不低于":"未改善","不可比较于":"无法比较"}[
        lower(c["test_intercept_calibrated_logistic"]["brier"],c["test_raw_logistic"]["brier"])]
    all_review_text="本次选到0，即全部建议复核。" if c["frozen_threshold"]==0 else "该阈值仅由验证集选择。"
    same_cost_text=("冻结策略与全复核相同，不能把差额宣称成模型增量价值。" if
                   abs(c["test_selected_threshold_cost"]["simulated_cost_yuan"]-c["test_review_all_cost"]["simulated_cost_yuan"])<1e-8
                   else "必须同时与不复核和全复核比较，成本差额不是已实现收益。")
    naive_value=o["completed_only_naive_p90"]["coverage_lower"]
    naive_comparison="无法比较于" if naive_value is None else "低于" if naive_value<.9 else "达到或高于"
    seed=json.loads((root/"data"/"manifest.json").read_text(encoding="utf-8"))["seed"]
    text=f'''# 实际运行结果：固定种子的模拟实验

本页由代码读取本次指标生成，不是预先填写的“理想成绩”。本次种子为{seed}。所有数据虚构，没有真实企业效果或生产动作。

## 1. 预售：预测误差小不等于假设正确

- 同一批20,000订单，各有独立发货/信息性发货两个场景。每个场景训练{p["independent"]["n_train_orders"]}单、验证{p["independent"]["n_validation_orders"]}单、测试{p["independent"]["n_test_orders"]}单；其他日期记录保留作成熟空档和事件账。
- 独立发货：测试每日hazard Brier，平滑模型{number(p["independent"]["test_smoothed_hazard_brier"],6)}，总体基线{number(p["independent"]["test_pooled_hazard_brier"],6)}。
- 信息性发货：测试每日hazard Brier，平滑模型{number(p["informative"]["test_smoothed_hazard_brier"],6)}，总体基线{number(p["informative"]["test_pooled_hazard_brier"],6)}。本次平滑误差{presale_comparison}总体。
- 第59日“无发货自然留存”估计减模拟潜在真值：独立场景{100*p["independent"]["oracle_age59_estimation_error"]:.2f}个百分点，信息性场景{100*p["informative"]["oracle_age59_estimation_error"]:.2f}个百分点。正数表示高估，负数表示低估。
- 两场景的风险集不同，不能拿两种场景的Brier直接排名。Oracle比较是模拟诊断，不是现实可以拿到的答案。

查看：`presale/survival.svg`、`presale/oracle_diagnostic_survival.csv`、`presale/conditional_pending_demand_scenario.csv`。

## 2. 退货：单件概率与日回流分开看

- 测试{r["n_test"]}个发货行。退货Brier：分组{number(r["test_return_grouped"]["brier"],6)}，总体{number(r["test_return_pooled"]["brier"],6)}。
- 测试批次日回流MAE：分组{number(r["test_cohort_daily_restock_mae"])}件/日，总体{number(r["pooled_daily_restock_mae"])}件/日，不回流基线{number(r["zero_restock_daily_mae"])}件/日。本次分组误差{return_comparison}总体。
- 测试批次预计最终回流{number(r["test_cohort_expected_restock_units"],2)}件，实际{r["test_cohort_actual_restock_units"]}件；日回流WAPE为{percent(r["test_cohort_restock_wape"])}。实际回流总量为0时，WAPE分母为0而无定义，仍可报告MAE。
- 第180日起下一周按当前状态预测：日MAE {number(r["next7_daily_mae"])}件/日；无历史支持实体数{r["next7_unsupported_entities"]}。这是另一个预测起点和口径，不与上项混比。

查看：`returns/daily_restock.svg`、`returns/test_cohort_daily_restock.csv`、`returns/state_conditioned_next7_daily.csv`。

## 3. COD：校准后也可能变差

- 测试{c["n_test"]}包裹，实际拒收率{percent(c["test_global_mean"]["observed_rate"])}。
- Brier：训练均值基线{number(c["test_global_mean"]["brier"],6)}；未校准逻辑回归{number(c["test_raw_logistic"]["brier"],6)}；验证集截距校准后{number(c["test_intercept_calibrated_logistic"]["brier"],6)}。本次校准后{calibration_comparison}，保留结果，不按测试答案反选模型。
- 验证集冻结复核阈值为{c["frozen_threshold"]:.2f}。{all_review_text}工作量为测试样本的{c["test_selected_threshold_cost"]["review_fraction"]:.0%}。
- 假想成本：按冻结阈值{c["test_selected_threshold_cost"]["simulated_cost_yuan"]:.2f}元，不复核{c["test_no_review_cost"]["simulated_cost_yuan"]:.2f}元，全复核{c["test_review_all_cost"]["simulated_cost_yuan"]:.2f}元。{same_cost_text}
- 成本假设：每包复核2元、每件拒收损失25元、复核可减少真实拒收损失的60%。未模拟复核容量或人工效果实验，数字不是已实现节省。

查看：`cod/calibration.svg`、`cod/test_calibration.csv`、`cod/validation_threshold_costs.csv`，以及三张单独的库存/在途/预期销售图。

## 4. PO：不确定的P90就留空

- 测试{o["n_test"]}条PO，截止时{o["test_right_censored"]}条未收齐；训练截止时{o["train_right_censored"]}条未收齐。
- 验证集按30天内收齐Brier选择{o["selected_model"]} KM。P50覆盖率{percent(o["km_p50"]["coverage_lower"])}，目标50%。
- P90可估计{po90["predictions_available"]}/{po90["n"]}条，不可估计{po90["n"]-po90["predictions_available"]}条，必须披露这个分母。可估计部分的实际覆盖率界为{percent(po90["coverage_lower"])}–{percent(po90["coverage_upper"])}；其中{po90["unknown_due_to_censoring"]}条观察不足以判定。P90留空原因是训练KM曲线未达到90%收齐概率；没有可估计预测时不报告覆盖率，不用0或最大观察日填补。这个区间不是统计置信区间。
- 只用已完成训练PO的朴素P90，在全测试集覆盖{percent(naive_value)}，{naive_comparison}目标90%。若训练没有已完成PO，该分位数与覆盖率均不可估计。
- 没有统一“最好模型”结论：覆盖只对有可估计预测的样本描述；仅已完成样本的pinball有选择偏差风险。

查看：`po/test_po_predictions.csv`、`po/coverage_bounds.csv`、`po/km_survival.svg`。

## 验证记录

运行命令：`python run_all.py`。测试的实际通过/失败与运行时间以 `test_results.txt`、`run_log.txt` 为准。生成清单在 `../data/manifest.json`。脚本重跑时会重写本页；本页没有把任何未运行模型列成已完成。
'''
    (root/"outputs"/"RESULTS.md").write_text(text,encoding="utf-8")

if __name__=="__main__":run()
