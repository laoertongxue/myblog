"""Contract tests: chronological labels, no future joins, and physical conservation."""
import json
import copy
import contextlib
import io
import shutil
import math
import sys
import unittest
import tempfile
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from common import SPECS,iso,read_csv,sha256,brier,group_events
from labels import labels,get_split,join_labels
from models import km_fit,km_quantile,quantile_evaluation,cod_vector,expected_return_by_state

class ProjectContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data={p:(read_csv(ROOT/"data"/p/"features.csv"),read_csv(ROOT/"data"/p/"events.csv")) for p in SPECS}
        cls.manifest=json.loads((ROOT/"data"/"manifest.json").read_text())

    def test_01_exact_entity_counts_and_unique_ids(self):
        for project,(features,_) in self.data.items():
            self.assertEqual(len(features),SPECS[project]["n"])
            self.assertEqual(len({f["entity_id"] for f in features}),len(features))
            self.assertTrue(all(f["synthetic"]=="1" for f in features))

    def test_02_recorded_hashes_match_raw_files(self):
        for project in SPECS:
            for name,digest in self.manifest["projects"][project]["hashes"].items():
                self.assertEqual(sha256(ROOT/"data"/project/name),digest)

    def test_03_features_available_before_or_at_score(self):
        forbidden=("refused","returned","complete_age","actual_delivery_day","return_reason","latent_frailty","restocked")
        for project,(features,_) in self.data.items():
            self.assertFalse(set(forbidden)&set(features[0]))
            for r in features:
                self.assertLessEqual(int(r["feature_available_day"]),int(r["score_day"]))
                self.assertEqual(int(r["score_day"]),int(r["created_day"]))
                self.assertLess(r["feature_available_at"],r["score_at"])

    def test_04_labels_mature_before_next_prediction_block(self):
        for p,s in SPECS.items():
            self.assertLess(s["train"][1],s["fit_cutoff"])
            self.assertLess(s["fit_cutoff"],s["validation"][0])
            self.assertLess(s["validation_cutoff"],s["test"][0])
            if s["maturity"]:
                self.assertLessEqual(s["train"][1]+s["maturity"],s["fit_cutoff"])
                self.assertLessEqual(s["validation"][1]+s["maturity"],s["validation_cutoff"])
                self.assertLessEqual(s["test"][1]+s["maturity"],s["cutoff"])

    def test_05_events_refer_to_valid_entities_and_times(self):
        for p,(features,events) in self.data.items():
            ids={r["entity_id"]:int(r["created_day"]) for r in features}
            unique=set()
            for e in events:
                day=int(e["event_day"])
                self.assertIn(e["entity_id"],ids)
                self.assertGreaterEqual(day,ids[e["entity_id"]])
                self.assertLessEqual(day,SPECS[p]["cutoff"])
                self.assertEqual(e["event_date"],iso(day))
                key=e["entity_id"],e["scenario"],e["sequence"]
                self.assertNotIn(key,unique);unique.add(key)
                self.assertGreater(int(e["units"]),0)

    def test_06_presale_event_span_and_competing_events(self):
        features,events=self.data["presale"]
        self.assertGreaterEqual(max(int(e["event_day"]) for e in events)-min(int(e["event_day"]) for e in events),60)
        created={f["entity_id"]:int(f["created_day"]) for f in features}
        for scenario in ("independent","informative"):
            grouped=group_events(events,419,scenario)
            self.assertEqual(len(grouped),20000)
            for entity,es in grouped.items():
                terminal=[e for e in es if e["event_type"]!="created"]
                self.assertEqual(len(terminal),1)
                age=int(terminal[0]["event_day"])-created[entity]
                self.assertLessEqual(age,60)
                if terminal[0]["event_type"]=="forced_cancel":self.assertEqual(age,60)
                if terminal[0]["event_type"]=="cancelled":self.assertLess(age,60)

    def test_07_risk_set_and_survival_invariants(self):
        for scenario in ("independent","informative"):
            rows=read_csv(ROOT/"outputs"/"presale"/f"{scenario}_risk_table.csv")
            groups=defaultdict(list)
            for r in rows:
                groups[r["group"]].append(r)
                a=int(r["at_risk_start"]);remaining=int(r["at_risk_next"])
                exits=sum(int(r[k]) for k in ("natural_cancelled","shipped","forced_cancelled","right_censored"))
                self.assertEqual(a-exits,remaining);self.assertGreaterEqual(remaining,0)
                if r["smoothed_hazard"]!="":self.assertTrue(0<=float(r["smoothed_hazard"])<=1)
                if int(r["age"])==60:self.assertEqual(r["smoothed_hazard"],"")
            for rows in groups.values():
                rows.sort(key=lambda r:int(r["age"]))
                previous=1.
                for i,r in enumerate(rows):
                    if r["no_shipping_natural_survival"]!="":
                        val=float(r["no_shipping_natural_survival"])
                        self.assertTrue(0<=val<=previous+1e-12);previous=val
                    if i+1<len(rows):self.assertEqual(int(r["at_risk_next"]),int(rows[i+1]["at_risk_start"]))

    def test_08_presale_calendar_states_conserve(self):
        for r in read_csv(ROOT/"outputs"/"presale"/"actual_state_ledger.csv"):
            for suffix in ("orders","units"):
                components=[int(r[k+"_"+suffix]) for k in ("pending","cancelled","shipped","forced_cancel")]
                self.assertTrue(all(v>=0 for v in components))
                self.assertEqual(sum(components),int(r["created_"+suffix]))

    def test_09_future_events_cannot_change_training_labels(self):
        for p,(features,events) in self.data.items():
            cutoff=SPECS[p]["fit_cutoff"]
            scenario="independent" if p=="presale" else None
            before=labels(p,features,events,cutoff,scenario)
            poisoned=[dict(e,event_day=str(cutoff+1000)) for e in events[:100]]
            after=labels(p,features,events+poisoned,cutoff,scenario)
            self.assertEqual(before,after)

    def test_10_unresolved_labels_not_false_negatives(self):
        for p in ("returns","cod"):
            features,events=self.data[p]
            rows=labels(p,features,events,179)
            unknown=[r for r in rows if r["returned" if p=="returns" else "refused"]==""]
            self.assertGreater(len(unknown),0)
        features,events=self.data["po"]
        rows=labels("po",features,events,449)
        incomplete=[r for r in rows if r["censored"]]
        self.assertGreater(len(incomplete),0)
        self.assertTrue(all(r["complete_age"]=="" and r["outstanding_units"]>0 for r in incomplete))

    def test_11_return_event_order_and_maturity_guarantee(self):
        features,events=self.data["returns"]
        for f in features:
            self.assertEqual(int(f["units"]),1)
        grouped=group_events(events,209)
        starts={r["entity_id"]:int(r["created_day"]) for r in features}
        for entity,es in grouped.items():
            times={e["event_type"]:int(e["event_day"]) for e in es}
            self.assertLessEqual(max(times.values())-starts[entity],29)
            if "restocked" in times:
                self.assertIn("quality_passed",times)
                self.assertNotIn("quality_failed",times)
                self.assertLess(times["warehouse_received"],times["quality_passed"])
                self.assertLess(times["quality_passed"],times["restocked"])

    def test_12_return_inventory_conservation_and_cold_scenario(self):
        for r in read_csv(ROOT/"outputs"/"returns"/"actual_physical_stock_ledger.csv"):
            quantities=[int(r[k]) for k in ("on_hand","customer_or_outbound","return_in_transit","in_qc","scrapped")]
            self.assertTrue(all(q>=0 for q in quantities));self.assertEqual(sum(quantities),12000)
        for r in read_csv(ROOT/"outputs"/"returns"/"state_conditioned_next7_daily.csv"):
            self.assertEqual(float(r["fresh_food_no_resale_scenario_units"]),0)
            self.assertEqual(int(r["unsupported_entities"]),0)

    def test_13_return_probability_mass_and_no_double_count(self):
        for r in read_csv(ROOT/"outputs"/"returns"/"test_cohort_predictions.csv"):
            self.assertTrue(0<=float(r["p_eventual_restock"])<=float(r["p_return"])<=1)
        sums=defaultdict(float)
        for r in read_csv(ROOT/"outputs"/"returns"/"state_conditioned_next7_entity_forecast.csv"):
            if r["expected_restock_units"]!="":sums[r["entity_id"]]+=float(r["expected_restock_units"])
        self.assertTrue(all(0<=v<=1+1e-10 for v in sums.values()))
        current=read_csv(ROOT/"outputs"/"returns"/"live_labels_asof179.csv")
        for r in current:
            if r["status"] in ("restocked","quality_failed"):
                self.assertEqual(sums[r["entity_id"]],0)

    def test_14_cod_probabilities_and_frozen_selection(self):
        path=ROOT/"outputs"/"cod"
        selection=json.loads((path/"model_selection.json").read_text())
        costs=read_csv(path/"validation_threshold_costs.csv")
        best=min(costs,key=lambda r:float(r["simulated_cost_yuan"]))
        self.assertEqual(selection["selected_threshold"],float(best["threshold"]))
        self.assertFalse(selection["test_used_for_selection"])
        for r in read_csv(path/"probability_ledger.csv"):
            self.assertEqual(r["model_selection_sha256"],sha256(path/"model_selection.json"))
            for key in ("raw_probability","calibrated_probability","baseline_probability"):
                self.assertTrue(0<=float(r[key])<=1)
        f=self.data["cod"][0][0]
        self.assertEqual(cod_vector(f),cod_vector({**f,"actual_refused":1,"future_delivery_day":9999}))

    def test_15_cod_physical_inventory_never_discounted_by_probability(self):
        for r in read_csv(ROOT/"outputs"/"cod"/"actual_inventory_and_expected_sales.csv"):
            physical=[int(r[k]) for k in ("on_hand","outbound","delivered_paid","refused_returning","in_qc","scrapped")]
            self.assertTrue(all(q>=0 for q in physical));self.assertEqual(sum(physical),40000)
            self.assertEqual(int(r["on_hand"]),40000-int(r["shipped_cumulative"])+int(r["restocked_cumulative"]))

    def test_16_po_partial_receipts_and_conservation(self):
        features,events=self.data["po"]
        grouped=group_events(events,449)
        partial=0
        for f in features:
            qty=int(f["ordered_units"]);total=0
            for e in grouped[f["entity_id"]]:
                if e["event_type"]=="received":
                    total+=int(e["units"]);self.assertLessEqual(total,qty)
                    if total<qty:partial+=1
        self.assertGreater(partial,0)
        for r in read_csv(ROOT/"outputs"/"po"/"all_po_final_status.csv"):
            self.assertEqual(int(r["ordered_units"]),int(r["received_units"])+int(r["outstanding_units"]))
        for r in read_csv(ROOT/"outputs"/"po"/"partial_receipt_ledger.csv"):
            self.assertEqual(int(r["ordered_units_cumulative"]),int(r["received_units_cumulative"])+int(r["outstanding_units"]))
        self.assert_po_label_consistency(features,events,read_csv(ROOT/"outputs"/"po"/"all_po_final_status.csv"),449)
        self.assert_po_label_consistency(features,events,read_csv(ROOT/"outputs"/"po"/"training_labels_asof179.csv"),179)
        predictions=read_csv(ROOT/"outputs"/"po"/"test_po_predictions.csv")
        converted=[{**r,"complete_age":r["observed_complete_age"],"observed_age":r["observed_followup_days"]} for r in predictions]
        self.assert_po_label_consistency(features,events,converted,449)

    def assert_po_label_consistency(self,features,events,rows,cutoff):
        """Independent reconciliation against the exact final partial-receipt event."""
        byid={r["entity_id"]:r for r in features}
        grouped=group_events(events,cutoff)
        for r in rows:
            f=byid[r["entity_id"]];created=int(f["created_day"]);ordered=int(f["ordered_units"])
            receipts=[e for e in grouped[r["entity_id"]] if e["event_type"]=="received"]
            self.assertLessEqual(len(receipts),3)
            self.assertEqual([int(e["sequence"]) for e in receipts],list(range(1,len(receipts)+1)))
            days=[int(e["event_day"]) for e in receipts]
            self.assertTrue(all(a<b for a,b in zip(days,days[1:])))
            received=0;completion=None
            for e in receipts:
                received+=int(e["units"])
                self.assertLessEqual(received,ordered)
                if received==ordered:completion=int(e["event_day"])-created
            self.assertEqual(int(r["received_units"]),received)
            self.assertEqual(int(r["outstanding_units"]),ordered-received)
            self.assertEqual(int(r["observed_age"]),cutoff-created)
            self.assertEqual(int(r["completed"]),int(completion is not None))
            if completion is None:self.assertEqual(r["complete_age"],"")
            else:
                self.assertEqual(len(receipts),3)
                self.assertEqual(int(r["complete_age"]),completion)
                self.assertEqual(int(r["complete_age"]),int(receipts[2]["event_day"])-created)

    def test_17_km_handles_unknown_tail_and_ties(self):
        rows=[{"completed":1,"complete_age":2,"observed_age":5},
              {"completed":0,"complete_age":"","observed_age":2},
              {"completed":1,"complete_age":4,"observed_age":5},
              {"completed":0,"complete_age":"","observed_age":5}]
        curve=km_fit(rows)
        self.assertAlmostEqual(curve[0]["survival_not_fully_received"],.75)
        self.assertAlmostEqual(curve[1]["survival_not_fully_received"],.375)
        self.assertEqual(km_quantile(curve,.5),4)
        self.assertIsNone(km_quantile(curve,.9))
        ev=quantile_evaluation(rows,[3,3,3,3],.9)
        self.assertEqual(ev["coverage_lower"],.25);self.assertEqual(ev["coverage_upper"],.5)
        undefined=quantile_evaluation(rows,[None]*len(rows),.9)
        self.assertIsNone(undefined["coverage_lower"])
        self.assertEqual(undefined["unknown_due_to_censoring"],0)
        self.assertIn("No quantile prediction",undefined["warning"])

    def test_18_hand_calculations(self):
        self.assertAlmostEqual(brier([.8,.2,.6,.4],[1,0,0,1]),.2)
        self.assertAlmostEqual(brier([.8,.2],[1,0]),.04)
        self.assertAlmostEqual(.9*.9,.81)
        self.assertAlmostEqual((1+8*.1)/(2+8),.18)
        self.assertAlmostEqual(80*.54/.72,60)
        self.assertAlmostEqual(100*.2*.8*.4+50*.2*.8*.6,11.2)
        self.assertEqual(100-100+18,18)

    def test_19_summary_changes_when_metric_direction_changes(self):
        from evaluate import write_results_summary
        m=json.loads((ROOT/"outputs"/"all_metrics.json").read_text())
        changed=copy.deepcopy(m)
        changed["cod"]["test_intercept_calibrated_logistic"]["brier"]=0.01
        changed["cod"]["test_raw_logistic"]["brier"]=0.02
        changed["cod"]["frozen_threshold"]=0.55
        changed["cod"]["test_selected_threshold_cost"]["simulated_cost_yuan"]=100.
        changed["presale"]["informative"]["test_smoothed_hazard_brier"]=0.001
        changed["presale"]["informative"]["test_pooled_hazard_brier"]=0.002
        changed["returns"]["test_cohort_daily_restock_mae"]=0.1
        changed["returns"]["pooled_daily_restock_mae"]=0.2
        changed["po"]["km_p90"].update(predictions_available=0,coverage_lower=None,coverage_upper=None)
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp);(target/"outputs").mkdir();(target/"data").mkdir()
            (target/"data"/"manifest.json").write_text('{"seed": 7}')
            write_results_summary(target,changed)
            text=(target/"outputs"/"RESULTS.md").read_text()
            self.assertIn("本次校准后改善",text)
            self.assertIn("本次平滑误差低于总体",text)
            self.assertIn("本次分组误差低于总体",text)
            self.assertIn("冻结复核阈值为0.55",text)
            self.assertNotIn("本次选到0，即全部建议复核",text)
            self.assertNotIn("冻结策略与全复核相同",text)
            self.assertIn("本次种子为7",text)
            self.assertIn("覆盖率界为无定义/不可估计–无定义/不可估计",text)

    def test_20_alternate_seed_runs_and_report_matches(self):
        from generate import generate
        from evaluate import run
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            target=Path(tmp)
            alternate_seed=self.manifest["seed"]+1
            manifest=generate(target,seed=alternate_seed)
            metrics=run(target)
            self.assertEqual(manifest["seed"],alternate_seed)
            for p in SPECS:
                self.assertEqual(manifest["projects"][p]["feature_rows"],SPECS[p]["n"])
                self.assertNotEqual(manifest["projects"][p]["hashes"]["features.csv"],
                                    self.manifest["projects"][p]["hashes"]["features.csv"])
            text=(target/"outputs"/"RESULTS.md").read_text()
            cal=metrics["cod"]["test_intercept_calibrated_logistic"]["brier"]
            raw=metrics["cod"]["test_raw_logistic"]["brier"]
            self.assertIn("本次校准后"+("改善" if cal<raw else "未改善"),text)
            threshold=metrics["cod"]["frozen_threshold"]
            self.assertIn(f"冻结复核阈值为{threshold:.2f}",text)
            self.assertIn(f"本次种子为{alternate_seed}",text)

    def test_21_zero_test_returns_has_undefined_wape_not_crash(self):
        from evaluate import returns,write_results_summary
        from common import write_csv
        features,events=self.data["returns"]
        test_ids={r["entity_id"] for r in features if r["split"]=="test"}
        altered=[e for e in events if e["entity_id"] not in test_ids or e["event_type"] in ("shipped","delivered")]
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp);shutil.copytree(ROOT/"data",target/"data")
            write_csv(target/"data"/"returns"/"events.csv",altered)
            results=returns(target)
            self.assertEqual(results["test_cohort_actual_restock_units"],0)
            self.assertIsNone(results["test_cohort_restock_wape"])
            combined=json.loads((ROOT/"outputs"/"all_metrics.json").read_text());combined["returns"]=results
            write_results_summary(target,combined)
            text=(target/"outputs"/"RESULTS.md").read_text()
            self.assertIn("日回流WAPE为无定义/不可估计",text)
            self.assertIn("WAPE分母为0而无定义",text)

    def test_22_all_training_po_censored_has_no_fabricated_quantiles(self):
        from evaluate import po,write_results_summary
        from common import write_csv
        features,events=self.data["po"]
        train_ids={r["entity_id"] for r in features if r["split"]=="train"}
        altered=[e for e in events if e["entity_id"] not in train_ids or e["event_type"]=="ordered"]
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp);shutil.copytree(ROOT/"data",target/"data")
            write_csv(target/"data"/"po"/"events.csv",altered)
            results=po(target)
            for name in ("km_p50","km_p90","completed_only_naive_p50","completed_only_naive_p90"):
                self.assertEqual(results[name]["predictions_available"],0)
                self.assertIsNone(results[name]["coverage_lower"])
            combined=json.loads((ROOT/"outputs"/"all_metrics.json").read_text());combined["po"]=results
            write_results_summary(target,combined)
            text=(target/"outputs"/"RESULTS.md").read_text()
            self.assertIn("P50覆盖率无定义/不可估计",text)
            self.assertIn("训练KM曲线未达到90%收齐概率",text)

    def test_23_po_age_shift_and_receipt_reordering_are_detected(self):
        features,events=self.data["po"]
        rows=read_csv(ROOT/"outputs"/"po"/"all_po_final_status.csv")
        altered=copy.deepcopy(rows)
        victim=next(r for r in altered if r["completed"]=="1")
        victim["complete_age"]=str(int(victim["complete_age"])-1)
        with self.assertRaises(AssertionError):self.assert_po_label_consistency(features,events,altered,449)
        bad_events=copy.deepcopy(events)
        receipts=[e for e in bad_events if e["entity_id"]==victim["entity_id"] and e["event_type"]=="received"]
        receipts[0]["event_day"]=str(int(receipts[1]["event_day"])+1)
        receipts[0]["event_date"]=iso(receipts[0]["event_day"])
        with self.assertRaises(AssertionError):self.assert_po_label_consistency(features,bad_events,rows,449)

if __name__=="__main__":unittest.main(verbosity=2)
