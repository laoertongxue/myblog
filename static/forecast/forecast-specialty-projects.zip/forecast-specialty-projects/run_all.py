"""Run from any directory: python /path/to/forecast-specialty-projects/run_all.py"""
import argparse
import platform
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"src"))

def main():
    parser=argparse.ArgumentParser(description="Generate and evaluate synthetic supply-chain projects, offline.")
    parser.add_argument("--skip-generate",action="store_true",help="Use existing raw CSVs.")
    parser.add_argument("--skip-tests",action="store_true",help="Skip tests; not recommended for final verification.")
    parser.add_argument("--seed",type=int,default=20261106,help="Synthetic experiment seed (default: 20261106).")
    args=parser.parse_args()
    if not args.skip_generate:
        from generate import generate
        generate(ROOT,seed=args.seed)
    from evaluate import run
    run(ROOT)
    if not args.skip_tests:
        suite=unittest.defaultTestLoader.discover(str(ROOT/"tests"))
        with (ROOT/"outputs"/"test_results.txt").open("w",encoding="utf-8") as log:
            result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
        print((ROOT/"outputs"/"test_results.txt").read_text(encoding="utf-8"))
        if not result.wasSuccessful():raise SystemExit(1)
        from common import write_json,sha256
        write_json(ROOT/"outputs"/"verification.json",{
            "python_version":platform.python_version(),"test_count":result.testsRun,
            "all_tests_passed":result.wasSuccessful(),"synthetic_only":True,
            "source_sha256":{str(p.relative_to(ROOT)):sha256(p) for p in sorted((ROOT/"src").glob("*.py"))},
            "test_sha256":sha256(ROOT/"tests"/"test_project.py"),
            "runner_sha256":sha256(ROOT/"run_all.py"),
            "data_manifest_sha256":sha256(ROOT/"data"/"manifest.json"),
            "metrics_sha256":sha256(ROOT/"outputs"/"all_metrics.json")})
    print("Complete. See outputs/all_metrics.json and README.md. All data are simulated.")

if __name__=="__main__":main()
