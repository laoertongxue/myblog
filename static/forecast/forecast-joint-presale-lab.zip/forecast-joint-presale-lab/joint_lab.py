#!/usr/bin/env python3
"""Joint finite presale/source planning teaching example. No external execution."""
import argparse,csv,hashlib,itertools,json,math
from copy import deepcopy
from pathlib import Path
import base_core as base
ROOT=Path(__file__).resolve().parent
EPS=1e-8

def day_offset(v,h,label):
    if isinstance(v,bool) or not isinstance(v,int) or not 0<=v<h:raise ValueError('INVALID_'+label+'_DAY_OFFSET')
    return v

def load():
    bc=json.loads((ROOT/'data/config.json').read_text());jc=json.loads((ROOT/'data/joint_config.json').read_text())
    cutoff=jc['cutoff'];target=bc['target_date'];snaps=base.csvread('snapshots.csv');master=base.csvread('master.csv');base.unique_master(master)
    p=base.pipeline(base.csvread('pos.csv'),snaps,bc,cutoff)
    get=lambda sy,k:float(base.asof_snapshot(snaps,sy,k,target,cutoff)['value'])
    inv=base.inventory([r for r in base.csvread('inventory.csv') if r['sku']==jc['sku']],cutoff)
    if inv['sellable']!=get('WMS','sellable'):raise ValueError('WMS_COUNT_SNAPSHOT_MISMATCH')
    bom=base.bom_at(base.csvread('bom.csv'),target,cutoff)
    pres=base.csvread('presale.csv');summary=base.presale(pres,cutoff)
    scenarios=[dict(name=r['scenario'],net=float(r['retained']),probability=float(r['probability']),known_at=r['known_at']) for r in pres if r['known_at']<=cutoff]
    src=[]
    for row in base.csvread('joint_sources.csv'):
        if row['known_at']>cutoff:raise ValueError('SOURCE_NOT_YET_KNOWN')
        src.append({k:(float(v) if k in ['cap','unit_cost','fixed_cost','moq'] else int(v) if k=='arrival_day_offset' else v) for k,v in row.items()})
    h=len(p['daily_forecast']);firm_day=day_offset(bc['firm_reservation_due_day_offset'],h,'FIRM');inbound_day=day_offset(bc['inbound_arrival_day_offset'],h,'INBOUND');firm=[0.0]*h;firm[firm_day]=get('OMS','firm_walkin_excluded')
    inbound=[0.0]*h;inbound[inbound_day]=get('WMS','firm_inbound')
    return dict(config=jc,base_config=bc,cutoff=cutoff,forecast=p['daily_forecast'],initial=inv['sellable'],firm=firm,inbound=inbound,bom=bom,resources=bc['sources'],mes_capacity=get('MES','capacity'),sources=src,scenarios=scenarios,presale_summary=summary,pipeline_forecast_hash=p['input_hash'])

def finite_nonnegative(x,label):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or x<0:raise ValueError('INVALID_'+label)

def validate(x):
    c=x['config'];h=len(x['forecast'])
    if c['known_at']>x['cutoff']:raise ValueError('CONFIG_NOT_YET_KNOWN')
    if c['currency']!='CNY':raise ValueError('UNSUPPORTED_CURRENCY')
    if c['sku']!='T-L' or len(x['firm'])!=h or len(x['inbound'])!=h or len(c['receiving_capacity'])!=h:raise ValueError('HORIZON_OR_SKU_MISMATCH')
    if c['minimum_terminal_reserve']!=0:raise ValueError('RESERVE_NOT_IMPLEMENTED_IN_THIS_SCENARIO_MODEL')
    if isinstance(c['quantity_step'],bool) or not isinstance(c['quantity_step'],int) or c['quantity_step']<=0:raise ValueError('INVALID_QUANTITY_STEP')
    day_offset(c['presale_due_day_offset'],h,'PRESALE')
    if isinstance(c['max_candidate_count'],bool) or not isinstance(c['max_candidate_count'],int) or not 1<=c['max_candidate_count']<=100000:raise ValueError('INVALID_CANDIDATE_LIMIT')
    for k in ['storage_capacity','shortage_cost_per_unit','terminal_excess_cost_per_unit']:finite_nonnegative(c[k],k.upper())
    for q in [x['initial'],x['mes_capacity']]+x['forecast']+x['firm']+x['inbound']+c['receiving_capacity']:finite_nonnegative(q,'QUANTITY')
    if sorted(r['source'] for r in x['sources'])!=['PO','STO','WO']:raise ValueError('SOURCE_CARDINALITY')
    for k in ['po_cap','sto_remote_stock','sto_reserve','wo_cap','syrup_kg','film_m','bottles']:finite_nonnegative(x['resources'][k],'RESOURCE_'+k.upper())
    if set(x['bom'])!={'R-SYRUP','R-FILM','R-BOTTLE'}:raise ValueError('BOM_CARDINALITY')
    for k,v in x['bom'].items():
        finite_nonnegative(v,'BOM_'+k)
        if v==0:raise ValueError('ZERO_BOM_QUANTITY')
    for r in x['sources']:
        if r['unit']!='ea':raise ValueError('SOURCE_UNIT_MISMATCH')
        if r['known_at']>x['cutoff']:raise ValueError('SOURCE_NOT_YET_KNOWN')
        for k in ['cap','unit_cost','fixed_cost','moq']:finite_nonnegative(r[k],'SOURCE_'+k.upper())
        if isinstance(r['arrival_day_offset'],bool) or not isinstance(r['arrival_day_offset'],int) or r['arrival_day_offset']<0:raise ValueError('INVALID_ARRIVAL_DAY')
    if len({s['name'] for s in x['scenarios']})!=len(x['scenarios']) or not x['scenarios']:raise ValueError('SCENARIO_CARDINALITY')
    if any(s['known_at']>x['cutoff'] for s in x['scenarios']):raise ValueError('SCENARIO_NOT_YET_KNOWN')
    for s in x['scenarios']:
        finite_nonnegative(s['net'],'NET_RETAINED');finite_nonnegative(s['probability'],'PROBABILITY')
        if s['net']>x['presale_summary']['gross_orders']:raise ValueError('NET_EXCEEDS_GROSS')
    if abs(sum(s['probability'] for s in x['scenarios'])-1)>EPS:raise ValueError('SCENARIO_PROBABILITIES_NOT_ONE')
    if x['resources']['sto_remote_stock']<x['resources']['sto_reserve']:raise ValueError('REMOTE_RESERVE_EXCEEDS_STOCK')
    return True

def choices(x):
    c=x['config'];step=c['quantity_step'];r=x['resources'];h=len(x['forecast']);source_cap={
      'PO':r['po_cap'],'STO':r['sto_remote_stock']-r['sto_reserve'],
      'WO':min(r['wo_cap'],x['mes_capacity'])}
    bounds=[];count=1
    for s in x['sources']:
        cap=min(s['cap'],source_cap[s['source']]);cap=0 if s['arrival_day_offset']>=h else cap
        maximum=math.floor(cap/step);minimum=max(1,math.ceil(s['moq']/step))
        count*=1+max(0,maximum-minimum+1)
        if count>c['max_candidate_count']:raise ValueError('CANDIDATE_LIMIT_EXCEEDED')
        bounds.append((minimum,maximum))
    result=[[0]+[i*step for i in range(low,high+1)] for low,high in bounds]

    return result

def evaluate(x,q,hard_service=False):
    """q has one number per source and is shared by every possible scenario."""
    c=x['config'];h=len(x['forecast']);src=x['sources'];plan=dict(zip([r['source'] for r in src],q));r=x['resources'];w=plan['WO']
    materials={'syrup_kg':w*x['bom']['R-SYRUP'],'film_m':w*x['bom']['R-FILM'],'bottles':w*x['bom']['R-BOTTLE']}
    if any(materials[k]>r[k]+EPS for k in materials):return None,'MATERIAL_LIMIT'
    receipts=x['inbound'].copy()
    for s,qty in zip(src,q):
        if qty and s['arrival_day_offset']>=h:return None,'LATE_SOURCE'
        if qty:receipts[s['arrival_day_offset']]+=qty
    if any(a>b+EPS for a,b in zip(receipts,c['receiving_capacity'])):return None,'RECEIVING_LIMIT'
    procurement=sum(s['unit_cost']*qty+(s['fixed_cost'] if qty else 0) for s,qty in zip(src,q))
    details=[];expected_penalty=0
    for scenario in x['scenarios']:
        stock=x['initial'];lost_total=0;days=[]
        for t in range(h):
            opening=stock+receipts[t]
            if opening>c['storage_capacity']+EPS:return None,'STORAGE_LIMIT'
            presale=scenario['net'] if t==c['presale_due_day_offset'] else 0
            demand=x['forecast'][t]+x['firm'][t]+presale;served=min(opening,demand);lost=demand-served;stock=opening-served;lost_total+=lost
            days.append(dict(day=t,opening=opening,receipts=receipts[t],walkin=x['forecast'][t],firm=x['firm'][t],presale=presale,demand=demand,served=served,lost=lost,closing=stock))
            assert abs(opening-served-stock)<EPS
        if hard_service and scenario['probability']>0 and lost_total>EPS:return None,'HARD_SERVICE_SHORTAGE'
        penalty=c['shortage_cost_per_unit']*lost_total+c['terminal_excess_cost_per_unit']*stock
        expected_penalty+=scenario['probability']*penalty
        details.append(dict(scenario=scenario['name'],probability=scenario['probability'],net_retained=scenario['net'],lost=lost_total,terminal=stock,penalty=penalty,total_cost=procurement+penalty,days=days,source_quantities=plan))
    return dict(plan=plan,total_quantity=sum(q),source_cost=procurement,expected_penalty=expected_penalty,expected_total_cost=procurement+expected_penalty,materials=materials,receipts=receipts,expected_lost=sum(s['probability']*s['lost'] for s in details),expected_terminal=sum(s['probability']*s['terminal'] for s in details),scenarios=details),None

def solve(x,hard_service=False):
    validate(x);grid=choices(x);feasible=[];rejected={};evaluated=0
    for q in itertools.product(*grid):
        evaluated+=1;record,reason=evaluate(x,q,hard_service)
        if reason:rejected[reason]=rejected.get(reason,0)+1
        else:feasible.append(record)
    feasible.sort(key=lambda r:(round(r['expected_total_cost'],10),r['total_quantity'],r['plan']['PO'],r['plan']['STO'],r['plan']['WO']))
    return dict(status='OPTIMAL_IN_FINITE_GRID' if feasible else 'INFEASIBLE_IN_FINITE_GRID',hard_service=hard_service,input_hash=base.digest(x),enumerated=evaluated,feasible=len(feasible),rejected=rejected,best=feasible[0] if feasible else None,top5=feasible[:5],all_feasible_cost_rows=[{k:r[k] for k in ['plan','total_quantity','source_cost','expected_penalty','expected_total_cost']} for r in feasible])

def min_sources_at_quantity(x,quantity):
    validate(x);valid=[]
    for q in itertools.product(*choices(x)):
        if sum(q)!=quantity:continue
        r,reason=evaluate(x,q)
        if not reason:valid.append(r)
    return min(valid,key=lambda r:r['source_cost']) if valid else None

def variants(x):
    v={}
    y=deepcopy(x);y['config']['receiving_capacity'][2]=210;v['capacity_210_soft']=solve(y)
    y=deepcopy(x);y['config']['receiving_capacity'][2]=240;v['capacity_240_hard']=solve(y,True)
    y=deepcopy(x);y['config']['receiving_capacity'][2]=240;v['capacity_240_soft']=solve(y)
    y=deepcopy(x);next(s for s in y['sources'] if s['source']=='STO')['arrival_day_offset']=3;v['sto_late_soft']=solve(y);v['sto_late_hard']=solve(y,True)
    y=deepcopy(x);y['resources']['film_m']=10;v['film_10_soft']=solve(y)
    y=deepcopy(x);next(s for s in y['sources'] if s['source']=='PO')['unit_cost']=5;v['po_cost_5_soft']=solve(y)
    y=deepcopy(x);y['inbound']=[0,0,60];v['existing_inbound_late_hard']=solve(y,True)
    y=deepcopy(x);y['scenarios'][0]['probability']=.1;y['scenarios'][1]['probability']=.2;y['scenarios'][2]['probability']=.7;v['high_retention_prob_70pct']=solve(y)
    return v

def run():
    x=load();normal=solve(x);hard=solve(x,True)
    deterministic_gap=sum(x['forecast'])+sum(x['firm'])-x['initial']-sum(x['inbound'])
    separate_hedge=x['presale_summary']['optimum']['quantity'];separate_total=math.ceil((deterministic_gap+separate_hedge)/x['config']['quantity_step'])*x['config']['quantity_step'];separate=min_sources_at_quantity(x,separate_total)
    oracle=0;oracle_rows=[];oracle_feasible=True
    for sc in x['scenarios']:
        y=deepcopy(x);y['scenarios']=[dict(sc,probability=1)];r=solve(y);b=r['best']
        if b:oracle+=sc['probability']*b['expected_total_cost']
        elif sc['probability']>0:oracle_feasible=False
        oracle_rows.append(dict(scenario=sc['name'],probability=sc['probability'],status=r['status'],plan=b['plan'] if b else None,quantity=b['total_quantity'] if b else None,cost=b['expected_total_cost'] if b else None))
    return dict(synthetic_only=True,external_execution=False,production_ready=False,requirement='A07',input_contract=x,normal=normal,hard=hard,separate_hedge=dict(base_deterministic_gap=deterministic_gap,presale_hedge=separate_hedge,total_quantity=separate_total,result=separate),oracle_forbidden_in_real_decision=dict(expected_cost=oracle if oracle_feasible else None,scenario_specific_plans=oracle_rows,warning='Uses unknown future retention, so is only a lower-bound diagnostic.'),variants=variants(x),input_files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'data').glob('*')) if p.is_file()},boundary='One SKU, three days, fixed source arrival days, three presale scenarios, one common integer source plan; not a general production MRP/APS/MEIO solver.')

def tests():
    import unittest
    class T(unittest.TestCase):
      def setUp(self):self.x=load()
      def test_optimum(self):
        r=solve(self.x);self.assertEqual(r['best']['plan'],{'PO':102,'STO':60,'WO':90});self.assertAlmostEqual(r['best']['expected_total_cost'],651);self.assertEqual(r['best']['total_quantity'],252)
      def test_expected_components(self):
        r=solve(self.x)['best'];self.assertEqual(r['source_cost'],593);self.assertAlmostEqual(r['expected_penalty'],58);self.assertAlmostEqual(r['expected_lost'],5.4);self.assertAlmostEqual(r['expected_terminal'],7.4)
      def test_same_plan_all_scenarios(self):
        r=solve(self.x)['best'];self.assertTrue(all(s['source_quantities']==r['plan'] for s in r['scenarios']))
      def test_calendar(self):
        r=solve(self.x)['best'];self.assertEqual([s['terminal'] for s in r['scenarios']],[32,2,0]);self.assertEqual([s['lost'] for s in r['scenarios']],[0,0,18]);self.assertEqual(r['scenarios'][0]['days'][0]['closing'],63);self.assertEqual(r['scenarios'][0]['days'][1]['closing'],6)
      def test_materials(self):self.assertEqual(solve(self.x)['best']['materials'],{'syrup_kg':18,'film_m':22.5,'bottles':90})
      def test_hard_service(self):
        r=solve(self.x,True)['best'];self.assertEqual(r['total_quantity'],270);self.assertAlmostEqual(r['expected_total_cost'],687)
      def test_hard_infeasible_capacity(self):
        self.x['config']['receiving_capacity'][2]=240;self.assertEqual(solve(self.x,True)['status'],'INFEASIBLE_IN_FINITE_GRID')
      def test_soft_capacity(self):
        self.x['config']['receiving_capacity'][2]=210;r=solve(self.x)['best'];self.assertEqual(r['total_quantity'],210);self.assertAlmostEqual(r['expected_total_cost'],787)
      def test_late_source(self):
        self.x['sources'][1]['arrival_day_offset']=3;r=solve(self.x)['best'];self.assertEqual(r['plan']['STO'],0);self.assertAlmostEqual(r['expected_total_cost'],835)
      def test_late_existing_inbound(self):
        self.x['inbound']=[0,0,60];self.assertEqual(solve(self.x,True)['status'],'INFEASIBLE_IN_FINITE_GRID')
      def test_material_perturbation(self):
        self.x['resources']['film_m']=10;self.assertLessEqual(solve(self.x)['best']['plan']['WO'],36)
      def test_zero_mes_capacity(self):
        self.x['mes_capacity']=0;self.assertEqual(solve(self.x)['best']['plan']['WO'],0)
      def test_probability_fault(self):
        self.x['scenarios'][0]['probability']=.9
        with self.assertRaisesRegex(ValueError,'PROBABILITIES'):solve(self.x)
      def test_future_scenario(self):
        self.x['scenarios'][0]['known_at']='2099-01-01T00:00:00Z'
        with self.assertRaisesRegex(ValueError,'NOT_YET'):solve(self.x)
      def test_unknown_source_time(self):
        self.x['sources'][0]['known_at']='2099-01-01T00:00:00Z'
        with self.assertRaisesRegex(ValueError,'NOT_YET'):solve(self.x)
      def test_duplicate_source(self):
        self.x['sources'][1]['source']='PO'
        with self.assertRaisesRegex(ValueError,'CARDINALITY'):solve(self.x)
      def test_negative_cost(self):
        self.x['sources'][0]['unit_cost']=-1
        with self.assertRaisesRegex(ValueError,'INVALID'):solve(self.x)
      def test_nan(self):
        self.x['scenarios'][0]['net']=float('nan')
        with self.assertRaisesRegex(ValueError,'INVALID'):solve(self.x)
      def test_no_silent_ss(self):
        self.x['config']['minimum_terminal_reserve']=28.58
        with self.assertRaisesRegex(ValueError,'RESERVE_NOT_IMPLEMENTED'):solve(self.x)
      def test_storage(self):
        self.x['config']['storage_capacity']=250;self.assertEqual(solve(self.x)['best']['total_quantity'],240)
      def test_full_enumeration(self):
        r=solve(self.x);self.assertEqual(r['enumerated'],3520);self.assertEqual(r['enumerated'],r['feasible']+sum(r['rejected'].values()));self.assertTrue(all(z['expected_total_cost']>=651-EPS for z in r['all_feasible_cost_rows']))
      def test_separate_is_worse(self):
        r=min_sources_at_quantity(self.x,270);self.assertAlmostEqual(r['expected_total_cost']-solve(self.x)['best']['expected_total_cost'],36)
      def test_resource_nan(self):
        self.x['resources']['film_m']=float('nan')
        with self.assertRaisesRegex(ValueError,'RESOURCE'):solve(self.x)
      def test_negative_resource(self):
        self.x['resources']['po_cap']=-1
        with self.assertRaisesRegex(ValueError,'RESOURCE'):solve(self.x)
      def test_bom_negative(self):
        self.x['bom']['R-SYRUP']=-.2
        with self.assertRaisesRegex(ValueError,'BOM'):solve(self.x)
      def test_bom_nan(self):
        self.x['bom']['R-SYRUP']=float('nan')
        with self.assertRaisesRegex(ValueError,'BOM'):solve(self.x)
      def test_source_unit(self):
        self.x['sources'][0]['unit']='box'
        with self.assertRaisesRegex(ValueError,'UNIT'):solve(self.x)
      def test_net_exceeds_gross(self):
        self.x['scenarios'][2]['net']=101
        with self.assertRaisesRegex(ValueError,'NET_EXCEEDS'):solve(self.x)
      def test_negative_day_offset(self):
        with self.assertRaisesRegex(ValueError,'DAY_OFFSET'):day_offset(-1,3,'INBOUND')
      def test_offset_after_horizon(self):
        with self.assertRaisesRegex(ValueError,'DAY_OFFSET'):day_offset(3,3,'FIRM')
      def test_wrong_inventory_sku(self):
        rows=[dict(r,sku='OTHER') for r in base.csvread('inventory.csv')]
        with self.assertRaisesRegex(ValueError,'CARDINALITY'):base.inventory([r for r in rows if r['sku']=='T-L'],self.x['cutoff'])
      def test_boolean_presale_day(self):
        self.x['config']['presale_due_day_offset']=True
        with self.assertRaisesRegex(ValueError,'DAY_OFFSET'):solve(self.x)
      def test_boolean_step(self):
        self.x['config']['quantity_step']=True
        with self.assertRaisesRegex(ValueError,'QUANTITY_STEP'):solve(self.x)
      def test_nan_candidate_limit(self):
        self.x['config']['max_candidate_count']=float('nan')
        with self.assertRaisesRegex(ValueError,'CANDIDATE_LIMIT'):solve(self.x)
      def test_no_physically_feasible_plan(self):
        self.x['config']['storage_capacity']=100
        self.assertEqual(solve(self.x)['status'],'INFEASIBLE_IN_FINITE_GRID')
      def test_large_candidate_grid_rejected_before_allocating(self):
        self.x['resources']['po_cap']=1e12;self.x['sources'][0]['cap']=1e12
        with self.assertRaisesRegex(ValueError,'CANDIDATE_LIMIT'):solve(self.x)
      def test_hash_change(self):
        a=solve(self.x)['input_hash'];self.x['sources'][0]['unit_cost']=4;self.assertNotEqual(a,solve(self.x)['input_hash'])
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(T))
    if not result.wasSuccessful():raise SystemExit(1)
    return result.testsRun

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--self-test',action='store_true');p.add_argument('--output-dir',type=Path,default=ROOT/'output');args=p.parse_args()
    count=tests() if args.self_test else None;r=run();r['tests_passed']=count;args.output_dir.mkdir(parents=True,exist_ok=True)
    base.jwrite(args.output_dir/'report.json',r)
    rows=[]
    for z in r['normal']['all_feasible_cost_rows']:rows.append(dict(**z['plan'],total_quantity=z['total_quantity'],source_cost=z['source_cost'],expected_penalty=z['expected_penalty'],expected_total_cost=z['expected_total_cost']))
    base.csvwrite(args.output_dir/'all_candidates.csv',rows,['PO','STO','WO','total_quantity','source_cost','expected_penalty','expected_total_cost'])
    calendar=[]
    for sc in (r['normal']['best']['scenarios'] if r['normal']['best'] else []):
        for day in sc['days']:calendar.append(dict(scenario=sc['scenario'],probability=sc['probability'],**day))
    base.csvwrite(args.output_dir/'scenario_calendar.csv',calendar,['scenario','probability','day','opening','receipts','walkin','firm','presale','demand','served','lost','closing'])
    print(json.dumps(dict(tests_passed=count,status=r['normal']['status'],plan=r['normal']['best']['plan'] if r['normal']['best'] else None,expected_cost=r['normal']['best']['expected_total_cost'] if r['normal']['best'] else None,external_execution=False)))
if __name__=='__main__':main()
