import sys,copy,itertools,json,csv,tempfile,shutil,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]));import joint_lab as j
x=j.load()
def independent(z,hard=False):
 c=z['config'];src={s['source']:s for s in z['sources']};r=z['resources'];step=c['quantity_step'];h=len(z['forecast']);out=[];count=0
 caps=[min(src['PO']['cap'],r['po_cap']),min(src['STO']['cap'],r['sto_remote_stock']-r['sto_reserve']),min(src['WO']['cap'],r['wo_cap'],z['mes_capacity'])]
 grids=[[v for v in range(0,int(cap//step)*step+1,step) if (v==0 or v>=src[n]['moq']) and (v==0 or src[n]['arrival_day_offset']<h)] for n,cap in zip(['PO','STO','WO'],caps)]
 for po,sto,wo in itertools.product(*grids):
  count+=1;q={'PO':po,'STO':sto,'WO':wo}
  if wo*z['bom']['R-SYRUP']>r['syrup_kg'] or wo*z['bom']['R-FILM']>r['film_m'] or wo*z['bom']['R-BOTTLE']>r['bottles']:continue
  receipts=[z['inbound'][t]+sum(q[n] for n in q if src[n]['arrival_day_offset']==t) for t in range(h)]
  if any(a>b for a,b in zip(receipts,c['receiving_capacity'])):continue
  cost=sum(q[n]*src[n]['unit_cost']+(src[n]['fixed_cost'] if q[n] else 0) for n in q);ok=True;rows=[]
  for sc in z['scenarios']:
   stock=z['initial'];lost=0
   for t in range(h):
    stock+=receipts[t]
    if stock>c['storage_capacity']:ok=False
    demand=z['forecast'][t]+z['firm'][t]+(sc['net'] if t==c['presale_due_day_offset'] else 0)
    lost+=max(0,demand-stock);stock=max(0,stock-demand)
   if hard and sc['probability']>0 and lost>1e-8:ok=False
   cost+=sc['probability']*(c['shortage_cost_per_unit']*lost+c['terminal_excess_cost_per_unit']*stock);rows.append([lost,stock])
  if ok:out.append((cost,po+sto+wo,po,sto,wo,rows))
 return {'enumerated':count,'feasible':len(out),'best':min(out) if out else None,'ties':sum(abs(v[0]-min(out)[0])<1e-8 for v in out) if out else 0},out
results={}
variants={'default':(x,False),'hard':(x,True)}
for name,mutate,hard in [('capacity210',lambda y:y['config']['receiving_capacity'].__setitem__(2,210),False),('capacity240hard',lambda y:y['config']['receiving_capacity'].__setitem__(2,240),True),('late_sto',lambda y:y['sources'][1].update(arrival_day_offset=3),False),('late_inbound_hard',lambda y:y.update(inbound=[0,0,60]),True),('film10',lambda y:y['resources'].update(film_m=10),False),('PO5',lambda y:y['sources'][0].update(unit_cost=5),False),('high_probability',lambda y:[s.update(probability=p) for s,p in zip(y['scenarios'],[.1,.2,.7])],False)]:
 z=copy.deepcopy(x);mutate(z);variants[name]=(z,hard)
for name,(z,hard) in variants.items():
 a,_=independent(z,hard);b=j.solve(z,hard);assert a['enumerated']==b['enumerated'];assert a['feasible']==b['feasible'];assert (a['best'] is None)==(b['best'] is None)
 if a['best']:assert abs(a['best'][0]-b['best']['expected_total_cost'])<1e-8;assert a['best'][2:5]==tuple(b['best']['plan'][n] for n in ['PO','STO','WO'])
 results[name]=a
# Compare every baseline feasible cost row, not just winner.
_,rows=independent(x);actual=j.solve(x)['all_feasible_cost_rows'];ar={tuple(r['plan'][n] for n in ['PO','STO','WO']):r['expected_total_cost'] for r in actual}
assert all(abs(r[0]-ar[r[2:5]])<1e-8 for r in rows)
# Copies keep source package untouched.
p=pathlib.Path(tempfile.mkdtemp(prefix='joint-audit-data-'));shutil.copytree(j.ROOT/'data',p/'data');j.ROOT=p;j.base.ROOT=p
original={f.name:f.read_bytes() for f in (p/'data').iterdir()}
def reset():
 for n,b in original.items():(p/'data'/n).write_bytes(b)
def jsonchange(filename,fn):
 f=p/'data'/filename;v=json.loads(f.read_text());fn(v);f.write_text(json.dumps(v))
def csvchange(filename,fn):
 f=p/'data'/filename;rs=list(csv.DictReader(f.open()));fn(rs)
 with f.open('w') as w:d=csv.DictWriter(w,fieldnames=rs[0].keys());d.writeheader();d.writerows(rs)
checks={}
mutations={
 'negative_inbound_offset':lambda:jsonchange('config.json',lambda c:c.update(inbound_arrival_day_offset=-1)),
 'negative_firm_offset':lambda:jsonchange('config.json',lambda c:c.update(firm_reservation_due_day_offset=-1)),
 'nan_film_resource':lambda:jsonchange('config.json',lambda c:c['sources'].update(film_m=float('nan'))),
 'negative_po_resource':lambda:jsonchange('config.json',lambda c:c['sources'].update(po_cap=-1)),
 'bad_bom_unit':lambda:csvchange('bom.csv',lambda rs:rs[0].update(unit='cm')),
 'bad_pos_unit':lambda:csvchange('pos.csv',lambda rs:rs[0].update(unit='box')),
 'future_pos_revision':lambda:csvchange('pos.csv',lambda rs:rs[-1].update(quantity='999999')),
 'future_mes':lambda:csvchange('snapshots.csv',lambda rs:[r.update(value='99999') for r in rs if r['system']=='MES' and r['known_at']>x['cutoff']]),
 'future_bom':lambda:csvchange('bom.csv',lambda rs:rs[-1].update(quantity='999999')),
 'future_source':lambda:csvchange('joint_sources.csv',lambda rs:rs[0].update(known_at='2099-01-01T00:00:00Z')),
 'future_presale_append':lambda:csvchange('presale.csv',lambda rs:rs.append(dict(rs[0],known_at='2099-01-01T00:00:00Z'))),
 'retained_over_gross':lambda:csvchange('presale.csv',lambda rs:rs[0].update(retained='101')),
 'active_bom_change':lambda:csvchange('bom.csv',lambda rs:rs[1].update(quantity='60')),
 'inventory_sku_wrong':lambda:csvchange('inventory.csv',lambda rs:[r.update(sku='OTHER') for r in rs]),
}
for name,fn in mutations.items():
 reset();fn()
 try:
  z=j.load();r=j.solve(z);checks[name]={'status':r['status'],'plan':r['best']['plan'] if r['best'] else None,'cost':r['best']['expected_total_cost'] if r['best'] else None,'hash_changed':r['input_hash']!=j.base.digest(x),'inbound':z['inbound'],'firm':z['firm']}
 except Exception as e:checks[name]={'error':type(e).__name__+': '+str(e)}
print(json.dumps({'independent':results,'file_mutations':checks},indent=2))
