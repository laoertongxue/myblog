#!/usr/bin/env python3
"""Pure-standard-library teaching simulation. No network, credentials or real execution."""
import argparse, csv, hashlib, json, math
from copy import deepcopy
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CUTOFF='2026-06-15T08:00:00Z'
TARGET='2026-06-17'
IDS=['A01','G01','A03','A02','G05','A07','A09','G02','G07','G11','A10','G12']

def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def csvwrite(path, rows,fieldnames=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:
        with path.open('w',newline='',encoding='utf-8') as f:
            if fieldnames:csv.DictWriter(f,fieldnames=fieldnames).writeheader()
        return
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def csvread(name):
    with (ROOT/'data'/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def jwrite(path,x): path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def seed_data():
    """Only --generate-fixtures writes these inputs; normal runs always read disk."""
    factors=[.9,.9,1.2,1,1.1,1,.9]
    history=[]
    from datetime import date,timedelta
    bases=[100,100,100,110,120,120,140]
    for n,(base,factor) in enumerate(zip(bases,factors)):
        day=(date(2026,6,8)+timedelta(days=n)).isoformat()
        history.append(dict(system='POS',source_id='pos-'+str(n),revision=1,sku='T-L',event_date=day,target_date=day,known_at=day+'T23:59:00Z',quantity=base*factor,unit='ea',factor=factor))
    history.append(dict(system='POS',source_id='pos-6',revision=2,sku='T-L',event_date='2026-06-14',target_date='2026-06-14',known_at='2026-06-15T10:00:00Z',quantity=132,unit='ea',factor=.9))
    csvwrite(ROOT/'data/pos.csv',history)
    mappings=[]
    for system,code,sku,spu,unit,factor,dimension in [('POS','LEMON500','T-L','TEA','ea',1,'count'),('OMS','L-CASE','T-L','TEA','box',6,'count'),('WMS','L-WH','T-L','TEA','ea',1,'count'),('MES','L-FIN','T-L','TEA','ea',1,'count'),('MES','SYRUP-G','R-SYRUP','RAW','g',.001,'mass'),('WMS','SYRUP-KG','R-SYRUP','RAW','kg',1,'mass'),('MES','FILM-CM','R-FILM','RAW','cm',.01,'length'),('WMS','FILM-M','R-FILM','RAW','m',1,'length'),('MES','BOTTLE','R-BOTTLE','RAW','ea',1,'count')]:
        mappings.append(dict(system=system,source_code=code,sku=sku,spu=spu,source_unit=unit,base_unit={'count':'ea','mass':'kg','length':'m'}[dimension],factor=factor,dimension=dimension,valid_from='2026-01-01',valid_to='2027-01-01',known_at='2026-01-01T00:00:00Z'))
    csvwrite(ROOT/'data/master.csv',mappings)
    csvwrite(ROOT/'data/bom.csv',[dict(version='B1',parent='T-L',component=c,quantity=q,unit=u,valid_from='2026-01-01',valid_to='2026-06-20',known_at='2026-01-01T00:00:00Z') for c,q,u in [('R-SYRUP',200,'g'),('R-FILM',25,'cm'),('R-BOTTLE',1,'ea')]]+[dict(version='B2',parent='T-L',component=c,quantity=q,unit=u,valid_from='2026-06-20',valid_to='2027-01-01',known_at='2026-06-15T09:00:00Z') for c,q,u in [('R-SYRUP',220,'g'),('R-FILM',30,'cm'),('R-BOTTLE',1,'ea')]])
    csvwrite(ROOT/'data/inventory.csv',[dict(sku='T-L',bucket=b,book=book,physical=actual,unit='ea',counted_at='2026-06-15T07:00:00Z',known_at='2026-06-15T07:30:00Z') for b,book,actual in [('good',190,180),('quarantine',8,10),('scrap',2,6)]])
    csvwrite(ROOT/'data/presale.csv',[dict(cohort='NEW-100',gross_orders=100,scenario=s,retained=n,probability=p,known_at='2026-06-15T07:00:00Z') for s,n,p in [('low',40,.2),('middle',70,.5),('high',90,.3)]])
    # Point-in-time snapshots are separate from event streams. Target-date meanings are explicit.
    snapshots=[]
    def snap(system,key,target,value,known,observed='2026-06-15T07:00:00Z',kind='snapshot'):
        snapshots.append(dict(system=system,key=key,target_date=target,value=value,known_at=known,observed_at=observed,kind=kind))
    snap('OMS','firm_walkin_excluded',TARGET,30,'2026-06-15T07:00:00Z')
    snap('WMS','sellable',TARGET,180,'2026-06-15T07:30:00Z')
    snap('WMS','firm_inbound',TARGET,60,'2026-06-15T07:30:00Z')
    snap('MES','capacity',TARGET,90,'2026-06-15T07:00:00Z');snap('MES','capacity',TARGET,60,'2026-06-15T09:00:00Z')
    snap('WEATHER','rain_probability',TARGET,.7,'2026-06-15T07:00:00Z',kind='forecast');snap('WEATHER','rain_probability',TARGET,.2,'2026-06-15T09:00:00Z',kind='forecast')
    snap('WEATHER','rain_probability',TARGET,0,'2026-06-17T23:00:00Z',observed='2026-06-17T23:00:00Z',kind='actual')
    snap('BID','campaign_price',TARGET,9,'2026-06-15T07:00:00Z',kind='announced');snap('BID','campaign_price',TARGET,8,'2026-06-15T09:00:00Z',kind='announced')
    snap('IOT','temperature','2026-06-15',6,'2026-06-15T07:55:00Z',observed='2026-06-15T07:50:00Z');snap('IOT','temperature','2026-06-15',12,'2026-06-15T08:20:00Z',observed='2026-06-15T07:55:00Z')
    csvwrite(ROOT/'data/snapshots.csv',snapshots)
    csvwrite(ROOT/'data/adoption.csv',[dict(id='REC-'+str(n+1),status=s,original_qty=q,final_qty=f,reason=r,issued_at='2026-06-15T08:00:00Z',decision_at=('2026-06-15T09:00:00Z' if s!='unhandled' else ''),decision_deadline='2026-06-15T10:00:00Z',eligible=1) for n,(s,q,f,r) in enumerate([('as_is',60,60,'NO_CHANGE'),('as_is',60,60,'NO_CHANGE'),('as_is',90,90,'NO_CHANGE'),('as_is',12,12,'NO_CHANGE'),('adjusted',30,24,'CAPACITY'),('adjusted',18,12,'QUALITY_HOLD'),('rejected',24,0,'DUPLICATE_PLAN'),('rejected',12,0,'SUPPLIER_UNAVAILABLE'),('unhandled',6,'',''),('unhandled',30,'','')])])
    csvwrite(ROOT/'data/policy_demand.csv',[dict(day=t,actual=q,history_lag7=[10,30,10,30,10,30,10][t] if t<7 else '',known_at_day=t+1) for t,q in enumerate([8,32,9,30,11,28,10]*2)])
    jwrite(ROOT/'data/events.json',[dict(event_id='C1',kind='CANCEL_RETAINED',before=70,after=40,known_at='2026-06-15T10:05:00Z'),dict(event_id='E1',kind='EXPIRING',quantity=6,known_at='2026-06-15T10:10:00Z'),dict(event_id='I1',kind='IOT_RISK',known_at='2026-06-15T08:20:00Z')])
    jwrite(ROOT/'data/config.json',dict(cutoff=CUTOFF,target_date=TARGET,errors=[-10,10,-10,10],z=1.65,lead_days=2,review_days=1,inbound_arrival_day_offset=1,firm_reservation_due_day_offset=2,moq=12,box=6,receiving_capacity=210,forecast_factors=[.9,.9,1.2],weights=[1,2,3],sources=dict(po_cap=120,sto_remote_stock=84,sto_reserve=24,wo_cap=90,syrup_kg=20,film_m=24,bottles=100),exposure=dict(block=100,budget_blocks=6,min_blocks=1,max_blocks=5,stock=[6,9],rate=[2,3],margin=[4,3],cost_per_block=1)))


def unique_master(rows):
    for i,a in enumerate(rows):
        if not math.isfinite(float(a['factor'])) or float(a['factor'])<=0: raise ValueError('NONPOSITIVE_CONVERSION')
        for b in rows[i+1:]:
            if (a['system'],a['source_code'])==(b['system'],b['source_code']) and max(a['valid_from'],b['valid_from'])<min(a['valid_to'],b['valid_to']):raise ValueError('OVERLAPPING_MASTER')
    return True

def convert(rows,system,code,quantity,unit,on_date,cutoff):
    eligible=[r for r in rows if r['system']==system and r['source_code']==code and r['valid_from']<=on_date<r['valid_to'] and r['known_at']<=cutoff]
    if len(eligible)!=1:raise ValueError('MASTER_CARDINALITY')
    r=eligible[0]
    if r['source_unit']!=unit:raise ValueError('UNIT_MISMATCH')
    return {'sku':r['sku'],'spu':r['spu'],'quantity':quantity*float(r['factor']),'unit':r['base_unit']}

def bom_at(rows,date,cutoff,parent='T-L'):
    eligible=[r for r in rows if r['parent']==parent and r['valid_from']<=date<r['valid_to'] and r['known_at']<=cutoff]
    keys=[(r['parent'],r['component']) for r in eligible]
    if len(keys)!=len(set(keys)):raise ValueError('BOM_JOIN_EXPLOSION')
    if {r['component'] for r in eligible}!={'R-SYRUP','R-FILM','R-BOTTLE'}:raise ValueError('BOM_MISSING_COMPONENT_OR_VERSION')
    factor={'g':.001,'kg':1,'cm':.01,'m':1,'ea':1}
    allowed={'R-SYRUP':{'g','kg'},'R-FILM':{'cm','m'},'R-BOTTLE':{'ea'}}
    if any(r['unit'] not in allowed[r['component']] for r in eligible):raise ValueError('BOM_DIMENSION_MISMATCH')
    if any(not math.isfinite(float(r['quantity'])) or float(r['quantity'])<=0 for r in eligible):raise ValueError('BOM_NONPOSITIVE_QUANTITY')
    return {r['component']:float(r['quantity'])*factor[r['unit']] for r in eligible}

def asof_events(rows,cutoff):
    latest={};versions={}
    for r in rows:
        if r['known_at']>cutoff:continue
        if r['event_date']>=cutoff[:10]:raise ValueError('POS_NOT_COMPLETED_HISTORICAL_DAY')
        version=(r['source_id'],r['revision'])
        if version in versions and versions[version]!=r:raise ValueError('CONFLICTING_POS_REVISION')
        versions[version]=r
        key=r['source_id']
        if key not in latest or (int(r['revision']),r['known_at'])>(int(latest[key]['revision']),latest[key]['known_at']):latest[key]=r
    return sorted(latest.values(),key=lambda r:r['event_date'])

def asof_snapshot(rows,system,key,target,cutoff):
    found=[r for r in rows if r['system']==system and r['key']==key and r['target_date']==target and r['known_at']<=cutoff and r['kind']!='actual']
    if not found:raise ValueError('NO_ASOF_SNAPSHOT')
    max_known=max(r['known_at'] for r in found);latest=[r for r in found if r['known_at']==max_known]
    if len(latest)!=1:raise ValueError('AMBIGUOUS_SNAPSHOT')
    return latest[0]

def inventory(rows,cutoff=CUTOFF):
    rows=[r for r in rows if r['known_at']<=cutoff and r['counted_at']<=cutoff]
    if sorted(r['bucket'] for r in rows)!=['good','quarantine','scrap']:raise ValueError('INVENTORY_BUCKET_CARDINALITY')
    book=sum(float(r['book']) for r in rows);physical=sum(float(r['physical']) for r in rows)
    if book<=0:raise ValueError('NO_INVENTORY_DENOMINATOR')
    if any(r['unit']!='ea' for r in rows):raise ValueError('INVENTORY_UNIT_MISMATCH')
    if any(not math.isfinite(float(r[k])) or float(r[k])<0 for r in rows for k in ('book','physical')):raise ValueError('NEGATIVE_INVENTORY')
    good=next(float(r['physical']) for r in rows if r['bucket']=='good')
    return dict(book=book,physical=physical,sellable=good,total_variance=physical-book,absolute_bucket_variance=sum(abs(float(r['physical'])-float(r['book'])) for r in rows),net_accuracy=max(0,1-abs(book-physical)/book),bucket_accuracy=max(0,1-sum(abs(float(r['physical'])-float(r['book'])) for r in rows)/book),exact_bucket_rate=sum(float(r['physical'])==float(r['book']) for r in rows)/len(rows),ghost_sellable=next(float(r['book']) for r in rows if r['bucket']=='good')-good)

def pipeline(pos,snaps,cfg,cutoff=None,capacity=None):
    cutoff=cutoff or cfg['cutoff'];known=asof_events(pos,cutoff);recent=known[-3:]
    if len(recent)!=3:raise ValueError('INSUFFICIENT_HISTORY')
    if any(r['unit']!='ea' or r['sku']!='T-L' or float(r['factor'])<=0 or float(r['quantity'])<0 for r in known):raise ValueError('INVALID_POS_UNIT_OR_VALUE')
    deseason=[float(r['quantity'])/float(r['factor']) for r in recent]
    weights=cfg['weights']
    if len(weights)!=3 or sum(weights)<=0 or any(w<0 for w in weights):raise ValueError('INVALID_WMA_WEIGHTS')
    base=sum(x*w for x,w in zip(deseason,weights))/sum(weights)
    forecast=[base*f for f in cfg['forecast_factors']]
    h=cfg['lead_days']+cfg['review_days']
    if h!=len(forecast):raise ValueError('HORIZON_MISMATCH')
    sigma=math.sqrt(sum(e*e for e in cfg['errors'])/len(cfg['errors']))
    ss=cfg['z']*sigma*math.sqrt(h)
    get=lambda system,key:float(asof_snapshot(snaps,system,key,cfg['target_date'],cutoff)['value'])
    inv=get('WMS','sellable')+get('WMS','firm_inbound')-get('OMS','firm_walkin_excluded')
    raw=max(0,sum(forecast)+ss-inv)
    order=0 if raw==0 else math.ceil(max(raw,cfg['moq'])/cfg['box'])*cfg['box']
    cap=capacity if capacity is not None else cfg['receiving_capacity']
    phash=digest(dict(pos=recent,cutoff=cutoff,config=cfg,visible_snapshots=[r for r in snaps if r['known_at']<=cutoff and r['kind']!='actual'],inventory_position=inv))
    return dict(cutoff=cutoff,forecast_version='F'+cutoff[11:13],forecast_id='T-L:'+cutoff,input_hash=phash,source_ids=[r['source_id']+':r'+r['revision'] for r in recent],deseason=deseason,weighted_base=base,daily_forecast=forecast,total_forecast=sum(forecast),sigma=sigma,ss=ss,inventory_position=inv,raw=raw,moq=cfg['moq'],box=cfg['box'],order=order,rounding_extra=order-raw,receiving_capacity=cap,status='VALIDATED' if order<=cap else 'BLOCKED_CAPACITY',shortfall_if_cap= max(0,order-cap))

def calendar_check(p,cfg,sellable,inbound,firm):
    """Small forward stock projection, not a multi-period scheduling optimizer."""
    h=len(p['daily_forecast']);in_day=cfg['inbound_arrival_day_offset'];firm_day=cfg['firm_reservation_due_day_offset'];new_day=cfg['lead_days']
    if any(not isinstance(d,int) or not 0<=d<h for d in [in_day,firm_day,new_day]):raise ValueError('ARRIVAL_OR_RESERVATION_OUTSIDE_HORIZON')
    stock=sellable;rows=[]
    for day,walkin in enumerate(p['daily_forecast']):
        old_receipt=inbound if day==in_day else 0;new_receipt=p['order'] if day==new_day else 0
        opening=stock+old_receipt+new_receipt;demand=walkin+(firm if day==firm_day else 0)
        lost=max(0,demand-opening);stock=max(0,opening-demand)
        rows.append(dict(day_offset=day,existing_receipt=old_receipt,new_plan_receipt=new_receipt,opening=opening,walkin_demand=walkin,firm_demand=firm if day==firm_day else 0,lost=lost,closing=stock))
    return dict(status='BLOCKED_DAILY_SHORTAGE' if any(r['lost']>1e-9 for r in rows) else 'DAILY_BALANCE_FEASIBLE',days=rows,end_stock=stock,assumption='Receipts are available at opening; sales are projections, not executed events.')

def joint_plan(required,cfg,bom,wo_cap=None):
    s=cfg['sources'];box=cfg['box'];out=[];cap=wo_cap if wo_cap is not None else s['wo_cap']
    for po in range(0,s['po_cap']+1,box):
      for sto in range(0,s['sto_remote_stock']-s['sto_reserve']+1,box):
       for wo in range(0,cap+1,box):
        if wo*bom['R-SYRUP']>s['syrup_kg']+1e-9 or wo*bom['R-FILM']>s['film_m']+1e-9 or wo*bom['R-BOTTLE']>s['bottles']:continue
        supply=po+sto+wo
        shortage=max(0,required-supply);excess=max(0,supply-required)
        cost=3*po+2*sto+(12 if sto else 0)+1.5*wo+(20 if wo else 0)+8*shortage+2*excess
        out.append(dict(po=po,sto=sto,wo=wo,shortage=shortage,excess=excess,cost=cost))
    return min(out,key=lambda r:(r['cost'],r['shortage'],r['excess'],r['po'],r['sto'],r['wo'])),len(out)

def presale(rows,cutoff=CUTOFF,box=6):
    rows=[r for r in rows if r['known_at']<=cutoff]
    if not rows:raise ValueError('NO_ASOF_PRESALE')
    if len({r['cohort'] for r in rows})!=1 or len({float(r['gross_orders']) for r in rows})!=1:raise ValueError('ONE_CONSISTENT_COHORT_REQUIRED')
    gross=float(rows[0]['gross_orders'])
    if gross<0 or any(not math.isfinite(float(r[k])) for r in rows for k in ['gross_orders','retained','probability']):raise ValueError('INVALID_PRESALE_NUMBER')
    if len({r['scenario'] for r in rows})!=len(rows):raise ValueError('DUPLICATE_PRESALE_SCENARIO')
    if any(not 0<=float(r['retained'])<=gross or not 0<=float(r['probability'])<=1 for r in rows):raise ValueError('INVALID_PRESALE_SCENARIO')
    if abs(sum(float(r['probability']) for r in rows)-1)>1e-9:raise ValueError('BAD_SCENARIO_PROBABILITIES')
    mean=sum(float(r['retained'])*float(r['probability']) for r in rows)
    trials=[]
    for q in range(0,math.ceil(gross/box)*box+1,box):
        cost=sum(float(r['probability'])*(8*max(float(r['retained'])-q,0)+2*max(q-float(r['retained']),0)) for r in rows)
        trials.append(dict(quantity=q,expected_cost=cost))
    return dict(gross_orders=gross,expected_retained=mean,expected_cancelled=gross-mean,optimum=min(trials,key=lambda r:(r['expected_cost'],r['quantity'])),trials=trials)

ROLES={'PO':'purchasing_manager','STO':'logistics_manager','WO':'production_manager','MARKETING':'marketing_manager'}
REASONS={'NO_CHANGE','CAPACITY','QUALITY_HOLD','DUPLICATE_PLAN','SUPPLIER_UNAVAILABLE','DEMAND_CHANGE'}
class Approval:
    def __init__(self):self.orders={};self.audit=[]
    def create(self,kind,key,qty,revision=1,details=None):
        if kind not in ROLES:raise ValueError('BAD_ORDER_KIND')
        if key in self.orders:raise ValueError('DUPLICATE_ORDER_ID')
        order=dict(kind=kind,id=key,qty=qty,revision=revision,state='DRAFT',creator='planner',approval_hash=None,validation_hash=None,filled=0,feedback_ids=[],details=details or {})
        self.orders[key]=order;self.audit.append(dict(id=key,action='CREATE',state='DRAFT',actor='planner'));return order
    def payload(self,o):return {k:o[k] for k in ['kind','id','qty','revision','details']}
    def step(self,key,action,actor,reason='NO_CHANGE'):
        o=self.orders[key]
        if action=='validate':
            if actor!='system' or o['state']!='DRAFT' or not math.isfinite(o['qty']) or o['qty']<=0:raise ValueError('INVALID_DRAFT')
            if o['kind']=='MARKETING':
                d=o['details']
                if o['qty']%100 or d['exposures']!=o['qty'] or d['exposures']>d['budget'] or d['price']<=0 or d['exposures']/100*d['units_per_block']>d['stock_cap']:raise ValueError('INVALID_CAMPAIGN_RESOURCES')
            elif o['qty']%6:raise ValueError('INVALID_DRAFT')
            o['validation_hash']=digest(self.payload(o))
            new='VALIDATED'
        elif action=='submit':
            if o['state']!='VALIDATED' or actor!='planner' or o['validation_hash']!=digest(self.payload(o)):raise ValueError('INVALID_SUBMISSION')
            new='PENDING_APPROVAL'
        elif action in ('approve','reject'):
            if o['state']!='PENDING_APPROVAL' or actor!=ROLES[o['kind']] or actor==o['creator'] or o['validation_hash']!=digest(self.payload(o)):raise ValueError('UNAUTHORIZED_APPROVAL')
            if reason not in REASONS:raise ValueError('MISSING_REASON_ENUM')
            new='APPROVED' if action=='approve' else 'REJECTED'
            if action=='approve':o['approval_hash']=digest(self.payload(o))
        else:raise ValueError('BAD_TRANSITION')
        o['state']=new;self.audit.append(dict(id=key,action=action,state=new,actor=actor))
    def adjusted(self,key,qty,reason):
        if reason not in REASONS-{'NO_CHANGE'}:raise ValueError('MISSING_ADJUSTMENT_REASON')
        o=self.orders[key]
        if o['state'] in ('MOCK_SENT','PARTIALLY_FILLED','COMPLETED'):raise ValueError('CANNOT_REWRITE_DISPATCHED')
        o.update(qty=qty,revision=o['revision']+1,state='DRAFT',approval_hash=None,validation_hash=None)
        self.audit.append(dict(id=key,action='ADJUST:'+reason,state='DRAFT',actor='planner'))
    def feedback(self,key,event_id,qty):
        o=self.orders[key]
        if event_id in o['feedback_ids']:return 'DUPLICATE_FEEDBACK'
        if o['state'] not in ('MOCK_SENT','PARTIALLY_FILLED'):raise ValueError('FEEDBACK_BEFORE_DISPATCH')
        if qty<=0 or o['filled']+qty>o['qty']:raise ValueError('OVERFILL')
        o['filled']+=qty;o['feedback_ids'].append(event_id);o['state']='COMPLETED' if o['filled']==o['qty'] else 'PARTIALLY_FILLED'
        return o['state']
class MockGateway:
    """An in-memory ledger, NOT an ERP/WMS/MES adapter. Replayable effects are simulated."""
    def __init__(self,cfg=None,sellable=180):
        src=(cfg or {}).get('sources',dict(sto_remote_stock=84,sto_reserve=24,syrup_kg=20,film_m=24,bottles=100))
        self.remote_reserve=src['sto_reserve'];self.receipts={};self.applied={};self.ledger=dict(local=sellable,remote=src['sto_remote_stock'],syrup_kg=src['syrup_kg'],film_m=src['film_m'],bottles=src['bottles'],external_po_received=0,manufactured=0);self.effects=0;self.campaign_ledger=dict(exposures_remaining=600,ringfenced_stock=6,price=9);self.campaign_feedback={}
    def send(self,approval,key,crash_after_apply=False):
        o=approval.orders[key];idem=f"{o['kind']}:{o['id']}:r{o['revision']}"
        payload_hash=digest(approval.payload(o))
        if idem in self.receipts:
            if self.receipts[idem]['hash']!=payload_hash:raise ValueError('IDEMPOTENCY_PAYLOAD_CONFLICT')
            return self.receipts[idem]
        if o['state']!='APPROVED' or o['approval_hash']!=payload_hash:raise ValueError('STALE_OR_MISSING_APPROVAL')
        self.receipts[idem]=dict(idempotency_key=idem,hash=payload_hash,ack='MOCK_ACCEPTED_NO_PHYSICAL_ACTION')
        o['state']='MOCK_SENT'
        if crash_after_apply:raise TimeoutError('ACK_LOST_LOOKUP_SAME_IDEMPOTENCY_KEY')
        return self.receipts[idem]
    def receive(self,approval,key,event_id,qty,bom):
        event_payload=(key,qty)
        if event_id in self.applied:
            if self.applied[event_id]!=event_payload:raise ValueError('FEEDBACK_PAYLOAD_CONFLICT')
            return 'DUPLICATE_FEEDBACK'
        o=approval.orders[key]
        # Validate all changes before committing any simulated physical delta.
        if o['state'] not in ('MOCK_SENT','PARTIALLY_FILLED') or not math.isfinite(qty) or qty<=0 or o['filled']+qty>o['qty'] or o['approval_hash']!=digest(approval.payload(o)):raise ValueError('INVALID_RECEIPT')
        if o['kind']=='MARKETING':raise ValueError('NOT_A_PHYSICAL_ORDER')
        if o['kind']=='STO' and self.ledger['remote']-qty<self.remote_reserve:raise ValueError('REMOTE_RESERVE')
        if o['kind']=='WO' and any(self.ledger[k]+1e-9<qty*bom[c] for k,c in [('syrup_kg','R-SYRUP'),('film_m','R-FILM'),('bottles','R-BOTTLE')]):raise ValueError('MATERIAL_SHORTAGE')
        approval.feedback(key,event_id,qty)
        if o['kind']=='PO':self.ledger['external_po_received']+=qty
        elif o['kind']=='STO':self.ledger['remote']-=qty
        elif o['kind']=='WO':
            for k,c in [('syrup_kg','R-SYRUP'),('film_m','R-FILM'),('bottles','R-BOTTLE')]:self.ledger[k]-=qty*bom[c]
            self.ledger['manufactured']+=qty
        else:raise ValueError('NOT_A_PHYSICAL_ORDER')
        self.ledger['local']+=qty;self.applied[event_id]=event_payload;self.effects+=1
        return o['state']

    def campaign_result(self,approval,key,event_id,sales,known_at):
        o=approval.orders[key];d=o['details'];payload=(key,sales,known_at)
        if event_id in self.campaign_feedback:
            if self.campaign_feedback[event_id]!=payload:raise ValueError('CAMPAIGN_FEEDBACK_CONFLICT')
            return 'DUPLICATE_CAMPAIGN_FEEDBACK'
        if o['kind']!='MARKETING' or o['state']!='MOCK_SENT' or o['approval_hash']!=digest(approval.payload(o)):raise ValueError('CAMPAIGN_NOT_APPROVED_AND_SENT')
        if d['exposures']>self.campaign_ledger['exposures_remaining'] or not math.isfinite(sales) or not float(sales).is_integer() or sales<0 or sales>d['stock_cap'] or sales>self.campaign_ledger['ringfenced_stock']:raise ValueError('CAMPAIGN_RESOURCE_EXCEEDED')
        if known_at<d['execute_after']:raise ValueError('FEEDBACK_BEFORE_ACTION')
        self.campaign_ledger['exposures_remaining']-=d['exposures'];self.campaign_ledger['ringfenced_stock']-=sales;self.campaign_ledger['price']=d['price']
        o['state']='COMPLETED';self.campaign_feedback[event_id]=payload
        return 'MOCK_CAMPAIGN_COMPLETED'

def integrated_event_loop(cfg,pos,snaps,events=None,cutoff='2026-06-15T11:00:00Z'):
    if events is None:events=json.loads((ROOT/'data/events.json').read_text())
    proposals=triggers(events+events,cutoff)
    visible={e['event_id']:e for e in events if e['known_at']<=cutoff}
    old=pipeline(pos,snaps,cfg);new=pipeline(pos,snaps,cfg,cutoff)
    old_retained=presale(csvread('presale.csv'),cfg['cutoff'],cfg['box'])['expected_retained'];new_retained=old_retained
    for e in visible.values():
        if e['kind']=='CANCEL_RETAINED':
            if e['before']!=new_retained or not 0<=e['after']<=e['before']:raise ValueError('CANCELLATION_BASE_VERSION_MISMATCH')
            new_retained=e['after']
    old_q=math.ceil((old['raw']+old_retained)/cfg['box'])*cfg['box'];new_q=math.ceil((new['raw']+new_retained)/cfg['box'])*cfg['box']
    a=Approval();g=MockGateway(cfg);stale_blocked=False;key='CAMPAIGN-E1'
    expiry=[e for e in visible.values() if e['kind']=='EXPIRING']
    if len(expiry)>1:raise ValueError('ONE_CAMPAIGN_DEMO_ONLY')
    if expiry:
        event=expiry[0];stock=event['quantity'];budget=cfg['exposure']['block']*cfg['exposure']['budget_blocks']
        if not math.isfinite(stock) or stock<0:raise ValueError('INVALID_EXPIRING_QUANTITY')
        old_exposure=min(budget,math.floor(stock/2)*100);new_exposure=min(budget,math.floor(stock/3)*100)
        if new_exposure<=0:raise ValueError('INSUFFICIENT_RINGFENCED_STOCK')
        g.campaign_ledger.update(exposures_remaining=budget,ringfenced_stock=stock)
        a.create('MARKETING',key,old_exposure,details=dict(price=9,exposures=old_exposure,stock_version='STOCK-08',budget=budget,units_per_block=2,stock_cap=stock,execute_after='2026-06-15T12:00:00Z'))
        a.step(key,'validate','system');a.step(key,'submit','planner');a.step(key,'approve','marketing_manager')
        a.adjusted(key,new_exposure,'DEMAND_CHANGE');a.orders[key]['details'].update(price=8,exposures=new_exposure,stock_version='STOCK-11',units_per_block=3)
        try:g.send(a,key)
        except ValueError:stale_blocked=True
        a.step(key,'validate','system');a.step(key,'submit','planner');a.step(key,'approve','marketing_manager');g.send(a,key)
        sales=min(4,stock);g.campaign_result(a,key,'M1',sales,'2026-06-15T13:00:00Z')
        after=digest(g.campaign_ledger);g.send(a,key);g.campaign_result(a,key,'M1',sales,'2026-06-15T13:00:00Z')
        campaign=a.orders[key];replay_unchanged=digest(g.campaign_ledger)==after
    else:
        campaign=dict(state='NO_ELIGIBLE_EXPIRY_EVENT_NO_ACTION');replay_unchanged=True
    return dict(proposals=proposals,old_future_qty=old_q,new_future_qty=new_q,new_plan_status=('BLOCKED_CAPACITY_'+str(cfg['receiving_capacity']) if new_q>cfg['receiving_capacity'] else 'PENDING_NEW_APPROVAL'),requires_new_capacity_approval=new_q>cfg['receiving_capacity'],already_dispatched_orders_unchanged=True,stale_approval_blocked=stale_blocked,campaign=campaign,campaign_ledger=g.campaign_ledger,campaign_audit=a.audit,replay_unchanged=replay_unchanged,external_execution=False)

def simulate_orders(plan,bom,cfg=None,sellable=180,inbound=60,planning_status='VALIDATED',context=None):
    a=Approval();g=MockGateway(cfg,sellable);rows=[]
    if planning_status!='VALIDATED' or plan['shortage']>0:
        return dict(status='BLOCKED_NO_MOCK_DISPATCH',orders=[],ledger=g.ledger,effect_count=0,acceptance_count=0,audit=[],replay_unchanged=True,existing_inbound_not_in_ledger=inbound,projected_local_after_existing_inbound=sellable+inbound)
    for kind,qty in [('PO',plan['po']),('STO',plan['sto']),('WO',plan['wo'])]:
        if not qty:continue
        key='PLAN08-'+kind;a.create(kind,key,qty,details=context or {});a.step(key,'validate','system');a.step(key,'submit','planner');a.step(key,'approve',ROLES[kind]);g.send(a,key);g.send(a,key)
        parts=[36,qty-36] if kind=='PO' and qty>36 else [qty]
        for n,p in enumerate(parts):
            eid=f'{key}-receipt-{n}';g.receive(a,key,eid,p,bom);g.receive(a,key,eid,p,bom)
        rows.append(dict(id=key,kind=kind,quantity=qty,unit='ea',state=a.orders[key]['state'],filled=a.orders[key]['filled'],cutoff=(context or {}).get('cutoff',CUTOFF),forecast_version=(context or {}).get('forecast_version','F08'),bom_version=(context or {}).get('bom_version','B1'),input_hash=(context or {}).get('input_hash','DEMO_FUNCTION_WITHOUT_SOURCE_CONTEXT'),external_execution=False))
    before=digest(g.ledger)
    for key in a.orders:g.send(a,key)
    assert digest(g.ledger)==before
    return dict(status='MOCK_COMPLETED',orders=rows,ledger=g.ledger,effect_count=g.effects,acceptance_count=len(g.receipts),audit=a.audit,replay_unchanged=True,existing_inbound_not_in_ledger=inbound,projected_local_after_existing_inbound=g.ledger['local']+inbound)

def adoption(rows,asof='2026-06-15T11:00:00Z'):
    if len({r['id'] for r in rows})!=len(rows):raise ValueError('DUPLICATE_ADOPTION_ID')
    eligible=[r for r in rows if r['issued_at']<=asof and int(r['eligible']) and r['decision_deadline']<=asof]
    if not eligible:raise ValueError('EMPTY_ELIGIBLE_DENOMINATOR')
    counts={s:0 for s in ['as_is','adjusted','rejected','unhandled']}
    for r in eligible:
        state=r['status'] if r['decision_at'] and r['decision_at']<=asof else 'unhandled'
        if state!='unhandled' and r['reason'] not in REASONS:raise ValueError('MISSING_REASON_ENUM')
        if state=='adjusted' and r['reason']=='NO_CHANGE':raise ValueError('MISSING_ADJUSTMENT_REASON')
        if state=='as_is' and float(r['original_qty'])!=float(r['final_qty']):raise ValueError('AS_IS_CHANGED')
        counts[state]+=1
    n=len(eligible);decided=n-counts['unhandled']
    return dict(eligible=n,counts=counts,strict_adoption=counts['as_is']/n,broad_adoption=(counts['as_is']+counts['adjusted'])/n,decision_completion=decided/n,broad_among_decided=(counts['as_is']+counts['adjusted'])/decided if decided else None)

def policy_sim(rows,name):
    if len(rows)!=14 or [int(r['day']) for r in rows]!=list(range(14)):raise ValueError('REQUIRE_ORDERED_14_DAY_WINDOW')
    if any(int(r['actual'])<0 for r in rows):raise ValueError('NEGATIVE_DEMAND')
    actuals=[int(r['actual']) for r in rows];initial=20;days=[];arriving=initial
    for t,actual in enumerate(actuals):
        opening=arriving;sales=min(opening,actual);lost=actual-sales;end=opening-sales;spoil=end # one-day labeled life: mandatory simulated disposal at closing
        # Both policies order at close t, arrive at open t+1. No future actual enters a decision.
        if t+1<len(actuals):
            target=t+1
            if name=='old':forecast=20;ss=0
            else:
                if target>=7 and int(rows[target-7]['known_at_day'])>t+1:raise ValueError('LAG7_NOT_YET_KNOWN')
                forecast=int(rows[target]['history_lag7']) if target<7 else actuals[target-7];ss=2
            order=max(0,forecast+ss) # after expiry usable carry=0, box=1, MOQ=0, common rule
        else:forecast=None;ss=None;order=0
        days.append(dict(policy=name,day=t,opening=opening,demand=actual,sales=sales,lost=lost,pre_disposal_end=end,spoil=spoil,closing=0,average_onhand=(opening+end)/2,next_day_forecast=forecast,safety_stock=ss,order_next_day=order))
        assert opening==sales+spoil
        arriving=order
    demand=sum(d['demand'] for d in days);sales=sum(d['sales'] for d in days);available=sum(d['opening'] for d in days);average=sum(d['average_onhand'] for d in days)/len(days)
    return dict(name=name,demand=demand,sales=sales,lost=demand-sales,stockout_rate=(demand-sales)/demand,spoil=sum(d['spoil'] for d in days),spoil_rate=sum(d['spoil'] for d in days)/available,average_onhand=average,turnover_for_14_days=sales/average,days=days,total_available=available)

def traffic(cfg,robust=False):
    e=cfg['exposure'];rate=e['rate'];caprate=[3,4] if robust else rate;candidates=[]
    for a in range(e['min_blocks'],e['max_blocks']+1):
      for b in range(e['min_blocks'],e['max_blocks']+1):
        x=[a,b]
        if sum(x)>e['budget_blocks'] or any(x[i]*caprate[i]>e['stock'][i] for i in range(2)):continue
        demand=[x[i]*rate[i] for i in range(2)]
        profit=sum(demand[i]*e['margin'][i] for i in range(2))-sum(x)*e['cost_per_block']
        candidates.append(dict(blocks=x,exposures=[v*e['block'] for v in x],expected_incremental_units=demand,capacity_check_units=[x[i]*caprate[i] for i in range(2)],profit=profit,unused_exposures=(e['budget_blocks']-sum(x))*e['block']))
    if not candidates:return dict(status='INFEASIBLE')
    return dict(status='SIMULATED_PROPOSAL',robust=robust,best=max(candidates,key=lambda r:(r['profit'],-sum(r['blocks']))),feasible_count=len(candidates))

def triggers(events,cutoff):
    seen={};proposals=[]
    for e in events:
        if e['known_at']>cutoff:continue
        if e['event_id'] in seen:
            if seen[e['event_id']]!=e:raise ValueError('TRIGGER_PAYLOAD_CONFLICT')
            continue
        seen[e['event_id']]=e
        if e['kind']=='CANCEL_RETAINED':proposals.append(dict(event_id=e['event_id'],action='RECOMPUTE_FUTURE_PLAN',released_units=e['before']-e['after'],requires_new_approval=True))
        elif e['kind']=='EXPIRING':proposals.append(dict(event_id=e['event_id'],action='PROPOSE_PRICE_TRAFFIC_PAIR',ringfenced_units=e['quantity'],price=8,exposure_blocks=2,requires_new_approval=True))
        elif e['kind']=='IOT_RISK':proposals.append(dict(event_id=e['event_id'],action='REQUEST_QUALITY_REVIEW',auto_release=False,requires_new_approval=True))
    return proposals

def four_dimensions():
    cases=[('base',30,10,14,2,.9),('short_physical',30,1,14,2,.9),('short_aesthetic',30,10,2,2,.9),('long_lead',30,10,14,5,.9),('uncertain_delivery',30,10,14,2,.6),('launch_phase',5,10,14,2,.9)]
    return [dict(case=n,plc_remaining_days=p,physical_days=s,aesthetic_days=a,lead_days=l,fill_probability=f,forecast_days=l+1,sale_window_days=min(p,s,a),late_risk=(l>=min(p,s,a)),model_choice='analogue+scenarios' if n=='launch_phase' else 'de-seasoned WMA baseline',action='BLOCK_NORMAL_REPLENISHMENT_AND_REVIEW' if l>=min(p,s,a) else ('SUPPLY_SCENARIOS_REVIEW' if f<.8 else 'BOUNDED_PLAN')) for n,p,s,a,l,f in cases]

def run_all():
    cfg=json.loads((ROOT/'data/config.json').read_text());pos=csvread('pos.csv');snaps=csvread('snapshots.csv');master=csvread('master.csv');unique_master(master)
    cutoff=cfg['cutoff'];target=cfg['target_date']
    bom=bom_at(csvread('bom.csv'),target,cutoff);inv=inventory(csvread('inventory.csv'),cutoff)
    get=lambda key:float(asof_snapshot(snaps,'WMS',key,target,cutoff)['value'])
    if inv['sellable']!=get('sellable'):raise ValueError('WMS_COUNT_SNAPSHOT_MISMATCH')
    capacity=float(asof_snapshot(snaps,'MES','capacity',target,cutoff)['value'])
    if capacity<0 or not capacity.is_integer():raise ValueError('INVALID_MES_CAPACITY')
    p=pipeline(pos,snaps,cfg);plan,count=joint_plan(p['order'],cfg,bom,wo_cap=min(cfg['sources']['wo_cap'],int(capacity)))
    later=pipeline(pos,snaps,cfg,'2026-06-15T11:00:00Z',capacity=240);latecap=float(asof_snapshot(snaps,'MES','capacity',target,'2026-06-15T11:00:00Z')['value']);lateplan,_=joint_plan(later['order'],cfg,bom,wo_cap=min(cfg['sources']['wo_cap'],int(latecap)))
    calendar=calendar_check(p,cfg,inv['sellable'],get('firm_inbound'),float(asof_snapshot(snaps,'OMS','firm_walkin_excluded',target,cutoff)['value']))
    dispatch_status=p['status'] if calendar['status']=='DAILY_BALANCE_FEASIBLE' else calendar['status']
    plan_input_hash=digest(dict(pipeline_input_hash=p['input_hash'],bom=bom,config=cfg,mes_capacity=capacity,inventory=inv,master_visible=[r for r in master if r['known_at']<=cutoff]))
    reports=dict(calendar_check=calendar,plan_input_hash=plan_input_hash,synthetic_only=True,external_execution=False,production_ready=False,covered_ids=IDS,four_dimensions=four_dimensions(),master_examples=[convert(master,'OMS','L-CASE',5,'box',TARGET,CUTOFF),convert(master,'MES','SYRUP-G',18000,'g',TARGET,CUTOFF),convert(master,'MES','FILM-CM',2250,'cm',TARGET,CUTOFF)],bom=bom,inventory=inv,pipeline=p,capacity_conflict=pipeline(pos,snaps,cfg,capacity=180),late_pipeline=later,joint_plan=plan,joint_enumerated=count,late_joint_plan=lateplan,presale=presale(csvread('presale.csv'),cutoff,cfg['box']),orders=simulate_orders(plan,bom,cfg,inv['sellable'],get('firm_inbound'),dispatch_status,dict(cutoff=cutoff,forecast_version=p['forecast_version'],input_hash=plan_input_hash,bom_version=next(r['version'] for r in csvread('bom.csv') if r['parent']=='T-L' and r['valid_from']<=target<r['valid_to'] and r['known_at']<=cutoff))),adoption=adoption(csvread('adoption.csv')),policy_old=policy_sim(csvread('policy_demand.csv'),'old'),policy_new=policy_sim(csvread('policy_demand.csv'),'new'),traffic=traffic(cfg),traffic_robust=traffic(cfg,True))
    events=json.loads((ROOT/'data/events.json').read_text())
    reports['asof_bundle']={
      'cutoff':cutoff,'target_date':target,'pos':asof_events(pos,cutoff),
      'snapshots':[asof_snapshot(snaps,system,key,day,cutoff) for system,key,day in [
        ('OMS','firm_walkin_excluded',target),('WMS','sellable',target),('WMS','firm_inbound',target),
        ('MES','capacity',target),('WEATHER','rain_probability',target),('BID','campaign_price',target),('IOT','temperature',cutoff[:10])]],
      'bom':bom,'bom_source_rows':[r for r in csvread('bom.csv') if r['parent']=='T-L' and r['valid_from']<=target<r['valid_to'] and r['known_at']<=cutoff],'units':{'finished':'ea','syrup':'kg','film':'m'},
      'weather_bid_iot_affect_forecast':False}
    reports['asof_bundle']['input_hash']=digest(reports['asof_bundle'])
    reports['input_file_hashes']={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'data').glob('*')) if f.is_file()}
    reports['forecast_input_hash']=p['input_hash']
    reports['event_proposals']=triggers(events+events,'2026-06-15T11:00:00Z')
    reports['event_loop']=integrated_event_loop(cfg,pos,snaps)
    reports['unimplemented']=['No live connectors, authentication or real order/price/exposure execution','No causal conversion estimation, learned forecast/weather effect or online ranking','No generic multi-period MRP/APS/MEIO optimizer, stochastic lead-time covariance or real ERP transaction atomicity','No real quality or food-safety release, finance ownership journal, legal compliance or business KPI guarantee','Presale hedge solved separately from the bounded three-source plan; full joint multi-period optimization remains unimplemented']
    return reports

def self_test():
    import unittest
    class Tests(unittest.TestCase):
      def setUp(self):
        self.cfg=json.loads((ROOT/'data/config.json').read_text());self.pos=csvread('pos.csv');self.snaps=csvread('snapshots.csv');self.master=csvread('master.csv');self.bom=bom_at(csvread('bom.csv'),TARGET,CUTOFF)
      def test_master_conversion(self):self.assertEqual(convert(self.master,'OMS','L-CASE',5,'box',TARGET,CUTOFF)['quantity'],30)
      def test_mass_length(self):
        self.assertEqual(convert(self.master,'MES','SYRUP-G',18000,'g',TARGET,CUTOFF)['quantity'],18);self.assertEqual(convert(self.master,'MES','FILM-CM',2250,'cm',TARGET,CUTOFF)['quantity'],22.5)
      def test_unknown_code(self):
        with self.assertRaisesRegex(ValueError,'CARDINALITY'):convert(self.master,'OMS','UNKNOWN',1,'ea',TARGET,CUTOFF)
      def test_unit_fault(self):
        with self.assertRaisesRegex(ValueError,'UNIT_MISMATCH'):convert(self.master,'OMS','L-CASE',5,'ea',TARGET,CUTOFF)
      def test_master_overlap(self):
        with self.assertRaisesRegex(ValueError,'OVERLAPPING'):unique_master(self.master+[self.master[0]])
      def test_negative_factor(self):
        m=deepcopy(self.master);m[0]['factor']=-1
        with self.assertRaisesRegex(ValueError,'NONPOSITIVE'):unique_master(m)
      def test_bom_version(self):self.assertEqual(self.bom['R-SYRUP'],.2)
      def test_future_bom_unknown(self):
        with self.assertRaisesRegex(ValueError,'MISSING'):bom_at(csvread('bom.csv'),'2026-06-21',CUTOFF)
      def test_future_bom_known(self):self.assertEqual(bom_at(csvread('bom.csv'),'2026-06-21','2026-06-15T11:00:00Z')['R-FILM'],.3)
      def test_bom_expansion(self):
        b=csvread('bom.csv')
        with self.assertRaisesRegex(ValueError,'JOIN_EXPLOSION'):bom_at(b+[b[0]],TARGET,CUTOFF)
      def test_late_pos(self):
        self.assertEqual(float(asof_events(self.pos,CUTOFF)[-1]['quantity']),126);self.assertEqual(float(asof_events(self.pos,'2026-06-15T11:00:00Z')[-1]['quantity']),132)
      def test_asof_weather(self):self.assertEqual(float(asof_snapshot(self.snaps,'WEATHER','rain_probability',TARGET,CUTOFF)['value']),.7)
      def test_no_actuals(self):self.assertNotEqual(asof_snapshot(self.snaps,'WEATHER','rain_probability',TARGET,'2026-06-18T00:00:00Z')['kind'],'actual')
      def test_iot_late(self):self.assertEqual(float(asof_snapshot(self.snaps,'IOT','temperature','2026-06-15',CUTOFF)['value']),6)
      def test_iot_known(self):self.assertEqual(float(asof_snapshot(self.snaps,'IOT','temperature','2026-06-15','2026-06-15T08:30:00Z')['value']),12)
      def test_snapshot_ambiguity(self):
        r=self.snaps[0]
        with self.assertRaisesRegex(ValueError,'AMBIGUOUS'):asof_snapshot(self.snaps+[r],r['system'],r['key'],r['target_date'],CUTOFF)
      def test_pipeline(self):
        p=pipeline(self.pos,self.snaps,self.cfg);self.assertEqual(p['weighted_base'],130);self.assertEqual(p['total_forecast'],390);self.assertEqual(p['order'],210)
      def test_late_recompute(self):self.assertEqual(pipeline(self.pos,self.snaps,self.cfg,'2026-06-15T11:00:00Z')['order'],222)
      def test_capacity_block(self):self.assertEqual(pipeline(self.pos,self.snaps,self.cfg,capacity=180)['status'],'BLOCKED_CAPACITY')
      def test_horizon(self):
        c=deepcopy(self.cfg);c['lead_days']=3
        with self.assertRaisesRegex(ValueError,'HORIZON'):pipeline(self.pos,self.snaps,c)
      def test_inventory(self):
        r=inventory(csvread('inventory.csv'));self.assertEqual(r['sellable'],180);self.assertAlmostEqual(r['net_accuracy'],.98);self.assertAlmostEqual(r['bucket_accuracy'],.92);self.assertEqual(r['ghost_sellable'],10)
      def test_joint(self):
        p,n=joint_plan(210,self.cfg,self.bom);self.assertEqual([p[k] for k in ['po','sto','wo','cost']],[60,60,90,467]);self.assertGreater(n,1000)
      def test_late_joint(self):
        p,n=joint_plan(222,self.cfg,self.bom,60);self.assertEqual([p[k] for k in ['po','sto','wo','cost']],[102,60,60,548])
      def test_presale(self):
        r=presale(csvread('presale.csv'));self.assertEqual(r['expected_retained'],70);self.assertEqual(r['optimum']['quantity'],90);self.assertEqual(r['optimum']['expected_cost'],40)
      def test_presale_probability_fault(self):
        r=csvread('presale.csv');r[0]['probability']=.9
        with self.assertRaisesRegex(ValueError,'PROBABILITIES'):presale(r)
      def test_approval_role(self):
        a=Approval();a.create('PO','p',60);a.step('p','validate','system');a.step('p','submit','planner')
        with self.assertRaisesRegex(ValueError,'UNAUTHORIZED'):a.step('p','approve','planner')
      def test_no_skip(self):
        a=Approval();a.create('PO','p',60)
        with self.assertRaisesRegex(ValueError,'UNAUTHORIZED'):a.step('p','approve','purchasing_manager')
      def approved(self,qty=60):
        a=Approval();a.create('PO','p',qty);a.step('p','validate','system');a.step('p','submit','planner');a.step('p','approve','purchasing_manager');return a
      def test_approval_tamper(self):
        a=self.approved();a.orders['p']['qty']=66
        with self.assertRaisesRegex(ValueError,'STALE'):MockGateway().send(a,'p')
      def test_adjustment_revokes(self):
        a=self.approved();a.adjusted('p',54,'CAPACITY');self.assertIsNone(a.orders['p']['approval_hash']);self.assertEqual(a.orders['p']['revision'],2)
      def test_adjustment_reason(self):
        a=self.approved()
        with self.assertRaisesRegex(ValueError,'REASON'):a.adjusted('p',54,'NO_CHANGE')
      def test_send_idempotent(self):
        a=self.approved();g=MockGateway();g.send(a,'p');g.send(a,'p');self.assertEqual(len(g.receipts),1);self.assertEqual(g.ledger['local'],180)
      def test_uncertain_ack(self):
        a=self.approved();g=MockGateway()
        with self.assertRaises(TimeoutError):g.send(a,'p',True)
        g.send(a,'p');self.assertEqual(len(g.receipts),1)
      def test_duplicate_receipt(self):
        a=self.approved();g=MockGateway();g.send(a,'p');g.receive(a,'p','e',36,self.bom);g.receive(a,'p','e',36,self.bom);self.assertEqual(g.ledger['local'],216);self.assertEqual(a.orders['p']['state'],'PARTIALLY_FILLED')
      def test_feedback_conflict(self):
        a=self.approved();g=MockGateway();g.send(a,'p');g.receive(a,'p','e',36,self.bom)
        with self.assertRaisesRegex(ValueError,'CONFLICT'):g.receive(a,'p','e',30,self.bom)
      def test_overfill(self):
        a=self.approved();g=MockGateway();g.send(a,'p')
        with self.assertRaisesRegex(ValueError,'INVALID_RECEIPT'):g.receive(a,'p','e',66,self.bom)
        self.assertEqual(g.ledger['local'],180)
      def test_order_ledger(self):
        p,_=joint_plan(210,self.cfg,self.bom);r=simulate_orders(p,self.bom);self.assertEqual(r['ledger']['local'],390);self.assertEqual(r['ledger']['remote'],24);self.assertEqual(r['ledger']['syrup_kg'],2);self.assertEqual(r['effect_count'],4)
      def test_adoption(self):
        r=adoption(csvread('adoption.csv'));self.assertEqual(r['strict_adoption'],.4);self.assertEqual(r['broad_adoption'],.6);self.assertEqual(r['broad_among_decided'],.75)
      def test_reason_fault(self):
        r=csvread('adoption.csv');r[4]['reason']=''
        with self.assertRaisesRegex(ValueError,'REASON'):adoption(r)
      def test_adoption_due(self):
        with self.assertRaisesRegex(ValueError,'EMPTY'):adoption(csvread('adoption.csv'),'2026-06-15T09:00:00Z')
      def test_policy(self):
        old=policy_sim(csvread('policy_demand.csv'),'old');new=policy_sim(csvread('policy_demand.csv'),'new');self.assertEqual(old['lost'],60);self.assertEqual(old['spoil'],84);self.assertEqual(new['lost'],0);self.assertEqual(new['spoil'],38);self.assertGreater(new['turnover_for_14_days'],old['turnover_for_14_days'])
      def test_policy_no_future(self):
        rows=csvread('policy_demand.csv');before=policy_sim(rows,'new');rows[6]['actual']=999;after=policy_sim(rows,'new');self.assertEqual(before['days'][5]['order_next_day'],after['days'][5]['order_next_day'])
      def test_traffic(self):self.assertEqual(traffic(self.cfg)['best']['blocks'],[3,3]);self.assertEqual(traffic(self.cfg)['best']['profit'],45)
      def test_traffic_robust(self):self.assertEqual(traffic(self.cfg,True)['best']['blocks'],[2,2]);self.assertEqual(traffic(self.cfg,True)['best']['unused_exposures'],200)
      def test_triggers(self):
        e=dict(event_id='C',kind='CANCEL_RETAINED',before=70,after=40,known_at=CUTOFF);self.assertEqual(len(triggers([e,e],CUTOFF)),1);self.assertEqual(len(triggers([e],'2026-06-15T07:59:00Z')),0)
      def test_event_loop(self):
        r=integrated_event_loop(self.cfg,self.pos,self.snaps);self.assertEqual(r['old_future_qty'],282);self.assertEqual(r['new_future_qty'],264);self.assertTrue(r['stale_approval_blocked']);self.assertEqual(r['campaign_ledger']['ringfenced_stock'],2);self.assertTrue(r['replay_unchanged'])
      def test_blocked_plan_never_dispatch(self):
        p,_=joint_plan(270,self.cfg,self.bom);r=simulate_orders(p,self.bom,self.cfg,120,60,'BLOCKED_CAPACITY');self.assertEqual(r['effect_count'],0);self.assertEqual(r['ledger']['local'],120)
      def test_ledger_inputs(self):
        p,_=joint_plan(210,self.cfg,self.bom);r=simulate_orders(p,self.bom,self.cfg,100,30);self.assertEqual(r['ledger']['local'],310);self.assertEqual(r['projected_local_after_existing_inbound'],340)
      def test_validated_mutation(self):
        a=Approval();a.create('PO','p',60);a.step('p','validate','system');a.orders['p']['qty']=7
        with self.assertRaisesRegex(ValueError,'SUBMISSION'):a.step('p','submit','planner')
      def test_pending_mutation(self):
        a=Approval();a.create('PO','p',60);a.step('p','validate','system');a.step('p','submit','planner');a.orders['p']['qty']=7
        with self.assertRaisesRegex(ValueError,'UNAUTHORIZED'):a.step('p','approve','purchasing_manager')
      def test_duplicate_order_id(self):
        a=Approval();a.create('PO','p',60)
        with self.assertRaisesRegex(ValueError,'DUPLICATE_ORDER'):a.create('PO','p',66)
      def test_bom_bad_dimension(self):
        b=csvread('bom.csv');b[0]['unit']='cm'
        with self.assertRaisesRegex(ValueError,'DIMENSION'):bom_at(b,TARGET,CUTOFF)
      def test_bom_negative(self):
        b=csvread('bom.csv');b[0]['quantity']=-200
        with self.assertRaisesRegex(ValueError,'NONPOSITIVE'):bom_at(b,TARGET,CUTOFF)
      def test_presale_cutoff(self):
        r=csvread('presale.csv')
        for x in r:x['known_at']='2099-01-01T00:00:00Z'
        with self.assertRaisesRegex(ValueError,'NO_ASOF'):presale(r)
      def test_presale_gross(self):
        r=csvread('presale.csv')
        for x in r:x['gross_orders']=200
        self.assertEqual(presale(r)['expected_cancelled'],130)
      def test_trigger_conflict(self):
        e=dict(event_id='C',kind='CANCEL_RETAINED',before=70,after=40,known_at=CUTOFF);f=dict(e,after=30)
        with self.assertRaisesRegex(ValueError,'CONFLICT'):triggers([e,f],CUTOFF)
      def test_future_inventory(self):
        r=csvread('inventory.csv');r[0]['known_at']='2099-01-01T00:00:00Z'
        with self.assertRaisesRegex(ValueError,'CARDINALITY'):inventory(r)
      def test_pos_unit(self):
        p=deepcopy(self.pos);p[4]['unit']='g'
        with self.assertRaisesRegex(ValueError,'UNIT_OR_VALUE'):pipeline(p,self.snaps,self.cfg)
      def test_inventory_unit(self):
        r=csvread('inventory.csv');r[0]['unit']='box'
        with self.assertRaisesRegex(ValueError,'UNIT_MISMATCH'):inventory(r)
      def test_receipt_approval_mutated(self):
        a=self.approved();g=MockGateway();g.send(a,'p');a.orders['p']['qty']=66
        with self.assertRaisesRegex(ValueError,'INVALID_RECEIPT'):g.receive(a,'p','e',60,self.bom)
      def test_policy_availability(self):
        rows=csvread('policy_demand.csv');rows[0]['known_at_day']=99
        with self.assertRaisesRegex(ValueError,'NOT_YET_KNOWN'):policy_sim(rows,'new')
      def test_event_loop_filters_future_actions(self):
        events=json.loads((ROOT/'data/events.json').read_text())
        for e in events:
            if e['kind']!='IOT_RISK':e['known_at']='2026-06-15T12:30:00Z'
        r=integrated_event_loop(self.cfg,self.pos,self.snaps,events);self.assertEqual(r['new_future_qty'],294);self.assertEqual(r['campaign']['state'],'NO_ELIGIBLE_EXPIRY_EVENT_NO_ACTION');self.assertEqual(r['campaign_ledger']['ringfenced_stock'],6)
      def test_bom_other_parent(self):
        b=csvread('bom.csv');b.append(dict(b[0],parent='OTHER',quantity=1,unit='g'));self.assertEqual(bom_at(b,TARGET,CUTOFF)['R-SYRUP'],.2)
      def approved_campaign(self,cap=6):
        a=Approval();a.create('MARKETING','m',100,details=dict(price=8,exposures=100,stock_version='S',budget=600,units_per_block=2,stock_cap=cap,execute_after='2026-06-15T12:00:00Z'));a.step('m','validate','system');a.step('m','submit','planner');a.step('m','approve','marketing_manager');g=MockGateway();g.send(a,'m');return a,g
      def test_campaign_nan(self):
        a,g=self.approved_campaign()
        with self.assertRaisesRegex(ValueError,'RESOURCE'):g.campaign_result(a,'m','e',float('nan'),'2026-06-15T13:00:00Z')
        self.assertEqual(g.campaign_ledger['ringfenced_stock'],6)
      def test_campaign_approved_stock_cap(self):
        a,g=self.approved_campaign(2)
        with self.assertRaisesRegex(ValueError,'RESOURCE'):g.campaign_result(a,'m','e',4,'2026-06-15T13:00:00Z')
      def test_campaign_feedback_before_action(self):
        a,g=self.approved_campaign()
        with self.assertRaisesRegex(ValueError,'BEFORE_ACTION'):g.campaign_result(a,'m','e',2,'2026-06-15T11:00:00Z')
      def test_hash_changes_with_risk_parameter(self):
        a=pipeline(self.pos,self.snaps,self.cfg);c=deepcopy(self.cfg);c['z']=1.66;b=pipeline(self.pos,self.snaps,c);self.assertNotEqual(a['input_hash'],b['input_hash'])
      def test_calendar_balance(self):
        p=pipeline(self.pos,self.snaps,self.cfg);c=calendar_check(p,self.cfg,180,60,30);self.assertEqual(c['status'],'DAILY_BALANCE_FEASIBLE');self.assertEqual([r['closing'] for r in c['days']],[63,6,30])
      def test_calendar_late_inbound(self):
        p=pipeline(self.pos,self.snaps,self.cfg);cfg=deepcopy(self.cfg);cfg['inbound_arrival_day_offset']=2;c=calendar_check(p,cfg,180,60,30);self.assertEqual(c['status'],'BLOCKED_DAILY_SHORTAGE');self.assertEqual(c['days'][1]['lost'],54)
      def test_four_dimensions(self):self.assertTrue(next(r for r in four_dimensions() if r['case']=='short_physical')['late_risk'])
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():raise SystemExit(1)
    return result.testsRun

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--generate-fixtures',action='store_true',help='Regenerate the synthetic input CSVs explicitly.')
    parser.add_argument('--self-test',action='store_true',help='Run tests, then produce report.')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'output')
    args=parser.parse_args()
    if args.generate_fixtures:seed_data()
    tests=self_test() if args.self_test else None
    report=run_all();report['tests_passed']=tests;args.output_dir.mkdir(parents=True,exist_ok=True)
    jwrite(args.output_dir/'report.json',report)
    csvwrite(args.output_dir/'policy_daily.csv',report['policy_old']['days']+report['policy_new']['days'])
    csvwrite(args.output_dir/'orders.csv',report['orders']['orders'],['id','kind','quantity','unit','state','filled','cutoff','forecast_version','bom_version','input_hash','external_execution']);csvwrite(args.output_dir/'approval_audit.csv',report['orders']['audit'],['id','action','state','actor']);csvwrite(args.output_dir/'four_dimensions.csv',report['four_dimensions'])
    print(json.dumps(dict(synthetic_only=True,external_execution=False,report=str(args.output_dir/'report.json'),tests_passed=tests,order=report['pipeline']['order'],cost=report['joint_plan']['cost']),ensure_ascii=False))
if __name__=='__main__':main()
