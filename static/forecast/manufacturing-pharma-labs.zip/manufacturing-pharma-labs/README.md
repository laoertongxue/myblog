# 10个制造/医药流通教学项目：只读输入版
全部数据为模拟。配合 ../cases-manufacturing-pharma.md 阅读。

使用Python 3标准库运行：python verify_cases.py
原始数据标准答案自测：python verify_cases.py --self-test
可指定副本目录：python verify_cases.py --input-dir PATH --output-dir OTHER_PATH

脚本只读当前目录中的实际CSV和parameters.csv，不生成、不修复、不重写输入。它从行数据计算10个案例结果，写入单独outputs/results.json与计算账本CSV；输入文件SHA256保存在outputs/input_hashes.json，并在计算前后比较。

默认模式允许修改真实CSV，并将新计算结果落盘，不要求结果等于原教材答案。--self-test模式才运行原始夹具标准答案、10个内存输入扰动、13个非法输入拒绝。新增检查包括M5到货前库存不足、原有到货超过库容，以及P4事后修改时间。修改后的数据请使用默认模式；非法数据仍被拒绝。已实测复制目录后把M1最新需求100改120，落盘预测86变96，修改后的输入未被恢复。

原目录中的 *_expected_*.csv 是随教材提供的参考答案，不是输入，也不被脚本读取或重写；本次运行结果以outputs目录为准。

M5分别输出目标库存位置缺额20件、保护期实际需求缺货8件、未达到的缓冲12件，禁止把20件全部称为实际缺货。

不联网、不访问生产、不发单、不做医疗判断。当前是小样本输入驱动项目与单元测试，尚不是180天完整训练/验证/测试回测；扩展回测须按教材要求另做。

M5是受限教学模型：不能保证到货前两日逐日需求、或原有到货就超库容时直接报不可行，不通过后到货掩盖前期缺货。P4必需origin_time、system_issued_at、adjusted_at、actual_available_at四字段，所有版本须在预测时点之前且早于真实结果可得时点。
