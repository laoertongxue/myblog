"""Read-only CSV inputs -> computed outputs + tests. Python 3 standard library."""
import csv, math, json, hashlib, copy, argparse
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def read(root,name):
    with (root/name).open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if not rows:raise ValueError('empty input '+name)
    return rows

def num(row,key,low=0,high=None):
    v=float(row[key])
    if not math.isfinite(v) or v<low or (high is not None and v>high):
        raise ValueError('invalid '+key)
    return v

def positive(row,key):
    v=num(row,key)
    if v<=0:raise ValueError('must be positive '+key)
    return v

def near(a,b):
    assert math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-9),(a,b)

def rejected(f):
    try:f()
    except (ValueError,KeyError):return
    raise AssertionError('illegal input was accepted')

def score(actual,pred):
    if len(actual)!=len(pred) or any(x<0 for x in actual+pred):raise ValueError('score inputs')
    den=sum(actual)
    return {'absolute_error':sum(abs(a-p) for a,p in zip(actual,pred)),
            'wmape':sum(abs(a-p) for a,p in zip(actual,pred))/den if den else None,
            'bias':(sum(pred)-den)/den if den else None}

def m1(demand,bom):
    near(sum(num(r,'weight',0,1) for r in demand),1)
    forecast=sum(num(r,'demand_units')*num(r,'weight') for r in demand)
    kits=[]
    for r in bom:
        available=num(r,'on_hand')-num(r,'reserved')+num(r,'confirmed_receipt')
        if available<0:raise ValueError('negative material availability')
        kits.append(math.floor(available/positive(r,'per_finished')))
    ctb=min(kits)
    return {'forecast':forecast,'ctb':ctb,'build':min(forecast,ctb),'shortfall':max(0,forecast-ctb)}

def m2(rows,cfg):
    p=num(cfg,'initial_p',0,1);z=num(cfg,'initial_z');a=num(cfg,'alpha',0,1);b=num(cfg,'beta',0,1)
    out=[]
    for r in rows:
        y=num(r,'demand');p=(1-b)*p+b*(y>0)
        if y>0:z=(1-a)*z+a*y
        out.append({'week':r['week'],'demand':y,'p':p,'z':z,'next_forecast':p*z})
    return out

def m3(rows):
    if len(set(r['group'] for r in rows))!=len(rows):raise ValueError('duplicate age group')
    return [{'group':r['group'],'forecast':num(r,'active_devices')*num(r,'failure_probability',0,1)*num(r,'network_share',0,1)*num(r,'parts_per_event')} for r in rows]

def m4(done,opened,validation):
    values=sorted(num(r,'lead_days') for r in done)
    for r in opened:
        num(r,'age_days')
        if r['status']!='not_accepted':raise ValueError('invalid open status')
    p90=values[math.ceil(.9*len(values))-1]
    return {'mean':sum(values)/len(values),'p50':values[math.ceil(.5*len(values))-1],
            'p90':p90,'validation_coverage':sum(num(r,'actual_lead_days')<=p90 for r in validation)/len(validation),
            'open_orders':opened}

def m5(r):
    d=num(r,'daily_demand');R=positive(r,'review_days');L=num(r,'lead_days');B=num(r,'buffer')
    I=num(r,'on_hand');O=num(r,'on_order');A=num(r,'backorders');pack=positive(r,'pack');cap=num(r,'capacity')
    H=R+L;target=d*H+B;ip=I+O-A;raw=math.ceil(max(0,target-ip)/pack)*pack
    if I<d*L:
        raise ValueError('pre-arrival demand shortage: '+str(d*L-I)+' units; on-order cannot cover earlier days')
    arrival_base=I-d*L+O-A
    if arrival_base<0:raise ValueError('backorder service infeasible at arrival')
    if arrival_base>cap:raise ValueError('existing arrivals exceed capacity; rerouting or changed receipt schedule required')
    limit=max(0,math.floor((cap-arrival_base)/pack)*pack)
    q=min(raw,limit)
    return {'protection_days':H,'target':target,'inventory_position':ip,'raw_order':raw,
            'arrival_base':arrival_base,'constrained_order':q,'target_gap':max(0,target-ip-q),
            'horizon_shortage':max(0,d*H-(ip+q)),
            'buffer_not_achieved':min(B,max(0,target-ip-q)),'arrival_stock':arrival_base+q}

def fefo(batches,ds,key):
    bs=[{'batch':r['batch'],'qty':num(r,'quantity_boxes'),'last':num(r,'last_usable_day')} for r in batches]
    if len(set(r['batch'] for r in bs))!=len(bs):raise ValueError('duplicate batch')
    rows=[];tot=[0,0,0]
    for r in sorted(ds,key=lambda x:float(x['day'])):
        day=num(r,'day');d=num(r,key);opening=sum(b['qty'] for b in bs);expired=0;out=0
        for b in bs:
            if day>b['last']:expired+=b['qty'];b['qty']=0
        for b in sorted(bs,key=lambda x:x['last']):
            take=min(d-out,b['qty']);b['qty']-=take;out+=take
            if day>b['last']:assert take==0
        closing=sum(b['qty'] for b in bs);near(closing,opening-expired-out)
        rows.append({'day':day,'demand':d,'opening':opening,'expired':expired,'fulfilled':out,'closing':closing,'short':d-out})
        tot=[tot[0]+out,tot[1]+expired,tot[2]+d-out]
    return {'totals':tot,'ledger':rows}

def p2(rows,cfg):
    contrib=[num(r,'windows')*num(r,'purchase_probability',0,1)*num(r,'boxes_per_purchase') for r in rows]
    f=sum(contrib)+num(cfg,'other_demand')
    return {'contributions':contrib,'forecast':f,'score':score([num(cfg,'actual')],[f])}

def p3(rows,cfg):
    pred=[];actual=[]
    for r in rows:
        if datetime.fromisoformat(r['feature_available_at'])>datetime.fromisoformat(r['origin_time']):raise ValueError('future feature')
        h=num(r,'holiday',0,1)
        if h not in (0,1):raise ValueError('holiday must be binary')
        f=float(cfg['intercept'])+float(cfg['index_coefficient'])*num(r,'x')+float(cfg['holiday_coefficient'])*h
        if f<0:raise ValueError('negative prediction')
        pred.append(f);actual.append(num(r,'actual'))
    return {'predictions':pred,'score':score(actual,pred),'baseline_score':score(actual,[num(cfg,'baseline')]*len(rows))}

def p4(rows):
    for r in rows:
        origin=datetime.fromisoformat(r['origin_time'])
        actual_at=datetime.fromisoformat(r['actual_available_at'])
        if origin>=actual_at:raise ValueError('forecast origin is not before actual availability')
        for field in ['system_issued_at','adjusted_at']:
            stamp=datetime.fromisoformat(r[field])
            if stamp>origin or stamp>=actual_at:raise ValueError('late forecast version: '+field)
    a=[num(r,'actual') for r in rows]
    result={k:score(a,[num(r,k) for r in rows]) for k in ['system','adjusted','extreme']}
    result['fva']=None if not sum(a) else result['system']['wmape']-result['adjusted']['wmape']
    return result

def cold(invrows,ds,released):
    stock=0;short=0;ledger=[]
    for r in invrows:
        if r['status'] not in {'qualified','confirmed_receipt','quarantine'}:raise ValueError('unknown quality status')
        num(r,'boxes');num(r,'available_day');num(r,'release_probability',0,1)
    for r in sorted(ds,key=lambda x:float(x['day'])):
        day=num(r,'day');d=num(r,'boxes')
        receipt=sum(num(i,'boxes') for i in invrows if num(i,'available_day')==day and (i['status']!='quarantine' or released))
        stock+=receipt;out=min(stock,d);stock-=out;short+=d-out
        ledger.append({'day':day,'receipt':receipt,'demand':d,'fulfilled':out,'closing':stock,'short':d-out})
    return {'closing':stock,'short':short,'ledger':ledger}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--self-test',action='store_true',help='check bundled fixture answers and mutations');parser.add_argument('--input-dir',type=Path,default=ROOT);parser.add_argument('--output-dir',type=Path,default=ROOT/'outputs')
    args=parser.parse_args();root=args.input_dir;outdir=args.output_dir
    if outdir.resolve()==root.resolve():raise ValueError('outputs must not replace inputs')
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.csv')}
    config={}
    for r in read(root,'parameters.csv'):config.setdefault(r['case'],{})[r['key']]=r['value']
    names=['m1_demand','m1_bom','m2_tsb_input','m3_installed_base','m4_completed_lead_times','m4_open_orders','m4_validation','m5_policy','p1_batches','p1_demand','p2_cohorts','p3_features','p4_versions','p5_inventory','p5_demand']
    data={n:read(root,n+'.csv') for n in names}
    result={
      'm1':m1(data['m1_demand'],data['m1_bom']),
      'm2':m2(data['m2_tsb_input'],config['m2']),
      'm3':m3(data['m3_installed_base']),
      'm4':m4(data['m4_completed_lead_times'],data['m4_open_orders'],data['m4_validation']),
      'm5':m5(data['m5_policy'][0]),
      'p1_a':fefo(data['p1_batches'],data['p1_demand'],'scenario_a'),
      'p1_b':fefo(data['p1_batches'],data['p1_demand'],'scenario_b'),
      'p2':p2(data['p2_cohorts'],config['p2']),
      'p3':p3(data['p3_features'],config['p3']),
      'p4':p4(data['p4_versions']),
      'p5_no':cold(data['p5_inventory'],data['p5_demand'],False),
      'p5_yes':cold(data['p5_inventory'],data['p5_demand'],True)}
    q=[r for r in data['p5_inventory'] if r['status']=='quarantine']
    if len(q)!=1:raise ValueError('teaching scenario requires one quarantined batch')
    prob=num(q[0],'release_probability',0,1)
    result['p5_expected']={k:prob*result['p5_yes'][k]+(1-prob)*result['p5_no'][k] for k in ['closing','short']}
    if args.self_test:
        # Fixed-fixture answer tests: fail visibly if inputs change, never reset them.
        assert result['m1']=={'forecast':86,'ctb':55,'build':55,'shortfall':31}
        near(result['m2'][-1]['next_forecast'],2.28);near(sum(r['forecast'] for r in result['m3']),23)
        near(result['m4']['mean'],7);near(result['m4']['p90'],10);near(result['m4']['validation_coverage'],.6)
        for k,v in [('target',120),('constrained_order',40),('target_gap',20),('horizon_shortage',8),('buffer_not_achieved',12)]:near(result['m5'][k],v)
        assert result['p1_a']['totals']==[15,0,0] and result['p1_b']['totals']==[10,5,5]
        near(result['p2']['forecast'],170);near(result['p3']['score']['wmape'],12/272);near(result['p4']['fva'],.21875)
        near(result['p5_expected']['closing'],5.4);near(result['p5_expected']['short'],.4)
        # In-memory perturbations demonstrate true input dependence; originals untouched.
        b=copy.deepcopy(data['m1_bom']);b[0]['confirmed_receipt']='0';near(m1(data['m1_demand'],b)['ctb'],45)
        d=copy.deepcopy(data['m2_tsb_input']);d.append({'week':'4','demand':'0'});near(m2(d,config['m2'])[-1]['next_forecast'],1.824)
        d=copy.deepcopy(data['m3_installed_base']);d[1]['active_devices']='400';near(sum(r['forecast'] for r in m3(d)),20)
        d=copy.deepcopy(data['m4_completed_lead_times']);d[-1]['lead_days']='30';near(m4(d,data['m4_open_orders'],data['m4_validation'])['mean'],8.5)
        r=dict(data['m5_policy'][0],capacity='1000');near(m5(r)['constrained_order'],60);near(m5(r)['horizon_shortage'],0)
        d=copy.deepcopy(data['p1_demand']);d[2]['scenario_b']='10';assert fefo(data['p1_batches'],d,'scenario_b')['totals']==[15,0,5]
        d=copy.deepcopy(data['p2_cohorts']);d[1]['purchase_probability']='0.4';near(p2(d,config['p2'])['forecast'],150)
        d=copy.deepcopy(data['p3_features']);d[2]['holiday']='0';near(p3(d,config['p3'])['predictions'][2],60)
        d=copy.deepcopy(data['p4_versions']);d[0]['adjusted']='100';assert p4(d)['fva']<result['p4']['fva']
        d=copy.deepcopy(data['p5_inventory']);d[0]['boxes']='13';near(cold(d,data['p5_demand'],False)['short'],0)
        # Illegal inputs: one for every scenario.
        b=copy.deepcopy(data['m1_bom']);b[0]['per_finished']='0';rejected(lambda:m1(data['m1_demand'],b))
        rejected(lambda:m2(data['m2_tsb_input'],dict(config['m2'],beta='1.1')))
        d=copy.deepcopy(data['m3_installed_base']);d[0]['failure_probability']='-0.1';rejected(lambda:m3(d))
        d=copy.deepcopy(data['m4_completed_lead_times']);d[0]['lead_days']='-1';rejected(lambda:m4(d,data['m4_open_orders'],data['m4_validation']))
        rejected(lambda:m5(dict(data['m5_policy'][0],pack='0')))
        d=copy.deepcopy(data['p1_batches']);d[0]['quantity_boxes']='-1';rejected(lambda:fefo(d,data['p1_demand'],'scenario_a'))
        d=copy.deepcopy(data['p2_cohorts']);d[0]['purchase_probability']='1.5';rejected(lambda:p2(d,config['p2']))
        d=copy.deepcopy(data['p3_features']);d[0]['feature_available_at']='2099-01-01T00:00:00+08:00';rejected(lambda:p3(d,config['p3']))
        d=copy.deepcopy(data['p4_versions']);d[0]['actual']='-1';rejected(lambda:p4(d))
        d=copy.deepcopy(data['p5_inventory']);d[0]['status']='auto_released';rejected(lambda:cold(d,data['p5_demand'],False))
        rejected(lambda:m5(dict(data['m5_policy'][0],on_hand='10',on_order='60')))
        rejected(lambda:m5(dict(data['m5_policy'][0],capacity='20')))
        d=copy.deepcopy(data['p4_versions']);d[0]['adjusted_at']='2099-01-01T00:00:00+08:00';rejected(lambda:p4(d))
    after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.csv')}
    assert hashes==after,'input files changed'
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    for name, table in [('m2_states',result['m2']),('m3_forecast',result['m3']),('p1_a_ledger',result['p1_a']['ledger']),('p1_b_ledger',result['p1_b']['ledger']),('p5_no_ledger',result['p5_no']['ledger']),('p5_yes_ledger',result['p5_yes']['ledger'])]:
        with (outdir/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    (outdir/'input_hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
    print('PASS: CSV inputs computed; source CSV SHA256 unchanged.' + (' Bundled answers, 10 perturbations, 13 illegal-input tests passed.' if args.self_test else ' Use --self-test for bundled fixture checks.'))
    print('Computed output:',outdir/'results.json')
if __name__=='__main__':main()
