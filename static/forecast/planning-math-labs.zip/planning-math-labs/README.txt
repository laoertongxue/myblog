完全模拟教学数据。先阅读教材，再运行 python verify_planning_math.py --self-test。验证器只读，不修复输入。生成新样本请运行 python generate_planning_examples.py --out-dir 新目录；该目录必须不存在，避免覆盖已有文件。生成器不重写教材。本包是60天教学曲线、约束枚举和数学核验，不是20,000订单训练数据。
