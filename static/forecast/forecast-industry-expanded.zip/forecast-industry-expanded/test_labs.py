"""Executable mutation tests. Assertions do not replace data loading or model computation."""
import unittest, copy, tempfile, math, json, shutil, csv
from pathlib import Path
import run_labs as L
D=Path(__file__).resolve().parent/'data'
class Labs(unittest.TestCase):
    def setUp(self):self.cfg=json.loads((D/'config.json').read_text())
    def rows(self,n):return L.read(D,n+'.csv')
    def temp_args(self):return [self.rows('temperature_batches'),self.rows('temperature_segments'),self.cfg['temperature']]
    def app_args(self):return [self.rows('apparel_funnel'),self.rows('apparel_future_exposure'),self.rows('apparel_stock')]
    def vmi_args(self):return [self.rows('vmi_materials'),self.rows('vmi_demand'),self.rows('vmi_shipment_notices'),self.rows('vmi_realized_arrivals_scoring_only'),self.rows('vmi_initial_transit_scoring_only'),self.cfg['vmi']]
    def col_args(self):return [self.rows('collab_events'),self.rows('collab_stores'),self.rows('collab_redemptions'),self.rows('collab_packaging'),self.cfg['collab']]
    def test_01_temperature_numbers_and_missing(self):
        r=L.temperature(*self.temp_args());a,b,c=r['batches'];self.assertEqual(a['quality_low'],92);self.assertEqual(b['planning_hours'],36);self.assertEqual(c['remaining_model_hours_low'],41);self.assertIsNone(c['planning_hours']);self.assertFalse(r['safety_release'])
    def test_02_future_warm_scenario_changes_priority(self):
        args=self.temp_args()
        for b in args[0]:b['future_temperature_C']=8
        r=L.temperature(*args);self.assertEqual(r['scenario_priority'],['A','B']);self.assertEqual(r['batches'][0]['planning_hours'],22)
    def test_03_missing_segment_rejected(self):
        args=self.temp_args();args[1].pop(0)
        with self.assertRaises(ValueError):L.temperature(*args)
    def test_04_late_sensor_not_seen(self):
        args=self.temp_args();args[1][0]['available_at']='2026-06-01T13:00:00+00:00'
        self.assertEqual(L.temperature(*args)['batches'][0]['status'],'unknown_temperature_review')
    def test_05_label_expired_never_extended(self):
        args=self.temp_args();args[0][0]['label_expiry_at']='2026-06-01T11:00:00+00:00'
        r=L.temperature(*args)['batches'][0];self.assertEqual(r['status'],'label_expired');self.assertIsNone(r['planning_hours'])
    def test_06_sensor_outside_validated_range_rejected(self):
        args=self.temp_args();args[1][0]['temperature_C']=30
        with self.assertRaises(ValueError):L.temperature(*args)
    def test_07_apparel_posterior_and_reorder(self):
        r=L.apparel(*self.app_args());self.assertEqual((r['alpha'],r['beta']),(48,272));self.assertEqual(r['posterior_mean'],.15);self.assertAlmostEqual(r['remaining_expected_units'],306);self.assertEqual(r['reorder_units'],110);self.assertAlmostEqual(r['probability_above_break'],.940554342973,places=10)
    def test_08_late_funnel_excluded(self):
        args=self.app_args();args[0][-1]['available_at']='2026-06-04T02:00:00+00:00'
        r=L.apparel(*args);self.assertEqual(r['excluded_windows'],['3']);self.assertEqual((r['alpha'],r['beta']),(28,192))
    def test_09_lifecycle_not_just_conversion(self):
        args=self.app_args();args[1][1]['eligible_sessions_per_day']=0
        r=L.apparel(*args);self.assertEqual(r['posterior_mean'],.15);self.assertEqual(r['remaining_expected_units'],198);self.assertEqual(r['reorder_units'],0)
    def test_10_arrival_after_season_no_order(self):
        args=self.app_args();args[2][0]['order_lead_days']=9;args[2][0]['inbound_arrival_day']=12
        r=L.apparel(*args);self.assertEqual(r['reorder_units'],0);self.assertEqual(r['reason'],'arrival_after_lifecycle')
    def test_11_bad_funnel_rejected(self):
        args=self.app_args();args[0][0]['orders']=90
        with self.assertRaises(ValueError):L.apparel(*args)
    def test_12_no_eligible_sessions_no_reorder(self):
        args=self.app_args()
        for r in args[0]:r['stockout_clicks']=int(r['stockout_clicks'])+int(r['eligible_sessions']);r['eligible_sessions']=0;r['orders']=0
        r=L.apparel(*args);self.assertEqual(r['posterior_mean'],.1);self.assertEqual(r['reason'],'insufficient_observations')
    def test_13_beta_uniform_identity(self):
        self.assertAlmostEqual(L.beta_tail(1,1,.3),.7);self.assertAlmostEqual(L.beta_quantile(1,1,.975),.975)
    def test_14_vmi_base_conservation(self):
        r=L.vmi(*self.vmi_args());a,b=r['final'];self.assertEqual(a['consumed'],24);self.assertEqual(a['network_remaining'],38);self.assertEqual(b['network_remaining'],23)
        for row in r['ledger']:self.assertEqual(row['network_remaining']+row['cumulative_consumed'],row['initial_network_units'])
    def test_15_vmi_delay_changes_service_not_prediction(self):
        base=L.vmi(*self.vmi_args());delay=L.vmi(*self.vmi_args(),scenario='delay');self.assertEqual(base['plans'],delay['plans']);self.assertEqual(delay['final'][0]['unmet_units'],4);self.assertEqual(delay['final'][0]['ending_transit'],8)
    def test_16_vmi_asof_replan_after_notice(self):
        args=self.vmi_args();args[-1]['origin']='2026-06-01T13:00:00+00:00'
        r=L.vmi(*args,scenario='delay');self.assertEqual(r['plans'][0]['proposed_units'],12);self.assertEqual(r['plans'][0]['remaining_target_gap'],4);self.assertEqual(r['final'][0]['unmet_units'],0)
    def test_17_vmi_duplicate_notice_rejected(self):
        args=self.vmi_args();args[2].append(copy.deepcopy(args[2][0]))
        with self.assertRaises(ValueError):L.vmi(*args)
    def test_18_vmi_negative_and_hold_controls(self):
        args=self.vmi_args();args[0][0]['plant_usable_units']=-1
        with self.assertRaises(ValueError):L.vmi(*args)
        self.assertEqual(L.vmi(*self.vmi_args())['final'][0]['ending_hold'],2)
    def test_19_fresh_two_methods_differ(self):
        r=L.fresh(self.rows('fresh_hourly'),self.cfg['fresh']);h=[h for h in r['hours'] if h['hour']==12][0]
        self.assertEqual((r['observed_total'],r['time_estimate_total'],r['uv_estimate_total']),(163,214,212));self.assertEqual(h['time_scenario_range'],[17.6,22.4]);self.assertEqual(h['uv_scenario_range'],[16,20]);self.assertIsNone(h['factual_upper_bound']);self.assertEqual(r['regular_price_scenario_total'],168)
    def test_20_fresh_no_support_does_not_fabricate_zero(self):
        rows=[r for r in self.rows('fresh_hourly') if int(r['day'])==7]
        h=[h for h in L.fresh(rows,self.cfg['fresh'])['hours'] if h['hour']==12][0];self.assertIsNone(h['uv_point']);self.assertEqual(h['factual_lower_bound'],8)
    def test_21_fresh_pv_not_used_as_unique_sessions(self):
        rows=self.rows('fresh_hourly');a=L.fresh(rows,self.cfg['fresh'])
        for r in rows:r['oos_pv']=int(r['oos_pv'])*20
        self.assertEqual(a,L.fresh(rows,self.cfg['fresh']))
    def test_22_fresh_zero_stock_with_sales_rejected(self):
        rows=self.rows('fresh_hourly');rows[-1]['in_stock_minutes']=0
        with self.assertRaises(ValueError):L.fresh(rows,self.cfg['fresh'])
    def test_23_fresh_late_history_removed(self):
        rows=self.rows('fresh_hourly')
        for r in rows:
            if r['hour']=='12' and r['day']=='1':r['available_at']='2026-06-08T00:00:00+00:00'
        h=[h for h in L.fresh(rows,self.cfg['fresh'])['hours'] if h['hour']==12][0];self.assertEqual(h['comparable_hours'],5);self.assertNotEqual(h['time_point'],20)
    def test_24_collab_allocations_and_lock_idempotency(self):
        r=L.collab(*self.col_args());self.assertEqual((r['first_total'],r['second_total'],r['central_after_second']),(240,100,20));self.assertEqual(r['excluded_events'],['A_late']);self.assertEqual(r['incremental_duplicate_safe_lock_units'],0)
        c=r['known_event_conservation'];self.assertEqual(c['opening'],sum(v for k,v in c.items() if k!='opening'))
    def test_25_collab_late_report_changes_forecast(self):
        args=self.col_args();args[-1]['second_origin']='2026-06-10T11:10:00+00:00'
        r=L.collab(*args);self.assertEqual(r['stores'][0]['known_redemptions'],75);self.assertEqual(r['stores'][0]['updated_total_scenario'],187.5);self.assertEqual(r['stores'][0]['remaining_scenario_gap'],27.5)
    def test_26_collab_duplicate_redemption_rejected(self):
        args=self.col_args();args[2].append(copy.deepcopy(args[2][0]))
        with self.assertRaises(ValueError):L.collab(*args)
    def test_27_collab_capacity_changes_second_allocation(self):
        args=self.col_args();args[-1]['van_capacity_units']=80
        r=L.collab(*args);self.assertEqual(r['second_total'],80);self.assertEqual([s['second_proposed'] for s in r['stores']],[50,0,30])
    def test_28_collab_invalid_share_rejected(self):
        for value in [0,1.2,-.1,'nan']:
            args=self.col_args();args[1][0]['known_hour_share']=value
            with self.assertRaises(ValueError):L.collab(*args)
    def test_29_collab_future_outcome_cannot_enter_analogs(self):
        args=self.col_args();args[0][0]['outcome_available_at']='2026-06-11T00:00:00+00:00'
        with self.assertRaises(ValueError):L.collab(*args)
    def test_30_nan_and_infinity_rejected(self):
        for value in ['nan','inf','-inf']:
            with self.assertRaises(ValueError):L.number(value)
    def test_31_full_pipeline_writes_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            r=L.run(D,d);self.assertTrue((Path(d)/'vmi_on_time_ledger.csv').is_file());self.assertEqual(r['fresh_scoring_only']['latent_total'],212)
    def test_32_hidden_truth_not_used_for_fresh_estimates(self):
        with tempfile.TemporaryDirectory() as td:
            data=Path(td)/'data';shutil.copytree(D,data)
            original=L.run(data,Path(td)/'before')
            path=data/'fresh_truth_scoring_only.csv';rows=L.read(data,path.name)
            for r in rows:r['latent_demand_units']='999'
            with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            mutated=L.run(data,Path(td)/'after')
            self.assertEqual(original['fresh'],mutated['fresh'])
            self.assertNotEqual(original['fresh_scoring_only'],mutated['fresh_scoring_only'])
    def test_33_moq_cannot_be_overridden_by_small_capacity(self):
        args=self.app_args();args[2][0]['max_order_units']=40
        r=L.apparel(*args);self.assertEqual(r['reorder_units'],0);self.assertEqual(r['reason'],'below_minimum_order_capacity')
    def test_34_unsupported_hours_do_not_crash_scoring(self):
        with tempfile.TemporaryDirectory() as td:
            data=Path(td)/'data';shutil.copytree(D,data);rows=[r for r in self.rows('fresh_hourly') if r['day']=='7']
            with (data/'fresh_hourly.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            r=L.run(data,Path(td)/'out');self.assertEqual(r['fresh_scoring_only']['uv_scored_hours'],8)
    def test_35_missing_target_hour_keeps_daily_totals_unknown(self):
        rows=[r for r in self.rows('fresh_hourly') if not(r['day']=='7' and r['hour']=='12')]
        r=L.fresh(rows,self.cfg['fresh']);self.assertEqual(r['target_coverage']['missing_hours'],[12]);self.assertIsNone(r['observed_total']);self.assertIsNone(r['uv_estimate_total']);self.assertEqual(r['partial_observed_total'],155)
    def test_36_late_target_hour_keeps_daily_totals_unknown(self):
        rows=self.rows('fresh_hourly')
        for r in rows:
            if r['day']=='7' and r['hour']=='12':r['available_at']='2026-06-08T00:00:00+00:00'
        r=L.fresh(rows,self.cfg['fresh']);self.assertEqual(r['target_coverage']['unavailable_hours'],[12]);self.assertIsNone(r['observed_total']);self.assertEqual(r['partial_uv_estimate_total'],194)
    def test_37_all_target_hours_absent_not_zero_and_pipeline_runs(self):
        with tempfile.TemporaryDirectory() as td:
            data=Path(td)/'data';shutil.copytree(D,data);rows=[r for r in self.rows('fresh_hourly') if r['day']!='7']
            with (data/'fresh_hourly.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            r=L.run(data,Path(td)/'out');self.assertIsNone(r['fresh']['observed_total']);self.assertEqual(r['fresh']['target_coverage']['status'],'no_target_observations');self.assertEqual(r['fresh_scoring_only']['uv_scored_hours'],0);self.assertIsNone(r['fresh_scoring_only']['uv_MAE']);self.assertEqual(len((Path(td)/'out'/'fresh_hourly_results.csv').read_text().splitlines()),1)
    def test_38_notice_visibility_does_not_change_physical_initial_stock(self):
        args=self.vmi_args()
        for r in args[2]:r['available_at']='2026-06-01T09:00:00+00:00'
        r=L.vmi(*args);self.assertEqual(r['plans'][0]['proposed_units'],12);self.assertEqual(r['final'][0]['initial_network_units'],62);self.assertEqual(r['final'][0]['ending_usable'],8);self.assertEqual(r['final'][0]['network_remaining'],38)
        received=[x for x in r['ledger'] if x['kind']=='receipt_old'];self.assertEqual(received[0]['units'],8)
    def test_39_notice_quantity_does_not_change_actual_receipt(self):
        args=self.vmi_args();args[2][0]['units']=1
        r=L.vmi(*args);self.assertEqual(r['final'][0]['initial_network_units'],62);self.assertEqual([x['units'] for x in r['ledger'] if x['kind']=='receipt_old'],[8])
    def test_40_old_duplicate_revisions_rejected_in_every_order(self):
        import itertools
        args=self.vmi_args();args[2][1]['available_at']='2026-06-01T07:30:00+00:00'
        for rows in itertools.permutations([args[2][1],args[2][0],copy.deepcopy(args[2][0])]):
            bad=copy.deepcopy(args);bad[2]=list(rows)
            with self.assertRaises(ValueError):L.vmi(*bad)
    def test_41_duplicate_packaging_received_or_pending_rejected(self):
        for index in [0,2]:
            args=self.col_args();args[3].append(copy.deepcopy(args[3][index]))
            with self.assertRaises(ValueError):L.collab(*args)
    def test_42_lock_netting_before_box_rounding(self):
        for pending,expected in [(170,0),(160,20),(167,20),(0,180)]:
            args=self.col_args();args[3][-1]['units']=pending
            r=L.collab(*args);self.assertEqual(r['incremental_duplicate_safe_lock_units'],expected);self.assertEqual(r['incremental_duplicate_safe_lock_units']%20,0)
    def test_43_packaging_time_fields_validated_and_delay_reported(self):
        for field,value in [('expected_at','bogus'),('planned_at','2099-01-01'),('original_expected_at','2026-06-01T00:00:00+00:00'),('planned_at','2099-01-01T00:00:00+00:00')]:
            args=self.col_args();args[3][-1][field]=value
            with self.assertRaises(ValueError):L.collab(*args)
        r=L.collab(*self.col_args());self.assertEqual(r['production_timing_risks'][0]['lot'],'locked_production');self.assertIn('latest_eta_after_activity_opening',r['production_timing_risks'][0]['flags'])
    def test_44_prior_activity_redemption_is_excluded(self):
        args=self.col_args();args[2][0]['event_at']='2026-06-09T10:50:00+00:00';args[2][0]['available_at']='2026-06-09T10:55:00+00:00'
        r=L.collab(*args);self.assertEqual(r['stores'][0]['known_redemptions'],0);self.assertIn('A_1',r['excluded_events'])
    def test_45_fractional_unit_boxes_rejected(self):
        for field,value in [('box_units',2.5),('production_box_units',.5)]:
            args=self.col_args();args[-1][field]=value
            with self.assertRaises(ValueError):L.collab(*args)
    def test_46_apparel_mixed_style_or_duplicate_snapshot_rejected(self):
        args=self.app_args();args[0][-1]['style']='OTHER'
        with self.assertRaises(ValueError):L.apparel(*args)
        args=self.app_args();args[2].append(copy.deepcopy(args[2][0]))
        with self.assertRaises(ValueError):L.apparel(*args)
    def test_47_apparel_origin_must_match_lifecycle_start(self):
        args=self.app_args();args[2][0]['origin']='2026-06-03T00:00:00+00:00';args[2][0]['observed_sales_units']=26
        with self.assertRaises(ValueError):L.apparel(*args)
    def test_48_duplicate_temperature_segment_id_rejected(self):
        args=self.temp_args();args[1][1]['segment']=args[1][0]['segment']
        with self.assertRaises(ValueError):L.temperature(*args)
    def test_49_unknown_vmi_demand_material_rejected(self):
        args=self.vmi_args();args[1].append({'material':'UNKNOWN','day':1,'units':999})
        with self.assertRaises(ValueError):L.vmi(*args)
    def test_50_duplicate_analog_id_rejected(self):
        args=self.col_args();args[0][0]['weight']=.2;args[0].append(copy.deepcopy(args[0][0]))
        with self.assertRaises(ValueError):L.collab(*args)
    def test_51_hour_labels_must_match_event_time(self):
        rows=self.rows('fresh_hourly');rows[-1]['event_end_at']='2026-06-06T23:00:00+00:00'
        with self.assertRaises(ValueError):L.fresh(rows,self.cfg['fresh'])
    def test_52_no_instock_exposure_without_instock_time(self):
        rows=self.rows('fresh_hourly');rows[-1]['in_stock_minutes']=0;rows[-1]['sales_units']=0
        with self.assertRaises(ValueError):L.fresh(rows,self.cfg['fresh'])
    def test_53_vmi_physical_snapshot_identity_validation(self):
        args=self.vmi_args();args[4].append(copy.deepcopy(args[4][0]))
        with self.assertRaises(ValueError):L.vmi(*args)
        args=self.vmi_args();args[2][0]['material']='M2'
        with self.assertRaises(ValueError):L.vmi(*args)
        args=self.vmi_args();args[4][0]['snapshot_at']='2026-06-02T08:00:00+00:00'
        with self.assertRaises(ValueError):L.vmi(*args)
    def test_54_vmi_cannot_replan_after_day_one_consumption(self):
        for origin in ['2026-06-01T16:00:00+00:00','2026-06-04T08:00:00+00:00']:
            args=self.vmi_args();args[-1]['origin']=origin
            with self.assertRaises(ValueError):L.vmi(*args)
    def test_55_second_delivery_cannot_precede_decision(self):
        for origin in ['2026-06-10T12:00:00+00:00','2026-06-10T13:00:00+00:00']:
            args=self.col_args();args[-1]['second_origin']=origin
            with self.assertRaises(ValueError):L.collab(*args)
if __name__=='__main__':unittest.main(verbosity=2)
