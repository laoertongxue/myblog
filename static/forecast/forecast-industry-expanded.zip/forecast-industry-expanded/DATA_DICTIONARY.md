# 输入字段字典

全部CSV为UTF-8，首行为字段名。时间字符串必须含时区；本包统一UTC。数值必须有限，不允许NaN/Infinity。除温度temperature_C明确允许空值外，必需数值不可空。没有个人用户资料、真实订单、真实食品检测或企业敏感数据。

## 共用约定

- event_at/start_at/end_at/event_end_at：事件发生或观察窗口时点。
- available_at/outcome_available_at：数据实际进入系统可供使用的时点，不等于事件时点。
- origin：本轮决策的信息截止时间。
- 带scoring_only的文件：仅用于估计完成后的回放/评分，不是决策特征。
- 记录唯一性：温度批次/段、日小时、核销event_id、供应通知shipment_id/revision、VMI物料日不允许重复冲销两次。
- 本包整数数量均以单件为单位；品质分、参数、概率、期望数量可为小数。

## temperature_batches.csv 3行

batch为批次唯一ID；harvest_at为采摘起点；origin为12小时轨迹截止；label_expiry_at为不可延长的硬标签截止；initial_quality为教学初始品质分100；quality_alert_level为教学提醒阈值70分；future_temperature_C为未来恒温情景，不是未来实测。

## temperature_segments.csv 18行

batch关联批次；segment为段号；start_at/end_at为连续不重叠区间；available_at不得早于整段结束；temperature_C是该段恒温模拟读数，单位℃，C第2段为空。未知值或晚到值均触发复核。区间总覆盖必须从采摘到origin，不允许删行后默默缩短暴露时间。

## apparel_funnel.csv 3行

style为款ID；window为24小时窗口；start_at/end_at/available_at为窗口和可用时点。impressions为曝光次，clicks为点击次；cart_sessions/favorite_sessions为至少一次加购/收藏的会话，二者可重叠；eligible_sessions为去重、当时可买且观察完整的会话n；orders为这些会话中购买1件的数量x；stockout_clicks为缺货条件下点击；duplicate_clicks为按本例规则排除的重复点击。后三类满足eligible_sessions+stockout_clicks+duplicate_clicks=clicks。缺货排除并不保证可迁移性。

## apparel_future_exposure.csv 3行

phase为生命周期阶段；start_day/end_day为相对上架的连续天数边界，左闭右开；eligible_sessions_per_day为未来每日合格会话情景；conversion_multiplier为该阶段对后验购买概率的倍率。不是训练标签。阶段覆盖第3日到第12日。

## apparel_stock.csv 1行

style为本次唯一款号X；launch_at为明确上架时点；origin为72小时决策时点；initial_units为首单库存100；observed_sales_units为库存渠道独立确认的累计已售46，不要求与迟到的点击漏斗同一到达速度；confirmed_inbound_units为已确认在途20；inbound_arrival_day为在途到达相对日6；order_lead_days为新追单交期3日；season_end_day为季末12；pack_units为箱规10；moq_units为最低订单50；max_order_units为供应上限120；prior_alpha/prior_beta为固定Beta先验2/18；p_break为固定概率门槛0.12；probability_gate为超过该门槛的后验概率要求0.8。本简化要求既有在途与新追单同日到，其他情况需另写日事件账，程序会拒绝静默套公式。

## vmi_materials.csv 2行

material为物料；supplier为未消耗库存所有者；supplier_units为供应商位置可发数量；plant_usable_units为厂内可领用；plant_hold_units为厂内待检，仅占空间不能消耗；target_units为覆盖期需求加缓冲的有限期库存位置目标；pack_units/moq_units为整箱/最小发运；supplier_dispatch_capacity为本日最大发运量；plant_capacity_units为厂内可用与待检合计容量；lead_days为新增补货从第1日发出到达的天数。

## vmi_demand.csv 4行

material、day（第1/2日）、units（当天领用需求）。本例需求无跨日积压，不足计为当日未满足；生产需求没有被供给上限覆盖成较小的需求数。

## vmi_shipment_notices.csv 2行

shipment_id为同一已发运批次OLD_M1；material为M1；revision为1/2版本；units为8件；eta_day为期望到达日2或3；available_at为版本发布时间。先检查全局shipment_id/revision唯一，再选择决策截止前最高版本，不加总两个版本。通知units只用于计划，不能决定物理初态和实收数量。

## vmi_initial_transit_scoring_only.csv 1行

shipment_id为初始在途唯一ID；material为物料；supplier为未消耗物料所属供应商；units为真实模拟初始在途数量8；snapshot_at必须等于config中的physical_snapshot_at。此表只为物理回放初始化，不能拿它补足当时不可见的通知。通知延迟或内容修订不改变该物理真值。

## vmi_realized_arrivals_scoring_only.csv 2行

scenario为on_time/delay；shipment_id对应旧在途；arrival_day为该情景的真实模拟到达日。两种回放共用冻结计划，之后才读取本文件判断实际是否来得及。

## fresh_hourly.csv 84行

day为实验第1—7天；hour为区间开始小时8—19；event_end_at为该小时结束；available_at为小时汇总进入系统的时间；price_regime为regular或markdown；price_yuan为每件售价10或6元；in_stock_minutes为0—60分钟有货时长；sales_units为已经实现销量；in_stock_unique_sessions/oos_unique_sessions为有货/无货期间按相同规则去重的独立会话；oos_pv为无货页面浏览次数，不能与会话转化率混用。

第1—6天是候选历史，只有同小时、同价格/价格状态、有货60分钟且时点已知的行进入实际价格需求估计。正价情景另筛同小时全程正价行。每会话最多1件是生成假设，故sales_units不能超过in_stock_unique_sessions。

## fresh_truth_scoring_only.csv 12行

day、hour为目标键；latent_demand_units为模拟器生成的假如始终有货的潜在件数。在fresh函数接口中不接收此文件；主程序先生成结果，再读它评分。它不是现实能直接观测的断货需求。

## collab_events.csv 4行

event为旧活动ID；baseline_cups为常态同口径首日杯量；day1_cups为旧联名活动首日杯量；weight为事前冻结相似度权重，和为1；feature_known_at为相似特征已知时间；outcome_available_at为该活动结果可用时间。基线必须大于0，不允许“用本次结果选择最相似的旧活动”。

## collab_stores.csv 3行

store为A/B/C；baseline_cups为本次门店常态首日杯量；first_capacity为首配数量上限；delivery_capacity为二配每店当车容量上限；known_hour_share为截至11时核销占全日的历史情景比例0.4；forecast_before_delivery为11—12时到货前新增需求情景20/10/15。它们是冻结参数，不是保证。

## collab_redemptions.csv 4行

event_id为唯一核销事件（可代表已汇总但不重复的批次）；store为门店；event_at为核销发生；available_at为上传到达；units为杯数。A_late在10:57发生、11:10上传，11:00不能用，11:10可用。无退款/冲销事件是本例限制，真实实现必须定义对应逆向事件，不可通过删除历史修改账。

## collab_packaging.csv 3行

lot为包材批次；units为数量；status为received或in_production；planned_at为计划建立时点；original_expected_at为原承诺到达（第9日）；expected_at为最新预计到达；actual_at为已收货时点（未收货为空）；available_at为该行状态信息可用时间。仅status=received且actual_at/available_at不晚于首配截止的行加入物理库存，in_production单列为未结锁产。lot必须唯一，所有日期解析校验先后，在制时点风险会实际输出。当前批次初始200+已收到160=360，在制180不加入首配。

## config.json

synthetic=true是实验标记；timezone=UTC。temperature定义0.5分/小时基准、每超4℃每小时每℃额外0.125分和有效模拟范围0—12℃。vmi定义物理初始快照时点、first_consumption_at=第1日16:00、信息截止与2日期间；决策必须在初态之后且首领用之前。fresh定义实验第1日午夜day1_start_at、预期营业小时expected_hours=8至19、目标第7天、20:00截止、至少3个可比小时。collab定义活动开始event_start=第10日08:00、second_delivery_at=第10日12:00（决策必须早于它）、首配07:00、二配11:00、核销窗口截至11:00、50%首配、10件配送箱规、20件生产箱规、首轮保留80/二轮保留20、车容量100。

## 关键输出口径

planning_hours：在完整已知温度与标签未到期时的教学提醒小时，不能解释为食用许可。posterior_mean：合格会话购买概率。remaining_expected_units：给定阶段流量和倍率后的需求期望。on_arrival_before_new_order与mean_scenario_ending：均值情景库存，不是随机库存的完整期望。

network_remaining+cumulative_consumed：VMI每事件应等于initial_network_units。factual_upper_bound为空：无假设不能识别有限需求上界。time_scenario_range/uv_scenario_range：条件敏感性范围，不带置信水平。asof_book_stock：仅按已到达核销计算的账存。second_proposed：必须核对实物和权限的二配草稿。incremental_duplicate_safe_lock_units：本单活动在相同台账下避免重复锁产后的新增建议。

第二版输出新增target_coverage（预期/已到/缺失/迟到小时），全天不完整时各total为空，partial_*仅为已有小时小计。production_timing_risks列出可见在制批次的时间风险。VMI owner只是未消耗物料和消耗来源标签，不是产权转移分录。
