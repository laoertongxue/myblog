# 第三版时点边界修复

第二版53项测试和原独立缺陷探针已通过复审，但独立审查额外发现两个越过决策窗口后仍能倒填过去的问题，本版补严格支持范围而不扩成商业滚动系统。

1. VMI新增first_consumption_at。必须与初态同在第1日、晚于初态，且physical_snapshot_at≤origin<first_consumption_at。第1日13:00示例仍有效，16:00或第4日08:00拒绝。
2. 联名新增second_delivery_at=12:00，要求event_window_end≤second_origin<second_delivery_at。11:10迟报重算仍有效，12:00或13:00拒绝倒填。

作者测试55项通过；独立复审结论另由审查方给出。原数学基线和16CSV/149行不变。
