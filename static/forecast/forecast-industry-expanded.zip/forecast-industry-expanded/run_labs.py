"""Five synthetic industry labs. Python standard library only; no external actions."""
import csv,json,math,argparse
from pathlib import Path
from datetime import datetime, timedelta, timezone
from collections import defaultdict
ROOT=Path(__file__).resolve().parent

def number(x,name='number',low=0,high=None,integer=False):
    try:v=float(x)
    except (TypeError,ValueError):raise ValueError(f'{name}: numeric value required')
    if not math.isfinite(v) or v<low or (high is not None and v>high) or (integer and not v.is_integer()):raise ValueError(f'{name}: invalid {x}')
    return int(v) if integer else v

def stamp(s):
    try:d=datetime.fromisoformat(s)
    except (ValueError,TypeError):raise ValueError(f'invalid timestamp {s}')
    if d.tzinfo is None:raise ValueError('timezone required')
    return d

def read(data,name):
    with (Path(data)/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def positive(x,name):
    v=number(x,name)
    if v<=0:raise ValueError(name+' must be positive')
    return v

def temperature(batches,segments,params):
    base=positive(params['base_rate_points_per_hour'],'base rate');extra=number(params['extra_rate_per_C_per_hour'])
    lo=number(params['valid_min_C']);hi=number(params['valid_max_C'],low=lo);ref=number(params['reference_C'],low=lo,high=hi)
    def rate(t):return base+extra*max(t-ref,0)
    out=[];segment_keys=set()
    if not batches:raise ValueError('at least one batch required')
    for row in segments:
        key=(row['batch'],number(row['segment'],'segment',1,integer=True))
        if key in segment_keys:raise ValueError('duplicate temperature segment ID')
        segment_keys.add(key)
    if len({b['batch'] for b in batches})!=len(batches):raise ValueError('duplicate batch')
    if any(s['batch'] not in {b['batch'] for b in batches} for s in segments):raise ValueError('unknown temperature batch')
    for b in batches:
        origin=stamp(b['origin']);start=stamp(b['harvest_at']);expiry=stamp(b['label_expiry_at'])
        q0=positive(b['initial_quality'],'initial quality');threshold=number(b['quality_alert_level'],high=q0)
        future=number(b['future_temperature_C'],'future temperature',lo,hi)
        if not start<origin:raise ValueError('harvest must precede origin')
        ss=sorted((s for s in segments if s['batch']==b['batch']),key=lambda s:stamp(s['start_at']))
        end=start;damage_lo=damage_hi=0;unknown=[];parts=[]
        for s in ss:
            a=stamp(s['start_at']);z=stamp(s['end_at']);av=stamp(s['available_at'])
            if a!=end or z<=a or z>origin:raise ValueError('temperature coverage gap, overlap, or future segment')
            if av<z:raise ValueError('whole-segment average cannot be available before segment ends')
            hours=(z-a).total_seconds()/3600;missing=av>origin or s['temperature_C']==''
            if missing:
                dl=hours*rate(lo);dh=hours*rate(hi);unknown.append(s['segment'])
            else:
                t=number(s['temperature_C'],'temperature',lo,hi);dl=dh=hours*rate(t)
            damage_lo+=dl;damage_hi+=dh;end=z
            parts.append({'segment':s['segment'],'hours':hours,'damage_low':dl,'damage_high':dh,'unknown':missing})
        if end!=origin:raise ValueError('temperature history does not reach origin')
        qlo=max(0,q0-damage_hi);qhi=max(0,q0-damage_lo)
        rlo=max(0,(qlo-threshold)/rate(future));rhi=max(0,(qhi-threshold)/rate(future))
        label=max(0,(expiry-origin).total_seconds()/3600)
        status='label_expired' if label==0 else ('unknown_temperature_review' if unknown else ('quality_alert_review' if qlo<=threshold else 'scenario_only'))
        out.append(dict(batch=b['batch'],damage_low=damage_lo,damage_high=damage_hi,quality_low=qlo,quality_high=qhi,remaining_model_hours_low=rlo,remaining_model_hours_high=rhi,label_remaining_hours=label,planning_hours=None if unknown or label==0 else min(label,rlo),status=status,segments=parts))
    return {'batches':out,'scenario_priority':[x['batch'] for x in sorted((x for x in out if x['planning_hours'] is not None),key=lambda x:(x['planning_hours'],x['batch']))],'safety_release':False}

def beta_tail(a,b,p):
    """P(Beta(a,b)>=p), positive integer a,b, via binomial identity."""
    if a<1 or b<1 or not float(a).is_integer() or not float(b).is_integer():raise ValueError('integer positive Beta parameters required')
    p=number(p,'p',0,1)
    if p==0:return 1.0
    if p==1:return 0.0
    n=int(a+b-1)
    # log gamma avoids underflow in each binomial coefficient, log-sum-exp stabilizes sum.
    logs=[math.lgamma(n+1)-math.lgamma(k+1)-math.lgamma(n-k+1)+k*math.log(p)+(n-k)*math.log1p(-p) for k in range(int(a))]
    m=max(logs)
    return min(1.0,math.exp(m)*sum(math.exp(x-m) for x in logs))
def beta_quantile(a,b,q):
    lo,hi=0.,1.
    for _ in range(70):
        mid=(lo+hi)/2
        if 1-beta_tail(a,b,mid)<q:lo=mid
        else:hi=mid
    return (lo+hi)/2

def apparel(funnel,phases,stock):
    if len(stock)!=1:raise ValueError('exactly one apparel stock snapshot required')
    s=stock[0];origin=stamp(s['origin']);launch=stamp(s['launch_at'])
    current_day=(origin-launch).total_seconds()/86400
    if current_day<0:raise ValueError('origin precedes launch')
    if not s['style'] or any(r['style']!=s['style'] for r in funnel):raise ValueError('single style must match stock snapshot')
    if len({r['window'] for r in funnel})!=len(funnel):raise ValueError('duplicate funnel window ID')
    if not phases or len({r['phase'] for r in phases})!=len(phases):raise ValueError('nonempty unique lifecycle phases required')
    a=number(s['prior_alpha'],integer=True);b=number(s['prior_beta'],integer=True)
    if a<1 or b<1:raise ValueError('positive prior required')
    included=[];excluded=[];n=x=im=cl=cart=fav=0;last_end=None
    for r in sorted(funnel,key=lambda r:stamp(r['start_at'])):
        start=stamp(r['start_at']);end=stamp(r['end_at']);av=stamp(r['available_at'])
        if start<launch or end<=start or av<end or (last_end and start<last_end):raise ValueError('overlapping or invalid funnel windows')
        last_end=end
        if end>origin or av>origin:excluded.append(r['window']);continue
        vals={k:number(r[k],k,integer=True) for k in ['impressions','clicks','cart_sessions','favorite_sessions','eligible_sessions','orders','stockout_clicks','duplicate_clicks']}
        if vals['clicks']>vals['impressions'] or vals['cart_sessions']>vals['clicks'] or vals['favorite_sessions']>vals['clicks'] or vals['orders']>vals['eligible_sessions'] or vals['orders']>vals['cart_sessions']:raise ValueError('funnel counts inconsistent')
        if vals['eligible_sessions']+vals['stockout_clicks']+vals['duplicate_clicks']!=vals['clicks']:raise ValueError('click denominator reconciliation failed')
        n+=vals['eligible_sessions'];x+=vals['orders'];im+=vals['impressions'];cl+=vals['clicks'];cart+=vals['cart_sessions'];fav+=vals['favorite_sessions'];included.append(r['window'])
    ap=a+x;bp=b+n-x;p=ap/(ap+bp)
    start_day=min(number(r['start_day']) for r in phases)
    if not math.isclose(start_day,current_day):raise ValueError('lifecycle start_day must equal origin minus launch in days')
    season=number(s['season_end_day']);arrival=start_day+number(s['order_lead_days'])
    future=before=after=0;phase_out=[];end=start_day
    for r in sorted(phases,key=lambda r:number(r['start_day'])):
        begin=number(r['start_day']);stop=number(r['end_day']);sessions=number(r['eligible_sessions_per_day']);mult=number(r['conversion_multiplier'])
        if begin!=end or stop<=begin or stop>season or p*mult>1:raise ValueError('invalid lifecycle phase or probability')
        days=stop-begin;pre=max(0,min(stop,arrival)-begin);d=days*sessions*p*mult
        future+=d;before+=pre*sessions*p*mult;after+=(days-pre)*sessions*p*mult;end=stop
        phase_out.append(dict(phase=r['phase'],eligible_sessions=days*sessions,conversion=p*mult,expected_units=d))
    if end!=season:raise ValueError('lifecycle phases must cover through season end')
    initial=number(s['initial_units'],integer=True);sold=number(s['observed_sales_units'],high=initial,integer=True);onhand=initial-sold
    inbound=number(s['confirmed_inbound_units'],integer=True);inbound_day=number(s['inbound_arrival_day'])
    if inbound_day!=arrival:raise ValueError('this exercise requires inbound and reorder to arrive together; use a daily ledger otherwise')
    arriving_stock=max(onhand-before,0)+inbound
    need=max(after-arriving_stock,0);pack=positive(s['pack_units'],'pack');moq=number(s['moq_units']);cap=number(s['max_order_units'])
    if not float(pack).is_integer() or moq%pack or cap%pack:raise ValueError('MOQ/cap must be whole packs')
    gate=number(s['probability_gate'],'probability gate',0,1);tail=beta_tail(ap,bp,number(s['p_break'],'p break',0,1))
    q=0;reason='threshold_not_met'
    if n==0:reason='insufficient_observations'
    elif arrival>=season:reason='arrival_after_lifecycle'
    elif tail>=gate:
        q=min(cap,max(moq,math.ceil(need/pack)*pack)) if need>0 and cap>=moq else 0;reason='draft_reorder' if q>0 else ('below_minimum_order_capacity' if need>0 and cap<moq else 'no_gap')
    return dict(included_windows=included,excluded_windows=excluded,eligible_sessions=n,orders=x,ctr=None if im==0 else cl/im,cart_per_click=None if cl==0 else cart/cl,favorite_per_click=None if cl==0 else fav/cl,alpha=ap,beta=bp,posterior_mean=p,credible_interval_95=[beta_quantile(ap,bp,.025),beta_quantile(ap,bp,.975)],probability_above_break=tail,phase_forecasts=phase_out,remaining_expected_units=future,lifecycle_expected_units=sold+future,before_arrival_expected_units=before,after_arrival_expected_units=after,current_onhand=onhand,on_arrival_before_new_order=arriving_stock,prearrival_mean_scenario_shortfall=max(before-onhand,0),net_gap_after_arrival=need,reorder_units=q,mean_scenario_ending=max(arriving_stock+q-after,0),reason=reason)

def asof_notices(notices,origin):
    out={};seen=set()
    for r in notices:
        key=r['shipment_id'];rev=number(r['revision'],'revision',1,integer=True)
        pair=(key,rev)
        if pair in seen:raise ValueError('duplicate shipment revision')
        seen.add(pair)
        number(r['units'],integer=True);number(r['eta_day'],'eta day',1,integer=True)
        av=stamp(r['available_at'])
        if av>origin:continue
        if key not in out or rev>number(out[key]['revision']):out[key]=r
    return list(out.values())

def vmi(materials,demand,notices,arrivals,initial_transit,params,scenario='on_time'):
    horizon=number(params['horizon_days'],'horizon',1,integer=True);origin=stamp(params['origin']);physical_clock=stamp(params['physical_snapshot_at']);visible=asof_notices(notices,origin)
    first_consumption=stamp(params['first_consumption_at'])
    if first_consumption.astimezone(timezone.utc).date()!=physical_clock.astimezone(timezone.utc).date() or first_consumption<=physical_clock:raise ValueError('first consumption must occur after the snapshot on day 1')
    if not physical_clock<=origin<first_consumption:raise ValueError('VMI decision must precede day-1 consumption; this is not a rolling replanner')
    if not materials or len({r['material'] for r in materials})!=len(materials):raise ValueError('nonempty unique VMI materials required')
    mids={r['material'] for r in materials};owners={r['material']:r['supplier'] for r in materials}
    if any(r['material'] not in mids for r in notices):raise ValueError('unknown material in VMI notice')
    physical_ids=set()
    for r in initial_transit:
        if r['shipment_id'] in physical_ids:raise ValueError('duplicate physical initial shipment')
        physical_ids.add(r['shipment_id'])
        if r['material'] not in mids or r['supplier']!=owners[r['material']]:raise ValueError('invalid physical shipment material/owner')
        number(r['units'],'physical shipment units',1,integer=True)
        if stamp(r['snapshot_at'])!=physical_clock:raise ValueError('physical transit snapshot time mismatch')
    if any(r['shipment_id'] not in physical_ids for r in notices):raise ValueError('notice has no corresponding initial physical shipment')
    physical_materials={r['shipment_id']:r['material'] for r in initial_transit}
    if any(r['material']!=physical_materials[r['shipment_id']] for r in notices):raise ValueError('shipment notice material does not match shipment identity')
    arrival_keys=set()
    for r in arrivals:
        key=(r['scenario'],r['shipment_id'])
        if key in arrival_keys:raise ValueError('duplicate realized shipment scenario')
        arrival_keys.add(key)
        if r['shipment_id'] not in physical_ids:raise ValueError('unknown realized shipment')
        number(r['arrival_day'],'realized arrival day',1,integer=True)
    dem={}
    for r in demand:
        key=(r['material'],number(r['day'],integer=True))
        if key[0] not in mids or key[1]<1 or key[1]>horizon:raise ValueError('unknown material or outside-horizon demand')
        if key in dem:raise ValueError('duplicate demand row')
        dem[key]=number(r['units'],integer=True)
    plans=[];ledgers=[];final=[]
    for m in materials:
        mid=m['material'];supp=number(m['supplier_units'],integer=True);plant=number(m['plant_usable_units'],integer=True);hold=number(m['plant_hold_units'],integer=True);lead=number(m['lead_days'],integer=True);arrday=1+lead
        pack=positive(m['pack_units'],'pack');moq=number(m['moq_units']);cap=number(m['supplier_dispatch_capacity']);sitecap=number(m['plant_capacity_units']);target=number(m['target_units'])
        if pack%1 or moq%pack or cap%pack:raise ValueError('VMI pack constraints invalid')
        if plant+hold>sitecap:raise ValueError('initial site capacity exceeded')
        if any((mid,d) not in dem for d in range(1,horizon+1)):raise ValueError('missing daily demand')
        shipments=[r for r in visible if r['material']==mid]
        by_horizon=sum(number(r['units']) for r in shipments if number(r['eta_day'])<=horizon)
        by_arrival=sum(number(r['units']) for r in shipments if number(r['eta_day'])<=arrday)
        pre=sum(dem[(mid,d)] for d in range(1,min(arrday,horizon+1)))
        room=max(0,sitecap-hold-max(plant-pre,0)-by_arrival)
        rawgap=max(target-plant-by_horizon,0);wanted=max(moq,math.ceil(rawgap/pack)*pack) if rawgap else 0
        feasible_cap=math.floor(min(cap,supp,room)/pack)*pack
        q=min(wanted,feasible_cap) if arrday<=horizon and feasible_cap>=moq else 0
        plans.append(dict(material=mid,owner=m['supplier'],inventory_position=plant+by_horizon,target=target,raw_gap=rawgap,proposed_units=q,remaining_target_gap=max(rawgap-q,0),arrival_day=arrday,status='simulated_approval_only'))
        # Replay ground truth is deliberately separate from the as-of notice list.
        physical_shipments=[r for r in initial_transit if r['material']==mid]
        balances={'supplier':supp,'plant_usable':plant,'plant_hold':hold}
        for r in physical_shipments:balances['transit_old_'+r['shipment_id']]=number(r['units'])
        balances['transit_new']=0;initial=sum(balances.values());used=0;seen=set();lost=0
        def apply(eid,day,kind,qty,src,dst=None):
            nonlocal used
            number(qty,integer=True)
            if eid in seen:raise ValueError('duplicate inventory event')
            seen.add(eid)
            if qty>balances[src]:raise ValueError('event would create negative stock')
            balances[src]-=qty
            if dst:balances[dst]=balances.get(dst,0)+qty
            else:used+=qty
            if balances['plant_usable']+balances['plant_hold']>sitecap:raise ValueError('realized plant capacity exceeded')
            if not math.isclose(sum(balances.values())+used,initial):raise AssertionError('inventory conservation failed')
            ledgers.append(dict(material=mid,event_id=eid,day=day,kind=kind,units=qty,owner=m['supplier'],supplier_units=balances['supplier'],plant_usable=balances['plant_usable'],plant_hold=balances['plant_hold'],transit_units=sum(v for k,v in balances.items() if k.startswith('transit_')),cumulative_consumed=used,network_remaining=sum(balances.values()),initial_network_units=initial))
        apply(mid+'_dispatch',1,'dispatch',q,'supplier','transit_new')
        for day in range(1,horizon+1):
            for r in physical_shipments:
                realized=[a for a in arrivals if a['scenario']==scenario and a['shipment_id']==r['shipment_id']]
                if len(realized)!=1:raise ValueError('missing/duplicate realized shipment scenario')
                if number(realized[0]['arrival_day'])==day:apply(mid+'_receive_'+r['shipment_id'],day,'receipt_old',number(r['units']),'transit_old_'+r['shipment_id'],'plant_usable')
            if day==arrday:apply(mid+'_receive_new',day,'receipt_new',q,'transit_new','plant_usable')
            need=dem[(mid,day)];take=min(need,balances['plant_usable']);lost+=need-take
            apply(mid+'_consume_'+str(day),day,'consume',take,'plant_usable')
        final.append(dict(material=mid,consumed=used,unmet_units=lost,ending_usable=balances['plant_usable'],ending_hold=balances['plant_hold'],ending_transit=sum(v for k,v in balances.items() if k.startswith('transit_')),network_remaining=sum(balances.values()),initial_network_units=initial,balances=balances))
    return dict(scenario=scenario,visible_notices=visible,plans=plans,ledger=ledgers,final=final)

def fresh(rows,params):
    target=number(params['target_day'],'target day',1,integer=True);origin=stamp(params['origin']);min_n=number(params['min_comparable_hours'],'minimum support',1,integer=True)
    expected=[number(h,'expected hour',0,23,integer=True) for h in params['expected_hours']]
    if not expected or len(set(expected))!=len(expected):raise ValueError('nonempty unique expected hours required')
    day1=stamp(params['day1_start_at'])
    if any([day1.hour,day1.minute,day1.second,day1.microsecond]):raise ValueError('day1 start must be midnight')
    hist=[];current=[];seen=set();unavailable_target=[]
    for r in rows:
        key=(number(r['day'],'day',1,integer=True),number(r['hour'],'hour',0,23,integer=True))
        if key in seen:raise ValueError('duplicate hourly row')
        seen.add(key)
        event_end=stamp(r['event_end_at']);available_at=stamp(r['available_at'])
        if event_end!=day1+timedelta(days=key[0]-1,hours=key[1]+1):raise ValueError('day/hour label disagrees with event_end_at')
        if key[0]==target and key[1] not in expected:raise ValueError('target hour outside expected operating schedule')
        if available_at<event_end:raise ValueError('hourly totals available too early')
        if available_at>origin or event_end>origin:
            if key[0]==target:unavailable_target.append(key[1])
            continue
        for k in ['sales_units','in_stock_unique_sessions','oos_unique_sessions','oos_pv']:number(r[k],k,integer=True)
        minutes=number(r['in_stock_minutes'],'in_stock_minutes',0,60);positive(r['price_yuan'],'price')
        if r['price_regime'] not in ('regular','markdown'):raise ValueError('unknown price regime')
        if minutes==0 and (number(r['sales_units'])!=0 or number(r['in_stock_unique_sessions'])!=0):raise ValueError('zero stock exposure cannot have sales or in-stock sessions')
        if minutes==60 and number(r['oos_unique_sessions'])!=0:raise ValueError('full-stock hour has oos sessions')
        if number(r['sales_units'])>number(r['in_stock_unique_sessions']):raise ValueError('one unit per session assumption violated')
        if key[0]<target:hist.append(r)
        elif key[0]==target:current.append(r)
    results=[]
    for r in sorted(current,key=lambda r:number(r['hour'])):
        obs=number(r['sales_units']);minutes=number(r['in_stock_minutes']);missing=(60-minutes)/60;uv=number(r['oos_unique_sessions'])
        compar=[h for h in hist if h['hour']==r['hour'] and h['price_regime']==r['price_regime'] and number(h['price_yuan'])==number(r['price_yuan']) and number(h['in_stock_minutes'])==60 and number(h['in_stock_unique_sessions'])>0]
        regular=[h for h in hist if h['hour']==r['hour'] and h['price_regime']=='regular' and number(h['in_stock_minutes'])==60 and number(h['in_stock_unique_sessions'])>0]
        rates=[number(h['sales_units']) for h in compar];ps=[number(h['sales_units'])/number(h['in_stock_unique_sessions']) for h in compar]
        supported=len(compar)>=min_n
        if minutes==60:tpoint=upoint=obs;trange=urange=[obs,obs];status='observed_under_actual_price'
        elif not supported:tpoint=upoint=None;trange=urange=None;status='unidentified_no_comparable_support'
        else:
            tpoint=obs+sum(rates)/len(rates)*missing;trange=[obs+min(rates)*missing,obs+max(rates)*missing]
            weighted_p=sum(number(h['sales_units']) for h in compar)/sum(number(h['in_stock_unique_sessions']) for h in compar)
            upoint=obs+weighted_p*uv;urange=[obs+min(ps)*uv,obs+max(ps)*uv];status='assumption_dependent_estimates'
        natural=None
        if len(regular)>=min_n:
            rp=sum(number(h['sales_units']) for h in regular)/sum(number(h['in_stock_unique_sessions']) for h in regular)
            natural=rp*(number(r['in_stock_unique_sessions'])+uv)
        results.append(dict(hour=number(r['hour'],integer=True),regime=r['price_regime'],observed_units=obs,factual_lower_bound=obs,factual_upper_bound=None,time_point=tpoint,time_scenario_range=trange,uv_point=upoint,uv_scenario_range=urange,regular_price_scenario=natural,comparable_hours=len(compar),status=status))
    observed_hours={r['hour'] for r in results};missing=sorted(set(expected)-observed_hours);complete=not missing
    def partial(k):return None if any(r[k] is None for r in results) else sum(r[k] for r in results)
    def total(k):return partial(k) if complete else None
    coverage={'expected_hours':sorted(expected),'observed_hours':sorted(observed_hours),'missing_hours':missing,'unavailable_hours':sorted(unavailable_target),'status':'complete' if complete else ('no_target_observations' if not results else 'incomplete')}
    return dict(hours=results,target_coverage=coverage,observed_total=total('observed_units'),time_estimate_total=total('time_point'),uv_estimate_total=total('uv_point'),regular_price_scenario_total=total('regular_price_scenario'),partial_observed_total=partial('observed_units'),partial_time_estimate_total=partial('time_point'),partial_uv_estimate_total=partial('uv_point'),partial_regular_price_scenario_total=partial('regular_price_scenario'),range_kind='conditional_sensitivity_range_not_confidence_interval')

def allocate_boxes(requests,budget,box):
    """Largest remainder allocation, capped by requested whole boxes. Ties by store id."""
    budget=int(number(budget)//box);d={k:int(number(v)//box) for k,v in requests.items()}
    total=sum(d.values())
    if total<=budget:return {k:v*box for k,v in d.items()}
    quotas={k:budget*v/total for k,v in d.items()};out={k:math.floor(v) for k,v in quotas.items()}
    left=budget-sum(out.values())
    for k in sorted(d,key=lambda k:(-(quotas[k]-out[k]),k)):
        if left and out[k]<d[k]:out[k]+=1;left-=1
    return {k:v*box for k,v in out.items()}

def collab(events,stores,redemptions,packaging,params):
    first=stamp(params['first_origin']);second=stamp(params['second_origin']);window=stamp(params['event_window_end']);start=stamp(params['event_start']);box=number(params['box_units'],'box',1,integer=True)
    delivery=stamp(params['second_delivery_at'])
    if not first<=start<=window<=second<delivery:raise ValueError('collab decision must precede second delivery; cannot dispatch into the past')
    if not stores or len({s['store'] for s in stores})!=len(stores):raise ValueError('nonempty unique stores required')
    if not events or len({e['event'] for e in events})!=len(events):raise ValueError('nonempty unique analog events required')
    if len({r['lot'] for r in packaging})!=len(packaging):raise ValueError('duplicate packaging lot')
    for r in events:
        if stamp(r['outcome_available_at'])<stamp(r['feature_known_at']):raise ValueError('analog outcome precedes feature availability')
    visible=[r for r in events if stamp(r['feature_known_at'])<=first and stamp(r['outcome_available_at'])<=first]
    weights=[number(r['weight']) for r in visible]
    if not math.isclose(sum(weights),1):raise ValueError('as-of analog weights must sum to one')
    mult=sum(number(r['day1_cups'])/positive(r['baseline_cups'],'baseline')*w for r,w in zip(visible,weights))
    if len({s['store'] for s in stores})!=len(stores):raise ValueError('duplicate store')
    available=0;pending=0;production_risks=[]
    for r in packaging:
        q=number(r['units'],integer=True);planned=stamp(r['planned_at']);original=stamp(r['original_expected_at']);eta=stamp(r['expected_at']);av=stamp(r['available_at'])
        if planned>av or original<planned or eta<planned:raise ValueError('inconsistent packaging planned/expected/available times')
        actual=stamp(r['actual_at']) if r['actual_at'] else None
        if r['status']=='received':
            if actual is None or actual<planned or av<actual:raise ValueError('invalid received packaging time')
        elif r['status']=='in_production':
            if actual is not None:raise ValueError('in-production lot cannot have actual receipt')
        else:raise ValueError('unknown packaging status')
        if av>first:continue
        if r['status']=='received' and actual<=first:available+=q
        elif r['status']=='in_production':
            pending+=q;flags=[]
            if original<first:flags.append('original_promise_missed_before_opening')
            if eta>start:flags.append('latest_eta_after_activity_opening')
            elif eta<first:flags.append('latest_eta_overdue')
            if flags:production_risks.append({'lot':r['lot'],'units':q,'flags':flags,'latest_expected_at':r['expected_at']})
    fraction=number(params['first_fraction'],'first fraction',0,1);reserve1=number(params['first_reserved_units'],integer=True);reserve2=number(params['second_reserved_units'],integer=True);van=number(params['van_capacity_units'],integer=True)
    if reserve1>available:raise ValueError('first reserve exceeds physical stock')
    forecast={s['store']:number(s['baseline_cups'])*mult for s in stores}
    firstreq={s['store']:math.floor(min(forecast[s['store']]*fraction,number(s['first_capacity'],integer=True))/box)*box for s in stores}
    alloc1=allocate_boxes(firstreq,available-reserve1,box);central=available-sum(alloc1.values())
    sales={s['store']:0 for s in stores};seen=set();excluded=[]
    for r in redemptions:
        if r['event_id'] in seen:raise ValueError('duplicate redemption event')
        seen.add(r['event_id'])
        if r['store'] not in sales:raise ValueError('unknown store')
        if stamp(r['available_at'])<stamp(r['event_at']):raise ValueError('redemption available before event')
        q=number(r['units'],integer=True)
        if stamp(r['event_at'])<start or stamp(r['event_at'])>window or stamp(r['available_at'])>second:excluded.append(r['event_id']);continue
        sales[r['store']]+=q
    requests={};detail=[]
    for s in stores:
        k=s['store'];share=number(s['known_hour_share'],'hour share',0,1)
        if share<=0:raise ValueError('hour share must be positive')
        if sales[k]>alloc1[k]:raise ValueError('known sales exceed allocated inventory')
        stock=alloc1[k]-sales[k];full=sales[k]/share;remaining=max(full-sales[k],0);pre=number(s['forecast_before_delivery']);cap=number(s['delivery_capacity'],integer=True)
        if pre>stock:status='prearrival_shortfall_requires_attention'
        else:status='draft_requires_stock_confirmation'
        after=max(remaining-pre,0);arrival_stock=max(stock-pre,0);gap=max(after-arrival_stock,0)
        requests[k]=min(math.ceil(gap/box)*box,math.floor(cap/box)*box)
        detail.append(dict(store=k,initial_forecast=forecast[k],first_allocated=alloc1[k],known_redemptions=sales[k],asof_book_stock=stock,updated_total_scenario=full,remaining_scenario=remaining,prearrival_scenario=pre,prearrival_shortfall=max(pre-stock,0),postarrival_gap=gap,capacity_capped_second_request=requests[k],status=status))
    if reserve2>central:raise ValueError('second reserve exceeds remaining stock')
    alloc2=allocate_boxes(requests,min(van,central-reserve2),box)
    for r in detail:r['second_proposed']=alloc2[r['store']];r['remaining_scenario_gap']=max(r['postarrival_gap']-r['second_proposed'],0)
    central_end=central-sum(alloc2.values())
    # Known-event book ledger only; excludes late events until received, not a physical-stock certification.
    known_sales=sum(sales.values());stores_after=sum(alloc1.values())-known_sales+sum(alloc2.values())
    if not math.isclose(known_sales+stores_after+central_end,available):raise AssertionError('collab allocation conservation')
    prod_box=number(params['production_box_units'],'production box',1,integer=True);gross_gap=max(sum(forecast.values())-available,0)
    gross_boxes=math.ceil(gross_gap/prod_box)*prod_box
    incremental=math.ceil(max(sum(forecast.values())-available-pending,0)/prod_box)*prod_box
    return dict(analog_multiplier=mult,forecast_total=sum(forecast.values()),physical_packaging=available,production_timing_risks=production_risks,pending_production_not_available=pending,gross_production_need_units=gross_boxes,incremental_duplicate_safe_lock_units=incremental,first_total=sum(alloc1.values()),central_after_first=central,second_total=sum(alloc2.values()),central_after_second=central_end,excluded_events=excluded,stores=detail,known_event_conservation={'opening':available,'known_redemptions':known_sales,'store_book_after_proposed_receipt':stores_after,'central_after_proposed_dispatch':central_end},execution='none_draft_and_simulation_only')

def run(data,out):
    data=Path(data);out=Path(out);out.mkdir(parents=True,exist_ok=True);cfg=json.loads((data/'config.json').read_text())
    if cfg.get('synthetic') is not True:raise ValueError('synthetic teaching fixture label required')
    results={
      'temperature':temperature(read(data,'temperature_batches.csv'),read(data,'temperature_segments.csv'),cfg['temperature']),
      'apparel':apparel(read(data,'apparel_funnel.csv'),read(data,'apparel_future_exposure.csv'),read(data,'apparel_stock.csv')),
      'vmi_on_time':vmi(read(data,'vmi_materials.csv'),read(data,'vmi_demand.csv'),read(data,'vmi_shipment_notices.csv'),read(data,'vmi_realized_arrivals_scoring_only.csv'),read(data,'vmi_initial_transit_scoring_only.csv'),cfg['vmi'],'on_time'),
      'vmi_delay':vmi(read(data,'vmi_materials.csv'),read(data,'vmi_demand.csv'),read(data,'vmi_shipment_notices.csv'),read(data,'vmi_realized_arrivals_scoring_only.csv'),read(data,'vmi_initial_transit_scoring_only.csv'),cfg['vmi'],'delay'),
      'fresh':fresh(read(data,'fresh_hourly.csv'),cfg['fresh']),
      'collab':collab(read(data,'collab_events.csv'),read(data,'collab_stores.csv'),read(data,'collab_redemptions.csv'),read(data,'collab_packaging.csv'),cfg['collab'])}
    truth={int(r['hour']):number(r['latent_demand_units']) for r in read(data,'fresh_truth_scoring_only.csv')}
    fres=results['fresh'];score={'latent_total':sum(truth.values())}
    for label,key in [('time','time_point'),('uv','uv_point')]:
        eligible=[r for r in fres['hours'] if r[key] is not None and r['hour'] in truth]
        score[label+'_scored_hours']=len(eligible)
        score[label+'_MAE']=None if not eligible else sum(abs(r[key]-truth[r['hour']]) for r in eligible)/len(eligible)
    results['fresh_scoring_only']=score
    (out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    for name,rows in [('fresh_hourly_results.csv',results['fresh']['hours']),('vmi_on_time_ledger.csv',results['vmi_on_time']['ledger']),('vmi_delay_ledger.csv',results['vmi_delay']['ledger']),('collab_allocation.csv',results['collab']['stores'])]:
        fields=list(rows[0]) if rows else ['hour','regime','observed_units','factual_lower_bound','factual_upper_bound','time_point','time_scenario_range','uv_point','uv_scenario_range','regular_price_scenario','comparable_hours','status']
        with (out/name).open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    return results
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=ROOT/'data');p.add_argument('--out',type=Path,default=ROOT/'outputs');a=p.parse_args()
    r=run(a.data,a.out);print(json.dumps({k:({'completed':True} if k!='fresh_scoring_only' else v) for k,v in r.items()},ensure_ascii=False,indent=2))
