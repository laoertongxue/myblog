"""Deterministic synthetic teaching fixtures. No real companies or safety standards."""
from pathlib import Path
import csv, json
from datetime import datetime, timedelta, timezone
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
def write(name, rows):
    DATA.mkdir(exist_ok=True)
    with (DATA/name).open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def ts(day,hour=0,minute=0):return f'2026-06-{day:02d}T{hour:02d}:{minute:02d}:00+00:00'
def generate():
    write('temperature_batches.csv',[
      dict(batch=b,harvest_at=ts(1),origin=ts(1,12),label_expiry_at=ts(exp),initial_quality=100,quality_alert_level=70,future_temperature_C=4)
      for b,exp in [('A',4),('B',3),('C',4)]])
    rows=[]
    for b,temps in [('A',[4,4,8,8,4,4]),('B',[4]*6),('C',[4,'',10,4,4,4])]:
        for i,t in enumerate(temps):rows.append(dict(batch=b,segment=i+1,start_at=ts(1,i*2),end_at=ts(1,i*2+2),available_at=ts(1,i*2+2),temperature_C=t))
    write('temperature_segments.csv',rows)
    write('apparel_funnel.csv',[
      dict(style='X',window=i+1,start_at=ts(1+i),end_at=ts(2+i),available_at=ts(2+i),impressions=im,clicks=cl,cart_sessions=ca,favorite_sessions=fa,eligible_sessions=n,orders=x,stockout_clicks=so,duplicate_clicks=du)
      for i,(im,cl,ca,fa,n,x,so,du) in enumerate([(1000,100,25,20,80,8,10,10),(1600,160,40,32,120,18,25,15),(2000,200,50,40,100,20,55,45)])])
    write('apparel_future_exposure.csv',[
      dict(phase='early',start_day=3,end_day=6,eligible_sessions_per_day=400,conversion_multiplier=1),
      dict(phase='middle',start_day=6,end_day=9,eligible_sessions_per_day=300,conversion_multiplier=.8),
      dict(phase='late',start_day=9,end_day=12,eligible_sessions_per_day=100,conversion_multiplier=.4)])
    write('apparel_stock.csv',[dict(style='X',launch_at=ts(1),origin=ts(4),initial_units=100,observed_sales_units=46,confirmed_inbound_units=20,inbound_arrival_day=6,order_lead_days=3,season_end_day=12,pack_units=10,moq_units=50,max_order_units=120,prior_alpha=2,prior_beta=18,p_break=.12,probability_gate=.8)])
    write('vmi_materials.csv',[
      dict(material='M1',supplier='S1',supplier_units=40,plant_usable_units=12,plant_hold_units=2,target_units=28,pack_units=4,moq_units=4,supplier_dispatch_capacity=12,plant_capacity_units=30,lead_days=1),
      dict(material='M2',supplier='S2',supplier_units=30,plant_usable_units=9,plant_hold_units=0,target_units=19,pack_units=5,moq_units=5,supplier_dispatch_capacity=15,plant_capacity_units=25,lead_days=1)])
    write('vmi_demand.csv',[dict(material=m,day=d,units=q) for m,qs in [('M1',[10,14]),('M2',[6,10])] for d,q in enumerate(qs,1)])
    write('vmi_shipment_notices.csv',[
      dict(shipment_id='OLD_M1',material='M1',revision=1,units=8,eta_day=2,available_at=ts(1,7)),
      dict(shipment_id='OLD_M1',material='M1',revision=2,units=8,eta_day=3,available_at=ts(1,12))])
    write('vmi_initial_transit_scoring_only.csv',[dict(shipment_id='OLD_M1',material='M1',supplier='S1',units=8,snapshot_at=ts(1,8))])
    write('vmi_realized_arrivals_scoring_only.csv',[
      dict(scenario=s,shipment_id='OLD_M1',arrival_day=d) for s,d in [('on_time',2),('delay',3)]])
    unique=[80,100,120,160,200,180,160,140,120,180,160,100]
    rows=[];truth=[]
    for d in range(1,8):
        for i,u in enumerate(unique):
            h=8+i
            regime='markdown' if h>=17 and d in (2,4,6,7) else 'regular'
            price=6 if regime=='markdown' else 10
            mult=[.8,.9,1,1.1,1.2,1,1][d-1]
            if d==7 and h==12:u=180
            p=.2 if regime=='markdown' else .1
            latent=round(u*p*mult)
            minutes=60;oos=0;sales=latent
            if d==7 and h in (11,12,15,18):
                minutes={11:30,12:24,15:30,18:15}[h]
                oos={11:80,12:100,15:70,18:120}[h]
                sales={11:8,12:8,15:7,18:8}[h]
            rows.append(dict(day=d,hour=h,event_end_at=ts(d,h+1),available_at=ts(d,h+1),price_regime=regime,price_yuan=price,in_stock_minutes=minutes,sales_units=sales,in_stock_unique_sessions=u-oos,oos_unique_sessions=oos,oos_pv=2*oos))
            if d==7:truth.append(dict(day=d,hour=h,latent_demand_units=latent))
    write('fresh_hourly.csv',rows);write('fresh_truth_scoring_only.csv',truth)
    write('collab_events.csv',[
      dict(event=e,baseline_cups=b,day1_cups=s,weight=w,feature_known_at=ts(i),outcome_available_at=ts(i+1))
      for i,(e,b,s,w) in enumerate([('E1',100,200,.4),('E2',100,300,.3),('E3',200,400,.2),('E4',100,100,.1)],1)])
    write('collab_stores.csv',[
      dict(store=s,baseline_cups=b,first_capacity=cap,delivery_capacity=dc,known_hour_share=.4,forecast_before_delivery=pre)
      for s,b,cap,dc,pre in [('A',100,100,60,20),('B',80,90,40,10),('C',60,60,40,15)]])
    write('collab_redemptions.csv',[
      dict(event_id=e,store=s,event_at=ts(10,h,m),available_at=ts(10,ah,am),units=q)
      for e,s,h,m,ah,am,q in [('A_1','A',10,50,10,55,70),('B_1','B',10,50,10,55,30),('C_1','C',10,50,10,55,40),('A_late','A',10,57,11,10,5)]])
    write('collab_packaging.csv',[
      dict(lot='initial',units=200,status='received',planned_at=ts(1),original_expected_at=ts(9),expected_at=ts(9),actual_at=ts(9),available_at=ts(9)),
      dict(lot='confirmed_receipt',units=160,status='received',planned_at=ts(2),original_expected_at=ts(9),expected_at=ts(9),actual_at=ts(9),available_at=ts(9)),
      dict(lot='locked_production',units=180,status='in_production',planned_at=ts(3),original_expected_at=ts(9),expected_at=ts(11),actual_at='',available_at=ts(9))])
    config={'synthetic':True,'timezone':'UTC','temperature':{'base_rate_points_per_hour':.5,'extra_rate_per_C_per_hour':.125,'reference_C':4,'valid_min_C':0,'valid_max_C':12},'vmi':{'physical_snapshot_at':ts(1,8),'first_consumption_at':ts(1,16),'origin':ts(1,8),'horizon_days':2},'fresh':{'day1_start_at':ts(1),'expected_hours':list(range(8,20)),'target_day':7,'origin':ts(7,20),'min_comparable_hours':3},'collab':{'event_start':ts(10,8),'second_delivery_at':ts(10,12),'first_origin':ts(10,7),'second_origin':ts(10,11),'event_window_end':ts(10,11),'first_fraction':.5,'box_units':10,'production_box_units':20,'first_reserved_units':80,'second_reserved_units':20,'van_capacity_units':100}}
    (DATA/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':generate();print('Generated synthetic CSV fixtures in',DATA)
