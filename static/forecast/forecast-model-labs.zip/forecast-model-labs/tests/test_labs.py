import unittest,copy,json,sys,math,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run_models as m
import numpy as np
class Labs(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.c=m.rows('three_products.csv');cls.t=m.rows('tree_features.csv');cls.s=m.rows('pricing_scenarios.csv');cls.config=json.loads((m.ROOT/'data/pricing_config.json').read_text());cls.d=json.loads((m.ROOT/'data/deep_inputs.json').read_text());cls.v=m.rows('image_vectors.csv');cls.h=m.rows('trend_history.csv')
 def test_01_randomized_price_truth(self):
  o=m.causal(self.c);self.assertLess(o['randomized_max_elasticity_error'],1e-8);self.assertGreater(o['confounded_naive_coefficients'][0][1],0);self.assertAlmostEqual(o['confounded_ORACLE_coefficients'][0][1],-1.4,8)
 def test_02_zero_price_rejected(self):
  x=copy.deepcopy(self.c);x[0]['price_A']='0'
  with self.assertRaises(ValueError):m.causal(x)
 def test_03_censored_sales_rejected(self):
  x=copy.deepcopy(self.c);x[0]['stockout']='1'
  with self.assertRaises(ValueError):m.causal(x)
 def test_04_causal_future_price_rejected(self):
  x=copy.deepcopy(self.c);x[0]['price_available_at']='2099'
  with self.assertRaises(ValueError):m.causal(x)
 def test_05_causal_random_split_rejected(self):
  x=copy.deepcopy(self.c);x[0]['split']='test'
  with self.assertRaises(ValueError):m.causal(x)
 def test_06_extrapolation_rejected(self):
  with self.assertRaises(ValueError):m.price_scenario([20,12,8],np.eye(3),[1]*3,[10,12,8],[[8,12],[10,14],[7,9]])
 def test_07_features_valid(self):m.validate_features(self.t)
 def test_08_feature_leak_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['weather_available_at']='2099'
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_09_rolling_target_leak_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['rolling7']=str(float(x[-1]['rolling7'])+1)
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_10_random_split_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['split']='train'
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_11_duplicate_rejected(self):
  x=copy.deepcopy(self.t);x.append(x[-1])
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_12_lag1_future_target_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['lag1']=str(float(x[-1]['lag1'])+1)
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_13_nan_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['target_demand']='nan'
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_14_dp_expected_and_benchmark(self):
  o=m.build_dp(self.s,self.config);self.assertAlmostEqual(o['expected_net_value'],44.375);self.assertEqual(o['initial_price'],10);self.assertAlmostEqual(max(o['fixed_schedules'].values()),43.625);self.assertGreater(o['expected_net_value'],max(o['fixed_prices'].values()))
 def test_15_nonanticipativity_and_inventory(self):
  o=m.build_dp(self.s,self.config);decisions={}
  for path in o['paths']:
   self.assertGreaterEqual(path['terminal_inventory'],0)
   for i,r in enumerate(path['trace']):
    key=tuple(path['scenarios'][:i]);value=r['chosen_price']
    if key in decisions:self.assertEqual(decisions[key],value)
    decisions[key]=value
    self.assertEqual(r['opening_inventory']-r['sales'],r['closing_inventory']);self.assertGreaterEqual(r['closing_inventory'],0)
   self.assertTrue(all(path['trace'][i]['chosen_price']>=path['trace'][i+1]['chosen_price'] for i in [0,1]))
 def test_16_invalid_prob_rejected(self):
  x=copy.deepcopy(self.s);x[0]['probability']='.6'
  with self.assertRaises(ValueError):m.build_dp(x,self.config)
 def test_17_negative_demand_rejected(self):
  x=copy.deepcopy(self.s);x[0]['demand']='-1'
  with self.assertRaises(ValueError):m.build_dp(x,self.config)
 def test_18_expiry_rejected(self):
  x=copy.deepcopy(self.config);x['expiry_period']=3
  with self.assertRaises(ValueError):m.build_dp(self.s,x)
 def test_19_zero_inventory(self):
  x=copy.deepcopy(self.config);x['initial_inventory']=0
  self.assertEqual(m.build_dp(self.s,x)['expected_net_value'],0)
 def test_20_salvage_change_recomputed(self):
  x=copy.deepcopy(self.config);x['terminal_salvage_per_unit']=-5
  self.assertLess(m.build_dp(self.s,x)['expected_net_value'],44.375)
 def test_21_vector_shapes_and_quantiles(self):
  o=m.deep(self.d,self.v,self.h);self.assertEqual(o['simulated_p90'][0],[12,11,10]);self.assertAlmostEqual(o['vector_predictions'][0]['forecast'],120.983976659,7)
 def test_22_zero_vector_rejected(self):
  x=copy.deepcopy(self.v);x[0]['v1']='0';x[0]['v2']='0'
  with self.assertRaises(ValueError):m.deep(self.d,x,self.h)
 def test_23_tensor_future_leak_rejected(self):
  x=copy.deepcopy(self.d);x['future_available_at']='2099'
  with self.assertRaises(ValueError):m.deep(x,self.v,self.h)
 def test_24_tensor_shape_rejected(self):
  x=copy.deepcopy(self.d);x['history'][0].pop()
  with self.assertRaises(ValueError):m.deep(x,self.v,self.h)
 def test_25_zero_weight_fallback(self):
  x=copy.deepcopy(self.v);x[-1]['category']='unseen'
  self.assertTrue(m.deep(self.d,x,self.h)['vector_predictions'][-1]['fallback'])
 def test_26_holdout_labels_not_features(self):
  a=m.deep(self.d,self.v,self.h);x=copy.deepcopy(self.v);x[-1]['units']='9000';b=m.deep(self.d,x,self.h)
  self.assertEqual(a['vector_predictions'][-1]['forecast'],b['vector_predictions'][-1]['forecast'])
 def test_27_trend_future_leak_rejected(self):
  x=copy.deepcopy(self.h);x[-1]['available_at']='2099'
  with self.assertRaises(ValueError):m.deep(self.d,self.v,x)
 def test_28_zero_metric_denominator(self):self.assertIsNone(m.metric([0,0],[1,2])['wape'])
 def test_29_results_recompute_from_ledger(self):
  p=m.rows('tree_features.csv');r=json.loads((m.ROOT/'outputs/results.json').read_text())
  import csv
  with (m.ROOT/'outputs/tree_test_predictions.csv').open() as f:pred=list(csv.DictReader(f))
  for name,v in r['trees']['results'].items():
   a=m.metric([float(x['actual']) for x in pred],[float(x[name]) for x in pred]);self.assertAlmostEqual(a['wape'],v['test']['wape'],12);self.assertEqual(a['toy_inventory_cost'],v['test']['toy_inventory_cost'])
 def test_30_vector_future_leak_rejected(self):
  x=copy.deepcopy(self.v);x[-1]['vector_available_at']='2099'
  with self.assertRaises(ValueError):m.deep(self.d,x,self.h)
 def test_31_clustering_fit_excludes_holdout(self):
  a=m.deep(self.d,self.v,self.h);x=copy.deepcopy(self.v);x[-1]['v1']='100';x[-1]['v2']='50';b=m.deep(self.d,x,self.h)
  self.assertEqual(a['clustering']['centers'],b['clustering']['centers']);self.assertEqual(a['clustering']['training_items'],['V1','V2','V3','V4','V5','V6'])
 def test_32_initial_price_ceiling_applies_to_all_policies(self):
  x=copy.deepcopy(self.config);x['initial_price_ceiling']=8
  o=m.build_dp(self.s,x)
  self.assertEqual(o['initial_price'],8);self.assertEqual(set(o['fixed_prices']),{'8'});self.assertEqual(set(o['fixed_schedules']),{'8,8,8'})
  self.assertEqual(o['expected_net_value'],o['fixed_prices']['8'])
  for path in o['paths']:self.assertLessEqual(path['trace'][0]['chosen_price'],8)
 def test_33_target_date_day_mismatch_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['date']='2099-01-01'
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_34_origin_and_weather_joint_shift_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['origin']='2099-01-01T18:00:00';x[-1]['weather_available_at']='2099-01-01T12:00:00'
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_35_wrong_origin_hour_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['origin']=x[-1]['origin'].replace('18:00:00','19:00:00')
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_36_scale_nan_and_infinity_rejected(self):
  for bad in [float('nan'),float('inf'),-float('inf')]:
   with self.subTest(bad=bad):
    x=copy.deepcopy(self.d);x['train_only_scale']=[10,bad]
    with self.assertRaises(ValueError):m.deep(x,self.v,self.h)
 def test_37_scale_wrong_shape_rejected(self):
  for bad in [[10],[],[10,20,30],[[10,20]],10]:
   with self.subTest(bad=bad):
    x=copy.deepcopy(self.d);x['train_only_scale']=bad
    with self.assertRaises(ValueError):m.deep(x,self.v,self.h)
 def test_38_scale_zero_negative_rejected(self):
  for bad in [0,-1]:
   x=copy.deepcopy(self.d);x['train_only_scale']=[10,bad]
   with self.assertRaises(ValueError):m.deep(x,self.v,self.h)
 def test_39_initial_cap_when_later_markup_allowed(self):
  x=copy.deepcopy(self.config);x['initial_price_ceiling']=8;x['markdown_only']=False
  o=m.build_dp(self.s,x)
  self.assertTrue(all(float(k.split(',')[0])<=8 for k in o['fixed_schedules']))
  self.assertIn('8,10,10',o['fixed_schedules']);self.assertEqual(set(o['fixed_prices']),{'8'})
 def test_40_timestamp_format_rejected(self):
  x=copy.deepcopy(self.t);x[-1]['weather_available_at']='1900-not-a-date'
  with self.assertRaises(ValueError):m.validate_features(x)
 def test_41_clustering_stable_under_multithreaded_caller(self):
  expected=None
  with m.threadpool_limits(limits=4):
   for i in range(8):
    x=copy.deepcopy(self.v)
    if i%2:x[-1]['v1']='100';x[-1]['v2']='50'
    c=m.deep(self.d,x,self.h)['clustering']
    fitted=(c['centers'],c['train_labels'],c['inertia'])
    if expected is None:expected=fitted
    self.assertEqual(fitted,expected)
 def test_42_clustering_fit_sees_only_training_vectors(self):
  from unittest.mock import patch
  captured=[];actual_fit=m.KMeans.fit
  def spy_fit(estimator,X,*args,**kwargs):
   captured.append(np.asarray(X).copy())
   return actual_fit(estimator,X,*args,**kwargs)
  x=copy.deepcopy(self.v);x[-1]['v1']='100';x[-1]['v2']='50'
  with patch.object(m.KMeans,'fit',new=spy_fit):m.deep(self.d,x,self.h)
  expected=np.array([[float(r['v1']),float(r['v2'])] for r in self.v if r['split']=='train']);expected/=np.linalg.norm(expected,axis=1,keepdims=True)
  self.assertEqual(len(captured),1);self.assertEqual(captured[0].shape,(6,2));np.testing.assert_array_equal(captured[0],expected)
 def test_43_clustering_responds_to_training_change(self):
  a=m.deep(self.d,self.v,self.h)['clustering'];x=copy.deepcopy(self.v);x[0]['v1']='.2';x[0]['v2']='.9';b=m.deep(self.d,x,self.h)['clustering']
  self.assertNotEqual(a['centers'],b['centers'])
if __name__=='__main__':unittest.main(verbosity=2)
