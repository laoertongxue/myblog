"""Regenerate only in a temporary copy; compare inputs and deterministic outputs."""
from pathlib import Path
import tempfile,shutil,subprocess,hashlib,sys,json,os
root=Path(__file__).resolve().parent
tracked=sorted(list((root/'data').glob('*'))+[root/'outputs/results.json',root/'outputs/tree_test_predictions.csv'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(root)):sha(p) for p in tracked}
with tempfile.TemporaryDirectory(prefix='forecast-model-repro-') as temp:
 dst=Path(temp)/'lab';shutil.copytree(root,dst,ignore=shutil.ignore_patterns('__pycache__'))
 env=dict(os.environ)  # No hidden thread overrides: test the documented plain-python command.
 subprocess.run([sys.executable,str(dst/'generate_data.py')],check=True,env=env,capture_output=True)
 subprocess.run([sys.executable,str(dst/'run_models.py')],check=True,env=env,capture_output=True)
 after={k:sha(dst/k) for k in before}
 if before!=after:raise AssertionError({k:(v,after[k]) for k,v in before.items() if v!=after[k]})
 if any(sha(root/k)!=v for k,v in before.items()):raise AssertionError('source files changed')
 report=dict(status='PASS',verified_file_count=len(before),source_unchanged=True,hashes=before)
 (root/'outputs/reproducibility.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='hashes'}))
