# 预测模型侧补课运行包

全部数据为匿名合成教学数据。只读取本包文件、生成本地输出；不接生产，不下单，不调价，不投放。本包确实拟合线性回归、sklearn 梯度提升树和合成向量 KMeans；未训练 Prophet、TFT、DeepAR 或任何视觉模型。

## 运行

测试环境 Python 3.12.14、numpy 2.3.5、scipy 1.17.0、scikit-learn 1.8.0。运行环境的精确版本以 outputs/results.json 为准。无网络步骤，不必安装不可用的大模型库。需要新环境时可从常用包仓库按 requirements.txt 建环境，安装不属于已执行步骤。

从本目录运行：

1. `python run_models.py`
2. `python tests/test_labs.py`
3. `python verify_reproducibility.py`

数据已经随包交付；不必先生成。`python generate_data.py` 会确定性覆盖本包 data 下的合成夹具，只在需要重建时运行，不要指向用户真实数据。运行模型会覆盖 outputs 中的教学结果。

## 输入与输出

- data/three_products.csv：1,008 行＝2 个试验设计 × 168 天 × 3 SKU。标签 randomized 表示块内随机排序的全因子外生价格；confounded 表示策略价与隐藏需求冲击相连。价格量纲元/件，销量量纲件，latent_demand 是模拟连续需求均值，不是实测整数订单。
- data/elasticity_truth.json：模拟结构真值，供单元测试与诊断；不充当模型训练样本。
- data/tree_features.csv：1,218 行＝3 SKU × 406 天。day 0–13 是生成历史暖启动，交付特征从 day 14 开始。训练 day 14–251，验证 252–335，测试 336–419。
- data/pricing_scenarios.csv：12 行＝3 期 × 2 价格 × 2 情景；data/pricing_config.json：库存、残值、法定售价、到期与只降不升约束。
- data/price_response.csv：42 行，生鲜三小时与服装四周，每期三个价格、两个开盘库存。生鲜为两个等概率潜在需求情景；服装为确定性响应设定。库存只截销量，不用于假造潜在需求减少。
- data/deep_inputs.json：静态、历史、未来已知张量及明确标记的模拟路径。
- data/image_vectors.csv、trend_history.csv：8 款匿名二维向量及截止前趋势；没有真实图片或真实 CV 输出。
- data/prophet_components.csv：14 天手工设定分量，不是 Prophet 输出。
- outputs/results.json：实际拟合参数、分块与分组指标、消融、DP 全状态表和八路径、向量与分位数算术。
- outputs/tree_test_predictions.csv：252 个相同测试样本的逐模型预测，指标可由该表重算。
- outputs/tests.txt：43 项通过记录。覆盖公式结果、时间泄漏、分割篡改、非预知决策、负库存、非法概率、零向量、未来特征、零权重回退、零分母与结果重算。
- docs/lesson.md：完整逐符号教学与验收。

## 证据范围

1. 树与线性：真实执行了拟合，但只在合成数据上；没有业务有效性证据。
2. 价格因果：模拟试验可恢复已知价格系数，不能证明真实世界识别成立。隐藏冲击列只作 oracle 诊断，禁止放进部署特征。
3. 动态定价：离散场景的精确有限状态最优值，不是现实价格的无条件最优值。
4. 深度/视觉/Prophet：输入、分解、计算和失败检查已运行，模型本身未训练或运行。
5. 单步滚动测试会读取昨日已经发生的销量；不能把它包装成在测试首日一次预测未来84天。

## 第二轮独立审查修订

修复首期价格上限未覆盖固定策略对照、目标日期/day/原点联动校验遗漏、train_only_scale 形状与有限值校验遗漏。补9项测试至40项，包含子案例；原始教学结果不变。

## 第三轮复现修订

对称KMeans夹具存在等损失的不同分组。默认多线程下浮点求和差异曾使固定随机种子仍选中不同中心；代码未把留出向量传给fit。现已在KMeans fit/predict内部使用threadpoolctl单线程，不要求调用者先设OMP环境。新增外层多线程反复运行、实际fit输入截获（严格6×2训练行）、训练数据变动会改变中心等测试。测试总数43；verify_reproducibility.py不再暗中设置线程环境，使用与普通运行一致的环境。该可重复性声明仅覆盖固定依赖和受测环境。
