"""Offline learning labs. All model fits and outputs consume delivered CSV/JSON."""
from pathlib import Path
from functools import lru_cache
import argparse,csv,json,math,itertools,platform,importlib.util,datetime
import numpy as np
import scipy,sklearn
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
ROOT=Path(__file__).resolve().parent

def rows(name):
 with (ROOT/'data'/name).open() as f:return list(csv.DictReader(f))
def finite(x):
 x=float(x)
 if not math.isfinite(x):raise ValueError('nonfinite input')
 return x

def fit_elasticity(data, design, oracle=False):
 subset=[r for r in data if r['design']==design and r['split']=='train'];coef=[]
 for sku in 'ABC':
  rs=[r for r in subset if r['sku']==sku]
  X=[];Y=[]
  for r in rs:
   v=[1]+[math.log(finite(r['price_'+s])/p) for s,p in zip('ABC',[10,12,8])]+[finite(r['promo_known'])]
   if oracle:v+=[finite(r['latent_shock_DIAGNOSTIC_ONLY'])]
   X.append(v);Y.append(math.log(finite(r['latent_demand'])/finite(r['q_base'])))
  if np.linalg.matrix_rank(X)!=len(X[0]):raise ValueError('rank deficient design')
  coef.append(np.linalg.lstsq(X,Y,rcond=None)[0].tolist())
 return coef

def price_scenario(prices, E, base, pbase, support):
 prices=np.asarray(prices,dtype=float)
 if not np.isfinite(prices).all() or (prices<=0).any():raise ValueError('invalid scenario prices')
 for j in range(3):
  if not support[j][0]<=prices[j]<=support[j][1]:raise ValueError('scenario outside training price support')
 return np.asarray(base)*np.exp(np.asarray(E)@np.log(prices/np.asarray(pbase)))

def causal(data):
 if len(data)!=1008:raise ValueError('three-product row count')
 seen=set()
 for r in data:
  k=(r['design'],int(r['day']),r['sku'])
  if k in seen:raise ValueError('duplicate product row')
  seen.add(k)
  if r['price_available_at']>r['forecast_origin']:raise ValueError('future price leak')
  if int(r['stockout'])!=0 or abs(finite(r['observed_sales'])-finite(r['latent_demand']))>1e-7:raise ValueError('censored sales require separate demand model')
  if finite(r['latent_demand'])<=0 or any(finite(r['price_'+s])<=0 for s in 'ABC') or finite(r['category_reference'])<=0:raise ValueError('log needs positive input')
  day=int(r['day']);expected='train' if day<112 else ('validation' if day<140 else 'test')
  if r['split']!=expected:raise ValueError('time split altered')
 rnd=fit_elasticity(data,'randomized');obs=fit_elasticity(data,'confounded');oracle=fit_elasticity(data,'confounded',True)
 truth=json.loads((ROOT/'data'/'elasticity_truth.json').read_text())
 E=np.array(truth['elasticity']);base=np.array(truth['q_base']);pbase=np.array(truth['price_base'])
 scenario=np.array([10.8,12,7.36]);logs=np.log(scenario/pbase)
 support=[[min(finite(r['price_'+s]) for r in data if r['design']=='randomized' and r['split']=='train'),max(finite(r['price_'+s]) for r in data if r['design']=='randomized' and r['split']=='train')] for s in 'ABC']
 learned_E=np.array(rnd)[:,1:4]
 q=price_scenario(scenario,learned_E,base,pbase,support)
 cost=np.array([6,7,4]);stock=np.array([80,60,50]);sold=np.minimum(q,stock);gap=np.maximum(0,np.ceil(q)-stock)
 # Report sales gross margin after unit COGS; not cash profit or inventory write-off accounting.
 return dict(randomized_training_coefficients=rnd,confounded_naive_coefficients=obs,confounded_ORACLE_coefficients=oracle,true_elasticity=E.tolist(),
   randomized_max_elasticity_error=float(np.max(np.abs(np.array(rnd)[:,1:4]-E))),
   training_days=[0,111],validation_days=[112,139],test_days=[140,167],
   fits_note='Fit uses train only. Diagnostic held-out blocks are not causal identification evidence; oracle uses unavailable simulated shock.',
   scenario=dict(predictor='randomized-train fitted price coefficients; separately supplied reference demand',training_price_support=support,price=scenario.tolist(),log_ratios=logs.tolist(),log_demand_changes=(E@logs).tolist(),latent_demand=q.tolist(),stock=stock.tolist(),realized_sales=sold.tolist(),procurement_gap=gap.tolist(),
   baseline_category_demand=float(sum(base)),scenario_category_demand=float(sum(q)),category_margin_without_replenishment=float(sum((scenario-cost)*sold)),
   category_margin_if_gap_arrives_in_time=float(sum((scenario-cost)*q)),cost=cost.tolist(),assumption='Known synthetic reference baseline at promo=0 and latent shock=0; fitted randomized price coefficients, not observational slopes; no lead time, MOQ or spoilage. Gap is suggestion, not an order.'))

def metric(y,p):
 y=np.asarray(y);p=np.asarray(p);den=float(sum(y))
 return dict(n=len(y),wape=float(sum(abs(y-p))/den) if den>0 else None,bias=float(sum(p-y)/den) if den>0 else None,mae=float(np.mean(abs(y-p))),
  toy_inventory_cost=float(sum(2*np.maximum(y-np.ceil(np.maximum(p,0)),0)+np.maximum(np.ceil(np.maximum(p,0))-y,0))))

def validate_features(data):
 seen=set();last={}
 for r in data:
  k=(int(r['day']),r['sku'])
  if k in seen:raise ValueError('duplicate row')
  seen.add(k)
  d=k[0]
  if not 14<=d<=419 or r['sku'] not in 'ABC' or len(r['sku'])!=1:raise ValueError('day or sku outside fixture contract')
  target=datetime.date.fromisoformat(r['date'])
  if target!=datetime.date(2024,1,1)+datetime.timedelta(days=d):raise ValueError('target date/day mismatch')
  expected_origin=datetime.datetime.combine(target-datetime.timedelta(days=1),datetime.time(18,0))
  origin=datetime.datetime.fromisoformat(r['origin'])
  if origin!=expected_origin:raise ValueError('forecast origin must be previous business day at 18:00 UTC')
  expected='train' if d<252 else ('validation' if d<336 else 'test')
  if r['split']!=expected:raise ValueError('time split altered')
  for a in ['history_available_at','promo_available_at','weather_available_at','lead_available_at']:
   available=datetime.datetime.fromisoformat(r[a])
   if available.tzinfo is not None:raise ValueError('fixture timestamps must use naive UTC consistently')
   if available>origin:raise ValueError('future available_at leak')
  for a in ['lag1','lag7','rolling7','target_demand']:
   if finite(r[a])<0:raise ValueError('negative counts')
  if k[1] in last and d!=last[k[1]]+1:raise ValueError('calendar hole')
  last[k[1]]=d
  if d-1>=14:
   prior=next(x for x in data if int(x['day'])==d-1 and x['sku']==r['sku'])
   if abs(finite(r['lag1'])-finite(prior['target_demand']))>1e-7:raise ValueError('lag1 mismatch')
  if d-7>=14:
   history=[x for x in data if d-7<=int(x['day'])<d and x['sku']==r['sku']]
   lag7=next(x for x in history if int(x['day'])==d-7)
   if abs(finite(r['lag7'])-finite(lag7['target_demand']))>1e-7:raise ValueError('lag7 mismatch')
   if abs(finite(r['rolling7'])-np.mean([finite(x['target_demand']) for x in history]))>1e-6:raise ValueError('rolling7 mismatch')
 if len(data)!=1218:raise ValueError('feature row count')

def trees(data):
 validate_features(data)
 groups={s:[r for r in data if r['split']==s] for s in ['train','validation','test']}
 base=['lag1','lag7','rolling7','sin7','cos30'];blocks=[('history_calendar',base),('plus_promo',base+['promo']),('plus_weather',base+['promo','weather_forecast']),('plus_lead',base+['promo','weather_forecast','supplier_lead_known'])]
 def arr(rs,fs):return np.array([[finite(r[f]) for f in fs]+[int(r['sku']==s) for s in 'ABC'] for r in rs])
 ys={s:np.array([finite(r['target_demand']) for r in rs]) for s,rs in groups.items()};results={};records=[];testpred={}
 for block,fs in blocks:
  X={s:arr(rs,fs) for s,rs in groups.items()}
  linear=make_pipeline(StandardScaler(),Ridge(alpha=1.0));linear.fit(X['train'],ys['train']);records.append(dict(model='ridge_'+block,train_rows=len(X['train']),feature_names=fs+['sku_A','sku_B','sku_C'],params=dict(alpha=1.0,scaler_fit_split='train')))
  lp=linear.predict(X['test']);results['ridge_'+block]=dict(validation=metric(ys['validation'],linear.predict(X['validation'])),test=metric(ys['test'],lp));testpred['ridge_'+block]=lp
  candidates=[]
  for depth in [2,3]:
   model=GradientBoostingRegressor(n_estimators=120,learning_rate=.05,max_depth=depth,min_samples_leaf=12,loss='squared_error',random_state=20261106)
   model.fit(X['train'],ys['train']);vm=metric(ys['validation'],model.predict(X['validation']))
   candidates.append((vm['wape'],depth,model,vm))
  candidates.sort(key=lambda x:(x[0],x[1]));_,depth,model,vm=candidates[0];p=model.predict(X['test'])
  results['gbdt_'+block]=dict(validation=vm,test=metric(ys['test'],p),validation_candidates=[dict(depth=x[1],wape=x[0]) for x in candidates]);testpred['gbdt_'+block]=p
  records.append(dict(model='gbdt_'+block,train_rows=len(X['train']),feature_names=fs+['sku_A','sku_B','sku_C'],params=model.get_params(),fit_count=2,selection_split='validation',refit_after_selection=False))
 for s,rs in groups.items():
  if s!='train':results.setdefault('seasonal_naive',{})[s]=metric(ys[s],[finite(r['lag7']) for r in rs])
 testpred['seasonal_naive']=np.array([finite(r['lag7']) for r in groups['test']])
 grouped={}
 for name,p in testpred.items():
  grouped[name]={sku:metric(ys['test'][[r['sku']==sku for r in groups['test']]],p[[r['sku']==sku for r in groups['test']]]) for sku in 'ABC'}
 out=[]
 for idx,r in enumerate(groups['test']):out.append(dict(day=r['day'],date=r['date'],sku=r['sku'],actual=float(ys['test'][idx]),**{n:float(p[idx]) for n,p in testpred.items()}))
 with (ROOT/'outputs'/'tree_test_predictions.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
 return dict(split_rows={s:len(v) for s,v in groups.items()},protocol='Frozen train models, validation-only depth selection, rolling one-day-ahead test; lag updates use only earlier observed targets. NOT fixed-origin 84-day forecast.',results=results,grouped_test=grouped,training_records=records)

def build_dp(scenarios,config):
 probs={};ds={}
 for r in scenarios:
  t=int(r['period']);p=finite(r['price']);q=finite(r['probability']);d=finite(r['demand']);state=r['scenario']
  if t not in [1,2,3] or state not in ['low','high'] or q<0 or q>1 or d<0 or int(d)!=d:raise ValueError('invalid scenario')
  if p not in config['legal_prices'] or p<config['minimum_price']:raise ValueError('illegal price')
  key=(t,p,state)
  if key in ds:raise ValueError('duplicate scenario')
  probs[key]=q;ds[key]=int(d)
 for t in [1,2,3]:
  for p in config['legal_prices']:
   if abs(sum(probs.get((t,p,s),-100) for s in ['low','high'])-1)>1e-9:raise ValueError('probability sum or missing scenario')
 if config['initial_inventory']<0 or int(config['initial_inventory'])!=config['initial_inventory']:raise ValueError('inventory must be nonnegative integer')
 if config['expiry_period']!=4:raise ValueError('fixture requires three sellable periods, expiry at four')
 initial_ceiling=finite(config['initial_price_ceiling'])
 if initial_ceiling<min(config['legal_prices']):raise ValueError('no legal initial price')
 salvage=finite(config['terminal_salvage_per_unit']);policy={};action_values={}
 def allowed(last,t):return [p for p in config['legal_prices'] if (t!=1 or p<=initial_ceiling) and (not config['markdown_only'] or p<=last)]
 @lru_cache(None)
 def value(t,I,last):
  if t==4:return salvage*I
  vals={}
  for p in allowed(last,t):
   vals[p]=sum(probs[t,p,s]*(p*min(I,ds[t,p,s])+value(t+1,I-min(I,ds[t,p,s]),p)) for s in ['low','high'])
  p=max(vals,key=lambda p:(vals[p],p));policy[t,I,last]=p;action_values[t,I,last]=vals
  return vals[p]
 initial=value(1,config['initial_inventory'],config['initial_price_ceiling'])
 # Complete table, including states not reached by optimal policy.
 for t in [3,2,1]:
  for I in range(config['initial_inventory']+1):
   for last in config['legal_prices']:value(t,I,last)
 def eval_schedule(schedule):
  def rec(t,I):
   if t==4:return salvage*I
   p=schedule[t-1]
   return sum(probs[t,p,s]*(p*min(I,ds[t,p,s])+rec(t+1,I-min(I,ds[t,p,s]))) for s in ['low','high'])
  return rec(1,config['initial_inventory'])
 schedules=[x for x in itertools.product(config['legal_prices'],repeat=3) if x[0]<=initial_ceiling and (not config['markdown_only'] or all(x[i]>=x[i+1] for i in range(2)))]
 paths=[]
 for states in itertools.product(['low','high'],repeat=3):
  I=config['initial_inventory'];last=config['initial_price_ceiling'];prob=1;rev=0;trace=[]
  for t,s in enumerate(states,1):
   p=policy[t,I,last];d=ds[t,p,s];sale=min(I,d);prob*=probs[t,p,s];rev+=p*sale
   trace.append(dict(period=t,opening_inventory=I,chosen_price=p,then_observed_scenario=s,demand=d,sales=sale,closing_inventory=I-sale));I-=sale;last=p
  paths.append(dict(scenarios=states,probability=prob,revenue=rev,terminal_inventory=I,net_value=rev+salvage*I,trace=trace))
 if abs(sum(p['probability']*p['net_value'] for p in paths)-initial)>1e-9:raise AssertionError('path sum mismatch')
 return dict(expected_net_value=initial,initial_price=policy[1,config['initial_inventory'],config['initial_price_ceiling']],fixed_prices={str(p):eval_schedule([p]*3) for p in config['legal_prices'] if p<=initial_ceiling},
 fixed_schedules={','.join(map(str,s)):eval_schedule(s) for s in schedules},bellman=[dict(period=t,inventory=I,last_price=last,best_price=policy[t,I,last],value=value(t,I,last),action_values=action_values[t,I,last]) for t,I,last in sorted(policy)],paths=paths)

def deep(data,vectors,trend):
 hist=np.array(data['history']);future=np.array(data['future_known']);static=np.array(data['static']);samples=np.array(data['simulated_samples_NOT_MODEL_OUTPUT'])
 if hist.shape!=(2,4,3) or future.shape!=(2,3,3) or static.shape!=(2,2) or samples.shape!=(2,5,3):raise ValueError('tensor shape mismatch')
 if not all(np.isfinite(x).all() for x in [hist,future,static,samples]):raise ValueError('nonfinite tensor')
 if data['future_available_at']>data['origin']:raise ValueError('future known unavailable')
 scale=np.asarray(data['train_only_scale'],dtype=float)
 if scale.shape!=(2,) or not np.isfinite(scale).all() or (scale<=0).any():raise ValueError('scale must contain exactly two finite positive values, one per series')
 if any(r['available_at']>data['origin'] for r in trend):raise ValueError('trend leak')
 rates=[finite(r['units'])/finite(r['comparable_exposure']) for r in trend]
 if rates[0]<=0:raise ValueError('trend zero base')
 trend_factor=rates[1]/rates[0]
 train=[r for r in vectors if r['split']=='train'];hold=[r for r in vectors if r['split']=='holdout'];pred=[]
 for r in vectors:
  if np.linalg.norm([finite(r['v1']),finite(r['v2'])])==0:raise ValueError('zero vector cosine undefined')
  if finite(r['exposure'])<=0:raise ValueError('exposure must be positive')
  if r['vector_available_at']>data['origin']:raise ValueError('vector unavailable at origin')
 for r in train:
  if r['label_available_at']>data['origin']:raise ValueError('analogue label leak')
 for r in hold:
  q=np.array([finite(r['v1']),finite(r['v2'])]);scores=[]
  for a in train:
   if a['category']!=r['category']:continue
   v=np.array([finite(a['v1']),finite(a['v2'])]);sim=float(q@v/(np.linalg.norm(q)*np.linalg.norm(v)))
   if sim>0:scores.append((sim,a))
  scores=sorted(scores,key=lambda x:(-x[0],x[1]['item']))[:2]
  if sum(x[0] for x in scores)==0:
   rate=sum(finite(a['units']) for a in train)/sum(finite(a['exposure']) for a in train);fallback=True
  else:rate=sum(s*finite(a['units'])/finite(a['exposure']) for s,a in scores)/sum(s for s,a in scores);fallback=False
  pred.append(dict(item=r['item'],neighbors=[dict(item=a['item'],cosine=s,weight=s/sum(z[0] for z in scores)) for s,a in scores],base_rate=rate,trend_factor=trend_factor,forecast=finite(r['exposure'])*rate*trend_factor,heldout_actual=finite(r['units']),fallback=fallback))
 train_vectors=np.array([[finite(r['v1']),finite(r['v2'])] for r in train]);train_vectors=train_vectors/np.linalg.norm(train_vectors,axis=1,keepdims=True)
 hold_vectors=np.array([[finite(r['v1']),finite(r['v2'])] for r in hold]);hold_vectors=hold_vectors/np.linalg.norm(hold_vectors,axis=1,keepdims=True)
 # Symmetric fixtures have equal-inertia optima. Parallel reduction roundoff can
 # switch the winning n_init run even with fixed random_state. Scope the thread
 # limit to the actual fit/predict, so callers need no environment variables.
 with threadpool_limits(limits=1):
  km=KMeans(n_clusters=2,n_init=10,random_state=20261106,algorithm='lloyd').fit(train_vectors)
  hold_labels=km.predict(hold_vectors)
 clustering=dict(model='sklearn KMeans on L2-normalized synthetic vectors',training_items=[r['item'] for r in train],n_clusters=2,random_state=20261106,algorithm='lloyd',thread_policy='fit and predict use threadpoolctl limits=1 internally',centers=km.cluster_centers_.tolist(),inertia=float(km.inertia_),train_labels=km.labels_.tolist(),holdout_labels=hold_labels.tolist(),cluster_count_selection='fixed teaching choice, not validated model selection',used_for_demand_forecast=False)
 return dict(clustering=clustering,shapes=dict(static=list(static.shape),history=list(hist.shape),future_known=list(future.shape),simulated_samples=list(samples.shape)),quantile_method='numpy.quantile method=higher',simulated_p50=np.quantile(samples,.5,axis=1,method='higher').tolist(),simulated_p90=np.quantile(samples,.9,axis=1,method='higher').tolist(),vector_predictions=pred,model_training='NONE: no TFT, DeepAR or vision model trained. Samples and vectors are explicitly synthetic.')

def main():
 (ROOT/'outputs').mkdir(exist_ok=True)
 out=dict(causal=causal(rows('three_products.csv')),trees=trees(rows('tree_features.csv')),pricing=build_dp(rows('pricing_scenarios.csv'),json.loads((ROOT/'data'/'pricing_config.json').read_text())),deep=deep(json.loads((ROOT/'data'/'deep_inputs.json').read_text()),rows('image_vectors.csv'),rows('trend_history.csv')),
 dependency=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,prophet_available=importlib.util.find_spec('prophet') is not None,torch_available=importlib.util.find_spec('torch') is not None),prophet_execution='NOT RUN: supplied components are arithmetic illustration, no fitted Prophet model.')
 comp=rows('prophet_components.csv');out['prophet_component_example']=[dict(day=int(r['day']),sum_prediction=finite(r['trend'])+finite(r['weekly'])+finite(r['holiday'])) for r in comp]
 (ROOT/'outputs'/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
 print(json.dumps(dict(causal_randomized_max_error=out['causal']['randomized_max_elasticity_error'],confounded_A_own=out['causal']['confounded_naive_coefficients'][0][1],dp_value=out['pricing']['expected_net_value'],dp_first_price=out['pricing']['initial_price'],test_wape={k:round(v['test']['wape'],6) for k,v in out['trees']['results'].items()},training_records=len(out['trees']['training_records'])),indent=2))
if __name__=='__main__':main()
