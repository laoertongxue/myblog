"""Deterministic synthetic data. Never reads production systems."""
from pathlib import Path
import csv,json,itertools,datetime,math
import numpy as np
ROOT=Path(__file__).resolve().parent

def write_csv(name, rows):
 p=ROOT/'data'/name
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 rng=np.random.default_rng(20261106)
 E=np.array([[-1.4,.35,-.15],[.4,-1.2,-.1],[-.2,-.15,-.9]])
 base=np.array([100,80,60]);prices=np.array([10,12,8]);rows=[]
 # Every eight-day block crosses all three randomized price signs.
 zvals=rng.permutation(np.linspace(-1,1,21))
 sign_orders=[rng.permutation(8) for _ in range(21)]
 for design in ['randomized','confounded']:
  for day in range(168):
   rep,k=divmod(day,8); signs=np.array(list(itertools.product([-1,1],repeat=3))[sign_orders[rep][k]])
   z=float(zvals[rep]); promo=int(rep%3==0)
   logs=.12*signs.astype(float)
   if design=='confounded':logs[0]=.12*z+.03*signs[0]
   logq=E@logs+.12*promo+.4*z
   date=datetime.date(2025,1,1)+datetime.timedelta(days=day)
   split='train' if day<112 else ('validation' if day<140 else 'test')
   for i,sku in enumerate('ABC'):
    rows.append(dict(design=design,day=day,date=str(date),split=split,sku=sku,
      q_base=int(base[i]),price_base=int(prices[i]),price_A=round(prices[0]*math.exp(logs[0]),10),
      price_B=round(prices[1]*math.exp(logs[1]),10),price_C=round(prices[2]*math.exp(logs[2]),10),
      category_reference=10,promo_known=promo,latent_shock_DIAGNOSTIC_ONLY=z,
      latent_demand=round(base[i]*math.exp(logq[i]),10),observed_sales=round(base[i]*math.exp(logq[i]),10),
      stockout=0,price_available_at=str(date)+'T00:00:00',forecast_origin=str(date)+'T00:00:00'))
 write_csv('three_products.csv',rows)
 (ROOT/'data'/'elasticity_truth.json').write_text(json.dumps(dict(rows=list('ABC'),columns=list('ABC'),elasticity=E.tolist(),q_base=base.tolist(),price_base=prices.tolist(),latent_shock_coefficient=.4,promo_coefficient=.12),indent=2))
 rows=[];rng=np.random.default_rng(98721);start=datetime.date(2024,1,1)
 for sku_i,sku in enumerate('ABC'):
  ys=[]
  for day in range(420):
   date=start+datetime.timedelta(days=day);prev=date-datetime.timedelta(days=1)
   promo=int((day+sku_i*3)%21 in [0,1,2,3]);temp=19+9*math.sin(day*2*math.pi/100)+rng.normal(0,1)
   lead=3+int((day//28+sku_i)%3==0)*2
   season=4*math.sin(day*2*math.pi/7)+3*math.cos(day*2*math.pi/30)
   demand=25+10*sku_i+season+promo*(12+sku_i*5)+max(temp-22,0)*(1.4+.3*sku_i)-2*(lead>3)+rng.normal(0,1.4)
   y=max(0,round(demand));ys.append(y)
   if day<14:continue
   rows.append(dict(day=day,date=str(date),sku=sku,sku_id=sku_i,split='train' if day<252 else ('validation' if day<336 else 'test'),
      origin=str(prev)+'T18:00:00',history_available_at=str(prev)+'T17:30:00',promo_available_at=str(prev)+'T12:00:00',weather_available_at=str(prev)+'T12:00:00',lead_available_at=str(prev)+'T12:00:00',
      lag1=ys[-2],lag7=ys[-8],rolling7=round(float(np.mean(ys[-8:-1])),8),sin7=round(math.sin(day*2*math.pi/7),8),cos30=round(math.cos(day*2*math.pi/30),8),
      promo=promo,weather_forecast=round(temp,8),supplier_lead_known=lead,target_demand=y))
 rows.sort(key=lambda r:(r['day'],r['sku']));write_csv('tree_features.csv',rows)
 scenarios=[]
 dem={1:{10:[1,3],8:[2,4]},2:{10:[1,2],8:[2,4]},3:{10:[0,1],8:[1,3]}}
 for t in dem:
  for p in dem[t]:
   for state,d in zip(['low','high'],dem[t][p]):scenarios.append(dict(period=t,price=p,scenario=state,probability=.5,demand=d))
 write_csv('pricing_scenarios.csv',scenarios)
 (ROOT/'data'/'pricing_config.json').write_text(json.dumps(dict(initial_inventory=5,initial_price_ceiling=10,terminal_salvage_per_unit=-1,markdown_only=True,expiry_period=4,legal_prices=[8,10],minimum_price=8),indent=2))
 response=[]
 for business,T,ps,stocks in [('fresh_hours',3,[8,9,10],[2,8]),('apparel_weeks',4,[60,80,100],[20,80])]:
  for t in range(1,T+1):
   for p in ps:
    if business=='fresh_hours':q=np.mean(dem[t][10])+(10-p)/2*(np.mean(dem[t][8])-np.mean(dem[t][10]))
    else:q=(32-5*t)*(100/p)**1.2
    for stock in stocks:
     capped=float(np.mean([min(stock,x10+(10-p)/2*(x8-x10)) for x10,x8 in zip(dem[t][10],dem[t][8])])) if business=='fresh_hours' else min(stock,float(q))
     response.append(dict(business=business,period=t,price=p,opening_stock=stock,mean_latent_demand=round(float(q),6),expected_sales=round(capped,6),response_source='stipulated_simulation',expiry_period=T+1))
 write_csv('price_response.csv',response)
 vectors=[('V1','train','shirts',1,0,1000,100),('V2','train','shirts',.8,.2,1000,120),('V3','train','shirts',0,1,1000,80),('V4','train','shoes',-1,0,1000,70),('V5','train','shoes',-.8,.2,1000,90),('V6','train','shoes',0,-1,1000,60),('V7','holdout','shirts',.9,.1,1000,118),('V8','holdout','shoes',-.9,.1,1000,87)]
 write_csv('image_vectors.csv',[dict(item=i,split=s,category=c,v1=v1,v2=v2,exposure=e,units=u,vector_available_at='2025-01-09T00:00:00',label_available_at='2025-01-10T00:00:00' if s=='train' else '2025-01-20T00:00:00') for i,s,c,v1,v2,e,u in vectors])
 write_csv('trend_history.csv',[dict(period=1,available_at='2025-01-05T00:00:00',comparable_exposure=6000,units=500),dict(period=2,available_at='2025-01-10T00:00:00',comparable_exposure=6000,units=550)])
 tensors=dict(origin='2025-01-10T18:00:00',static_fields=['category_code','base_price'],static=[[0,10],[1,12]],train_only_scale=[10,20],
  history_fields=['sales_divided_by_train_scale','promo_observed','temperature_scaled'],history=[[[.8,0,.2],[.9,0,.3],[1,1,.1],[1.2,1,.2]],[[.7,0,.1],[.8,0,.2],[.9,1,.3],[1,1,.2]]],
  future_known_fields=['promo_announced','weather_forecast_scaled','days_ahead_divided_by_3'],future_known=[[[0,.2,1/3],[1,.3,2/3],[0,.1,1]],[[0,.1,1/3],[0,.2,2/3],[1,.3,1]]],
  future_available_at='2025-01-10T12:00:00',simulated_samples_NOT_MODEL_OUTPUT=[[[8,7,6],[9,8,7],[10,9,8],[11,10,9],[12,11,10]],[[16,15,14],[18,17,16],[20,19,18],[22,21,20],[24,23,22]]])
 (ROOT/'data'/'deep_inputs.json').write_text(json.dumps(tensors,indent=2))
 write_csv('prophet_components.csv',[dict(day=t,trend=100+2*t,weekly=10*math.sin(2*math.pi*t/7),holiday=20 if t==7 else 0,known_origin='2025-01-01T00:00:00') for t in range(1,15)])
 print('Synthetic fixtures written.')
if __name__=='__main__':main()
