#!/usr/bin/env python3
"""Eight bounded pedagogic gaps. Synthetic data, offline calculations, no business actions."""
import argparse, csv, hashlib, json, math, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import binom
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, mean_pinball_loss
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT=Path(__file__).resolve().parent
D=ROOT/'data'; O=ROOT/'outputs'
SEED=20261106
MET={}
REUSE=False
RAW={"hazard_orders.csv","hazard_events.csv","return_order_cohorts.csv","cod_orders.csv","po_release_features.csv","po_receipt_events.csv"}

def save(df,name):
    p=(D if name.startswith('data/') else O)/name.split('/',1)[-1]
    if REUSE and name.startswith('data/') and p.name in RAW:
        if not p.exists():raise FileNotFoundError('Missing required input '+str(p))
        return
    p.parent.mkdir(parents=True,exist_ok=True); df.to_csv(p,index=False,float_format='%.9f')

def dump(obj,name):
    (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def scores(y,p):
    return {'n':len(y),'positive_rate':float(np.mean(y)),'brier':float(brier_score_loss(y,p)),
            'logloss':float(log_loss(y,p,labels=[0,1]))}

def linear(C=1): return make_pipeline(StandardScaler(),LogisticRegression(C=C,max_iter=800,random_state=SEED))

def age_x(df,features,maxage=12):
    age=np.column_stack([(df.age.to_numpy()==a).astype(float) for a in range(2,maxage+1)])
    return np.column_stack([age,df[features].to_numpy()]) if features else age

def build_person_days(orders,cutoff,maxage=12):
    rows=[]
    for q in orders.itertuples():
        stop=min(q.cancel_age,q.ship_age,maxage,cutoff-q.day)
        for a in range(1,max(0,int(stop))+1):
            rows.append({'id':q.id,'day':q.day,'age':a,'known_at':q.day,'interval_end':q.day+a,
                         'price100':q.price/100,'warehouse':q.warehouse,'promo':q.promo,
                         'y':int(a==q.cancel_age and q.cancel_age<=q.ship_age)})
    return pd.DataFrame(rows)

def hazard(rng):
    rows=[]
    for i in range(4800):
        day=i//20; price=int(rng.choice([80,120,180,240])); wh=int(rng.integers(0,2)); promo=int(rng.random()<.3)
        cancel=99
        for a in range(1,13):
            base=-2.0 if a==1 else -3.15 if a<=3 else -3.8 if a<=7 else -4.3
            if rng.random()<expit(base+.32*price/100+.45*wh+.4*promo):cancel=a;break
        # Shipment independent of latent cancellation conditional on observed warehouse.
        ship=int(rng.integers(5,13)) if wh==0 else int(rng.integers(8,16))
        rows.append((i,day,price,wh,promo,cancel,ship))
    all_=pd.DataFrame(rows,columns=['id','day','price','warehouse','promo','cancel_age','ship_age'])
    save(all_[['id','day','price','warehouse','promo']],'data/hazard_orders.csv')
    events=[]
    for q in all_.itertuples():
        if q.cancel_age<=q.ship_age and q.cancel_age<=12:events.append((q.id,q.day+q.cancel_age,'cancel'))
        elif q.ship_age<=12:events.append((q.id,q.day+q.ship_age,'ship'))
    save(pd.DataFrame(events,columns=['id','event_day','event']),'data/hazard_events.csv')
    # Every fit consumes persisted raw inputs, including in --reuse-inputs mode.
    all_=pd.read_csv(D/'hazard_orders.csv'); events_in=pd.read_csv(D/'hazard_events.csv')
    all_['cancel_age']=99;all_['ship_age']=99
    for e in events_in.itertuples():
        match=all_.id==e.id
        if match.sum()!=1:raise ValueError('event must map to exactly one order')
        a=int(e.event_day-all_.loc[match,'day'].iloc[0])
        if a<1:raise ValueError('event before first interval')
        col='cancel_age' if e.event=='cancel' else 'ship_age' if e.event=='ship' else None
        if col is None:raise ValueError('unknown event')
        all_.loc[match,col]=a
    sets={k:build_person_days(all_[(all_.day>=a)&(all_.day<=b)],cut) for k,(a,b,cut) in
          {'train':(0,99,112),'validation':(120,159,172),'test':(180,219,232)}.items()}
    for k,v in sets.items():save(v,'data/hazard_person_days_'+k+'.csv')
    tr,va,te=[sets[k] for k in ['train','validation','test']]
    features=['price100','warehouse','promo']; trials=[]; fitted=[]
    for C in [.1,1,10]:
        model=linear(C).fit(age_x(tr,features),tr.y)
        p=model.predict_proba(age_x(va,features))[:,1]; trials.append({'C':C,**scores(va.y,p)});fitted.append(model)
    idx=int(np.argmin([v['logloss'] for v in trials]));m=fitted[idx]
    baseline=linear().fit(age_x(tr,[]),tr.y)
    p=m.predict_proba(age_x(te,features))[:,1]; pb=baseline.predict_proba(age_x(te,[]))[:,1]
    save(te.assign(prediction=p,age_only=pb),'hazard_test_predictions.csv')
    scaler,fit=m.steps[0][1],m.steps[1][1]
    beta=fit.coef_[0]/scaler.scale_; intercept=fit.intercept_[0]-np.sum(fit.coef_[0]*scaler.mean_/scaler.scale_)
    names=['age_'+str(a) for a in range(2,13)]+features
    save(pd.DataFrame({'term':['intercept']+names,'coefficient':[intercept]+list(beta)}),'hazard_coefficients.csv')
    cal=[]
    for a,g in te.assign(p=p).groupby('age'):
        cal.append({'age':a,'risk_rows':len(g),'cancels':int(g.y.sum()),'mean_prediction':g.p.mean(),'observed':g.y.mean()})
    save(pd.DataFrame(cal),'hazard_age_calibration.csv')
    query=pd.DataFrame({'age':range(1,13),'price100':[1.2]*12,'warehouse':[0]*12,'promo':[0]*12})
    h=m.predict_proba(age_x(query,features))[:,1];surv=np.cumprod(1-h)
    save(query.assign(hazard=h,survival=surv),'hazard_example_curve.csv')
    MET['P14']={'scope':'actual discrete logistic age-dummy hazard fit, not Cox or causal identification',
      'split_orders':{k:int(v.id.nunique()) for k,v in sets.items()},'split_person_days':{k:len(v) for k,v in sets.items()},
      'validation_candidates':trials,'selected_C':trials[idx]['C'],'test_model':scores(te.y,p),'test_age_only':scores(te.y,pb),
      'future_feature_rows':int(sum((v.known_at>v.interval_end-1).sum() for v in sets.values()))}
    return h

def retained_probability(h,start_age,lead):
    if start_age<0 or lead<0 or start_age+lead>len(h): raise ValueError('age/horizon outside fitted support')
    return float(np.prod(1-h[start_age:start_age+lead]))

def silent_eligible(hours): return float(hours)>=24

def planning(h, fabric_meters=160):
    if not math.isfinite(float(fabric_meters)) or fabric_meters<0:raise ValueError("fabric_meters must be finite and nonnegative")
    n=80; scenarios=[(3,.3,78),(5,.5,76),(8,.2,72)]
    scen=[];cost=[]; demand_dist=np.zeros(n+1)
    for lead,w,cap in scenarios:
        p=retained_probability(h,1,lead);pm=binom.pmf(np.arange(n+1),n,p);demand_dist+=w*pm
        scen.append({'lead_days_after_24h':lead,'weight':w,'conditional_survival':p,'expected_net_orders':n*p,'delivery_capacity':cap})
    # One garment = 2m fabric + 1 trim, both materials jointly cap available quantity.
    cap=min(int(fabric_meters//2),90,85)
    for mode,maxq,unit in [('cut_now',cap,10),('wait_fixed_quantity',min(55,cap),12)]:
        for q in range(maxq+1):
            ds=np.arange(n+1); purchase=unit*q
            v=purchase+8*np.maximum(q-ds,0)+45*np.maximum(ds-q,0)
            risk=max(float(binom.sf(min(q,c),n,retained_probability(h,1,l))) for l,w,c in scenarios)
            cost.append({'mode':mode,'quantity':q,'expected_cost':float(demand_dist@v),'unit_cost':unit,'capacity':maxq,'worst_shortfall_probability':risk,'service_feasible':risk<=.05})
    costs=pd.DataFrame(cost);best=costs.loc[costs.groupby('mode').expected_cost.idxmin()]
    service_choices=costs[costs.service_feasible]
    service_best=service_choices.loc[service_choices.groupby('mode').expected_cost.idxmin()] if not service_choices.empty else service_choices
    over=[]
    for total in range(n,121):
        risks=[float(binom.sf(min(cap,c),total,retained_probability(h,1,l))) for l,w,c in scenarios]
        weighted=sum(w*r for (_,w,_),r in zip(scenarios,risks))
        feasible_q=[q for q in range(cap+1) if max(float(binom.sf(min(q,c),total,retained_probability(h,1,l))) for l,w,c in scenarios)<=.05]
        required_q=min(feasible_q) if feasible_q else None
        over.append({'minimum_committed_supply_for_5pct':required_q,'total_active_commitments':total,'extra_orders':total-n,'weighted_failure':weighted,
                     'worst_scenario_failure':max(risks),'feasible_weighted':weighted<=.05,'feasible_each_scenario':required_q is not None and max(risks)<=.05})
    overs=pd.DataFrame(over);feasible=overs[overs.feasible_each_scenario]
    selected=None if feasible.empty else int(feasible.total_active_commitments.max())
    save(pd.DataFrame(scen),'presale_lead_scenarios.csv');save(costs,'presale_hedge_cost_grid.csv');save(best,'presale_best_policies.csv');save(service_best,'presale_service_constrained_best.csv');save(overs,'presale_overbooking_grid.csv')
    gate=pd.DataFrame({'age_hours':[0,23.999,24,48]});gate['eligible']=gate.age_hours.map(silent_eligible);save(gate,'presale_silent_gate.csv')
    MET['P15']={'active_after_24h':n,'expected_net_orders':float(demand_dist@np.arange(n+1)),
      'material_cap':int(cap),'fabric_meters':float(fabric_meters),'service_status':'feasible' if not service_best.empty else 'infeasible_for_current_active_orders','best_policies':best.to_dict('records'),'service_constrained_best':service_best.to_dict('records'),'max_total_under_each_scenario_5pct':selected,'committed_supply_needed_for_max_total':None if selected is None else int(overs.loc[overs.total_active_commitments==selected,'minimum_committed_supply_for_5pct'].iloc[0]),
      'scope':'fixed actions at same 24h decision time; waiting has no oracle information; probabilities assume conditional independent orders and calibrated hazards; no execution'}

def return_features(df):return df[['category','size_mismatch','live_channel','price100','promo','history_rate']].to_numpy()

def returns(rng):
    rows=[]
    for i in range(4200):
        day=i//14; cat=int(rng.integers(0,2));size=int(rng.integers(0,3));live=int(rng.random()<.45)
        price=float(rng.choice([.8,1.2,1.8,2.4]));promo=int(rng.random()<.35);hist=float(rng.beta(2,6))
        p=expit(-2.5+.35*cat+.5*size+.85*live+.3*price+.45*promo+.8*hist+.6*live*promo)
        ret=int(rng.random()<p);good=int(ret and rng.random()<(.90-.1*cat));lag=int(rng.integers(6,15)) if ret else -1
        rows.append((i,day,cat,size,live,price,promo,hist,ret,good,lag,day+30))
    df=pd.DataFrame(rows,columns=['id','ship_day','category','size_mismatch','live_channel','price100','promo','history_rate','return30','good','restock_lag','label_known_day'])
    save(df,'data/return_order_cohorts.csv')
    df=pd.read_csv(D/'return_order_cohorts.csv')
    if (df.label_known_day!=df.ship_day+30).any():raise ValueError('return label maturity contract violated')
    tr=df[df.ship_day<=99];va=df[df.ship_day.between(140,179)];te=df[df.ship_day.between(220,259)]
    trial=[];models=[]
    for depth in [1,2,3]:
        m=GradientBoostingClassifier(n_estimators=100,max_depth=depth,learning_rate=.05,min_samples_leaf=25,random_state=SEED)
        m.fit(return_features(tr),tr.return30);p=m.predict_proba(return_features(va))[:,1]
        trial.append({'max_depth':depth,**scores(va.return30,p)});models.append(m)
    i=int(np.argmin([t['logloss'] for t in trial]));m=models[i]
    p=m.predict_proba(return_features(te))[:,1];base=np.repeat(tr.return30.mean(),len(te))
    save(te[['id','ship_day','return30']].assign(p_return=p,training_mean=base),'return_test_predictions.csv')
    parts=[]; daily={k:0.0 for k in range(1,31)}
    # New 100 one-unit shipments at t=300; features available at shipment. Conditional category good/lag.
    cohort=te.iloc[:100].copy();p0=m.predict_proba(return_features(cohort))[:,1]
    for cat,g in tr.groupby('category'):
        returned=g[g.return30==1];good=returned[returned.good==1]
        gamma=float(good.shape[0]/returned.shape[0]);distr=good.restock_lag.value_counts(normalize=True).to_dict()
        expected_return=float(p0[cohort.category.to_numpy()==cat].sum())
        for lag,prob in distr.items():daily[int(lag)]+=expected_return*gamma*float(prob)
        parts.append({'category':int(cat),'returned_train':len(returned),'good_train':len(good),'gamma':gamma,'expected_returns_new100':expected_return,'expected_good_new100':expected_return*gamma})
    forecast=pd.DataFrame({'future_day':list(daily),'expected_restock':list(daily.values())})
    save(pd.DataFrame(parts),'return_gamma_by_category.csv');save(forecast,'return_expected_restock_new100.csv')
    # One decision date, one due date. Firm reserved demand is kept separate from uncommitted target.
    opening=40;firm_po=20;reserved=35;target=100;safety=10
    expected=float(forecast[forecast.future_day<=14].expected_restock.sum())
    strict_atp=opening+firm_po-reserved
    # total target demand 100 includes existing 35 reservations, not 100+35.
    no_return=max(0,math.ceil(target+safety-opening-firm_po))
    with_return=max(0,math.ceil(target+safety-opening-firm_po-expected))
    decision={'due_day':14,'opening_verified_sellable':opening,'firm_po_due':firm_po,'reserved_orders':reserved,
              'target_total_demand_includes_reservations':target,'safety':safety,'forecast_virtual_inbound':expected,
              'strict_atp_for_additional_promises':strict_atp,'additional_request':30,'accepted_in_offline_example':min(30,strict_atp),
              'suggested_procurement_without_returns':no_return,'suggested_procurement_with_expected_returns':with_return}
    save(pd.DataFrame([decision]),'return_atp_procurement_comparison.csv')
    opening_=40;ledger=[]
    for day,actual,po,ship in [(1,0,0,5),(2,0,0,5),(3,2,0,5),(4,4,20,5),(5,0,0,5),(6,3,0,5),(7,1,0,5)]:
        close=opening_+actual+po-ship
        ledger.append({'day':day,'opening':opening_,'actual_qc_passed_and_shelved':actual,'actual_po_received':po,'actual_shipped':ship,'closing':close})
        opening_=close
    save(pd.DataFrame(ledger),'return_physical_ledger.csv')
    MET['R01_R04']={'split_rows':[len(tr),len(va),len(te)],'maturity_days':30,'validation_candidates':trial,'selected_depth':trial[i]['max_depth'],
       'test_gbdt':scores(te.return30,p),'test_mean_baseline':scores(te.return30,base),'atp_and_purchase':decision,
       'scope':'actual GBDT fitted; category-conditional gamma and lag; future return forecast changes planning suggestions, never firm ATP; no supplier order sent'}

def validate_cod_inputs(df):
    if not np.isfinite(df[['day','history_known_at','label_known_at']].to_numpy()).all():raise ValueError('non-finite COD timestamp')
    if (df.history_known_at>df.day).any():raise ValueError('future COD history')
    if (df.label_known_at!=df.day+10).any():raise ValueError('COD maturity must be day+10')

def validate_cod_timeline(blocks):
    timeline=[]
    for name,df in blocks:
        if df.empty:raise ValueError('COD time block is empty: '+name)
        timeline.append({'stage':name,'first_score_day':int(df.day.min()),'last_score_day':int(df.day.max()),'all_labels_mature_day':int(df.label_known_at.max())})
    for prior,later in zip(timeline,timeline[1:]):
        if prior['all_labels_mature_day']>=later['first_score_day']:
            raise ValueError('COD timeline leak: '+prior['stage']+' labels are not mature before '+later['stage']+' scoring starts')
    return timeline

COD_COLS=['address_complete','night_2_5','pieces','basket100','history_sign_rate','prior_orders','remote_region']
def score_cod(model,features,score_time,history_known_at,calibration_offset=0.0):
    if not all(math.isfinite(float(x)) for x in [score_time,history_known_at,calibration_offset]):raise ValueError("non-finite scoring time or calibration offset")
    if history_known_at>score_time:raise ValueError('future history is not available at scoring')
    if any(c not in features or features[c] is None for c in COD_COLS):raise ValueError('missing required feature')
    a=np.array([[float(features[c]) for c in COD_COLS]])
    if not np.isfinite(a).all():raise ValueError('non-finite feature')
    raw=float(np.clip(model.predict_proba(a)[0,1],1e-12,1-1e-12))
    return float(expit(math.log(raw/(1-raw))+calibration_offset))

TRANSITIONS={('SCORED','flag'):'HOLD',('SCORED','low_risk'):'RELEASED',('HOLD','capacity_available'):'REVIEWING',
 ('HOLD','capacity_full'):'REVIEW_QUEUED',('REVIEW_QUEUED','capacity_available'):'REVIEWING',
 ('REVIEWING','customer_confirmed'):'CONFIRMED',('CONFIRMED','reviewer_approved'):'RELEASED',
 ('REVIEWING','customer_denied'):'CANCEL_RECOMMENDATION',('HOLD','timeout'):'EXPIRED_REVIEW',
 ('REVIEWING','timeout'):'EXPIRED_REVIEW',('REVIEW_QUEUED','timeout'):'EXPIRED_REVIEW',
 ('EXPIRED_REVIEW','reviewer_approved'):'RELEASED'}
def transition(state,event,reviewer=None):
    if event=='reviewer_approved' and not reviewer:raise ValueError('reviewer ID required')
    if (state,event) not in TRANSITIONS:raise ValueError('forbidden state transition')
    return TRANSITIONS[state,event]

def cod(rng):
    rows=[]
    for i in range(4800):
        day=i//20;address=int(rng.random()<.8);hour=int(rng.integers(0,24));night=int(2<=hour<=5);pieces=int(rng.integers(1,5))
        basket=float(rng.uniform(.4,3)*pieces);prior=int(rng.integers(0,30));signed=int(rng.binomial(prior,.83));history=(signed+1)/(prior+2);remote=int(rng.random()<.25)
        p=expit(-1.3-1.1*address+.7*night+.13*pieces+.16*basket-1.3*history+.7*remote)
        y=int(rng.random()<p)
        rows.append((i,day,address,hour,night,pieces,basket,history,prior,signed,remote,day-.01,y,day+10))
    df=pd.DataFrame(rows,columns=['id','day','address_complete','hour','night_2_5','pieces','basket100','history_sign_rate','prior_orders','prior_signed','remote_region','history_known_at','refused','label_known_at'])
    save(df,'data/cod_orders.csv');df=pd.read_csv(D/'cod_orders.csv')
    validate_cod_inputs(df)
    tr=df[df.day<=99];cal=df[df.day.between(120,139)];va=df[df.day.between(160,179)];te=df[df.day.between(200,239)]
    timeline=validate_cod_timeline([('train',tr),('calibration',cal),('threshold_selection',va),('test',te)])
    save(pd.DataFrame(timeline),'cod_fit_timeline.csv')
    m=linear().fit(tr[COD_COLS].to_numpy(),tr.refused)
    # Calibrate a single logit intercept without exposing validation-selection/test labels.
    def logits(part):
        p=m.predict_proba(part[COD_COLS].to_numpy())[:,1];return np.log(p/(1-p))
    offsets=np.arange(-1,1.0001,.05);offs=float(min(offsets,key=lambda o:log_loss(cal.refused,expit(logits(cal)+o),labels=[0,1])))
    pv=expit(logits(va)+offs);pt=expit(logits(te)+offs)
    thresholds=[]
    for threshold in [.2,.3,.4,.5,.6,.7,.8]:
        selected=[]
        q=va.assign(p=pv)
        for day,g in q.groupby('day'):selected.extend(g[g.p>threshold].nlargest(3,'p').index.tolist())
        use=va.index.isin(selected)
        # Costs are model-based hypothetical expectations, not measured treatment effects.
        c=float(np.sum(100*pv*(1-.3*use)+5*use))
        thresholds.append({'threshold':threshold,'selected':int(sum(use)),'capacity_per_day':3,'assumed_reduction':.3,'assumed_cost':c})
    choice=min(thresholds,key=lambda d:d['assumed_cost'])
    out=te[['id','day','refused']].assign(p_refuse=pt);out['flag']=out.p_refuse>choice['threshold'];out['selected']=False
    for day,g in out.groupby('day'):
        out.loc[g[g.flag].nlargest(3,'p_refuse').index,'selected']=True
    save(out,'cod_test_scoring.csv');save(pd.DataFrame(thresholds),'cod_threshold_capacity_scenarios.csv')
    # Fixtures are explicit scenario inputs, not real customer responses or production actions.
    fixtures=[('A',['flag','capacity_available','customer_confirmed','reviewer_approved']),
              ('B',['flag','capacity_available','customer_denied']),('C',['flag','capacity_full','timeout']),
              ('D',['low_risk']),('E',['flag','capacity_available','timeout','reviewer_approved'])]
    events=[]
    for oid,path in fixtures:
        state='SCORED'
        for step,event in enumerate(path):
            reviewer='SIM_REVIEWER_1' if event=='reviewer_approved' else None
            nxt=transition(state,event,reviewer);events.append({'order':oid,'step':step,'from_state':state,'event':event,'reviewer':reviewer,'to_state':nxt});state=nxt
    save(pd.DataFrame(events),'cod_state_machine_trace.csv')
    probe={c:float(te.iloc[0][c]) for c in COD_COLS};t=time.perf_counter()
    raw=score_cod(m,probe,float(te.iloc[0].day),float(te.iloc[0].history_known_at),calibration_offset=offs);elapsed=(time.perf_counter()-t)*1000
    MET['D01_D02']={'timeline':timeline,'split_rows':[len(tr),len(cal),len(va),len(te)],'calibration_logit_offset':offs,
       'test_model':scores(te.refused,pt),'test_mean':scores(te.refused,np.repeat(tr.refused.mean(),len(te))),
       'selected_scenario':choice,'test_flagged':int(out.flag.sum()),'test_review_capacity_selected':int(out.selected.sum()),
       'calibrated_probe_score':raw,'single_local_probe_ms_not_SLA':elapsed,
       'scope':'offline as-of feature contract and state machine; no live service, messages, holds or actual intervention experiment; 30% reduction is assumed only'}

def lead_sensitivity():
    rows=[]
    for mu in [10,20,40]:
        for sdL in [0,.5,1,2]:
            a=4*2**2;b=mu**2*sdL**2;total=a+b
            rows.append({'mean_daily_demand':mu,'sd_daily_demand':2,'mean_lead_days':4,'sd_lead_days':sdL,
                         'demand_variance_part':a,'lead_variance_part':b,'total_variance':total,
                         'lead_variance_share':b/total,'ss_continuous':1.65*math.sqrt(total),'ss_integer_ceiling':math.ceil(1.65*math.sqrt(total))})
    save(pd.DataFrame(rows),'lead_variance_sensitivity.csv');MET['L02']={'rows':len(rows),'baseline_variance':116,'baseline_SS':1.65*math.sqrt(116),'scope':'independent iid daily demand and independent lead time; normal approximation'}

PO_COLS=['age','wip_load','season','complexity','history_otd','received_fraction','stage']
def validate_po_history(df):
    if not np.isfinite(df[['day','history_known_at']].to_numpy()).all() or (df.history_known_at>df.day).any():raise ValueError('future or non-finite PO history')

def po_full_support(row, training):
    reasons=[]
    for name in ['season','complexity','stage']:
        if row[name] not in set(training[name]):reasons.append(name+'_unseen')
    for name in ['age','wip_load','history_otd','received_fraction']:
        if not float(training[name].min())<=float(row[name])<=float(training[name].max()):reasons.append(name+'_outside_training_range')
    return reasons

NEXT_COLS=['elapsed','wip_load','season','complexity','history_otd','remaining_fraction','stage']
def po(rng):
    orders=[];receipts=[];hist=[];event_lookup={}
    for i in range(1800):
        day=i//5;season=int(150<=day%180<180);complexity=int(rng.integers(1,4));supplier=int(rng.integers(0,2))
        # Compute historical WIP and OTD from only receipts/due dates known at release.
        past=[o for o in orders if o['supplier']==supplier]
        outstanding=sum(100-sum(qty for event_day,qty in event_lookup[o['id']] if event_day<=day) for o in past)
        wip=outstanding/5000
        due_past=[o for o in past if o['promised_day']<day]
        otd=sum(o['final_day']<=o['promised_day'] for o in due_past)/len(due_past) if due_past else .5
        first=max(3,int(round(4+2*complexity+4*wip+4*season+rng.normal(0,1.4))))
        second=first+int(rng.integers(3,7));last=second+int(rng.integers(3,9))+complexity
        promised=day+18+2*complexity
        orders.append({'id':i,'day':day,'supplier':supplier,'quantity':100,'wip_load':wip,'season':season,'complexity':complexity,
                       'history_otd':otd,'history_known_at':day,'promised_day':promised,'final_day':day+last})
        event_lookup[i]=[(day+first,30),(day+second,30),(day+last,40)]
        for k,(lag,qty) in enumerate([(first,30),(second,30),(last,40)]):receipts.append({'id':i,'event_day':day+lag,'qty':qty,'stage_after':k+1})
    od=pd.DataFrame(orders);ev=pd.DataFrame(receipts)
    save(od.drop(columns='final_day'),'data/po_release_features.csv');save(ev,'data/po_receipt_events.csv')
    od=pd.read_csv(D/'po_release_features.csv');ev=pd.read_csv(D/'po_receipt_events.csv')
    validate_po_history(od)
    if ev.groupby('id').qty.sum().ne(100).any():raise ValueError('synthetic complete event ledger must total 100 per PO')
    od['final_day']=od.id.map(ev.groupby('id').event_day.max())
    # Supplier WIP at each as-of day: known releases minus receipts already observed.
    wip_by_day={}
    for supplier in od.supplier.unique():
        stock=np.zeros(450)
        own=od[od.supplier==supplier]
        for q in own.itertuples():stock[q.day]+=q.quantity
        for e in ev[ev.id.isin(own.id)].itertuples():stock[e.event_day]-=e.qty
        for day,v in enumerate(np.cumsum(stock)):wip_by_day[(int(supplier),day)]=float(v/5000)
    # Snapshot rows are created at ages 5/10/15 if still incomplete. final remaining is a label, never a feature.
    snapshots=[]
    for q in od.itertuples():
        ee=ev[ev.id==q.id]
        for age in [5,10,15]:
            asof=q.day+age;seen=ee[ee.event_day<=asof];received=seen.qty.sum()
            if received>=100:continue
            snapshots.append({'id':q.id,'release_day':q.day,'asof':asof,'age':age,'wip_load':wip_by_day[(q.supplier,asof)],'season':q.season,'complexity':q.complexity,
              'history_otd':q.history_otd,'received_fraction':received/100,'stage':len(seen),'remaining_to_full':q.final_day-asof,
              'label_known_at':q.final_day,'promised_day':q.promised_day})
    sn=pd.DataFrame(snapshots);save(sn,'data/po_training_snapshots.csv')
    tr=sn[(sn.release_day<=179)&(sn.label_known_at<=239)];va=sn[sn.release_day.between(240,279)&(sn.label_known_at<=339)];te=sn[sn.release_day.between(340,359)&(sn.label_known_at<=419)]
    if tr.label_known_at.max()>=va['asof'].min() or va.label_known_at.max()>=te['asof'].min():raise ValueError('PO model selection is not frozen before next block scoring')
    models={};trials=[];preds={}
    for quantile in [.5,.9]:
        cand=[]
        for depth in [1,2,3]:
            m=GradientBoostingRegressor(loss='quantile',alpha=quantile,n_estimators=120,learning_rate=.05,max_depth=depth,min_samples_leaf=20,random_state=SEED)
            m.fit(tr[PO_COLS],tr.remaining_to_full);loss=mean_pinball_loss(va.remaining_to_full,m.predict(va[PO_COLS]),alpha=quantile)
            cand.append((loss,m,depth));trials.append({'quantile':quantile,'depth':depth,'validation_pinball':float(loss)})
        best=min(cand,key=lambda t:t[0]);models[quantile]=best[1];preds[quantile]=np.maximum(0,best[1].predict(te[PO_COLS]))
    raw_cross=int(np.sum(preds[.5]>preds[.9]));p50=np.minimum(preds[.5],preds[.9]);p90=np.maximum(preds[.5],preds[.9])
    baseline50=float(tr.remaining_to_full.quantile(.5));baseline90=float(tr.remaining_to_full.quantile(.9))
    test_support_reasons=[po_full_support(row,tr) for _,row in te.iterrows()]
    test_support=np.array([not reasons for reasons in test_support_reasons])
    save(te[['id','asof','remaining_to_full','promised_day']].assign(p50_remaining=p50,p90_remaining=p90,training_constant_p50=baseline50,training_constant_p90=baseline90,within_training_feature_support=test_support,support_reason=[';'.join(v) if v else 'supported' for v in test_support_reasons]),'po_quantile_test.csv')
    # Grouped diagnostics: repeated snapshots remain clustered within PO.
    diag=te.copy();diag['supplier']=diag.id.map(od.set_index('id').supplier);diag['p50']=p50;diag['p90']=p90;diag['feature_supported']=test_support
    group_cal=[]
    for scope in ['all_raw_test','feature_supported_test']:
        part=diag if scope=='all_raw_test' else diag[diag.feature_supported]
        for grouping in ['supplier','age']:
            for value,g in part.groupby(grouping):
                for level in [.5,.9]:
                    col='p50' if level==.5 else 'p90'
                    group_cal.append({'scope':scope,'grouping':grouping,'group_value':int(value),'quantile':level,'snapshot_rows':len(g),'unique_PO':int(g.id.nunique()),'coverage':float((g.remaining_to_full<=g[col]).mean()),'pinball':float(mean_pinball_loss(g.remaining_to_full,g[col],alpha=level))})
    save(pd.DataFrame(group_cal),'po_quantile_group_calibration.csv')
    # Next receipt intervals including administrative right censoring at day 270.
    cutoff=270;episodes=[]
    for q in od[od.day<cutoff].itertuples():
        ee=ev[ev.id==q.id].sort_values('event_day');start=q.day;received=0;stage=0
        for e in ee.itertuples():
            if start>=cutoff:break
            duration=min(e.event_day,cutoff)-start;observed=e.event_day<=cutoff
            for a in range(1,int(duration)+1):
                episodes.append({'id':q.id,'episode':stage,'elapsed':a,'interval_end':start+a,'wip_load':wip_by_day[(q.supplier,start)],'season':q.season,
                 'complexity':q.complexity,'history_otd':q.history_otd,'remaining_fraction':(100-received)/100,'stage':stage,
                 'y':int(observed and a==duration),'censored_episode':int(not observed)})
            if not observed:break
            start=e.event_day;received+=e.qty;stage+=1
    ep=pd.DataFrame(episodes);save(ep,'data/po_next_receipt_person_days.csv')
    stage_elapsed_support={int(k):int(v) for k,v in ep.groupby('stage').elapsed.max().items()}
    nextmodel=GradientBoostingClassifier(n_estimators=100,max_depth=2,min_samples_leaf=40,random_state=SEED).fit(ep[NEXT_COLS],ep.y)
    # Live snapshot at day 360; future events are used only after scoring in a separate evaluation ledger.
    pending=[];cut=360
    for q in od[od.day<=cut].itertuples():
        seen=ev[(ev.id==q.id)&(ev.event_day<=cut)].sort_values('event_day');got=int(seen.qty.sum())
        if got>=100:continue
        age=cut-q.day;last=q.day if seen.empty else int(seen.event_day.max());elapsed=cut-last;stage=len(seen)
        feature=pd.DataFrame([{'age':age,'wip_load':wip_by_day[(q.supplier,cut)],'season':q.season,'complexity':q.complexity,'history_otd':q.history_otd,
                              'received_fraction':got/100,'stage':stage}])
        # Quantile model was trained only ages 5/10/15; never extrapolate unnoticed.
        in_age_support=5<=age<=15
        support_reasons=po_full_support(feature.iloc[0],tr)
        in_support=not support_reasons
        q50=float(max(0,models[.5].predict(feature[PO_COLS])[0])) if in_support else None
        q90=float(max(0,models[.9].predict(feature[PO_COLS])[0])) if in_support else None
        if in_support:q50,q90=min(q50,q90),max(q50,q90)
        support_horizon=max(0,min(15,stage_elapsed_support.get(stage,0)-elapsed))
        xx=pd.DataFrame([{'elapsed':elapsed+k,'wip_load':wip_by_day[(q.supplier,last)],'season':q.season,'complexity':q.complexity,'history_otd':q.history_otd,
                         'remaining_fraction':(100-got)/100,'stage':stage} for k in range(1,support_horizon+1)])
        hs=nextmodel.predict_proba(xx[NEXT_COLS])[:,1] if support_horizon else np.array([]);cdf=1-np.cumprod(1-hs)
        def qnext(p):
            ids=np.where(cdf>=p)[0];return int(ids[0]+1) if len(ids) else None
        pending.append({'id':q.id,'asof':cut,'age':age,'received_qty':got,'outstanding_qty':100-got,'last_receipt_elapsed':elapsed,
                        'promised_day':q.promised_day,'otd_status':'late_unfilled' if cut>q.promised_day else 'not_yet_due',
                        'full_quantile_in_age_support':in_age_support,'full_quantile_in_feature_support':in_support,'full_quantile_support_reason':';'.join(support_reasons) if support_reasons else 'supported','p50_remaining_full':q50,'p90_remaining_full':q90,
                        'next_receipt_stage':stage,'next_receipt_stage_elapsed_max':stage_elapsed_support.get(stage,0),'next_receipt_supported_horizon':support_horizon,'p50_days_to_next_receipt':qnext(.5),'p90_days_to_next_receipt':qnext(.9),'p_next_within7':float(cdf[6]) if support_horizon>=7 else None,
                        'expected_next_qty_given_event':30 if stage<2 else 40})
    pe=pd.DataFrame(pending);save(pe,'po_pending_snapshot360_predictions.csv')
    full_eval=pe[['id','asof','p50_remaining_full','p90_remaining_full','full_quantile_in_feature_support','full_quantile_support_reason']].copy()
    full_eval['actual_remaining_to_full']=full_eval.id.map(od.set_index('id').final_day)-cut
    save(full_eval,'po_full_pending_future_only_evaluation.csv')
    full_known=full_eval[full_eval.full_quantile_in_feature_support]
    # Evaluation only: reveal next events after cutoff, not used above.
    evals=[]
    for q in pe.itertuples():
        future=ev[(ev.id==q.id)&(ev.event_day>cut)].sort_values('event_day')
        actual=int(future.iloc[0].event_day-cut);evals.append({'id':q.id,'stage':q.next_receipt_stage,'actual_days_to_next':actual,'y_next7':int(actual<=7),'p_next7':q.p_next_within7,'p50_days_to_next':q.p50_days_to_next_receipt,'p90_days_to_next':q.p90_days_to_next_receipt})
    ee=pd.DataFrame(evals);save(ee,'po_future_only_evaluation.csv')
    next_cal=[]
    for stage,g in ee.groupby('stage'):
        for level in ['p50','p90']:
            predcol=level+'_days_to_next';known=g[g[predcol].notna()]
            next_cal.append({'stage':int(stage),'quantile':level,'supported_n':len(known),'total_stage_n':len(g),'coverage':float((known.actual_days_to_next<=known[predcol]).mean()) if len(known) else None})
    save(pd.DataFrame(next_cal),'po_next_receipt_stage_calibration.csv')
    # OTD full completion against promise, not within30. Due future and still open are unresolved.
    status=[]
    for q in od.itertuples():
        received=int(ev[(ev.id==q.id)&(ev.event_day<=cut)].qty.sum());complete=received==100
        if complete:state='on_time' if q.final_day<=q.promised_day else 'late_complete'
        else:state='late_unfilled' if cut>q.promised_day else 'unresolved_not_due'
        status.append({'id':q.id,'asof':cut,'received_qty':received,'promised_day':q.promised_day,'status':state})
    st=pd.DataFrame(status);save(st,'po_otd_asof360.csv');eligible=st[st.status!='unresolved_not_due']
    MET['L03']={'time_contract':{'train_release':[0,179],'train_labels_asof':239,'validation_release':[240,279],'validation_labels_asof':339,'test_release':[340,359],'test_labels_asof':419,'model_frozen_by':339},'training_season_values':sorted(int(x) for x in tr.season.unique()),'validation_season_values':sorted(int(x) for x in va.season.unique()),'test_season_values':sorted(int(x) for x in te.season.unique()),'split_snapshot_rows':[len(tr),len(va),len(te)],'validation_candidates':trials,'quantile_crossings_before_reorder':raw_cross,
      'training_constant_p50':baseline50,'training_constant_p90':baseline90,
      'test_constant_p50_pinball':float(mean_pinball_loss(te.remaining_to_full,np.repeat(baseline50,len(te)),alpha=.5)),
      'test_constant_p90_pinball':float(mean_pinball_loss(te.remaining_to_full,np.repeat(baseline90,len(te)),alpha=.9)),
      'test_p50_pinball':float(mean_pinball_loss(te.remaining_to_full,p50,alpha=.5)),
      'test_p90_pinball':float(mean_pinball_loss(te.remaining_to_full,p90,alpha=.9)),
      'test_full_feature_supported_n':int(test_support.sum()),'test_supported_p50_coverage':float(np.mean(te.remaining_to_full.to_numpy()[test_support]<=p50[test_support])) if test_support.any() else None,'test_supported_p90_coverage':float(np.mean(te.remaining_to_full.to_numpy()[test_support]<=p90[test_support])) if test_support.any() else None,'pending_full_supported_p50_coverage':float((full_known.actual_remaining_to_full<=full_known.p50_remaining_full).mean()) if len(full_known) else None,'pending_full_supported_p90_coverage':float((full_known.actual_remaining_to_full<=full_known.p90_remaining_full).mean()) if len(full_known) else None,
      'test_p50_coverage':float(np.mean(te.remaining_to_full<=p50)),'test_p90_coverage':float(np.mean(te.remaining_to_full<=p90)),
      'next_receipt_training_person_days':len(ep),'censored_episodes':int(ep[ep.censored_episode==1][['id','episode']].drop_duplicates().shape[0]),
      'pending_at360':len(pe),'pending_outside_full_quantile_age_support':int((~pe.full_quantile_in_age_support).sum()),'pending_full_quantile_abstained':int((~pe.full_quantile_in_feature_support).sum()),'pending_full_quantile_supported':int(pe.full_quantile_in_feature_support.sum()),
      'next_receipt_stage_elapsed_support':stage_elapsed_support,'next_receipt_stage_calibration':next_cal,'next_receipt_training_cutoff':cutoff,'next_receipt_max_elapsed_support':int(ep.elapsed.max()),'pending_next7_scored':int(ee.p_next7.notna().sum()),'pending_next7_brier':float(brier_score_loss(ee[ee.p_next7.notna()].y_next7,ee[ee.p_next7.notna()].p_next7)),
      'OTD_eligible_denominator':len(eligible),'OTD_numerator':int((eligible.status=='on_time').sum()),
      'OTD_rate':float((eligible.status=='on_time').mean()),'not_yet_due_unresolved':int((st.status=='unresolved_not_due').sum()),
      'scope':'actual sklearn quantile GBDT on mature vintages plus next-event hazard with censored episodes; no LightGBM/AFT; not a censor-aware full-completion quantile loss; full-quantile WIP as-of snapshot; next-event WIP fixed at episode start'}

def write_report():
    p=MET['P14'];a=MET['P15'];r=MET['R01_R04'];c=MET['D01_D02'];l=MET['L03']
    checks={'po_p50_coverage':{'observed':l['test_p50_coverage'],'teaching_warning_band':[.45,.55],
             'pass':.45<=l['test_p50_coverage']<=.55},
            'po_p90_coverage':{'observed':l['test_p90_coverage'],'teaching_warning_band':[.85,.95],
             'pass':.85<=l['test_p90_coverage']<=.95}}
    dump({'seed':SEED,'statistical_diagnostics':checks,
          'warning':'These are coarse teaching diagnostics, not confidence intervals or deployment gates. Code contract tests are separate in tests.txt.'},'acceptance.json')
    lines=['# 实际运行结果','',f'全部为合成数据。种子{SEED}。以下数值由本次运行自动更新；代码规则测试另运行tests目录。','',
      f"- P14：训练/验证/测试订单{p['split_orders']}；person-day {p['split_person_days']}。测试Brier {p['test_model']['brier']:.6f}，年龄基线{p['test_age_only']['brier']:.6f}。",
      f"- P15：当前80单期望净需求{a['expected_net_orders']:.4f}；物料容量{a['material_cap']}。成本最优与服务约束最优见以下JSON。",
      json.dumps({'cost_only':a['best_policies'],'service_constrained':a['service_constrained_best']},ensure_ascii=False),
      f"- 超卖风险约束最多支持{a['max_total_under_each_scenario_5pct']}活跃承诺，需要供应承诺{a['committed_supply_needed_for_max_total']}件；不能与更低裁剪量拼接。",
      f"- R01：订单GBDT Brier {r['test_gbdt']['brier']:.6f}，均值基线{r['test_mean_baseline']['brier']:.6f}。",
      f"- R04：预计回流{r['atp_and_purchase']['forecast_virtual_inbound']:.4f}件，硬ATP仍{r['atp_and_purchase']['strict_atp_for_additional_promises']}件；采购建议不计回流{r['atp_and_purchase']['suggested_procurement_without_returns']}，计期望回流{r['atp_and_purchase']['suggested_procurement_with_expected_returns']}。这不是已下订单。",
      f"- D01/D02：COD Brier {c['test_model']['brier']:.6f}；测试风险标记{c['test_flagged']}单，容量选中{c['test_review_capacity_selected']}单。复核相对改善30%只是成本情景，未经因果实验。",
      f"- L02：基准方差116，安全库存{MET['L02']['baseline_SS']:.6f}，向上取整18；完整12种组合见CSV。",
      f"- L03：最终收齐P50/P90 pinball {l['test_p50_pinball']:.6f}/{l['test_p90_pinball']:.6f}；训练常数分位基线{l['test_constant_p50_pinball']:.6f}/{l['test_constant_p90_pinball']:.6f}。",
      f"- P50覆盖{l['test_p50_coverage']:.2%}，P90覆盖{l['test_p90_coverage']:.2%}。校准警戒带检查：P50 {checks['po_p50_coverage']['pass']}，P90 {checks['po_p90_coverage']['pass']}。未通过必须保留；pinball改善不保证校准。",
      f"- 上述测试覆盖是全部{l['split_snapshot_rows'][2]}行的原始诊断；其中仅{l['test_full_feature_supported_n']}行通过输入支持检查。360日可输出最终分位仅{l['pending_full_quantile_supported']}单，其事后P50/P90覆盖{l['pending_full_supported_p50_coverage']}/{l['pending_full_supported_p90_coverage']}，不能拿整体测试P90替代这个结果。",
      f"- 下一批模型含{l['censored_episodes']}个右删失episode、{l['next_receipt_training_person_days']}风险日，截止{l['next_receipt_training_cutoff']}；elapsed按到货阶段支持上限{l['next_receipt_stage_elapsed_support']}。",
      f"- 第360日未收齐{l['pending_at360']}单；最终分位因全部输入支持检查留空{l['pending_full_quantile_abstained']}单（其中年龄越界{l['pending_outside_full_quantile_age_support']}单）；7天下一批概率仅{l['pending_next7_scored']}单有支持，Brier {l['pending_next7_brier']:.6f}。其余不可悄悄算0。",
      f"- OTD={l['OTD_numerator']}/{l['OTD_eligible_denominator']}={l['OTD_rate']:.2%}；未到期且未完成{l['not_yet_due_unresolved']}单暂不计分母。",'',
      '没有安装或运行LightGBM、AFT或实时业务服务。所有计划/状态均为离线演算，未下单、未发送消息、未改变真实订单。']
    (O/'RESULTS.md').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')

def main():
    global SEED, REUSE
    pa=argparse.ArgumentParser();pa.add_argument('--seed',type=int,default=20261106);pa.add_argument('--reuse-inputs',action='store_true');args=pa.parse_args();SEED=args.seed;REUSE=args.reuse_inputs
    D.mkdir(exist_ok=True);O.mkdir(exist_ok=True)
    for name,func,offset in [('hazard',hazard,0),('returns',returns,100),('cod',cod,200),('po',po,300)]:
        print('Running',name,flush=True);res=func(np.random.default_rng(SEED+offset))
        if name=='hazard':planning(res)
    lead_sensitivity()
    import sklearn,scipy
    dump({'seed':SEED,'python':sys.version.split()[0],'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,'scipy':scipy.__version__,
          'all_data_synthetic':True,'no_external_actions':True,'metrics':MET},'metrics.json')
    write_report()
    files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(D.rglob('*.csv'))}
    dump(files,'input_sha256.json')
    print('Complete. Run python -m unittest discover -s tests -v',flush=True)
if __name__=='__main__':main()
