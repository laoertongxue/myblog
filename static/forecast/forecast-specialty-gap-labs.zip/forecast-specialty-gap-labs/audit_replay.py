"""Non-production replay tests in a temporary directory. Does not mutate released inputs."""
import contextlib,hashlib,importlib.util,json,shutil,tempfile
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('lab',ROOT/'run_all.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
report={}
with tempfile.TemporaryDirectory(prefix='specialty-replay-') as td:
 base=Path(td)/'lab';shutil.copytree(ROOT,base)
 r.ROOT=base;r.D=base/'data';r.O=base/'outputs';r.REUSE=True
 # Same persisted input produces same deterministic metrics/predictions. Runtime latency excluded.
 prior=pd.read_csv(r.O/'hazard_test_predictions.csv')
 r.hazard(np.random.default_rng(r.SEED));new=pd.read_csv(r.O/'hazard_test_predictions.csv')
 assert np.allclose(prior.prediction,new.prediction,atol=1e-9)
 report['hazard_same_raw_input_replay']={'passed':True,'max_prediction_abs_delta':float(np.max(abs(prior.prediction-new.prediction)))}
 # Changing raw test channel changes predictions without changing mature training labels.
 prior=pd.read_csv(r.O/'return_test_predictions.csv');p=r.D/'return_order_cohorts.csv';raw=pd.read_csv(p)
 mask=raw.ship_day.between(220,259);raw.loc[mask,'live_channel']=1-raw.loc[mask,'live_channel'];raw.to_csv(p,index=False)
 r.returns(np.random.default_rng(r.SEED+100));new=pd.read_csv(r.O/'return_test_predictions.csv')
 change=float(np.mean(abs(prior.p_return-new.p_return)));assert change>1e-5
 report['raw_test_channel_mutation_consumed']={'passed':True,'mean_abs_prediction_change':change}
 # Future history is rejected, not silently accepted into scoring.
 p=r.D/'cod_orders.csv';raw=pd.read_csv(p);raw.loc[0,'history_known_at']=raw.loc[0,'day']+1;raw.to_csv(p,index=False)
 try:r.cod(np.random.default_rng(r.SEED+200));raise AssertionError('future history accepted')
 except ValueError as e:
  assert 'future COD history' in str(e);report['cod_future_history_blocked']={'passed':True,'error':str(e)}
 # Move only a future receipt of newest order. Day360 prediction must stay the same.
 p=r.D/'po_receipt_events.csv';raw=pd.read_csv(p);mask=(raw.id==raw.id.max())&(raw.event_day>360)
 assert mask.sum()==3
 raw.loc[mask,'event_day']+=2;raw.to_csv(p,index=False)
 prior=pd.read_csv(r.O/'po_pending_snapshot360_predictions.csv');r.po(np.random.default_rng(r.SEED+300));new=pd.read_csv(r.O/'po_pending_snapshot360_predictions.csv')
 pd.testing.assert_frame_equal(prior,new,check_exact=False,atol=1e-9,rtol=1e-9)
 report['po_future_event_mutation_isolated_from_asof_predictions']={'passed':True,'modified_events':int(mask.sum()),'asof':360}
 # Regression counterexample: 140m cannot meet current 80 commitments, but must not crash.
 h=pd.read_csv(ROOT/'outputs/hazard_example_curve.csv').hazard.to_numpy();r.planning(h,fabric_meters=140)
 assert r.MET['P15']['max_total_under_each_scenario_5pct'] is None
 assert r.MET['P15']['committed_supply_needed_for_max_total'] is None
 report['fabric140_joint_capacity_infeasible_without_crash']={'passed':True,'material_cap':70,'selected':None}
 # Future COD label maturity is rejected even if its label value is changed.
 raw=pd.read_csv(ROOT/'data/cod_orders.csv');raw.loc[raw.day.between(70,99),'label_known_at']=999;raw.loc[raw.day.between(70,99),'refused']=1-raw.loc[raw.day.between(70,99),'refused'];raw.to_csv(r.D/'cod_orders.csv',index=False)
 try:r.cod(np.random.default_rng(r.SEED+200));raise AssertionError('future maturity accepted')
 except ValueError as e:
  assert 'maturity' in str(e);report['cod_future_label_poison_rejected']={'passed':True,'error':str(e),'mutated_rows':600}
 # PO history availability is a hard input gate.
 raw=pd.read_csv(ROOT/'data/po_release_features.csv');raw.loc[0,'history_known_at']=999;raw.to_csv(r.D/'po_release_features.csv',index=False)
 try:r.po(np.random.default_rng(r.SEED+300));raise AssertionError('future PO history accepted')
 except ValueError as e:
  assert 'PO history' in str(e);report['po_future_history_rejected']={'passed':True,'error':str(e)}
(ROOT/'outputs'/'audit_replay.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
