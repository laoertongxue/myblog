# 预售 退货 COD 与交期专项补课项目

这是五个离线模拟实验，补P14、P15、R01、R04、D01、D02、L02、L03八项教学缺口。所有订单都是虚构的。没有账号、密钥、网络请求或生产动作，不需要企业数据。

## 从哪开始

- 不运行软件：读docs/LESSONS.md和outputs/RESULTS.md，CSV可直接用表格软件打开。
- 运行：先确认依赖，再执行以下命令。生成器与模型会覆盖本文件夹内同名文件，不触及文件夹之外。

```bash
python run_all.py
python -m unittest discover -s tests -v
```

Mac/Linux若没有python可试python3，Windows可试py。完整默认数据和实跑输出已附上。

## 依赖及缺少时的处理

本次实跑Python 3.12.14、numpy 2.3.5、pandas 2.2.3、scipy 1.17.0、scikit-learn 1.8.0。requirements.txt记录确切版本；若缺少依赖，在你自己的环境按正常软件安装流程安装后再运行。项目不会自动联网安装，环境不能安装时可先学习附带输出。LightGBM、lifelines、AFT未安装未运行，本包也不依赖它们。

## 输入与重复运行

默认seed=20261106；新模拟可用python run_all.py --seed 20261107。改变种子后必须看新结果，不沿用默认成绩。

六个原始CSV在data/：hazard_orders.csv、hazard_events.csv、return_order_cohorts.csv、cod_orders.csv、po_release_features.csv、po_receipt_events.csv。默认运行生成并保存，再从盘上重新读取它们用于模型。要保留你对这些原始文件的修改，用：

```bash
python run_all.py --reuse-inputs
```

这个选项不会覆盖这六个原始文件，但会重新生成衍生person-day、快照和所有输出。不要修改衍生表后以为它是模型输入。原始模拟输入要求完整字段与其规定的事件结构；不是适配任意真实业务数据的导入器。特别是PO完整事件文件包含模拟未来，用于建立各时点标签和事后评估；特征只读as-of以前的事件。

## 文件

- run_all.py：生成器、读取原始CSV、训练、评分、计划计算和状态机，函数按模块分开。
- tests/test_contracts.py：结构、边界与算术测试；这些通过不代表模型概率已校准。
- audit_replay.py：独立复制目录后检查同输入复算、原始输入修改的影响和未来事件隔离。
- docs/LESSONS.md：完整逐符号教材。
- docs/DATA_DICTIONARY.md：字段、单位、已知时点和目标。
- outputs/metrics.json：实际数值、分块与限制。
- outputs/RESULTS.md：人可读结果及不合格项。
- outputs/input_sha256.json：所有数据CSV的校验值。
- outputs/acceptance.json：代码规则与统计校准分开报告。
- outputs/audit_replay.json：复现与突变实验记录。

## 模型与计划的已知限制

年龄hazard是离散logistic，不是Cox；添加特征不能证明删失独立。退货使用订单特征GBDT，良率和时滞分品类估计，预计回流只修采购建议而不修硬ATP。COD仅本地评分与纯函数状态机，复核30%降低拒收是假设。最终收齐分位GBDT仅训练成熟批次；下一次到货hazard另行使用删失episode，不能说二者合成了一套删失感知最终交期分位模型。

特别注意修正时块后的全部300行原始P50覆盖58.67%，未通过本教材45%至55%的教学警戒带；P90约90%位于85%至95%的粗警戒带。这不是置信区间或上线门槛，多快照不是独立样本。请保留失败，不调测试集。

第二版通过53项契约测试与7项副本实验。PO最终分位360日只对21/131张通过输入支持的订单输出，110张留空；下一批7天概率只对99/131张输出，32张留空。分stage及当前有支持订单的事后校准另列CSV，不能用全体测试成绩替代。
