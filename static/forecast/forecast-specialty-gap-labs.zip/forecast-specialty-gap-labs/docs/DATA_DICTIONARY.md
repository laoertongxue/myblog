# 输入数据字典与已知时点

六个原始CSV均由本项目生成，每个模型从保存后的CSV读取。day是各项目独立的整数日历，年龄是日差。空预测表示证据/支持不足，不是0。除了明示的0/1/2编码，类别编号不可当连续业务量。模拟标签放在原始记录中便于审计，训练函数只使用明确的特征列。

## 年龄hazard

hazard_orders.csv：id唯一订单；day创建日；price元；warehouse虚构二分类仓库；promo是否促销。特征创建时已知。hazard_events.csv：id、event_day、event（cancel或ship）。一单只记录最先终止观察的事件，最多12天；同日取消优先。无事件不表示永不取消。

衍生hazard_person_days_*.csv：age为1至12；known_at创建时点；interval_end为当前观察日末；price100=price/100；y为本日取消。列中的id不参与拟合。训练、验证、测试订单日分别0–99、120–159、180–219，截止112、172、232。

## 退货

return_order_cohorts.csv：id一件订单；ship_day发货日；category 0/1品类；size_mismatch 0/1/2先验尺码不合倾向；live_channel 0/1；price100百元；promo 0/1；history_rate为事先已有历史率（模拟特征，不含当前标签）。return30为30天退货标签；good=1代表退回后可售；restock_lag在return30=1时记录模拟流程时长，在good=1子集中才可解释成上架时滞；未退货为-1。label_known_day=ship_day+30是统一成熟日。严禁把good、restock_lag、return30、label_known_day当模型特征。

GBDT特征白名单为category、size_mismatch、live_channel、price100、promo、history_rate。训练、验证、测试发货日0–99、140–179、220–259。γ是成熟退货中good=1比例，d(k)是good=1子集中时滞分布。现版本出现某品类无退货/无合格样本时没有自动回退保证，不应继续套默认结果；要先明确回退先验和最小样本政策。

## COD

cod_orders.csv：id、day、address_complete、hour、night_2_5（2≤hour≤5）、pieces（件）、basket100（百元）、prior_orders、prior_signed（之前已知签收）、history_sign_rate=(prior_signed+1)/(prior_orders+2)、remote_region。history_known_at≤day。refused是10天后成熟的拒收标签；label_known_at=day+10；这些不是评分特征。四块日范围0–99、120–139、160–179、200–239。

复核成本5元、拒收损失100元、相对风险下降30%、每日容量3为政策情景参数。state trace的reviewer名称全是SIM_开头的虚构角色；状态变化仅写CSV，没有业务动作。

## PO

po_release_features.csv：id、day释放日、supplier虚构供应商0/1、quantity=100件、wip_load释放之前尚未收数量/5000件、season季节指示、complexity复杂度1/2/3、history_otd释放时已经过承诺日历史单的按期收齐率、history_known_at、promised_day承诺收齐日。没有真实供应商名称。

po_receipt_events.csv：id、event_day、qty（依次30、30、40）、stage_after（1、2、3）。文件包括完整模拟未来，只有已发生的行可进as-of特征，未来行仅供成熟标签与事后评估。普通真实数据不应为尚未发生事件补造行。

po_training_snapshots.csv：在订单年龄5/10/15日且尚未收齐创建一行。age为总年龄；wip_load重新按该快照时点计算当前供应商未收量/5000；received_fraction为当时已收/100；stage当时已收次数；remaining_to_full是事后剩余天数标签；label_known_at是真正最终收齐日；promised_day是原承诺日。模型特征不含id、未来label、真实剩余时间和最终收齐日。

po_next_receipt_person_days.csv：每次下单/部分收货开始一段episode；elapsed是本段开始后的年龄；interval_end是当前区间终点；wip_load使用episode开始时已知WIP且在整段固定；remaining_fraction为该段开始时未收比例；stage为开始时已收次数。y=1表示这一日发生下一次收货。censored_episode只是审计字段，不进入模型。训练截止270。

po_pending_snapshot360_predictions.csv：第360日仍有未收量的PO；总年龄、已收/未收、上一批到货后年龄及承诺状态。最终收齐P50/P90检查5至15天年龄、季节/复杂度/stage已见类别及WIP/历史OTD/已收比例训练数值范围；下一次到货P50/P90是从当前起等几天，不是总交期。预测窗最多15天，且不越过对应stage的训练elapsed最大值；达不到分位概率或7天越出支持范围时相应输出为空。

OTD分母纳入已完成及承诺日已过未完成订单，排除未来未到期且未完成的记录。“按30天内收齐”不能替代OTD。

## 计划常量输入

P15的场景、BOM和成本以及R04的一日到期ATP/采购参数在run_all.py的planning与returns函数中明确给出；这些是可编辑的场景输入，不是从CSV估出来的事实。修改后运行对应项目并重算所有结果，不能把固定答案测试失败解释成软件一定错误。改变数据结构/范围超出本模拟契约时，必须同时更新验证规则与说明。

最终收齐分位训练释放日0–179（标签截至239），验证240–279（截至339），测试340–359（截至419）；模型339日前冻结。训练季节0/1均有，测试新一轮季节1。po_quantile_test.csv的全部原始预测是评估诊断，within_training_feature_support标明135/300行有输入支持；正式360日输出不支持的预测为缺失。单一变量范围检查不能证明联合分布支持或校准。
