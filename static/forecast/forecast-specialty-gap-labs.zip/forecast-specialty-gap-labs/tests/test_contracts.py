import sys,json,math,unittest
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import run_all as r
D=ROOT/'data';O=ROOT/'outputs'

class Contracts(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.m=json.loads((O/'metrics.json').read_text())['metrics']
 def test_01_person_day_one_event_at_most(self):
  for k in ['train','validation','test']:
   x=pd.read_csv(D/f'hazard_person_days_{k}.csv');self.assertLessEqual(x.groupby('id').y.sum().max(),1)
 def test_02_person_day_stops_at_event(self):
  for k in ['train','validation','test']:
   x=pd.read_csv(D/f'hazard_person_days_{k}.csv')
   for oid,g in x.groupby('id'):
    if g.y.sum():self.assertEqual(int(g[g.y==1].age.iloc[0]),int(g.age.max()))
 def test_03_no_order_split_leak(self):
  ids=[set(pd.read_csv(D/f'hazard_person_days_{k}.csv').id) for k in ['train','validation','test']]
  self.assertFalse(ids[0]&ids[1]);self.assertFalse(ids[0]&ids[2]);self.assertFalse(ids[1]&ids[2])
 def test_04_feature_asof(self):
  for k in ['train','validation','test']:
   x=pd.read_csv(D/f'hazard_person_days_{k}.csv');self.assertTrue((x.known_at<=x.interval_end-1).all())
 def test_05_age_dummy_shape_and_reference(self):
  df=pd.DataFrame({'age':[1,2,12]});x=r.age_x(df,[]);self.assertEqual(x.shape,(3,11));self.assertEqual(x[0].sum(),0);self.assertEqual(x[1].sum(),1)
 def test_06_conditional_survival_handcalculation(self):
  self.assertAlmostEqual(r.retained_probability(np.array([.2,.1,.25]),1,2),.9*.75)
 def test_07_survival_rejects_extrapolation(self):
  with self.assertRaises(ValueError):r.retained_probability([.1,.2],1,5)
 def test_08_hazard_curve_monotonic(self):
  x=pd.read_csv(O/'hazard_example_curve.csv');self.assertTrue((x.hazard.between(0,1)).all());self.assertTrue((x.survival.diff().dropna()<=0).all())
 def test_09_silence_exact24(self):
  self.assertFalse(r.silent_eligible(23.999));self.assertTrue(r.silent_eligible(24))
 def test_10_hedging_capacity(self):
  x=pd.read_csv(O/'presale_best_policies.csv');self.assertTrue((x.quantity<=x.capacity).all());self.assertEqual(self.m['P15']['material_cap'],80)
 def test_11_risk_monotonic(self):
  x=pd.read_csv(O/'presale_overbooking_grid.csv');self.assertTrue((x.worst_scenario_failure.diff().dropna()>=-1e-9).all())
 def test_12_risk_selection(self):
  x=pd.read_csv(O/'presale_overbooking_grid.csv');q=self.m['P15']['max_total_under_each_scenario_5pct']
  if q is not None:self.assertLessEqual(float(x[x.total_active_commitments==q].worst_scenario_failure.iloc[0]),.05+1e-9)
 def test_13_return_maturity(self):
  x=pd.read_csv(D/'return_order_cohorts.csv');self.assertTrue((x.label_known_day==x.ship_day+30).all());self.assertLessEqual(x[x.ship_day<=99].label_known_day.max(),129)
 def test_14_probability_limits(self):
  for name,col in [('return_test_predictions.csv','p_return'),('cod_test_scoring.csv','p_refuse')]:
   x=pd.read_csv(O/name);self.assertTrue(x[col].between(0,1).all())
 def test_15_return_mass_conservation(self):
  x=pd.read_csv(O/'return_gamma_by_category.csv');y=pd.read_csv(O/'return_expected_restock_new100.csv');self.assertAlmostEqual(x.expected_good_new100.sum(),y.expected_restock.sum(),places=6);self.assertLessEqual(y.expected_restock.sum(),100)
 def test_16_atp_excludes_forecast(self):
  x=self.m['R01_R04']['atp_and_purchase'];self.assertEqual(x['strict_atp_for_additional_promises'],40+20-35);self.assertGreater(x['forecast_virtual_inbound'],0);self.assertEqual(x['accepted_in_offline_example'],25)
 def test_17_procurement_is_suggestion(self):
  x=self.m['R01_R04']['atp_and_purchase'];self.assertEqual(x['suggested_procurement_without_returns'],50);self.assertLessEqual(x['suggested_procurement_with_expected_returns'],50)
 def test_18_actual_stock_conserves_units(self):
  x=pd.read_csv(O/'return_physical_ledger.csv');self.assertTrue((x.closing==x.opening+x.actual_qc_passed_and_shelved+x.actual_po_received-x.actual_shipped).all());self.assertTrue((x.closing>=0).all());self.assertEqual(x.closing.iloc[-1],35)
 def test_19_future_history_rejected(self):
  with self.assertRaises(ValueError):r.score_cod(None,{c:1 for c in r.COD_COLS},10,11)
 def test_20_missing_feature_rejected(self):
  with self.assertRaises(ValueError):r.score_cod(None,{},10,9)
 def test_21_timeout_does_not_release(self):
  for s in ['HOLD','REVIEWING','REVIEW_QUEUED']:self.assertEqual(r.transition(s,'timeout'),'EXPIRED_REVIEW')
 def test_22_reviewer_required(self):
  with self.assertRaises(ValueError):r.transition('CONFIRMED','reviewer_approved')
 def test_23_denial_not_cancel_execution(self):self.assertEqual(r.transition('REVIEWING','customer_denied'),'CANCEL_RECOMMENDATION')
 def test_24_invalid_repeat_release(self):
  with self.assertRaises(ValueError):r.transition('RELEASED','reviewer_approved','R')
 def test_25_review_capacity(self):
  x=pd.read_csv(O/'cod_test_scoring.csv');self.assertLessEqual(x.groupby('day').selected.sum().max(),3);self.assertTrue((~x.selected|x.flag).all())
 def test_26_lead_variance_handcalculation(self):
  self.assertEqual(4*2**2+10**2*1**2,116);self.assertAlmostEqual(self.m['L02']['baseline_SS'],1.65*math.sqrt(116))
 def test_27_lead_variance_sensitivity(self):
  x=pd.read_csv(O/'lead_variance_sensitivity.csv');a=x[(x.mean_daily_demand==10)&(x.sd_lead_days==1)].iloc[0];b=x[(x.mean_daily_demand==20)&(x.sd_lead_days==1)].iloc[0];self.assertEqual(b.lead_variance_part,4*a.lead_variance_part)
 def test_28_po_event_conservation(self):
  x=pd.read_csv(D/'po_receipt_events.csv');self.assertTrue((x.groupby('id').qty.sum()==100).all())
 def test_29_po_censored_present(self):
  x=pd.read_csv(D/'po_next_receipt_person_days.csv');self.assertGreater(x.censored_episode.sum(),0);self.assertEqual(x[x.censored_episode==1].y.sum(),0);self.assertLessEqual(x.interval_end.max(),270)
 def test_30_po_quantiles_ordered(self):
  x=pd.read_csv(O/'po_quantile_test.csv');self.assertTrue((x.p90_remaining>=x.p50_remaining).all());self.assertTrue((x.p50_remaining>=0).all())
 def test_31_pending_preserves_partial(self):
  x=pd.read_csv(O/'po_pending_snapshot360_predictions.csv');self.assertTrue((x.received_qty+x.outstanding_qty==100).all());self.assertTrue((x.outstanding_qty>0).all());self.assertGreater((x.received_qty>0).sum(),0)
 def test_32_no_unsupported_quantiles(self):
  x=pd.read_csv(O/'po_pending_snapshot360_predictions.csv');self.assertTrue(x[~x.full_quantile_in_age_support].p50_remaining_full.isna().all())
 def test_33_otd_denominator(self):
  x=pd.read_csv(O/'po_otd_asof360.csv');known=x[x.status!='unresolved_not_due'];self.assertEqual(len(known),self.m['L03']['OTD_eligible_denominator']);self.assertEqual(int((known.status=='on_time').sum()),self.m['L03']['OTD_numerator'])
 def test_34_pending_never_marked_on_time(self):
  x=pd.read_csv(O/'po_otd_asof360.csv');self.assertTrue((x[x.status=='on_time'].received_qty==100).all())
 def test_35_quantile_training_not_test(self):
  x=pd.read_csv(D/'po_training_snapshots.csv');a=set(x[x.release_day<=179].id);b=set(x[x.release_day.between(340,359)].id);self.assertFalse(a&b)
 def test_36_input_hashes(self):
  import hashlib
  for p,h in json.loads((O/'input_sha256.json').read_text()).items():self.assertEqual(hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),h)
 def test_37_service_best_not_cost_only(self):
  x=pd.read_csv(O/'presale_service_constrained_best.csv');self.assertTrue((x.worst_shortfall_probability<=.05).all());self.assertTrue((x.quantity<=x.capacity).all())
 def test_38_overbooking_has_supply(self):
  m=self.m['P15'];self.assertLessEqual(m['committed_supply_needed_for_max_total'],m['material_cap']);x=pd.read_csv(O/'presale_overbooking_grid.csv');self.assertTrue(x[x.feasible_each_scenario].minimum_committed_supply_for_5pct.notna().all())
 def test_39_next_receipt_support(self):
  x=pd.read_csv(O/'po_pending_snapshot360_predictions.csv');max_elapsed=self.m['L03']['next_receipt_max_elapsed_support'];self.assertTrue((x.last_receipt_elapsed+x.next_receipt_supported_horizon<=max_elapsed).all());self.assertTrue(x[x.next_receipt_supported_horizon<7].p_next_within7.isna().all())
 def test_40_next_receipt_season_covered(self):
  x=pd.read_csv(D/'po_next_receipt_person_days.csv');self.assertEqual(set(x.season),{0,1})
 def test_41_low_fabric_infeasible_no_crash(self):
  import tempfile,copy
  old_o=r.O;old_met=copy.deepcopy(r.MET)
  try:
   with tempfile.TemporaryDirectory() as td:
    r.O=Path(td);h=pd.read_csv(O/'hazard_example_curve.csv').hazard.to_numpy();r.planning(h,fabric_meters=140)
    m=r.MET['P15'];self.assertEqual(m['material_cap'],70);self.assertIsNone(m['max_total_under_each_scenario_5pct']);self.assertIsNone(m['committed_supply_needed_for_max_total']);self.assertEqual(m['service_status'],'infeasible_for_current_active_orders')
    x=pd.read_csv(r.O/'presale_overbooking_grid.csv');self.assertFalse(x.feasible_each_scenario.any());self.assertTrue(x.minimum_committed_supply_for_5pct.isna().all())
  finally:r.O=old_o;r.MET=old_met
 def test_42_zero_fabric_no_late_capacity_escape(self):
  import tempfile,copy
  old_o=r.O;old_met=copy.deepcopy(r.MET)
  try:
   with tempfile.TemporaryDirectory() as td:
    r.O=Path(td);h=pd.read_csv(O/'hazard_example_curve.csv').hazard.to_numpy();r.planning(h,fabric_meters=0)
    m=r.MET['P15'];self.assertIsNone(m['max_total_under_each_scenario_5pct']);x=pd.read_csv(r.O/'presale_hedge_cost_grid.csv');self.assertTrue((x.quantity==0).all());self.assertTrue((x.capacity==0).all())
  finally:r.O=old_o;r.MET=old_met
 def test_43_cod_old_timeline_rejected(self):
  d=pd.read_csv(D/'cod_orders.csv')
  with self.assertRaisesRegex(ValueError,'timeline leak'):
   r.validate_cod_timeline([('calibration',d[d.day.between(120,139)]),('threshold_selection',d[d.day.between(140,159)])])
 def test_44_cod_frozen_before_next_block(self):
  x=pd.read_csv(O/'cod_fit_timeline.csv')
  for i in range(len(x)-1):self.assertLess(x.iloc[i].all_labels_mature_day,x.iloc[i+1].first_score_day)
  self.assertEqual(list(x.first_score_day),[0,120,160,200])
 def test_45_po_unseen_season_rejected(self):
  x=pd.read_csv(D/'po_training_snapshots.csv');train=x[(x.release_day<=179)&(x.label_known_at<=239)]
  self.assertEqual(set(train.season),{0,1});zero=train[train.season==0];row=zero.iloc[0].copy();row['season']=1
  self.assertIn('season_unseen',r.po_full_support(row,zero))
 def test_46_po_unsupported_predictions_blank(self):
  x=pd.read_csv(O/'po_pending_snapshot360_predictions.csv');u=x[~x.full_quantile_in_feature_support]
  self.assertTrue(u.p50_remaining_full.isna().all());self.assertTrue(u.p90_remaining_full.isna().all());self.assertTrue((u.full_quantile_support_reason!='supported').all())
 def test_47_po_strict_fit_time_contract(self):
  m=self.m['L03'];self.assertLess(m['time_contract']['train_labels_asof'],m['time_contract']['validation_release'][0]);self.assertLess(m['time_contract']['validation_labels_asof'],m['time_contract']['test_release'][0]);self.assertLess(m['time_contract']['model_frozen_by'],360)
 def test_48_cod_nan_time_rejected(self):
  f={c:1 for c in r.COD_COLS}
  for st,ht in [(float('nan'),0),(1,float('nan')),(float('inf'),0)]:
   with self.assertRaisesRegex(ValueError,'non-finite'):r.score_cod(None,f,st,ht)
 def test_49_cod_calibrated_serving_matches_batch(self):
  d=pd.read_csv(D/'cod_orders.csv');tr=d[d.day<=99];te=d[d.day.between(200,239)];m=r.linear().fit(tr[r.COD_COLS].to_numpy(),tr.refused);q=te.iloc[0]
  p=r.score_cod(m,q.to_dict(),q.day,q.history_known_at,self.m['D01_D02']['calibration_logit_offset']);batch=pd.read_csv(O/'cod_test_scoring.csv').iloc[0].p_refuse
  self.assertAlmostEqual(p,batch,places=8)
 def test_50_cod_future_maturity_rejected(self):
  d=pd.read_csv(D/'cod_orders.csv').head(5).copy();d.loc[0,'label_known_at']=999
  with self.assertRaisesRegex(ValueError,'maturity'):r.validate_cod_inputs(d)
 def test_51_po_future_history_rejected(self):
  d=pd.read_csv(D/'po_release_features.csv').head(5).copy();d.loc[0,'history_known_at']=999
  with self.assertRaisesRegex(ValueError,'PO history'):r.validate_po_history(d)
 def test_52_next_receipt_stage_specific_support(self):
  x=pd.read_csv(O/'po_pending_snapshot360_predictions.csv');ep=pd.read_csv(D/'po_next_receipt_person_days.csv');mx=ep.groupby('stage').elapsed.max().to_dict()
  for q in x.itertuples():
   self.assertLessEqual(q.last_receipt_elapsed+q.next_receipt_supported_horizon,mx[q.next_receipt_stage]);self.assertEqual(q.next_receipt_stage_elapsed_max,mx[q.next_receipt_stage])
   for c in ['p50_days_to_next_receipt','p90_days_to_next_receipt']:
    v=getattr(q,c)
    if not pd.isna(v):self.assertLessEqual(v,q.next_receipt_supported_horizon)
 def test_53_group_calibration_reconciles(self):
  x=pd.read_csv(O/'po_quantile_group_calibration.csv')
  for quantile,key in [(.5,'test_p50_coverage'),(.9,'test_p90_coverage')]:
   for grouping in ['supplier','age']:
    g=x[(x.scope=='all_raw_test')&(x.grouping==grouping)&(x['quantile']==quantile)]
    self.assertEqual(int(g.snapshot_rows.sum()),self.m['L03']['split_snapshot_rows'][2]);self.assertAlmostEqual(float((g.coverage*g.snapshot_rows).sum()/g.snapshot_rows.sum()),self.m['L03'][key],places=8)
  self.assertTrue((x.unique_PO<=x.snapshot_rows).all())
if __name__=='__main__':unittest.main()
