"""Load CSV inputs without modifying them. --self-test runs perturbation/error tests.
Outputs describe the supplied inputs; reference checks are separate self-tests.
"""
import csv,json,argparse,hashlib,tempfile,shutil
from pathlib import Path
from math import ceil,isclose
P=Path(__file__).parent

def rows(root,name):
 with (root/f'{name}-input.csv').open(newline='') as f:return list(csv.DictReader(f))
def num(r,k):
 x=float(r[k])
 if not __import__('math').isfinite(x):raise ValueError(f'{k}: finite value required')
 return x
def nonneg(x,name):
 if x<0:raise ValueError(f'{name}: negative value')
 return x
def boolean(x):
 if x not in ['True','False']:raise ValueError('boolean must be True or False')
 return x=='True'
def solve(root):
 R={}
 a=rows(root,'F1');current=[r for r in a if num(r,'day')==0]
 if not current:raise ValueError('F1 needs current rows')
 for r in a:
  nonneg(num(r,'sales_kg'),'sales_kg');boolean(r['in_stock']);boolean(r['regular_price'])
 expected={'1','2','3','4'}
 if {r['slot'] for r in current}!=expected or len(current)!=4:raise ValueError('F1 incomplete current slots')
 # Exclude the entire historical day, not just its stockout/discounted row:
 # otherwise the denominator is itself censored and creates a distorted profile.
 history=[];excluded=[]
 for day in sorted({r['day'] for r in a if num(r,'day')<0}):
  group=[r for r in a if r['day']==day]
  if len(group)==4 and {r['slot'] for r in group}==expected and all(boolean(r['in_stock']) and boolean(r['regular_price']) for r in group):history.extend(group)
  else:excluded.append(day)
 if not history:raise ValueError('F1 no complete in-stock regular-price historical days')
 slots={r['slot'] for r in current if boolean(r['in_stock']) and boolean(r['regular_price'])}
 if not slots:raise ValueError('F1 no usable observed slots: demand not identifiable')
 if any(not boolean(r['regular_price']) for r in current):raise ValueError('F1 current discount regime: baseline extrapolation not supported')
 total=sum(num(r,'sales_kg') for r in history)
 if total<=0:raise ValueError('F1 historical total must be positive')
 p=sum(num(r,'sales_kg') for r in history if r['slot'] in slots)/total
 if p<=0:raise ValueError('F1 observed share must be positive')
 observed=sum(num(r,'sales_kg') for r in current if r['slot'] in slots)
 R['F1']={'p':p,'estimated_demand':observed/p,'excluded_historical_days':excluded,'historical_rows_used':len(history)}
 a=rows(root,'F2');prob=[nonneg(num(r,'probability'),'probability') for r in a]
 if not isclose(sum(prob),1,abs_tol=1e-9):raise ValueError('F2 probabilities must sum to 1')
 demand=[nonneg(num(r,'demand_boxes'),'demand') for r in a]
 R['F2']={str(v):{str(q):sum(pr*(10*min(d,q)+v*max(q-d,0)-6*q) for d,pr in zip(demand,prob)) for q in sorted(set(demand))} for v in [2,5]}
 a=rows(root,'F3')
 def replay(demands,expire_override=None):
  stock=[nonneg(num(r,'stock_boxes'),'stock') for r in a];expiry=expire_override or [num(r,'expiry_day') for r in a];ledger=[]
  for day,d in enumerate(demands):
   opening=sum(stock);waste=0
   for i,e in enumerate(expiry):
    if e<day:waste+=stock[i];stock[i]=0
   sold=0
   for i in sorted(range(len(a)),key=lambda i:expiry[i]):
    x=min(d-sold,stock[i]);stock[i]-=x;sold+=x
   for i,e in enumerate(expiry):
    if e==day:waste+=stock[i];stock[i]=0
   if not isclose(opening,sold+waste+sum(stock)):raise AssertionError('stock conservation')
   ledger.append(dict(day=day,sales=sold,lost=d-sold,waste=waste,ending=sum(stock)))
  return ledger
 R['F3']={'normal':replay([8,7]),'stress':replay([2,12])}
 a=rows(root,'F4')
 for r in a:
  for k in ['demand_kg','yield_kg_per_batch','buy_cost_per_kg']:nonneg(num(r,k),k)
 costs=[50*n+sum(num(r,'buy_cost_per_kg')*max(num(r,'demand_kg')-num(r,'yield_kg_per_batch')*n,0) for r in a) for n in range(11)]
 R['F4']={'costs':costs,'optimal_batches':costs.index(min(costs)),'optimal_cost':min(costs)}
 a=rows(root,'F5');exposure={}
 for batch in sorted({r['batch'] for r in a}):
  group=[r for r in a if r['batch']==batch]
  if len(group)!=3 or {num(r,'hour') for r in group}!={1,2,3}:
   exposure[batch]={'exposure':None,'data_incomplete':True,'risk_flag':None,'review_required':True};continue
  e=0
  try:
   for r in group:
    dt=num(r,'duration_h')
    if dt<=0:raise ValueError('duration must be positive')
    e+=max(num(r,'temperature_c')-4,0)*dt
  except (ValueError,KeyError):
   exposure[batch]={'exposure':None,'data_incomplete':True,'risk_flag':None,'review_required':True};continue
  exposure[batch]={'exposure':e,'data_incomplete':False,'risk_flag':e>=4,'review_required':e>=4}
 R['F5']=exposure
 a=rows(root,'A1');scores=[]
 for r in a:
  matches=[num(r,k) for k in ['category_match','fabric_match','fit_match']]
  if any(v not in [0,1] for v in matches):raise ValueError('A1 match must be binary')
  scores.append(sum(w*v for w,v in zip([3,2,1],matches)));nonneg(num(r,'orders'),'orders')
 if sum(scores)<=0:raise ValueError('A1 no matched history')
 R['A1']=sum(s*num(r,'orders') for s,r in zip(scores,a))/sum(scores)
 r=rows(root,'A2')[0];al=num(r,'alpha');be=num(r,'beta');n=num(r,'visitors');k=num(r,'orders')
 if al<=0 or be<=0 or n<0 or k<0 or k>n:raise ValueError('A2 invalid prior or order counts')
 for key in ['next_visitors','stock']:nonneg(num(r,key),key)
 al+=k;be+=n-k;expected=num(r,'next_visitors')*al/(al+be)
 R['A2']={'alpha':al,'beta':be,'expected':expected,'reorder':max(ceil(expected)-num(r,'stock'),0)}
 a=rows(root,'A3');good=[r for r in a if boolean(r['all_in_stock'])]
 for r in a:
  for k in ['S','M','L']:nonneg(num(r,k),k)
 counts=[sum(num(r,k) for r in good) for k in ['S','M','L']]
 if sum(counts)<=0:raise ValueError('A3 no complete stock window')
 def sizes(q):
  raw=[q*x/sum(counts) for x in counts];out=[int(x) for x in raw]
  for i in sorted(range(3),key=lambda i:(-(raw[i]-out[i]),i))[:q-sum(out)]:out[i]+=1
  return out
 R['A3']={'100':sizes(100),'7':sizes(7)}
 a=rows(root,'A4');gross=0;pieces=0
 for r in a:
  u=num(r,'utilization')
  if not 0<u<=1:raise ValueError('A4 utilization must be in (0,1]')
  n=nonneg(num(r,'demand'),'demand');b=nonneg(num(r,'net_m_per_piece'),'net consumption');gross+=n*b/u;pieces+=n
 rolls=max(2,ceil((gross-100)/20)) if gross>100 else 0
 R['A4']={'gross':gross,'rolls':rolls,'left':100+20*rolls-gross,'capacity_feasible':pieces<=80}
 a=rows(root,'A5');survival=1;ss=[];hs=[]
 for r in a:
  n=num(r,'at_risk');k=num(r,'cancelled')
  if n<=0 or k<0 or k>n:raise ValueError('A5 invalid risk set')
  h=k/n;hs.append(h);survival*=1-h;ss.append(survival)
 if len(ss)!=2 or ss[0]<=0:raise ValueError('A5 requires two intervals and positive S10')
 current=num(rows(root,'A5-current')[0],'current_orders');nonneg(current,'current_orders')
 conditional=ss[1]/ss[0];R['A5']={'hazards':hs,'S10':ss[0],'S20':ss[1],'conditional':conditional,'current_orders':current,'retained':current*conditional}
 return R

def digest(root):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*-input.csv')}
def change(root,case,col,value,row=0):
 path=root/f'{case}-input.csv'
 with path.open(newline='') as f:reader=csv.DictReader(f);fields=reader.fieldnames;data=list(reader)
 data[row][col]=value
 with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
def selftest():
 base=solve(P)
 assert isclose(base['F1']['estimated_demand'],50)
 assert base['F2']['2']['30.0']==104 and base['F2']['5']['40.0']==115
 assert base['F3']['normal'][-1]['ending']==3 and base['F3']['stress'][0]['waste']==3
 assert base['F4']['optimal_cost']==390 and base['F4']['optimal_batches']==7
 assert base['F5']['A']['exposure']==6 and base['F5']['A']['risk_flag'] and base['F5']['B']['exposure']==1 and not base['F5']['B']['risk_flag']
 assert isclose(base['A1'],72.85714285714286)
 assert base['A2']['reorder']==27 and base['A3']['100']==[30,47,23]
 assert base['A4']['rolls']==2 and isclose(base['A5']['retained'],60)
 tests=[('F1','in_stock','False',lambda r:r['F1']['historical_rows_used']==8 and '-3' in r['F1']['excluded_historical_days']),('F1','regular_price','False',lambda r:r['F1']['historical_rows_used']==8),('A5-current','current_orders','50',lambda r:isclose(r['A5']['retained'],37.5) and isclose(r['A5']['hazards'][1],.25)),('A2','orders','30',lambda r:r['A2']['reorder']==44),('F5','duration_h','0.5',lambda r:r['F5']['A']['exposure']==4 and r['F5']['A']['risk_flag'],2),('A4','demand','100',lambda r:not r['A4']['capacity_feasible']),('F2','probability','0.4',None),('A2','orders','101',None),('A4','utilization','0',None),('A1','category_match','2',None)]
 report=[]
 for case,col,value,check,*row in tests:
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)
   for f in P.glob('*-input.csv'):shutil.copy2(f,target/f.name)
   change(target,case,col,value,row[0] if row else 0)
   try:r=solve(target)
   except ValueError as e:
    if check is not None:raise
    report.append({'test':f'{case}:{col}={value}','status':'PASS rejected','reason':str(e)})
   else:
    if check is None:raise AssertionError('invalid input was accepted')
    assert check(r);report.append({'test':f'{case}:{col}={value}','status':'PASS changed result'})
 with tempfile.TemporaryDirectory() as t:
  target=Path(t)
  for f in P.glob('*-input.csv'):shutil.copy2(f,target/f.name)
  path=target/'F5-input.csv'
  with path.open() as f:rr=list(csv.DictReader(f))
  rr=[r for r in rr if not(r['batch']=='A' and r['hour']=='3')]
  with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
  result=solve(target)['F5']['A']
  assert result['data_incomplete'] and result['risk_flag'] is None and result['review_required']
  report.append({'test':'F5 delete batch A hour 3','status':'PASS missing-data review, no safe flag'})
 return report
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--input-dir',type=Path,default=P);parser.add_argument('--output',type=Path,default=P/'verified-answers.json');parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
 before=digest(args.input_dir);result=solve(args.input_dir)
 tests=selftest() if args.self_test else []
 assert before==digest(args.input_dir),'inputs modified'
 args.output.write_text(json.dumps({'results':result,'tests':tests,'input_sha256':before,'inputs_unchanged':True},ensure_ascii=False,indent=2))
 print(f'PASS: loaded 11 CSV inputs; {len(tests)} mutation/error tests; inputs unchanged; output={args.output}')
