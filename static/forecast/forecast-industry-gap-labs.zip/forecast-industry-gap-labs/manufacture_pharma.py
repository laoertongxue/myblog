#!/usr/bin/env python3
"""SIMULATED TEACHING ONLY. Python standard library, no downloads.

Public API: generate_inputs(data_dir), run(data_dir, output_dir), build(outdir),
self_test(). CLI: build DIR | run DATA_DIR OUTPUT_DIR | self-test.
Never writes to data_dir in run(). Units and information cutoffs are in CSV.
"""
from __future__ import annotations
import argparse
import copy
import csv
import json
import math
from pathlib import Path
import statistics
import tempfile

DATA_KIND = 'SIMULATED_TEACHING_ONLY'
LESSONS = [
    {'slug':'industry-mps-count-vmi','source_ids':['B05'],
     'source_scope':'第二部分 L65–67：13–52周 MPS、网点备件月、VMI、泊松/负二项'},
    {'slug':'industry-installed-base-bathtub','source_ids':['C17'],
     'source_scope':'§3.5 L125：Installed Base 与浴盆失效率先验'},
    {'slug':'industry-aggregate-repurchase-leading-ols','source_ids':['C19'],
     'source_scope':'第二部分 L69：流感/气象先行指标与慢病复购周期'},
]

def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError('Cannot infer columns from an empty table')
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def read_csv(path):
    with Path(path).open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError('Empty input: ' + str(path))
    return rows


def num(value):
    x = float(value)
    if not math.isfinite(x):
        raise ValueError('Expected a finite number')
    return x


def integer(value):
    x = num(value)
    if x != int(x):
        raise ValueError('Expected an integer, got ' + str(value))
    return int(x)


def nonnegative(value):
    x = num(value)
    if x < 0:
        raise ValueError('Negative quantity')
    return x


def params(rows):
    if len(rows) != 1:
        raise ValueError('Expected one parameter row')
    return rows[0]


def mps_plan(demands, previous, opening, safety, capacity, lot, freeze):
    """Signed net = physical on-hand minus backlog. No optimization claim."""
    if not demands or len(demands) != len(previous):
        raise ValueError('MPS requires equal nonempty vectors')
    if min(opening, safety, capacity, lot, freeze) < 0 or lot == 0:
        raise ValueError('Invalid MPS parameters')
    if capacity % lot or freeze != int(freeze) or freeze > len(demands):
        raise ValueError('Capacity must be a multiple of lot; freeze must fit')
    net = opening
    rows = []
    for week, (demand, old) in enumerate(zip(demands, previous), 1):
        if demand < 0 or old < 0 or old > capacity or old % lot:
            raise ValueError('Invalid demand or previously approved receipt')
        start = net
        need = max(0, demand + safety - start)
        proposed = min(capacity, math.ceil(need / lot) * lot)
        receipt = old if week <= freeze else proposed
        net = start + receipt - demand
        rows.append(dict(period_week=week, demand_units=demand,
            previous_receipt_units=old, frozen=int(week <= freeze),
            unconstrained_by_freeze_receipt_units=proposed,
            planned_receipt_units=receipt, capacity_units=capacity,
            opening_net_units=start, closing_net_units=net,
            closing_on_hand_units=max(0, net), closing_backlog_units=max(0, -net),
            freeze_change_request=int(week <= freeze and proposed != old),
            status='REVIEW_FROZEN_SHORTAGE' if week <= freeze and net < 0 else
                ('CAPACITY_SHORTAGE' if net < 0 else 'PLANNED'),
            units='finished_goods_units', data_kind=DATA_KIND))
    return rows


def log_poisson(k, mu):
    if k < 0 or k != int(k) or mu < 0:
        raise ValueError('Poisson requires nonnegative integer counts and mean')
    if mu == 0:
        return 0.0 if k == 0 else -math.inf
    return k * math.log(mu) - mu - math.lgamma(k + 1)


def fit_count(values):
    if len(values) < 2 or any(x < 0 or x != int(x) for x in values):
        raise ValueError('At least two nonnegative integer counts required')
    mu = statistics.mean(values)
    variance = statistics.variance(values)  # denominator n-1
    r = mu * mu / (variance - mu) if variance > mu and mu > 0 else None
    return mu, variance, r


def log_nb(k, mu, r):
    """NB2: mean mu; variance mu + mu**2/r. r=None means Poisson fallback."""
    if r is None or mu == 0:
        return log_poisson(k, mu)
    if k < 0 or k != int(k) or mu < 0 or r <= 0:
        raise ValueError('Invalid negative-binomial parameter')
    p = r / (r + mu)
    return (math.lgamma(k + r) - math.lgamma(r) - math.lgamma(k + 1)
            + r * math.log(p) + k * math.log1p(-p))


def count_comparison(rows, train_end, as_of):
    result = []
    for branch in sorted({r['branch'] for r in rows}):
        part = sorted([r for r in rows if r['branch'] == branch],
                      key=lambda r: integer(r['period_month']))
        months = [integer(r['period_month']) for r in part]
        if len(set(months)) != len(months):
            raise ValueError('Duplicate branch-month')
        train = [integer(r['count_units']) for r in part
                 if integer(r['period_month']) <= train_end
                 and integer(r['known_at_month']) <= as_of]
        test = [integer(r['count_units']) for r in part
                if integer(r['period_month']) > train_end]
        if not test:
            raise ValueError('No held-out count observations')
        mu, variance, r = fit_count(train)
        for model in ['Poisson', 'NegativeBinomial_MoM']:
            effective = r if model.startswith('Negative') else None
            lp = [log_nb(k, mu, effective) for k in test]
            # Inf is honest for an all-zero training series followed by positive count.
            nll = -sum(lp) / len(lp)
            result.append(dict(branch=branch, model=model,
                effective_model='Poisson' if effective is None else 'NegativeBinomial',
                train_n=len(train), test_n=len(test), train_end_month=train_end,
                forecast_as_of_month=as_of, mean_count=mu, sample_variance=variance,
                dispersion_r='' if effective is None else effective,
                probability_zero=math.exp(log_nb(0, mu, effective)),
                probability_at_least_6=max(0.0, 1-sum(math.exp(log_nb(k, mu, effective)) for k in range(6))),
                test_mean_nll='infinity' if math.isinf(nll) else nll,
                empirical_test_zero_fraction=test.count(0)/len(test),
                units='parts_per_branch_month', data_kind=DATA_KIND))
    return result


def vmi_ledger(events, opening, unit_value):
    """A teaching responsibility ledger, NOT legal/accounting certification.
    Supplier retains title in transit/on-site until the transfer+use pair.
    All prices/costs equal unit_value, no tax, margin, discount or impairment.
    """
    if opening < 0 or unit_value <= 0:
        raise ValueError('Invalid VMI opening inventory/value')
    s = dict(remote=opening, transit=0, supplier_site=0, factory_site=0,
             consumed=0, scrapped=0, payable=0.0, receivable=0.0,
             supplier_scrap_expense=0.0, factory_use_expense=0.0,
             cumulative_title_transfer=0, paid=0.0)
    output = []
    pending_use = 0
    pending_day = None
    last_day = -1
    def move(src, dst, q):
        if q <= 0 or q != int(q) or s[src] < q:
            raise ValueError('Invalid VMI movement / insufficient ' + src)
        s[src] -= q
        s[dst] += q
    for seq, e in enumerate(events, 1):
        day, known = integer(e['period_day']), integer(e['known_at_day'])
        if day < last_day or known > day:
            raise ValueError('Events must be ordered and known by posting day')
        last_day = day
        kind, q, amount = e['event'], integer(e['qty_units']), nonnegative(e['amount'])
        if pending_use and kind != 'USE':
            raise ValueError('Consumption-triggered title transfer must be followed by matching USE')
        if kind == 'SHIP':
            move('remote', 'transit', q)
        elif kind == 'RECEIVE':
            move('transit', 'supplier_site', q)
        elif kind == 'TITLE_TRANSFER':
            move('supplier_site', 'factory_site', q)
            pending_use = q
            pending_day = day
            s['cumulative_title_transfer'] += q
            s['payable'] += q * unit_value
            s['receivable'] += q * unit_value
        elif kind == 'USE':
            if q != pending_use or day != pending_day:
                raise ValueError('USE must match pending title transfer quantity and day')
            move('factory_site', 'consumed', q)
            pending_use = 0
            s['factory_use_expense'] += q * unit_value
        elif kind == 'SUPPLIER_QUALITY_SCRAP':
            move('supplier_site', 'scrapped', q)
            s['supplier_scrap_expense'] += q * unit_value
        elif kind == 'RETURN_SHIP':
            move('supplier_site', 'transit', q)
        elif kind == 'RETURN_RECEIVE':
            move('transit', 'remote', q)
        elif kind == 'PAYMENT':
            if q or amount > s['payable'] or amount <= 0:
                raise ValueError('Invalid payment')
            s['payable'] -= amount
            s['receivable'] -= amount
            s['paid'] += amount
        else:
            raise ValueError('Unknown VMI event ' + kind)
        if kind != 'PAYMENT' and amount:
            raise ValueError('Only payment rows carry explicit amount')
        owned = s['remote'] + s['transit'] + s['supplier_site']
        physical = owned + s['factory_site']
        qty_residual = opening - physical - s['consumed'] - s['scrapped']
        value_residual = opening*unit_value - physical*unit_value - s['factory_use_expense'] - s['supplier_scrap_expense']
        if qty_residual or abs(value_residual) > 1e-8 or abs(s['payable'] - s['receivable']) > 1e-8:
            raise AssertionError('VMI conservation failed')
        output.append(dict(seq=seq, period_day=day, known_at_day=known, event=kind,
            event_qty_units=q, event_amount=amount, **s,
            supplier_owned_units=owned, supplier_owned_inventory_value=owned*unit_value,
            factory_owned_units=s['factory_site'], factory_owned_inventory_value=s['factory_site']*unit_value,
            physical_stock_units=physical, quantity_residual=qty_residual,
            value_residual=value_residual, monetary_units='CNY_teaching_value', data_kind=DATA_KIND))
    if pending_use:
        raise ValueError('Unmatched consumption-triggered title transfer')
    return output


def age_stage(age):
    if age < 0:
        raise ValueError('Negative equipment age')
    return 'early' if age < 3 else ('stable' if age < 12 else 'wear')


def installed_base(cohorts, events, priors, histories, horizon, coverage, parts):
    if not 0 <= coverage <= 1 or parts < 0 or horizon < 1:
        raise ValueError('Invalid installed-base parameters')
    cs = {r['cohort']: {'installed':integer(r['installed_month']),
                      'count':integer(r['opening_count_units'])} for r in cohorts}
    if len(cs) != len(cohorts) or any(c['count'] < 0 for c in cs.values()):
        raise ValueError('Duplicate cohort or negative count')
    ps = {}
    for r in priors:
        a, b = num(r['alpha']), num(r['beta'])
        if a <= 0 or b <= 0 or r['stage'] in ps:
            raise ValueError('Invalid / duplicate Beta prior')
        ps[r['stage']] = (a, b)
    if set(ps) != {'early','stable','wear'}:
        raise ValueError('All three prior stages required')
    movements = {}
    for r in events:
        name, m = r['cohort'], integer(r['period_month'])
        if name not in cs or not 1 <= m <= horizon or integer(r['known_at_month']) > m:
            raise ValueError('Unknown cohort, invalid period, or future movement')
        q = integer(r['qty_units'])
        if q < 0 or r['event'] not in ('ENTER','EXIT'):
            raise ValueError('Invalid movement')
        movements.setdefault((name,m), []).append((r['event'],q))
    detail, summary = [], []
    for month in range(1,horizon+1):
        prior_demand = posterior_demand = 0.0
        starts = ins = outs = closes = 0
        for name, c in cs.items():
            start = c['count']
            entry = sum(q for k,q in movements.get((name,month),[]) if k == 'ENTER')
            exit_ = sum(q for k,q in movements.get((name,month),[]) if k == 'EXIT')
            if entry and c['installed'] != month:
                raise ValueError('New entries need a cohort installed in that month')
            close = start + entry - exit_
            if close < 0:
                raise ValueError('Retirements exceed registered active equipment')
            c['count'] = close
            if month < c['installed']:
                if close:
                    raise ValueError('Equipment exists before installation')
                continue
            age, stage = month-c['installed'], age_stage(month-c['installed'])
            a,b = ps[stage]
            hist = [r for r in histories if r['stage']==stage and integer(r['known_at_month'])<=month]
            exposure = sum(nonnegative(r['exposure_units']) for r in hist)
            failures = sum(nonnegative(r['failures_units']) for r in hist)
            if failures > exposure:
                raise ValueError('Historical failures exceed exposure under one-failure Bernoulli assumption')
            h0, h1 = a/(a+b), (a+failures)/(a+b+exposure)
            d0, d1 = close*h0*coverage*parts, close*h1*coverage*parts
            detail.append(dict(period_month=month, cohort=name, installed_month=c['installed'],
                age_months=age, stage=stage, opening_units=start, entered_units=entry,
                exited_units=exit_, at_risk_units=close, prior_failure_probability=h0,
                posterior_failure_probability=h1, covered_fraction=coverage,
                parts_per_failure=parts, expected_parts_prior=d0, expected_parts_posterior=d1,
                history_exposure_units=exposure, history_failures_units=failures,
                data_kind=DATA_KIND))
            starts+=start;ins+=entry;outs+=exit_;closes+=close
            prior_demand+=d0;posterior_demand+=d1
        summary.append(dict(period_month=month, opening_units=starts, entered_units=ins,
            exited_units=outs, at_risk_units=closes, expected_parts_prior=prior_demand,
            expected_parts_posterior=posterior_demand, data_kind=DATA_KIND))
    return detail,summary


def distribution(hist):
    counts = {}
    for r in hist:
        day, count = integer(r['interval_days']), integer(r['count_intervals'])
        if day <= 0 or count <= 0 or day in counts:
            raise ValueError('Intervals must be distinct positive days/counts')
        counts[day] = count
    total = sum(counts.values())
    return [(d,c/total) for d,c in sorted(counts.items())]


def shortest_window(dist, mass=0.8):
    if not 0 < mass <= 1 or not dist:
        raise ValueError('Invalid interval mass/distribution')
    if abs(sum(p for _,p in dist)-1) > 1e-8 or any(p<=0 for _,p in dist):
        raise ValueError('Distribution must have positive probabilities summing to one')
    choices = []
    for i in range(len(dist)):
        cumulative = 0
        for j in range(i,len(dist)):
            cumulative += dist[j][1]
            if cumulative+1e-12 >= mass:
                choices.append((dist[j][0]-dist[i][0],dist[i][0],dist[j][0],cumulative))
                break
    width,lo,hi,p = min(choices)  # width, then earliest start, then end
    return lo,hi,p


def repurchase(hist, cohorts, cutoff, days, mass):
    dist = distribution(hist)
    lo,hi,p = shortest_window(dist,mass)
    rows=[]
    for c in cohorts:
        last = integer(c['last_purchase_day'])
        initial = integer(c['initial_count_units'])
        repeated = integer(c['repeat_observed_units'])
        known = integer(c['known_at_day'])
        if last>cutoff or known>cutoff or initial<0 or repeated<0 or repeated>initial:
            raise ValueError('Invalid aggregate cohort / future input')
        remaining=initial-repeated
        age=cutoff-last
        survival=sum(p for d,p in dist if d>age)
        next_mass=sum(p for d,p in dist if age<d<=age+days)
        if survival==0 and remaining:
            raise ValueError('Remaining cohort outside histogram support; revise model, do not invent zero risk')
        probability=next_mass/survival if survival else 0
        conditional=[(d,p/survival) for d,p in dist if d>age] if survival else []
        clo,chi,cp=shortest_window(conditional,mass) if conditional else ('','','')
        rows.append(dict(cohort=c['cohort'], cutoff_day=cutoff, known_at_day=known,
            last_purchase_day=last, age_days=age, initial_count_units=initial,
            repeat_observed_units=repeated, remaining_units=remaining,
            unconditional_window_start_day=last+lo, unconditional_window_end_day=last+hi,
            unconditional_window_mass=p,
            conditional_window_start_day=last+clo if conditional else '',
            conditional_window_end_day=last+chi if conditional else '',
            conditional_window_mass=cp, survival_probability=survival,
            forecast_start_day=cutoff+1, forecast_end_day=cutoff+days,
            probability_next_window=probability, expected_repeats=remaining*probability,
            units='aggregate_purchase_events', data_kind=DATA_KIND))
    return rows


def fit_ols(features, targets):
    """Actual unregularized ordinary least squares via normal equations + pivoting.
    Small, nonsingular teaching matrices only; QR/SVD preferable at production scale.
    """
    if not features or len(features)!=len(targets):
        raise ValueError('OLS needs matching nonempty rows')
    width=len(features[0])
    if len(features)<width+1 or any(len(r)!=width for r in features):
        raise ValueError('Insufficient / inconsistent OLS design')
    x=[[1.0]+[num(v) for v in r] for r in features]
    y=[num(v) for v in targets]
    p=width+1
    a=[[sum(row[i]*row[j] for row in x) for j in range(p)]
       +[sum(row[i]*target for row,target in zip(x,y))] for i in range(p)]
    for col in range(p):
        pivot=max(range(col,p),key=lambda row:abs(a[row][col]))
        a[col],a[pivot]=a[pivot],a[col]
        if abs(a[col][col])<1e-10:
            raise ValueError('Singular teaching design matrix')
        factor=a[col][col]
        a[col]=[v/factor for v in a[col]]
        for row in range(p):
            if row!=col:
                factor=a[row][col]
                a[row]=[v-factor*w for v,w in zip(a[row],a[col])]
    return [a[i][-1] for i in range(p)]


def asof_indicator(vintages, series, week, origin):
    candidates=[r for r in vintages if r['series']==series
        and integer(r['event_week'])==week and integer(r['known_at_week'])<=origin]
    if not candidates:
        return None
    latest=max(candidates,key=lambda r:(integer(r['known_at_week']),integer(r['version'])))
    return num(latest['value']),integer(latest['known_at_week']),integer(latest['version'])


def feature_row(vintages,target,lag_flu,lag_weather):
    origin=target-1
    flu=asof_indicator(vintages,'flu_proxy',target-lag_flu,origin)
    weather=asof_indicator(vintages,'weather_proxy',target-lag_weather,origin)
    return dict(target_week=target,origin_week=origin,
        flu_source_week=target-lag_flu,flu_known_at_week=flu[1] if flu else '',
        flu_version=flu[2] if flu else '',flu_value=flu[0] if flu else '',
        weather_source_week=target-lag_weather,weather_known_at_week=weather[1] if weather else '',
        weather_version=weather[2] if weather else '',weather_value=weather[0] if weather else '',
        features_available=int(flu is not None and weather is not None), data_kind=DATA_KIND)


def rolling_ols(vintages,labels,start,end,lag_flu,lag_weather,min_train):
    if start>end or lag_flu<1 or lag_weather<1 or min_train<3:
        raise ValueError('Invalid rolling specification')
    labels=sorted(labels,key=lambda r:integer(r['target_week']))
    if len({integer(r['target_week']) for r in labels})!=len(labels):
        raise ValueError('Duplicate target label')
    for r in labels:
        if integer(r['known_at_week'])<integer(r['target_week']) or num(r['actual_units'])<0:
            raise ValueError('Invalid label timing/quantity')
    feature_cache={integer(r['target_week']):feature_row(vintages,integer(r['target_week']),lag_flu,lag_weather)
                   for r in labels}
    out=[]
    for target in range(start,end+1):
        origin=target-1
        actual=[r for r in labels if integer(r['target_week'])==target]
        if len(actual)!=1:
            raise ValueError('Missing evaluation target')
        known=[r for r in labels if integer(r['target_week'])<target and integer(r['known_at_week'])<=origin]
        if len(known)<4:
            raise ValueError('Need four previously released targets for baseline')
        baseline=num(known[-1]['actual_units'])
        mean4=statistics.mean(num(r['actual_units']) for r in known[-4:])
        train=[r for r in known if feature_cache[integer(r['target_week'])]['features_available']]
        beta=[]
        if len(train)>=min_train:
            x=[[feature_cache[integer(r['target_week'])]['flu_value'],
                feature_cache[integer(r['target_week'])]['weather_value']] for r in train]
            try:
                beta=fit_ols(x,[num(r['actual_units']) for r in train])
            except ValueError:
                beta=[]
        f=feature_cache[target]
        mode='OLS' if beta and f['features_available'] else 'FALLBACK_LAST_AVAILABLE'
        raw=beta[0]+beta[1]*f['flu_value']+beta[2]*f['weather_value'] if mode=='OLS' else baseline
        out.append(dict(**f, train_n=len(train),
            train_last_target_week=max(integer(r['target_week']) for r in train) if train else '',
            train_max_label_known_at=max(integer(r['known_at_week']) for r in train) if train else '',
            baseline_source_week=integer(known[-1]['target_week']),
            baseline_known_at_week=integer(known[-1]['known_at_week']),
            intercept=beta[0] if beta else '', beta_flu=beta[1] if beta else '',
            beta_weather=beta[2] if beta else '', mode=mode,
            forecast_raw_units=raw, forecast_units=max(0,raw),
            baseline_last_available_units=baseline, baseline_mean4_units=mean4,
            actual_units=num(actual[0]['actual_units'])))
    metrics=[]
    for field,name in [('forecast_units','OLS_with_operational_fallback'),
                       ('baseline_last_available_units','Last_available_label'),
                       ('baseline_mean4_units','Last_four_available_mean')]:
        errors=[r[field]-r['actual_units'] for r in out]
        denom=sum(r['actual_units'] for r in out)
        metrics.append(dict(model=name,evaluation_n=len(out),
            mae=sum(abs(e) for e in errors)/len(errors),
            rmse=math.sqrt(sum(e*e for e in errors)/len(errors)),
            wape=sum(abs(e) for e in errors)/denom if denom else '',
            bias=sum(errors)/denom if denom else '',data_kind=DATA_KIND))
    return list(feature_cache.values()),out,metrics


def generate_inputs(data_dir):
    """Generate deterministic synthetic fixtures. Refuse to overwrite existing inputs."""
    data_dir=Path(data_dir)
    if data_dir.exists() and any(data_dir.iterdir()):
        raise FileExistsError('Input directory is not empty; preserve learner changes: '+str(data_dir))
    data_dir.mkdir(parents=True,exist_ok=True)
    def save(name,rows):
        write_csv(data_dir/name,[dict(**r,data_kind=DATA_KIND) for r in rows])
    base=[60,70,80,90]*13
    prior=mps_plan(base,[0]*52,40,20,100,10,0)
    save('mps_parameters.csv',[dict(horizon_weeks=h,opening_units=40,safety_units=20,
        capacity_units=100,lot_units=10,freeze_weeks=4,planning_as_of_week=0) for h in [13,52]])
    save('mps_demand.csv',[dict(period_week=i+1,known_at_week=0,base_demand_units=d,
        revised_demand_units=d+(100 if i==1 else 0),
        prior_receipt_units=prior[i]['planned_receipt_units']) for i,d in enumerate(base)])
    save('count_parameters.csv',[dict(train_end_month=24,forecast_as_of_month=25)])
    save('branch_month_counts.csv',[dict(branch=name,period_month=i+1,known_at_month=i+2,
        count_units=(train if i<24 else test)[i%6])
        for name,train,test in [('regular',[0,1,2,2,3,4],[0,1,2,2,3,4]),
                                ('bursty',[0,0,1,1,2,8],[0,0,0,1,3,8])]
        for i in range(36)])
    save('vmi_parameters.csv',[dict(opening_supplier_units=100,unit_value_cny=10)])
    ev=[('SHIP',40,0),('RECEIVE',40,0),('TITLE_TRANSFER',25,0),('USE',25,0),
        ('SUPPLIER_QUALITY_SCRAP',5,0),('RETURN_SHIP',10,0),('RETURN_RECEIVE',10,0),('PAYMENT',0,100)]
    save('vmi_events.csv',[dict(period_day=[1,2,3,3,4,5,6,7][i],known_at_day=[1,2,3,3,4,5,6,7][i],event=k,qty_units=q,amount=a)
         for i,(k,q,a) in enumerate(ev)])
    save('installed_base_parameters.csv',[dict(horizon_months=12,covered_fraction=.8,parts_per_failure=1)])
    save('installed_cohorts.csv',[dict(cohort=c,installed_month=m,opening_count_units=n)
        for c,m,n in [('old_stable',-4,200),('old_wear',-12,50),('entry_1',1,0),('entry_4',4,0),('entry_7',7,0)]])
    ev=[('entry_1',1,'ENTER',100),('old_wear',1,'EXIT',10),('old_stable',3,'EXIT',20),
        ('entry_4',4,'ENTER',60),('entry_1',6,'EXIT',5),('entry_7',7,'ENTER',40),('old_wear',9,'EXIT',15)]
    save('installed_movements.csv',[dict(cohort=c,period_month=m,known_at_month=m,event=e,qty_units=q) for c,m,e,q in ev])
    save('bathtub_priors.csv',[dict(stage=s,alpha=a,beta=b) for s,a,b in [('early',3,47),('stable',1,99),('wear',4,96)]])
    save('bathtub_history.csv',[dict(stage=s,exposure_units=n,failures_units=k,known_at_month=0)
        for s,n,k in [('early',50,2),('stable',100,1),('wear',25,2)]])
    save('repurchase_parameters.csv',[dict(cutoff_day=20,forecast_days=7,window_mass=.8,histogram_known_at_day=0)])
    save('repurchase_histogram.csv',[dict(interval_days=d,count_intervals=n) for d,n in [(14,10),(21,20),(28,40),(35,20),(42,10)]])
    save('repurchase_cohorts.csv',[dict(cohort=c,last_purchase_day=d,initial_count_units=n,
        repeat_observed_units=k,known_at_day=20) for c,d,n,k in [('cohort_A',0,100,10),('cohort_B',7,80,0),('cohort_C',14,60,0)]])
    save('ols_parameters.csv',[dict(eval_start_week=41,eval_end_week=80,lag_flu_weeks=2,lag_weather_weeks=3,min_train_rows=12)])
    vals={}
    vintages=[]
    for week in range(-2,81):
        flu=18+6*math.sin(2*math.pi*week/13)+.15*week+((week*7)%5-2)
        weather=15+5*math.cos(2*math.pi*week/17)+.3*((week*3)%7-3)
        vals[week]=(flu,weather)
        for series,value,delay in [('flu_proxy',flu,1+(1 if week%11==0 else 0)),
                                   ('weather_proxy',weather,1+(2 if week%13==0 else 0))]:
            vintages.append(dict(series=series,event_week=week,known_at_week=week+delay,version=1,value=value))
            vintages.append(dict(series=series,event_week=week,known_at_week=week+5,version=2,value=value+2))
    save('leading_indicator_vintages.csv',vintages)
    save('pharma_weekly_demand.csv',[dict(target_week=t,known_at_week=t+1,
        actual_units=round(40+1.2*vals[t-2][0]-.8*vals[t-3][1]+[-2,1,0,2,-1][t%5])) for t in range(1,81)])
    return str(data_dir)


def run(data_dir, output_dir):
    """Read existing CSV inputs only. Write calculations to a separate output dir."""
    data_dir,output_dir=Path(data_dir),Path(output_dir)
    if data_dir.resolve()==output_dir.resolve() or data_dir.resolve() in output_dir.resolve().parents:
        raise ValueError('Output must be outside the input directory')
    output_dir.mkdir(parents=True,exist_ok=True)
    def read(name):
        rows=read_csv(data_dir/name)
        if any(r.get('data_kind')!=DATA_KIND for r in rows):
            raise ValueError('Every fixture row must remain explicitly simulated')
        return rows
    def save(name,rows):write_csv(output_dir/name,rows)
    mps_results={}
    demand=read('mps_demand.csv')
    for p in read('mps_parameters.csv'):
        horizon=integer(p['horizon_weeks'])
        if not 13<=horizon<=52:
            raise ValueError('Teaching MPS horizon must be 13–52 weeks')
        part=sorted([r for r in demand if integer(r['period_week'])<=horizon],key=lambda r:integer(r['period_week']))
        if [integer(r['period_week']) for r in part]!=list(range(1,horizon+1)):
            raise ValueError('MPS needs one row per week')
        if any(integer(r['known_at_week'])>integer(p['planning_as_of_week']) for r in part):
            raise ValueError('MPS input not known at planning cutoff')
        rows=mps_plan([nonnegative(r['revised_demand_units']) for r in part],
            [nonnegative(r['prior_receipt_units']) for r in part],
            nonnegative(p['opening_units']),nonnegative(p['safety_units']),
            nonnegative(p['capacity_units']),nonnegative(p['lot_units']),integer(p['freeze_weeks']))
        save('mps_'+str(horizon)+'.csv',rows)
        mps_results[str(horizon)]=dict(weeks=len(rows),frozen_receipts=[r['planned_receipt_units'] for r in rows[:integer(p['freeze_weeks'])]],
            peak_backlog=max(r['closing_backlog_units'] for r in rows),
            freeze_change_requests=sum(r['freeze_change_request'] for r in rows),
            final_on_hand=rows[-1]['closing_on_hand_units'],final_backlog=rows[-1]['closing_backlog_units'])
    p=params(read('count_parameters.csv'))
    count=count_comparison(read('branch_month_counts.csv'),integer(p['train_end_month']),integer(p['forecast_as_of_month']))
    save('count_model_comparison.csv',count)
    p=params(read('vmi_parameters.csv'))
    ledger=vmi_ledger(read('vmi_events.csv'),integer(p['opening_supplier_units']),num(p['unit_value_cny']))
    save('vmi_responsibility_ledger.csv',ledger)
    p=params(read('installed_base_parameters.csv'))
    detail,installed=installed_base(read('installed_cohorts.csv'),read('installed_movements.csv'),
        read('bathtub_priors.csv'),read('bathtub_history.csv'),integer(p['horizon_months']),
        num(p['covered_fraction']),num(p['parts_per_failure']))
    save('installed_base_by_age.csv',detail);save('installed_base_monthly.csv',installed)
    p=params(read('repurchase_parameters.csv'))
    if integer(p['histogram_known_at_day'])>integer(p['cutoff_day']):
        raise ValueError('Histogram was not known at forecast cutoff')
    windows=repurchase(read('repurchase_histogram.csv'),read('repurchase_cohorts.csv'),
        integer(p['cutoff_day']),integer(p['forecast_days']),num(p['window_mass']))
    save('repurchase_windows.csv',windows)
    p=params(read('ols_parameters.csv'))
    features,predictions,metrics=rolling_ols(read('leading_indicator_vintages.csv'),read('pharma_weekly_demand.csv'),
        integer(p['eval_start_week']),integer(p['eval_end_week']),integer(p['lag_flu_weeks']),
        integer(p['lag_weather_weeks']),integer(p['min_train_rows']))
    save('ols_historical_asof_features.csv',features)
    save('ols_rolling_predictions.csv',predictions);save('ols_rolling_metrics.csv',metrics)
    result=dict(schema_version=1,data_kind=DATA_KIND,lessons=LESSONS,
        mps=mps_results,count_models=count,
        vmi_final=ledger[-1],installed_base_first_month=installed[0],installed_base_last_month=installed[-1],
        repurchase_total_expected=sum(r['expected_repeats'] for r in windows),
        ols=dict(evaluation_n=len(predictions),ols_predictions=sum(r['mode']=='OLS' for r in predictions),
            fallback_predictions=sum(r['mode']!='OLS' for r in predictions),
            first_coefficients=[predictions[0][k] for k in ['intercept','beta_flu','beta_weather']],
            last_coefficients=[predictions[-1][k] for k in ['intercept','beta_flu','beta_weather']],metrics=metrics),
        limitations=['Synthetic educational data only; no real business effect or production deployment.',
          'VMI ownership contract and equal unit valuations are stipulated, not legal/accounting advice.',
          'Repairable equipment; one failure indicator per device-month; entries/exits at month start.',
          'Repurchase is an aggregate next-purchase histogram, not patient behavior, dosing, treatment or medical guidance.',
          'OLS is correlational; lags are predeclared, not selected using evaluation weeks.'])
    (output_dir/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return result


def build(outdir):
    """Create fresh data/ and results/ below outdir, then return serializable summary."""
    outdir=Path(outdir)
    generate_inputs(outdir/'data')
    return run(outdir/'data',outdir/'results')


def self_test():
    checks=[]
    def check(condition,name):
        if not condition:raise AssertionError(name)
        checks.append(name)
    def close(a,b):return abs(a-b)<1e-9
    def rejects(fn,name):
        try:fn()
        except ValueError:checks.append(name);return
        raise AssertionError('Expected rejection: '+name)
    with tempfile.TemporaryDirectory(prefix='manufacture_pharma_test_') as td:
        root=Path(td)
        result=build(root/'fixture')
        data=root/'fixture'/'data';output=root/'fixture'/'results'
        before={p.name:p.read_bytes() for p in data.glob('*.csv')}
        again=run(data,root/'recomputed')
        check(result==again,'recompute_same_result')
        check(before=={p.name:p.read_bytes() for p in data.glob('*.csv')},'run_never_changes_inputs')
        check(all(p.read_bytes()==(root/'recomputed'/p.name).read_bytes() for p in output.iterdir()),'deterministic_output_bytes')
        for h in (13,52):
            rows=read_csv(output/('mps_'+str(h)+'.csv'))
            check(len(rows)==h,'mps_horizon_'+str(h))
            check([num(r['planned_receipt_units']) for r in rows[:4]]==[40,70,80,90],'frozen_receipts_'+str(h))
            check(all(close(num(r['closing_net_units']),num(r['opening_net_units'])+num(r['planned_receipt_units'])-num(r['demand_units'])) for r in rows),'mps_balance_'+str(h))
            check(all(num(r['planned_receipt_units'])<=100 and num(r['planned_receipt_units'])%10==0 for r in rows),'mps_capacity_lots_'+str(h))
            check(close(num(rows[1]['closing_backlog_units']),80),'frozen_backlog_visible_'+str(h))
        check(result['mps']['13']['final_backlog']==0,'mps_backlog_recovered')
        check(fit_count([0]*4)==(0,0,None),'all_zero_count_fit')
        check(log_poisson(0,0)==0 and log_poisson(1,0)==-math.inf,'zero_count_probability_boundary')
        mu,var,r=fit_count([0,0,1,1,2,8]*4)
        check(close(mu,2) and close(var,8) and close(r,2/3),'nb_moments_hand_example')
        check(close(math.exp(log_nb(0,mu,r)),.25**(2/3)),'nb_zero_probability')
        check(fit_count([0,1,2,2,3,4]*4)[2] is None,'underdispersion_does_not_invent_negative_r')
        check(abs(sum(math.exp(log_nb(k,2,2/3)) for k in range(200))-1)<1e-12,'nb_probability_normalizes')
        check(all(r['train_n']==24 and r['test_n']==12 for r in result['count_models']),'count_time_split')
        ledger=read_csv(output/'vmi_responsibility_ledger.csv');final=result['vmi_final']
        check(num(ledger[0]['supplier_owned_units'])==100 and num(ledger[1]['factory_owned_units'])==0,'shipping_receiving_do_not_transfer_title')
        check(num(ledger[2]['physical_stock_units'])==100 and num(ledger[2]['factory_owned_units'])==25,'title_transfer_keeps_physical_stock')
        check(final['supplier_owned_units']==70 and final['payable']==150 and final['receivable']==150,'vmi_final_ownership_finance')
        check(final['factory_use_expense']==250 and final['supplier_scrap_expense']==50,'vmi_value_responsibility')
        check(all(num(r['quantity_residual'])==0 and num(r['value_residual'])==0 for r in ledger),'vmi_all_event_conservation')
        bad=read_csv(data/'vmi_events.csv');bad[3]['qty_units']='99'
        rejects(lambda:vmi_ledger(bad,100,10),'reject_unmatched_or_overdrawn_use')
        check([age_stage(a) for a in [0,2,3,11,12]]==['early','early','stable','stable','wear'],'bathtub_stage_boundaries')
        first=result['installed_base_first_month'];last=result['installed_base_last_month']
        check(first['at_risk_units']==340 and close(first['expected_parts_prior'],7.68),'installed_month1_hand_example')
        check(close(first['expected_parts_posterior'],7.136),'installed_beta_update_hand_example')
        check(last['at_risk_units']==400 and close(last['expected_parts_prior'],8.12),'installed_12month_ageing')
        detail=read_csv(output/'installed_base_by_age.csv')
        check(all(num(r['at_risk_units'])==num(r['opening_units'])+num(r['entered_units'])-num(r['exited_units']) for r in detail),'installed_every_cohort_balance')
        movement=read_csv(data/'installed_movements.csv');movement[1]['qty_units']='51'
        rejects(lambda:installed_base(read_csv(data/'installed_cohorts.csv'),movement,read_csv(data/'bathtub_priors.csv'),read_csv(data/'bathtub_history.csv'),12,.8,1),'reject_excessive_retirements')
        dist=distribution(read_csv(data/'repurchase_histogram.csv'))
        lo,hi,mass=shortest_window(dist,.8)
        check((lo,hi)==(21,35) and close(mass,.8),'histogram_generates_shortest_window')
        check(close(result['repurchase_total_expected'],28),'conditional_repurchase_total')
        windows=read_csv(output/'repurchase_windows.csv')
        check(close(num(windows[0]['probability_next_window']),2/9),'conditional_survivor_denominator')
        rejected=[dict(cohort='unsupported',last_purchase_day=-30,initial_count_units=10,repeat_observed_units=0,known_at_day=20)]
        rejects(lambda:repurchase(read_csv(data/'repurchase_histogram.csv'),rejected,20,7,.8),'reject_survivors_outside_support')
        beta=fit_ols([[0,0],[1,0],[0,1],[1,1]],[5,7,8,10])
        check(all(close(a,b) for a,b in zip(beta,[5,2,3])),'ols_really_fits_known_coefficients')
        rejects(lambda:fit_ols([[1],[1],[1]],[2,3,4]),'reject_singular_ols')
        pred=read_csv(output/'ols_rolling_predictions.csv')
        check(len(pred)==40,'rolling_same_40_targets')
        check(all(num(r['train_max_label_known_at'])<=num(r['origin_week']) for r in pred),'rolling_labels_known_by_origin')
        check(all(num(r['train_last_target_week'])<=num(r['target_week'])-2 for r in pred),'rolling_reporting_lag')
        check(all(num(r[k])<=num(r['origin_week']) for r in pred for k in ['flu_known_at_week','weather_known_at_week'] if r[k]!=''),'rolling_features_known_by_origin')
        check(0<result['ols']['fallback_predictions']<40,'late_features_use_explicit_fallback')
        vintages=read_csv(data/'leading_indicator_vintages.csv');labels=read_csv(data/'pharma_weekly_demand.csv')
        _,base,_=rolling_ols(vintages,labels,41,41,2,3,12)
        future_v=copy.deepcopy(vintages);future_y=copy.deepcopy(labels)
        for r in future_v:
            if integer(r['known_at_week'])>40:r['value']=str(num(r['value'])+10000)
        for r in future_y:
            if integer(r['known_at_week'])>40:r['actual_units']=str(num(r['actual_units'])+10000)
        _,changed,_=rolling_ols(future_v,future_y,41,41,2,3,12)
        check(base[0]['forecast_units']==changed[0]['forecast_units'],'future_data_mutation_cannot_change_forecast')
        check(all(integer(r['flu_version'])==1 for r in pred if r['flu_version']),'later_revisions_excluded_from_historical_snapshot')
        # Learner modifies an existing CSV; run() must actually respond.
        p=read_csv(data/'repurchase_parameters.csv');p[0]['forecast_days']='14';write_csv(data/'repurchase_parameters.csv',p)
        modified=run(data,root/'modified')
        check(close(modified['repurchase_total_expected'],90),'changed_csv_parameter_changes_results')
        check(read_csv(data/'repurchase_parameters.csv')[0]['forecast_days']=='14','modified_csv_preserved')
    return dict(passed=True,checks=len(checks),check_names=checks)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    b=sub.add_parser('build');b.add_argument('outdir')
    g=sub.add_parser('generate');g.add_argument('data_dir')
    r=sub.add_parser('run');r.add_argument('data_dir');r.add_argument('output_dir')
    sub.add_parser('self-test')
    args=parser.parse_args()
    if args.command=='build':result=build(args.outdir)
    elif args.command=='generate':result={'data_dir':generate_inputs(args.data_dir),'data_kind':DATA_KIND}
    elif args.command=='run':result=run(args.data_dir,args.output_dir)
    else:result=self_test()
    print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))


if __name__=='__main__':main()
