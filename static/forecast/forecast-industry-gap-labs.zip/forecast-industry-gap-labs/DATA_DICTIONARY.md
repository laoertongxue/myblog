# 数据字典与边界

所有数据都是独立模拟；名称、数值、周期均不对应真实企业或个人。Python浮点保留计算精度，课文按展示位数四舍五入；整数订单使用明确的向上取整/最大余数规则。

## 主行业输入

| 文件 | 主键和粒度 | 字段解释与单位 | 时间契约 |
|---|---|---|---|
| fresh_months.csv | month=1..6，一大类一教学月 | top/store_raw为净菜kg；top_weight无单位；yield_rate净/毛；source_lead_days交期天；target_day月度到货目标 | 预测在第0天可得；每月30天，目标日30..180 |
| fresh_short.csv | store+day，2店×3日 | revised_kg为近端需求预测；只能非负 | 第0天可得，第1..3天 |
| apparel_regions.csv | region+color+size，12行 | old/recent_common_count为共同有货窗购买次数；all_window_count是不用于建模的偏差对照；prior_strength伪样本强度；color_share颜色比例；exposures会话；stock/arrival/presale件；keep_probability概率；pack/moq件 | 第3天末观测完成；before为第4..6天，post为第7..15天；在途第7天可用 |
| apparel_config.json | 单个实验 | alpha/beta先验强度；measured_sessions/purchases测款会话；fabric_m米/件；yield比例；capacity件；arrival/sale_end/presale_deadline天 | 仿真固定交期4天，非下一课12天工艺 |
| postpone_scenarios.csv | demand_state+signal_state，4行 | probability联合概率；红蓝需求件，总需求100 | 第7天信号，第21天销售截止 |
| postpone_config.json | 单个实验 | 交期天；成本为教学货币/件，持有成本/件/天 | 通用坯布第−21天释放，第0天准备好；颜色决策冻结 |
| promotions.csv | event+day，8×4行 | baseline/actual件；discount/ad二值；available_at和complete_at相对天 | 预测起点前1天；仅完整成熟的先前事件可用于拟合；actual只做历史训练或事后评分 |
| events.csv | event_id | fans_k千人代理、gift二值、discount折扣比例、budget_k千元、day1_multiplier无单位 | 截止50；只用feature known及completed在50以前且同品类的事件 |
| event_target.json | 单个目标 | 普通日件数、包材份数、库存件、赠品概率、配货约束 | 所有计划特征在目标截止可得；中午信息为第二决策时点的给定模拟状态 |
| pharma_weeks.csv | week=1..4 | store_a/b需求单位；central_inbound外部已确认入库单位 | 第0天预测；周初收货，再配送，再销售 |
| pharma_stock.csv | location+batch | qty单位；status released/quarantine；expires_week | 本课仅使用已放行、能覆盖全部4周的批次；非完整FEFO |
| pharma_config.json | 单个实验 | 大仓/门店目标单位；采购到货周与效期周 | 月采购只在指定到货周可用；失销量不结转欠交 |

## 主行业输出

- fresh_month_plan：协调月量、两店量、毛料量、释放日、是否需要过去承诺。source_plan按两基地分毛料；daily保留原始形态与协调计划；hour只拆第1月前三天。没有真实采购单。
- apparel_sku_orders：尺码占比、到货前需求/流失、到货时可用、到货后零售、净预售、净需、整包追单。apparel_scenarios重新算五个地区曝光情景，没有置信度承诺。
- postpone_schedule/costs：两策略工序日历，四个联合情景的缺货、余货、成本和概率。共同基础成本与额外成本不重复记。
- promotion_backtest：event/day、实际、基线、模型与无透支预测；折训练截止、系数、ρ及WAPE在industry_results.json。
- event_neighbors：距离、成熟历史倍数、原始权重、归一化权重。预测选择不使用目标实际结果。
- pharma_network：外部入库、店间配送、销售、失销、逐节点与全网余额、安全量缺口。每周网络守恒。

## 制造医药子项目

data/manufacture_pharma 每个输入含 data_kind=SIMULATED_TEACHING_ONLY。其完整逐列解释见 LESSONS.md 中的三课“数据和运行”部分；核心契约如下：

- MPS：周1..52；known_at_week不晚于planning_as_of_week。13/52周是同一需求版本的两种视野，冻结前4周。这是成品周完工量计划，不含工序释放日或多资源APS。
- 网点计数：branch+period_month；count_units是月备件次数。前24月训练，后12月评分；已知时间用于剔除未发布历史。
- VMI：序号、事件日、可得日、事件、件数、货币金额。实物流与产权转移不同；设每件教学价值10 CNY，非税务或法定账务报告。
- 安装基数：群组安装月、在网数量、入网/退网事件、三阶段Beta先验和历史故障/暴露。月初入退网后计算风险人数，设备可修复，故障本身不自动退网。
- 聚合复购：间隔天数直方图、群组上次购买日、初始聚合量、已复购量、可得日。无姓名、病种、处方、个体病史；只估下一次匿名购买事件。
- 先行指标：series+event_week+version+known_at_week，flu_proxy/weather_proxy为模拟宏观代理，标签actual_units另表。使用目标前2/3周指标，滞后事前固定；每个历史训练行冻结于其原预测时点，后发布修订不能泄漏。

输入修改必须保持单位、主键、支持范围、信息时点。异常退出表示这个教学模型不能覆盖该输入，不应删除验证再宣布通过。

## R2输入契约

生鲜 month=1..6 唯一且 target_day=30×month；short 必须有六个唯一store/day。鞋服 prior_strength 和 color_share 是地区颜色级共享参数，重复到三尺码行必须一致；地区曝光在该地区六行一致。两色份额和与每色尺码和分别等于1。医药周行按week排序后推进库存，location/batch不可重复。后置制造仅支持总量100及80/20、20/80两种需求，其他模板显式拒绝，不冒用60件错配阈值。
