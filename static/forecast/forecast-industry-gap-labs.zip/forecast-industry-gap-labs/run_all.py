#!/usr/bin/env python3
"""Read existing synthetic CSV inputs; never overwrite them."""
import argparse,json
from pathlib import Path
import industry_chain
import manufacture_pharma
p=argparse.ArgumentParser();p.add_argument('--data',default='data');p.add_argument('--out',default='outputs');a=p.parse_args()
data=Path(a.data);out=Path(a.out)
r={'data_kind':'SIMULATED_TEACHING_ONLY','industry':industry_chain.run(data,out),'manufacture_pharma':manufacture_pharma.run(data/'manufacture_pharma',out/'manufacture_pharma')}
(out/'all_results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print('Recomputed 9 lessons from CSV. No input files changed. Results: '+str(out/'all_results.json'))
