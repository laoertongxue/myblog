#!/usr/bin/env python3
"""Generate NEW synthetic inputs. Refuses any nonempty destination."""
import argparse
from pathlib import Path
import industry_chain
import manufacture_pharma
p=argparse.ArgumentParser();p.add_argument('--data',default='fresh_data');a=p.parse_args();d=Path(a.data)
if d.exists() and any(d.iterdir()):raise SystemExit('Destination is not empty. Choose a new --data directory to preserve learner changes.')
industry_chain.generate(d);manufacture_pharma.generate_inputs(d/'manufacture_pharma')
print('Generated clearly simulated inputs in '+str(d))
