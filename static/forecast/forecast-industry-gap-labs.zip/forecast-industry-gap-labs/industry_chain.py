"""Synthetic offline teaching cases. Standard library only. No production actions."""
import csv, json, math, argparse
from pathlib import Path

def write_csv(path, rows):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def read_csv(path):
    with open(path,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def num(row,key):
    value=float(row[key])
    require(math.isfinite(value),'non-finite numeric input: '+key)
    return value
def require(ok,msg):
    if not ok:raise ValueError(msg)

def largest_remainder(total,weights):
    require(total>=0 and int(total)==total,'total must be a nonnegative integer')
    require(all(x>=0 for x in weights) and sum(weights)>0,'invalid allocation weights')
    raw=[total*x/sum(weights) for x in weights]; out=[math.floor(x) for x in raw]
    order=sorted(range(len(raw)),key=lambda i:(-(raw[i]-out[i]),i))
    for i in order[:int(total-sum(out))]:out[i]+=1
    return out

def solve(a,b):
    n=len(b);m=[list(map(float,a[i]))+[float(b[i])] for i in range(n)]
    for j in range(n):
        k=max(range(j,n),key=lambda i:abs(m[i][j]));m[j],m[k]=m[k],m[j]
        require(abs(m[j][j])>1e-10,'design is rank deficient; do not report unique coefficients')
        d=m[j][j];m[j]=[v/d for v in m[j]]
        for i in range(n):
            if i!=j:
                q=m[i][j];m[i]=[m[i][k]-q*m[j][k] for k in range(n+1)]
    return [r[-1] for r in m]

def ols(xs,ys):
    p=len(xs[0]);return solve([[sum(x[i]*x[j] for x in xs) for j in range(p)] for i in range(p)],[sum(x[i]*y for x,y in zip(xs,ys)) for i in range(p)])

def generate(data):
    data=Path(data);data.mkdir(parents=True,exist_ok=True)
    write_csv(data/'fresh_months.csv',[dict(month=m,top_finished_kg=t,store_a_raw_kg=a,store_b_raw_kg=b,top_weight=.6,yield_rate=.8,source_lead_days=60,target_day=30*m) for m,t,a,b in [(1,3000,1800,1400),(2,3300,2000,1500),(3,3600,2100,1600),(4,3500,2050,1550),(5,3200,1900,1400),(6,3000,1700,1400)]])
    write_csv(data/'fresh_short.csv',[dict(store=s,day=d,revised_kg=v) for s,vals in [('A',[75,70,80]),('B',[55,50,60])] for d,v in enumerate(vals,1)])
    groups=[('north','black',[10,30,60],[20,40,40],.6,1400),('north','white',[20,50,30],[30,40,30],.4,1400),('south','black',[50,30,20],[40,40,20],.4,1000),('south','white',[30,50,20],[50,30,20],.6,1000)]
    rows=[]
    for region,color,old,recent,color_share,exposures in groups:
        for i,size in enumerate(['S','M','L']):
            rows.append(dict(region=region,color=color,size=size,old_common_count=old[i],recent_common_count=recent[i],recent_all_window_count=recent[i]*(2 if i<2 else 1),common_window_id='all_sizes_full_stock_same_hours',prior_strength=100,color_share=color_share,post_arrival_region_exposures=exposures,pre_arrival_region_exposures=exposures/4,stock=8,confirmed_arrival=2,pending_presale=(20 if (region,color,size)==('north','black','M') else 10 if size=='M' and color=='white' else 0),keep_probability=.8,pack=5,moq=10))
    write_csv(data/'apparel_regions.csv',rows)
    (data/'apparel_config.json').write_text(json.dumps(dict(alpha=2,beta=18,measured_sessions=1000,measured_purchases=80,net_fabric_m=1.5,fabric_yield=.9,capacity=300,arrival_day=7,sale_end_day=15,presale_deadline_day=14),indent=2))
    write_csv(data/'postpone_scenarios.csv',[dict(demand_state=d,signal_state=s,probability=p,red_demand=rd,blue_demand=100-rd) for d,s,p,rd in [('red','red',.45,80),('red','blue',.05,80),('blue','red',.05,20),('blue','blue',.45,20)]])
    (data/'postpone_config.json').write_text(json.dumps(dict(units=100,blank_lead=21,dye_days=7,cut_days=2,sew_days=3,sale_deadline=21,signal_day=7,shortage_cost=8,leftover_cost=4,base_make_cost=10,late_make_premium=1,blank_holding_per_unit_day=.05),indent=2))
    prows=[]
    for e,base in enumerate([100,120,90,110,130,105,100,115],1):
        bd,ba,inter,rho=(.3,.2,.1,.4) if e<=6 else ((.35,.18,.08,.5) if e==7 else (.25,.22,.12,.3))
        flags=[(1,0),(0,1)] if e%3==1 else [(1,1),(1,0)] if e%3==2 else [(1,1),(0,1)]
        uplifts=[base*(bd*d+ba*a+inter*d*a) for d,a in flags];u=sum(uplifts)
        for day in range(1,5):
            d,a=flags[day-1] if day<=2 else (0,0)
            actual=base+uplifts[day-1] if day<=2 else base-rho*u*(.75 if day==3 else .25)
            prows.append(dict(event=e,event_start=10*e,day=day,baseline=base,discount=d,ad=a,actual=actual,available_at=10*e+5,event_complete_at=10*e+5))
    write_csv(data/'promotions.csv',prows)
    ev=[('E1',10,'drink',20,1,.10,30,2.0),('E2',20,'drink',30,1,.15,40,2.8),('E3',30,'drink',10,0,.05,10,1.2),('E4',40,'drink',25,1,.10,25,2.2),('E5',100,'drink',50,1,.20,60,3.5),('E6',15,'cosmetic',22,1,.10,30,8.0)]
    write_csv(data/'events.csv',[dict(event_id=i,completed_at=t,features_known_at=t-7,category=c,fans_k=f,gift=g,discount=d,budget_k=b,day1_multiplier=m) for i,t,c,f,g,d,b,m in ev])
    (data/'event_target.json').write_text(json.dumps(dict(event_id='TARGET',cutoff=50,category='drink',fans_k=22,gift=1,discount=.1,budget_k=30,normal_day_units=100,gift_rate=.5,package_stock=30,confirmed_packages=20,first_cap=160,product_available=200,sold_by_noon=100,remaining_forecast_at_noon=120,warehouse_available=80),indent=2))
    write_csv(data/'pharma_weeks.csv',[dict(week=w,store_a=60,store_b=40,central_inbound=(50 if w==3 else 0)) for w in range(1,5)])
    write_csv(data/'pharma_stock.csv',[dict(location=l,batch=b,qty=q,status=s,expires_week=e) for l,b,q,s,e in [('central','C1',80,'released',4),('central','Q1',10,'quarantine',8),('central','X1',5,'released',0),('A','A1',20,'released',4),('B','B1',10,'released',4)]])
    (data/'pharma_config.json').write_text(json.dumps(dict(central_safety=40,store_a_safety=10,store_b_safety=10,purchase_arrival_week=2,purchase_expiry_week=8),indent=2))

def fresh(data,out):
    rows=read_csv(data/'fresh_months.csv');short=read_csv(data/'fresh_short.csv'); results=[];daily=[]
    require(len(rows)==6 and {int(r['month']) for r in rows}==set(range(1,7)),'expected distinct months 1..6')
    require(len(short)==6 and len({(r['store'],int(r['day'])) for r in short})==6,'duplicate or missing store/day in short forecast')
    require({(r['store'],int(r['day'])) for r in short}=={(store,day) for store in ['A','B'] for day in [1,2,3]},'expected stores A/B and days 1..3')
    require(all(num(r,'revised_kg')>=0 for r in short),'invalid short forecast')
    require(all(num(r,'target_day')==30*int(r['month']) for r in rows),'this fixture requires target_day = 30 * month')
    require(all(num(r,'source_lead_days')>=0 for r in rows),'negative source lead time')
    rows=sorted(rows,key=lambda r:int(r['month']))
    for r in rows:
        m=int(r['month']);a=num(r,'store_a_raw_kg');b=num(r,'store_b_raw_kg');w=num(r,'top_weight');y=num(r,'yield_rate')
        require(a>=0 and b>=0 and a+b>0 and num(r,'top_finished_kg')>=0 and 0<=w<=1 and 0<y<=1,'invalid hierarchy or yield')
        rec=w*num(r,'top_finished_kg')+(1-w)*(a+b)
        stores={'A':rec*a/(a+b),'B':rec*b/(a+b)}
        release=num(r,'target_day')-num(r,'source_lead_days')
        results.append(dict(month=m,reconciled_finished_kg=rec,store_a_kg=stores['A'],store_b_kg=stores['B'],gross_source_kg=rec/y,source_release_day=release,requires_existing_commitment=release<0))
        for store,total in stores.items():
            first=total*.12
            updates={int(x['day']):num(x,'revised_kg') for x in short if x['store']==store} if m==1 else {}
            require(not updates or set(updates)=={1,2,3},'T+1..3 rows must be complete')
            updated=sum(updates.values()) if updates else first
            require(0<=updated<=total,'short-term revision exceeds approved month; approval exception required')
            for d in range(1,31):
                old=total*.04 if d<=3 else (total-first)/27
                val=updates[d] if d<=3 and updates else ((total-updated)/27 if d>3 else old)
                daily.append(dict(month=m,store=store,day=d,base_kg=old,coherent_kg=val))
    write_csv(out/'fresh_month_plan.csv',results);write_csv(out/'fresh_daily_plan.csv',daily)
    write_csv(out/'fresh_source_plan.csv',[dict(month=r['month'],category='synthetic_leaf_greens',base=base,raw_kg=r['gross_source_kg']*share,receipt_target_day=30*r['month'],release_day=r['source_release_day'],requires_existing_commitment=r['requires_existing_commitment']) for r in results for base,share in [('base_A',.6),('base_B',.4)]])
    write_csv(out/'fresh_hour_plan.csv',[dict(store=r['store'],day=r['day'],hour_block=j+1,kg=r['coherent_kg']*w) for r in daily if r['month']==1 and r['day']<=3 for j,w in enumerate([.15,.25,.35,.25])])
    return dict(months=results,first_three_days_total=sum(r['coherent_kg'] for r in daily if r['month']==1 and r['day']<=3),month1_daily_sum=sum(r['coherent_kg'] for r in daily if r['month']==1))

def apparel(data,out):
    rows=read_csv(data/'apparel_regions.csv');cfg=json.loads((data/'apparel_config.json').read_text());res=[]
    require(all(math.isfinite(v) for v in cfg.values()),'non-finite apparel configuration')
    require(cfg['alpha']>0 and cfg['beta']>0 and cfg['capacity']>=0 and cfg['net_fabric_m']>=0 and 0<cfg['fabric_yield']<=1,'invalid apparel configuration')
    p=(cfg['alpha']+cfg['measured_purchases'])/(cfg['alpha']+cfg['beta']+cfg['measured_sessions'])
    require(0<=cfg['measured_purchases']<=cfg['measured_sessions'],'purchases exceed sessions')
    require(cfg['arrival_day']<=cfg['presale_deadline_day']<=cfg['sale_end_day'],'arrival misses committed teaching deadline')
    require(len(rows)==12 and {(r['region'],r['color'],r['size']) for r in rows}=={(region,color,size) for region in ['north','south'] for color in ['black','white'] for size in ['S','M','L']},'expected 12 distinct regional SKUs')
    rows=sorted(rows,key=lambda r:([ 'north','south'].index(r['region']),['black','white'].index(r['color']),['S','M','L'].index(r['size'])))
    # A repeated region/color field is a shared parameter, not a free SKU parameter.
    for region in ['north','south']:
        region_rows=[r for r in rows if r['region']==region]
        for field in ['pre_arrival_region_exposures','post_arrival_region_exposures']:
            values={num(r,field) for r in region_rows}
            require(len(values)==1 and min(values)>=0,'inconsistent region exposure: '+field)
        color_shares=[]
        for color in ['black','white']:
            group=[r for r in region_rows if r['color']==color]
            require(len({num(r,'prior_strength') for r in group})==1,'prior_strength must be shared within each region/color')
            shares={num(r,'color_share') for r in group}
            require(len(shares)==1 and 0<=min(shares)<=1,'color_share must be shared within each region/color')
            color_shares.append(next(iter(shares)))
        require(abs(sum(color_shares)-1)<1e-9,'distinct color shares must sum to 1 within region')
    require(all(num(r,k)>=0 for r in rows for k in ['stock','confirmed_arrival','pending_presale','old_common_count','recent_common_count','prior_strength']),'negative apparel input')
    require(all(0<=num(r,'keep_probability')<=1 for r in rows),'invalid presale probability')
    for r in rows:
        group=[x for x in rows if x['region']==r['region'] and x['color']==r['color']]
        require(len(group)==3 and {x['size'] for x in group}=={'S','M','L'},'size group incomplete')
        require(all(x['common_window_id']==r['common_window_id'] for x in group),'not comparable stock windows')
        oldsum=sum(num(x,'old_common_count') for x in group);recentsum=sum(num(x,'recent_common_count') for x in group);strength=num(r,'prior_strength')
        require(oldsum>0 and recentsum+strength>0,'empty size evidence')
        share=(num(r,'recent_common_count')+strength*num(r,'old_common_count')/oldsum)/(recentsum+strength)
        retail=num(r,'post_arrival_region_exposures')*p*num(r,'color_share')*share
        before=num(r,'pre_arrival_region_exposures')*p*num(r,'color_share')*share
        stock=num(r,'stock');remaining=max(0,stock-before)+num(r,'confirmed_arrival')
        presale=num(r,'pending_presale')*num(r,'keep_probability');need=max(0,retail+presale-remaining)
        pack=int(r['pack']);moq=int(r['moq']);require(pack>0 and moq%pack==0,'MOQ must respect packs')
        order=0 if need==0 else max(moq,math.ceil(need/pack)*pack)
        res.append(dict(region=r['region'],color=r['color'],size=r['size'],size_share=share,pre_arrival_need=before,pre_arrival_lost=max(0,before-stock),arrival_available=remaining,post_arrival_retail=retail,presale_net=presale,net_need=need,order_units=order))
    for region in ['north','south']:
        for color in ['black','white']:
            require(abs(sum(r['size_share'] for r in res if r['region']==region and r['color']==color)-1)<1e-9,'size shares must sum to 1')
        region_expected=num(next(r for r in rows if r['region']==region),'post_arrival_region_exposures')*p
        require(abs(sum(r['post_arrival_retail'] for r in res if r['region']==region)-region_expected)<1e-8,'regional retail hierarchy does not reconcile')
    total=sum(r['order_units'] for r in res);write_csv(out/'apparel_sku_orders.csv',res)
    scenarios=[]
    for name,north,south in [('base',1,1),('north_hot',1.2,.8),('south_hot',.8,1.2),('both_low',.8,.8),('both_high',1.2,1.2)]:
        orders=0;retail_total=0
        for r,src in zip(res,rows):
            retail=r['post_arrival_retail']*(north if r['region']=='north' else south);retail_total+=retail
            need=max(0,retail+r['presale_net']-r['arrival_available']);pack=int(src['pack']);moq=int(src['moq'])
            orders+=0 if need==0 else max(moq,math.ceil(need/pack)*pack)
        scenarios.append(dict(scenario=name,north_exposure_factor=north,south_exposure_factor=south,post_retail=retail_total,presale_net=sum(r['presale_net'] for r in res),orders=orders,capacity_feasible=orders<=cfg['capacity']))
    write_csv(out/'apparel_scenarios.csv',scenarios)
    return dict(posterior_mean=p,retail=sum(r['post_arrival_retail'] for r in res),presale_net=sum(r['presale_net'] for r in res),orders=total,fabric_m=total*cfg['net_fabric_m']/cfg['fabric_yield'],capacity_feasible=total<=cfg['capacity'],pre_arrival_lost=sum(r['pre_arrival_lost'] for r in res),scenarios=scenarios)

def postpone(data,out):
    rows=read_csv(data/'postpone_scenarios.csv');c=json.loads((data/'postpone_config.json').read_text());lead=c['dye_days']+c['cut_days']+c['sew_days'];latest=c['sale_deadline']-lead
    require(c['signal_day']<=latest,'signal arrives after latest dye release; delayed option infeasible')
    require(all(math.isfinite(v) and v>=0 for v in c.values()),'invalid postponement configuration')
    require(c['units']==100,'this bounded fixture requires 100 units')
    require(c['shortage_cost']+c['leftover_cost']>0,'positive combined mismatch cost required for accuracy threshold')
    for r in rows:
        expected=[80,20] if r['demand_state']=='red' else [20,80]
        demand=[num(r,'red_demand'),num(r,'blue_demand')]
        require(sum(demand)==c['units'],'scenario demand must total the fixed 100 units')
        require(demand==expected,'this fixture only supports red/blue demand states 80/20 and 20/80')
    require(all(num(r,'probability')>=0 for r in rows) and abs(sum(num(r,'probability') for r in rows)-1)<1e-9,'scenario probabilities must be nonnegative and sum to 1')
    require(len(rows)==4 and {(r['demand_state'],r['signal_state']) for r in rows}=={('red','red'),('red','blue'),('blue','red'),('blue','blue')},'four distinct joint scenarios required')
    res=[]
    for r in rows:
        demand=[num(r,'red_demand'),num(r,'blue_demand')]
        for strategy,qty in [('early',[50,50]),('delayed',[80,20] if r['signal_state']=='red' else [20,80])]:
            lack=sum(max(0,d-q) for d,q in zip(demand,qty));left=sum(max(0,q-d) for d,q in zip(demand,qty))
            extra=c['units']*(c['late_make_premium']+c['blank_holding_per_unit_day']*c['signal_day']) if strategy=='delayed' else 0
            cost=c['units']*c['base_make_cost']+lack*c['shortage_cost']+left*c['leftover_cost']+extra
            res.append(dict(demand_state=r['demand_state'],signal_state=r['signal_state'],probability=num(r,'probability'),strategy=strategy,shortage=lack,leftover=left,total_cost=cost))
    write_csv(out/'postpone_costs.csv',res)
    expected={s:sum(r['probability']*r['total_cost'] for r in res if r['strategy']==s) for s in ['early','delayed']}
    write_csv(out/'postpone_schedule.csv',[dict(strategy=s,blank_order_day=-c['blank_lead'],blank_ready=0,color_frozen=d,dye_ready=d+c['dye_days'],cut_ready=d+c['dye_days']+c['cut_days'],sew_ready=d+lead,sale_deadline=c['sale_deadline']) for s,d in [('early',0),('delayed',c['signal_day'])]])
    return dict(expected_cost=expected,latest_color_decision=latest,saving=expected['early']-expected['delayed'],accuracy_break_even=1-((expected['early']-c['units']*c['base_make_cost'])-c['units']*(c['late_make_premium']+c['blank_holding_per_unit_day']*c['signal_day']))/(60*(c['shortage_cost']+c['leftover_cost'])))

def fit_promotions(rows,cutoff):
    eligible=[r for r in rows if num(r,'event_complete_at')<=cutoff and num(r,'available_at')<=cutoff]
    ids={r['event'] for r in eligible};require(all(len([r for r in eligible if r['event']==i])==4 for i in ids),'need full event and recovery window')
    promo=[r for r in eligible if int(r['day'])<=2];xs=[[num(r,'discount'),num(r,'ad'),num(r,'discount')*num(r,'ad')] for r in promo];ys=[num(r,'actual')/num(r,'baseline')-1 for r in promo]
    coeff=ols(xs,ys);up=sum(num(r,'actual')-num(r,'baseline') for r in promo);post=[r for r in eligible if int(r['day'])>2];dip=sum(num(r,'baseline')-num(r,'actual') for r in post)
    require(up>0 and dip>=0,'positive uplift/deficit support required for this pantry model')
    rho=dip/up;w=sum(num(r,'baseline')-num(r,'actual') for r in post if int(r['day'])==3)/dip if dip else .5
    return coeff,rho,w,sorted(map(int,ids))

def promotions(data,out):
    rows=read_csv(data/'promotions.csv');res=[];summ=[]
    require(all(num(r,'baseline')>0 and num(r,'actual')>=0 for r in rows),'invalid promotion baseline or sales')
    for e in [6,7,8]:
        target=[r for r in rows if int(r['event'])==e];cutoff=num(target[0],'event_start')-1;coef,rho,w,ids=fit_promotions(rows,cutoff)
        uplift=sum(num(r,'baseline')*sum(b*x for b,x in zip(coef,[num(r,'discount'),num(r,'ad'),num(r,'discount')*num(r,'ad')])) for r in target if int(r['day'])<=2)
        for r in target:
            day=int(r['day']);base=num(r,'baseline');pre=base*(1+sum(b*x for b,x in zip(coef,[num(r,'discount'),num(r,'ad'),num(r,'discount')*num(r,'ad')])))
            pred=pre if day<=2 else max(0,base-rho*uplift*(w if day==3 else 1-w))
            res.append(dict(event=e,day=day,actual=num(r,'actual'),baseline=base,prediction=pred,no_dip_prediction=pre))
        rr=[r for r in res if r['event']==e];den=sum(r['actual'] for r in rr)
        summ.append(dict(event=e,cutoff=cutoff,train_events=ids,coefficients=coef,rho=rho,day1_dip_weight=w,wape=sum(abs(r['actual']-r['prediction']) for r in rr)/den,no_dip_wape=sum(abs(r['actual']-r['no_dip_prediction']) for r in rr)/den))
    write_csv(out/'promotion_backtest.csv',res);return dict(folds=summ,all_event_wape=sum(abs(r['actual']-r['prediction']) for r in res)/sum(r['actual'] for r in res),no_dip_wape=sum(abs(r['actual']-r['no_dip_prediction']) for r in res)/sum(r['actual'] for r in res))

def events(data,out):
    rows=read_csv(data/'events.csv');t=json.loads((data/'event_target.json').read_text());history=[r for r in rows if num(r,'completed_at')<=t['cutoff'] and num(r,'features_known_at')<=t['cutoff'] and r['category']==t['category']]
    require(len(history)>=3,'at least three comparable matured events required')
    features=['fans_k','discount','budget_k'];ranges={f:max(num(r,f) for r in history)-min(num(r,f) for r in history) for f in features}
    scored=[]
    for r in history:
        distance=(sum(abs(num(r,f)-t[f])/ranges[f] if ranges[f] else 0 for f in features)+(num(r,'gift')!=t['gift']))/4
        scored.append(dict(event_id=r['event_id'],distance=distance,multiplier=num(r,'day1_multiplier'),raw_weight=1/(distance+.1)))
    selected=sorted(scored,key=lambda r:(r['distance'],r['event_id']))[:3];den=sum(r['raw_weight'] for r in selected)
    for r in selected:r['weight']=r['raw_weight']/den
    multiplier=sum(r['weight']*r['multiplier'] for r in selected);units=math.ceil(t['normal_day_units']*multiplier);packages=math.ceil(units*t['gift_rate']);lock=max(0,packages-t['package_stock']-t['confirmed_packages']);first=min(units,t['first_cap'],t['product_available']);remaining=first-t['sold_by_noon'];require(remaining>=0,'noon sales exceed first allocation')
    second=min(max(0,t['remaining_forecast_at_noon']-remaining),t['warehouse_available'])
    write_csv(out/'event_neighbors.csv',selected)
    return dict(eligible_ids=sorted(r['event_id'] for r in history),ranges=ranges,neighbors=selected,multiplier=multiplier,predicted_units=units,package_lock=lock,first_allocation=first,second_allocation=second,limitation='Feature similarity is conditional analogy, not causal uplift or actual dispatch.')

def pharma(data,out):
    rows=read_csv(data/'pharma_weeks.csv');stock=read_csv(data/'pharma_stock.csv');c=json.loads((data/'pharma_config.json').read_text())
    require(len(rows)==4 and {int(r['week']) for r in rows}=={1,2,3,4},'four distinct weeks required')
    rows=sorted(rows,key=lambda r:int(r['week']))
    require(all(math.isfinite(v) and v>=0 for v in c.values()),'invalid pharma configuration')
    require(c['purchase_arrival_week'] in [1,2,3,4],'purchase arrival must be in the four-week horizon')
    require(len({(r['location'],r['batch']) for r in stock})==len(stock),'duplicate stock batch key')
    require(all(r['location'] in ['central','A','B'] and r['status'] in ['released','quarantine'] for r in stock),'invalid stock location or status')
    require(all(num(r,'qty')>=0 for r in stock),'negative stock')
    require(all(num(r,k)>=0 for r in rows for k in ['store_a','store_b','central_inbound']),'negative demand or arrival')
    usable={l:sum(num(r,'qty') for r in stock if r['location']==l and r['status']=='released' and int(r['expires_week'])>=4) for l in ['central','A','B']}
    excluded=sum(num(r,'qty') for r in stock)-sum(usable.values());demand=sum(num(r,'store_a')+num(r,'store_b') for r in rows);incoming=sum(num(r,'central_inbound') for r in rows);target=c['central_safety']+c['store_a_safety']+c['store_b_safety'];purchase=max(0,demand+target-sum(usable.values())-incoming)
    require(c['purchase_expiry_week']>=4,'purchase batch does not cover this four-week exercise; time-phased expiry needed')
    central=usable['central'];stores=[usable['A'],usable['B']];initial=central+sum(stores);res=[];cum_external=0;cum_sales=0
    for r in rows:
        w=int(r['week']);external=num(r,'central_inbound')+(purchase if w==c['purchase_arrival_week'] else 0);central+=external;cum_external+=external
        dem=[num(r,'store_a'),num(r,'store_b')];needs=[max(0,d+s-q) for d,s,q in zip(dem,[c['store_a_safety'],c['store_b_safety']],stores)];shipment=needs if sum(needs)<=central else largest_remainder(int(central),needs);central-=sum(shipment)
        sold=[min(q+x,d) for q,x,d in zip(stores,shipment,dem)];stores=[q+x-y for q,x,y in zip(stores,shipment,sold)];cum_sales+=sum(sold)
        require(abs(initial+cum_external-cum_sales-central-sum(stores))<1e-8,'network conservation broken')
        res.append(dict(week=w,external_received=external,ship_a=shipment[0],ship_b=shipment[1],sales=sum(sold),lost=sum(dem)-sum(sold),central_end=central,store_a_end=stores[0],store_b_end=stores[1],network_end=central+sum(stores),central_safety_shortfall=max(0,c['central_safety']-central),store_safety_shortfall=max(0,c['store_a_safety']-stores[0])+max(0,c['store_b_safety']-stores[1])))
    write_csv(out/'pharma_network.csv',res);return dict(month_demand=demand,initial_released=initial,excluded_units=excluded,purchase=purchase,external_scheduled=incoming,terminal_target=target,ending_stock=res[-1]['network_end'],lost=sum(r['lost'] for r in res),weekly=res)

def run(data_dir,output_dir):
    data=Path(data_dir);out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    result={name:fn(data,out) for name,fn in [('fresh_hierarchy',fresh),('apparel_hierarchy',apparel),('postponement',postpone),('promotion_pantry',promotions),('event_analogy',events),('pharma_multiperiod',pharma)]}
    (out/'industry_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--data',default='data');parser.add_argument('--out',default='outputs');parser.add_argument('--generate',action='store_true');a=parser.parse_args()
    if a.generate:generate(a.data)
    print(json.dumps(run(a.data,a.out),ensure_ascii=False,indent=2))
