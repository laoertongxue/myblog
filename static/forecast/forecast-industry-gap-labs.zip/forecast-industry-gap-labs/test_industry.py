import unittest,tempfile,json,csv,copy
from pathlib import Path
import industry_chain as m

class IndustryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.data=self.root/'data';self.out=self.root/'out';self.out.mkdir();m.generate(self.data)
    def mutate_json(self,name,**changes):
        p=self.data/name;c=json.loads(p.read_text());c.update(changes);p.write_text(json.dumps(c))
    def test_fresh_month1(self):
        r=m.fresh(self.data,self.out);self.assertAlmostEqual(r['months'][0]['reconciled_finished_kg'],3080);self.assertAlmostEqual(r['months'][0]['gross_source_kg'],3850)
    def test_fresh_sums_all_six(self):
        r=m.fresh(self.data,self.out);ds=m.read_csv(self.out/'fresh_daily_plan.csv')
        for row in r['months']:self.assertAlmostEqual(sum(float(x['coherent_kg']) for x in ds if int(x['month'])==row['month']),row['reconciled_finished_kg'])
    def test_fresh_source_release(self):
        r=m.fresh(self.data,self.out);self.assertTrue(r['months'][0]['requires_existing_commitment']);self.assertEqual(r['months'][1]['source_release_day'],0)
    def test_fresh_short_and_hour(self):
        r=m.fresh(self.data,self.out);hs=m.read_csv(self.out/'fresh_hour_plan.csv');self.assertEqual(r['first_three_days_total'],390);self.assertAlmostEqual(sum(float(x['kg']) for x in hs),390)
    def test_fresh_overbudget_rejected(self):
        rows=m.read_csv(self.data/'fresh_short.csv');rows[0]['revised_kg']=99999;m.write_csv(self.data/'fresh_short.csv',rows)
        with self.assertRaises(ValueError):m.fresh(self.data,self.out)
    def test_fresh_yield_rejected(self):
        rows=m.read_csv(self.data/'fresh_months.csv');rows[0]['yield_rate']=0;m.write_csv(self.data/'fresh_months.csv',rows)
        with self.assertRaises(ValueError):m.fresh(self.data,self.out)
    def test_apparel_posterior(self):
        r=m.apparel(self.data,self.out);self.assertAlmostEqual(r['posterior_mean'],82/1020);self.assertAlmostEqual(r['retail'],192.94117647058826);self.assertEqual(r['presale_net'],32)
    def test_apparel_pack_and_total(self):
        r=m.apparel(self.data,self.out);self.assertEqual(r['orders'],200);self.assertAlmostEqual(r['fabric_m'],1000/3);self.assertTrue(all(int(x['order_units'])%5==0 for x in m.read_csv(self.out/'apparel_sku_orders.csv')))
    def test_apparel_regions_distinct(self):
        m.apparel(self.data,self.out);rows=m.read_csv(self.out/'apparel_sku_orders.csv');north=next(x for x in rows if (x['region'],x['color'],x['size'])==('north','black','S'));south=next(x for x in rows if (x['region'],x['color'],x['size'])==('south','black','S'));self.assertAlmostEqual(float(north['size_share']),.15);self.assertAlmostEqual(float(south['size_share']),.45)
    def test_apparel_naive_raw_ignored(self):
        before=m.apparel(self.data,self.out);rows=m.read_csv(self.data/'apparel_regions.csv');rows[0]['recent_all_window_count']=999999;m.write_csv(self.data/'apparel_regions.csv',rows);self.assertEqual(before,m.apparel(self.data,self.out))
    def test_apparel_uncertainty_orders(self):
        r=m.apparel(self.data,self.out);s={x['scenario']:x for x in r['scenarios']};self.assertLess(s['both_low']['orders'],s['both_high']['orders']);self.assertNotEqual(s['north_hot']['orders'],s['south_hot']['orders'])
    def test_apparel_capacity_not_silently_clipped(self):
        self.mutate_json('apparel_config.json',capacity=150);r=m.apparel(self.data,self.out);self.assertFalse(r['capacity_feasible']);self.assertEqual(r['orders'],200)
    def test_apparel_late_rejected(self):
        self.mutate_json('apparel_config.json',arrival_day=16)
        with self.assertRaises(ValueError):m.apparel(self.data,self.out)
    def test_postponement_costs(self):
        r=m.postpone(self.data,self.out);self.assertEqual(r['expected_cost'],dict(early=1360.,delayed=1207.));self.assertEqual(r['latest_color_decision'],9);self.assertAlmostEqual(r['accuracy_break_even'],.6875)
    def test_postponement_uninformative_worse(self):
        rows=m.read_csv(self.data/'postpone_scenarios.csv')
        for r in rows:r['probability']=.25
        m.write_csv(self.data/'postpone_scenarios.csv',rows);r=m.postpone(self.data,self.out);self.assertEqual(r['expected_cost']['delayed'],1495);self.assertLess(r['saving'],0)
    def test_postponement_deadline_rejected(self):
        self.mutate_json('postpone_config.json',signal_day=10)
        with self.assertRaises(ValueError):m.postpone(self.data,self.out)
    def test_promotion_coefficients(self):
        r=m.promotions(self.data,self.out);f=r['folds'][0]
        for a,b in zip(f['coefficients'],[.3,.2,.1]):self.assertAlmostEqual(a,b)
        self.assertAlmostEqual(f['rho'],.4);self.assertAlmostEqual(f['day1_dip_weight'],.75)
    def test_promotion_rolling_train(self):
        r=m.promotions(self.data,self.out)
        for f in r['folds']:self.assertLess(max(f['train_events']),f['event'])
        self.assertGreater(r['all_event_wape'],0);self.assertLess(r['all_event_wape'],r['no_dip_wape'])
    def test_promotion_future_poison(self):
        rows=m.read_csv(self.data/'promotions.csv');original=m.fit_promotions(rows,59)
        for r in rows:
            if int(r['event'])>=6:r['actual']=999999
        self.assertEqual(original,m.fit_promotions(rows,59))
    def test_rank_deficiency_rejected(self):
        with self.assertRaises(ValueError):m.ols([[1,1],[2,2]],[1,2])
    def test_event_feature_selection(self):
        r=m.events(self.data,self.out);self.assertEqual([x['event_id'] for x in r['neighbors']],['E1','E4','E2']);self.assertAlmostEqual(r['multiplier'],2.191852202747513);self.assertEqual(r['package_lock'],60)
    def test_event_exclusion(self):
        r=m.events(self.data,self.out);self.assertNotIn('E5',r['eligible_ids']);self.assertNotIn('E6',r['eligible_ids'])
    def test_event_future_extreme_does_not_scale(self):
        before=m.events(self.data,self.out);rows=m.read_csv(self.data/'events.csv')
        for r in rows:
            if r['event_id']=='E5':r['fans_k']=99999;r['day1_multiplier']=99999
        m.write_csv(self.data/'events.csv',rows);self.assertEqual(before,m.events(self.data,self.out))
    def test_event_allocations(self):
        r=m.events(self.data,self.out);self.assertEqual(r['first_allocation'],160);self.assertEqual(r['second_allocation'],60)
    def test_pharma_month_net_not_transfer_double_count(self):
        r=m.pharma(self.data,self.out);self.assertEqual(r['purchase'],300);self.assertEqual(r['ending_stock'],60);self.assertEqual(r['excluded_units'],15)
    def test_pharma_week1_constraint(self):
        r=m.pharma(self.data,self.out);w=r['weekly'][0];self.assertEqual((w['ship_a'],w['ship_b']),(44,36));self.assertEqual(w['central_safety_shortfall'],40);self.assertEqual(w['store_safety_shortfall'],10);self.assertEqual(r['lost'],0)
    def test_pharma_late_purchase_breaks_service(self):
        self.mutate_json('pharma_config.json',purchase_arrival_week=3);r=m.pharma(self.data,self.out);self.assertEqual(r['purchase'],300);self.assertEqual(r['lost'],90);self.assertEqual(r['ending_stock'],150)
    def test_pharma_reverse_rows_invariant(self):
        before=m.pharma(self.data,self.out);rows=m.read_csv(self.data/'pharma_weeks.csv');m.write_csv(self.data/'pharma_weeks.csv',list(reversed(rows)));self.assertEqual(before,m.pharma(self.data,self.out))
    def test_pharma_all_week_permutations_invariant(self):
        import itertools
        before=m.pharma(self.data,self.out);rows=m.read_csv(self.data/'pharma_weeks.csv')
        for perm in itertools.permutations(rows):
            m.write_csv(self.data/'pharma_weeks.csv',list(perm));self.assertEqual(before,m.pharma(self.data,self.out))
    def test_apparel_one_row_prior_strength_rejected(self):
        rows=m.read_csv(self.data/'apparel_regions.csv');rows[0]['prior_strength']=0;m.write_csv(self.data/'apparel_regions.csv',rows)
        with self.assertRaisesRegex(ValueError,'prior_strength'):m.apparel(self.data,self.out)
    def test_apparel_shared_zero_prior_strength_valid(self):
        rows=m.read_csv(self.data/'apparel_regions.csv')
        for r in rows:
            if r['region']=='north' and r['color']=='black':r['prior_strength']=0
        m.write_csv(self.data/'apparel_regions.csv',rows);result=m.apparel(self.data,self.out);rr=[r for r in m.read_csv(self.out/'apparel_sku_orders.csv') if r['region']=='north' and r['color']=='black'];self.assertEqual([float(r['size_share']) for r in rr],[.2,.4,.4]);self.assertAlmostEqual(result['retail'],2400*82/1020)
    def test_apparel_any_inconsistent_color_row_rejected(self):
        original=m.read_csv(self.data/'apparel_regions.csv')
        for i in range(12):
            rows=copy.deepcopy(original);rows[i]['color_share']=.9;m.write_csv(self.data/'apparel_regions.csv',rows)
            with self.subTest(row=i),self.assertRaisesRegex(ValueError,'color_share'):m.apparel(self.data,self.out)
    def test_apparel_consistent_new_color_mix_valid(self):
        rows=m.read_csv(self.data/'apparel_regions.csv')
        for r in rows:
            if r['region']=='north':r['color_share']=.7 if r['color']=='black' else .3
        m.write_csv(self.data/'apparel_regions.csv',rows);result=m.apparel(self.data,self.out);self.assertAlmostEqual(result['retail'],2400*82/1020)
    def test_apparel_inconsistent_region_exposure_rejected(self):
        rows=m.read_csv(self.data/'apparel_regions.csv');rows[0]['post_arrival_region_exposures']=1500;m.write_csv(self.data/'apparel_regions.csv',rows)
        with self.assertRaisesRegex(ValueError,'region exposure'):m.apparel(self.data,self.out)
    def test_apparel_consistent_region_exposure_valid(self):
        rows=m.read_csv(self.data/'apparel_regions.csv')
        for r in rows:
            if r['region']=='north':r['post_arrival_region_exposures']=1500
        m.write_csv(self.data/'apparel_regions.csv',rows);result=m.apparel(self.data,self.out);self.assertAlmostEqual(result['retail'],2500*82/1020)
    def test_apparel_reverse_rows_invariant(self):
        before=m.apparel(self.data,self.out);csv_before=(self.out/'apparel_sku_orders.csv').read_bytes();rows=m.read_csv(self.data/'apparel_regions.csv');m.write_csv(self.data/'apparel_regions.csv',list(reversed(rows)));self.assertEqual(before,m.apparel(self.data,self.out));self.assertEqual(csv_before,(self.out/'apparel_sku_orders.csv').read_bytes())
    def test_fresh_duplicate_store_day_rejected(self):
        rows=m.read_csv(self.data/'fresh_short.csv');duplicate=copy.deepcopy(rows[0]);duplicate['revised_kg']=100;rows.append(duplicate);m.write_csv(self.data/'fresh_short.csv',rows)
        with self.assertRaisesRegex(ValueError,'duplicate'):m.fresh(self.data,self.out)
    def test_fresh_identical_duplicate_rejected(self):
        rows=m.read_csv(self.data/'fresh_short.csv');rows.append(copy.deepcopy(rows[0]));m.write_csv(self.data/'fresh_short.csv',rows)
        with self.assertRaisesRegex(ValueError,'duplicate'):m.fresh(self.data,self.out)
    def test_fresh_missing_store_day_rejected(self):
        rows=m.read_csv(self.data/'fresh_short.csv')[:-1];m.write_csv(self.data/'fresh_short.csv',rows)
        with self.assertRaisesRegex(ValueError,'missing'):m.fresh(self.data,self.out)
    def test_fresh_reverse_rows_invariant(self):
        before=m.fresh(self.data,self.out)
        for file in ['fresh_months.csv','fresh_short.csv']:m.write_csv(self.data/file,list(reversed(m.read_csv(self.data/file))))
        self.assertEqual(before,m.fresh(self.data,self.out))
    def test_fresh_target_day_40_rejected(self):
        rows=m.read_csv(self.data/'fresh_months.csv');rows[0]['target_day']=40;m.write_csv(self.data/'fresh_months.csv',rows)
        with self.assertRaisesRegex(ValueError,'target_day'):m.fresh(self.data,self.out)
    def test_postpone_demand_110_rejected(self):
        rows=m.read_csv(self.data/'postpone_scenarios.csv');rows[0]['red_demand']=90;m.write_csv(self.data/'postpone_scenarios.csv',rows)
        with self.assertRaisesRegex(ValueError,'total'):m.postpone(self.data,self.out)
    def test_postpone_outside_template_rejected(self):
        rows=m.read_csv(self.data/'postpone_scenarios.csv');rows[0]['red_demand']=90;rows[0]['blue_demand']=10;m.write_csv(self.data/'postpone_scenarios.csv',rows)
        with self.assertRaisesRegex(ValueError,'80/20'):m.postpone(self.data,self.out)
    def test_postpone_threshold_changes_with_cost(self):
        self.mutate_json('postpone_config.json',late_make_premium=2);r=m.postpone(self.data,self.out);self.assertAlmostEqual(r['accuracy_break_even'],1-125/720)
    def test_pharma_duplicate_batch_rejected(self):
        rows=m.read_csv(self.data/'pharma_stock.csv');rows.append(copy.deepcopy(rows[0]));m.write_csv(self.data/'pharma_stock.csv',rows)
        with self.assertRaisesRegex(ValueError,'duplicate'):m.pharma(self.data,self.out)
    def test_nonfinite_input_rejected(self):
        rows=m.read_csv(self.data/'apparel_regions.csv');rows[0]['stock']='nan';m.write_csv(self.data/'apparel_regions.csv',rows)
        with self.assertRaisesRegex(ValueError,'non-finite'):m.apparel(self.data,self.out)
    def test_largest_remainder(self):self.assertEqual(m.largest_remainder(7,[.3,.47,.23]),[2,3,2])
    def test_reproducibility(self):
        m.run(self.data,self.out);files={p.name:p.read_bytes() for p in self.out.iterdir()};m.run(self.data,self.out);self.assertEqual(files,{p.name:p.read_bytes() for p in self.out.iterdir()})

if __name__=='__main__':unittest.main(verbosity=2)
