"""Golden, invariance, input-mutation and perturbation tests; no external packages."""
import copy, json, math, tempfile
from pathlib import Path
import run
BASE=Path(__file__).parent
D=run.load_data(BASE/'data')
R={k:f(D[k]) for k,f in run.RUNNERS.items()}
checks=[]
def check(name,ok):
    if not ok:raise AssertionError(name)
    checks.append({'id':name,'passed':True})
def eq(a,b):return math.isclose(a,b,abs_tol=1e-8,rel_tol=1e-9)
def rejects(name,lab,mutate):
    d=copy.deepcopy(D[lab]);mutate(d)
    try:run.RUNNERS[lab](d)
    except ValueError:check(name,True)
    else:raise AssertionError(name+' was accepted')
def setpath(d,path,value):
    for p in path[:-1]:d=d[p]
    d[path[-1]]=value

check('SOP-12x2',len(R['sop']['base']['rows'])==len(R['sop']['rolling']['rows'])==12)
check('SOP-late-event',R['sop']['base']['rejected_cpfr']==['CPFR-LATE'])
check('SOP-no-demand-cap-clipping',R['sop']['base']['rows'][4]['consensus_demand']==145 and R['sop']['base']['rows'][4]['capacity']==130)
check('SOP-total-backlog',R['sop']['base']['total_consensus']==1555 and R['sop']['base']['total_fulfilled']==1530 and R['sop']['base']['ending_backlog']==25)
check('SOP-actual-roll',R['sop']['rolling']['rows'][0]['opening_inventory']==10 and R['sop']['rolling']['total_consensus']==1600)
k=R['production']['kitchen']['rows'];m=R['production']['manufacturing']
check('BOM-kitchen-first-week',eq(k[0]['sauce_produced_kg'],20) and eq(k[0]['closing_tomato_kg'],55))
check('BOM-kitchen-capacity-unserved',k[1]['fulfilled_B']==26 and k[1]['unserved_B']==14 and eq(k[1]['closing_sauce_kg'],.2))
check('BOM-late-raw-not-borrowed',k[2]['tomato_arrival_eligible_kg']==0 and len(R['production']['kitchen']['ignored_late_arrivals'])==1)
check('APS-shared-chips-once',m['rows'][1]['produced_B']==0 and m['rows'][2]['produced_B']==2 and m['rows'][2]['closing_chips']==0)
check('APS-original-demand-preserved',m['total_new_demand']==17 and m['total_produced']==14 and m['rows'][-1]['backlog_B']==3)
check('APS-two-denominators',eq(m['period_unit_completion'],14/17) and eq(m['due_line_completion'],4/6))
check('APS-nonbottleneck-release',m['shell_procurement_sensitivity']['unconstrained_net_need']==7 and m['shell_procurement_sensitivity']['feasible_plan_net_need']==4)
n=R['network'];check('NET-ledger-540',len(n['ledger'])==540)
check('NET-grid-210',n['independent']['grid_candidate_count']==n['correlated']['grid_candidate_count']==210)
check('NET-independent-cost',eq(n['independent']['fixed']['mixed']['expected_cost'],78.65) and eq(n['independent']['grid_best']['expected_cost'],77.2))
check('NET-correlation-cost',eq(n['correlated']['fixed']['mixed']['expected_cost'],88.9))
check('NET-service-not-cost-objective',n['independent']['fixed']['mixed']['aggregate_fill_rate']>n['independent']['grid_best']['aggregate_fill_rate'])
check('NET-no-instant-delivery',all(r['served']==0 for r in n['ledger'] if r['placement']=='central' and r['day']<=2))
s=R['sourcing'];check('SRC-seven-candidates',len(s['candidates'])==7)
check('SRC-optimal-split',s['best']['additional_A']==20 and s['best']['additional_B']==60 and eq(s['best']['expected_total_cost'],1140))
check('SRC-commitment-delay',s['best']['scenarios'][1]['shortage']==40 and eq(s['best']['expected_shortage'],12))
c=R['cash'];check('CASH-before-remit',c['rows'][4]['closing_receivables']==280 and c['rows'][4]['net_cash_change']==-50)
check('CASH-final',c['final']['closing_cash']==1348 and c['final']['cumulative_profit']==180 and c['final']['inventory_at_cost']==72)
check('CASH-refusal-no-revenue',c['rows'][3]['revenue']==0 and c['rows'][5]['return_fee']==5 and c['rows'][5]['damage_writeoff']==8)
v=R['metrics']['summary'];check('KPI-financial-DOI',eq(v['DOI_gross_cost'],15.393939393939393) and eq(v['DOI_net_book'],15.381818181818181))
check('KPI-coverage-different',eq(v['ending_historical_runrate_coverage_days'],20/11) and not eq(v['DOI_gross_cost'],v['ending_historical_runrate_coverage_days']))
check('KPI-waste-markdown-impairment',eq(v['waste_rate_inflow'],1/15) and v['markdown_loss']==220 and v['ending_impairment']==16)
check('KPI-closure-denominators',eq(v['forced_close_rate_original_cohort'],.05) and eq(v['forced_close_rate_matured'],.0625))
check('KPI-service-three-rates',R['metrics']['service_episode_summary']==dict(instock_time_rate=.75,complete_order_rate=.5,unit_fill_rate=.65))
check('KPI-dual-track',eq(v['WAPE_system'],24/132) and eq(v['WAPE_human'],18/132) and eq(v['Brier'],.24) and eq(v['FVA'],6/132))
d=copy.deepcopy(D['production'])
for w in d['manufacturing']['weeks']:w['demand']={'A':0,'B':0}
z=run.production(d);check('BOUNDARY-zero-active-lines',z['manufacturing']['due_lines']==0 and z['manufacturing']['due_line_completion'] is None)
d=copy.deepcopy(D['production']);d['manufacturing']['priority']=['B','A'];z=run.production(d);check('PERTURB-priority-label',z['manufacturing']['policy'].startswith('B then A'))
d=copy.deepcopy(D['network']);d['low']=[0]*6;d['high']=[0]*6;z=run.network(d);check('BOUNDARY-zero-network-demand',z['independent']['fixed']['central']['aggregate_fill_rate'] is None)
# Valid input changes must flow through calculations, rather than returning constants.
d=copy.deepcopy(D['sourcing']);d['shortage_cost']=0;z=run.sourcing(d);check('PERTURB-shortage-cost-changes-choice',z['best']['additional_A']==80 and z['best']['additional_B']==0)
d=copy.deepcopy(D['network']);d['cost']['transport_per_unit_edge']=0;z=run.network(d);check('PERTURB-transport-changes-ranking',z['independent']['fixed']['mixed']['expected_cost']<z['independent']['fixed']['decentral']['expected_cost'])
d=copy.deepcopy(D['sop']);d['base']['months'][0]['capacity']=50;z=run.sop(d);check('PERTURB-supply-not-demand',z['base']['rows'][0]['consensus_demand']==100 and z['base']['rows'][0]['closing_backlog']==30)
d=copy.deepcopy(D['production']);d['manufacturing']['weeks'][1]['chip_arrival']=0;z=run.production(d);check('PERTURB-late-chip-affects-week',z['manufacturing']['rows'][1]['produced_A']==2)
d=copy.deepcopy(D['cash']);d['orders'][0]['collect_day']=8;z=run.cash(d);check('PERTURB-collection-not-profit',z['rows'][5]['closing_receivables']>c['rows'][5]['closing_receivables'] and z['final']['cumulative_profit']==180)
d=copy.deepcopy(D['metrics']);
for row in d['daily']:row['demand']=0;row['waste']=0
z=run.metrics(d);check('BOUNDARY-zero-COGS',z['summary']['DOI_gross_cost'] is None and z['summary']['WAPE_system'] is None)
mutations=[
 ('BAD-fractional-salvage-day','cash',['salvage_day'],6.5),
 ('BAD-fractional-shell','production',['manufacturing','initial_shells'],0.5),
 ('BAD-fractional-chip','production',['manufacturing','initial_chips'],10.5),
 ('BAD-gapped-months','sop',['base','months',11,'month'],'2027-12'),
 ('BAD-fractional-collection-day','cash',['orders',0,'collect_day'],5.5),
 ('BAD-rolling-backlog','sop',['rolling','opening_backlog'],1),
 ('BAD-inconsistent-actual-backlog','sop',['december_actual','closing_backlog'],1),
 ('BAD-kitchen-week-order','production',['kitchen','weeks',1,'week'],3),
 ('BAD-kitchen-date-order','production',['kitchen','weeks',1,'production_date'],'2026-12-02'),
 ('BAD-manufacture-week-order','production',['manufacturing','weeks',1,'week'],3),
 ('BAD-negative-capacity','sop',['base','months',0,'capacity'],-1),
 ('BAD-roll-opening','sop',['rolling','opening_inventory'],999),
 ('BAD-duplicate-month','sop',['base','months',1,'month'],'2026-12'),
 ('BAD-kitchen-yield','production',['kitchen','sauce_bom','tomato_kg_per_good_kg'],0),
 ('BAD-kitchen-date','production',['kitchen','weeks',0,'production_date'],'2026-12-05'),
 ('BAD-chip-reservation','production',['manufacturing','reserved_chips'],11),
 ('BAD-priority-double','production',['manufacturing','priority'],['A','A']),
 ('BAD-negative-arrival','production',['manufacturing','weeks',1,'chip_arrival'],-1),
 ('BAD-unfair-initial','network',['placements','mixed'],[30,10,10,10,10]),
 ('BAD-zero-lead','network',['edges',0,'lead_days'],0),
 ('BAD-negative-cost','network',['cost','holding_per_unit_day'],-1),
 ('BAD-no-feasible-supplier','sourcing',['suppliers','B','total_capacity'],0), # A can still fulfill, handled separately below
 ('BAD-scenario-probability','sourcing',['scenarios',0,'probability'],.8),
 ('BAD-negative-shortage-cost','sourcing',['shortage_cost'],-1),
 ('BAD-mixed-currency','cash',['currency'],'USD+CNY'),
 ('BAD-early-collection','cash',['orders',0,'collect_day'],1),
 ('BAD-return-over-quantity','cash',['orders',1,'resalable_qty'],6),
 ('BAD-presale-overlap','metrics',['presale_cohort','forced_close'],6),
 ('BAD-probability-range','metrics',['daily',0,'event_probability'],1.2),
 ('BAD-duplicate-day','metrics',['daily',1,'day'],1),
 ('BAD-overfill','metrics',['service_episode',0,'filled'],5),
]
for name,lab,path,val in mutations:
    if name=='BAD-no-feasible-supplier':
        def impossible(d):d['suppliers']['A']['total_capacity']=20;d['suppliers']['B']['total_capacity']=0
        rejects(name,lab,impossible)
    else: rejects(name,lab,lambda d,p=path,v=val:setpath(d,p,v))
# Verify delivered output bytes represent these inputs; a stale or edited answer is rejected.
stored=json.loads((BASE/'outputs'/'results.json').read_text())
check('ARTIFACT-results-recomputed',stored==R)
report={'status':'passed','count':len(checks),'checks':checks,'scope':'Authored test suite, not independent audit or real business validation.'}
(BASE/'outputs'/'test_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks)},ensure_ascii=False))
