"""Six synthetic planning labs. Python 3.10+, standard library only.
No external service, fitted forecasting model, MILP solver, or enterprise action.
All quantities/costs are recomputed from files under --data.
"""
from __future__ import annotations
import argparse, copy, csv, itertools, json, math
from datetime import date
from pathlib import Path

def require(test, message):
    if not test: raise ValueError(message)
def nonneg(x, name):
    require(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and x>=0, f'{name} must be finite and nonnegative')
def integer(x,name):
    nonneg(x,name); require(int(x)==x,f'{name} must be an integer')
def close(a,b): return math.isclose(a,b,abs_tol=1e-8,rel_tol=1e-9)
def ratio(n,d): return None if d==0 else n/d

def plan_version(v):
    date.fromisoformat(v['cutoff'])
    require(len(v['months'])==12,'S&OP requires exactly 12 months')
    month_ids=[date.fromisoformat(r['month']+'-01').year*12+date.fromisoformat(r['month']+'-01').month for r in v['months']]
    require(all(b==a+1 for a,b in zip(month_ids,month_ids[1:])), 'S&OP months must be consecutive')
    require(len({r['month'] for r in v['months']})==12,'duplicate month')
    require([r['month'] for r in v['months']]==sorted(r['month'] for r in v['months']),'months must be sorted')
    for k in ['opening_inventory','opening_backlog','safety_target']: nonneg(v[k],k)
    decisions={}; accepted=[]; rejected=[]
    for c in sorted(v['cpfr'],key=lambda c:(c['available_at'],c['id'])):
        date.fromisoformat(c['available_at']); nonneg(c['consensus'],'consensus')
        if c['available_at']>v['cutoff']: rejected.append(c['id']); continue
        require(c['month'] in {r['month'] for r in v['months']},'CPFR outside horizon')
        decisions[c['month']]=c; accepted.append(c['id'])
    inv=v['opening_inventory']; backlog=v['opening_backlog']; rows=[]
    for r in v['months']:
        for k in ['system_demand','customer_demand','finance_target_revenue','capacity','unit_price','unit_production_cost']: nonneg(r[k],k)
        d=decisions.get(r['month'],{}).get('consensus',r['system_demand'])
        required=d+backlog; production=min(r['capacity'],max(0,required+v['safety_target']-inv))
        available=inv+production; fulfilled=min(available,required)
        end=available-fulfilled; back_end=required-fulfilled
        row=dict(version=v['version'],cutoff=v['cutoff'],month=r['month'],system_demand=r['system_demand'],customer_demand=r['customer_demand'],shared_gap=r['customer_demand']-r['system_demand'],cpfr_exception=abs(r['customer_demand']-r['system_demand'])>0.1*max(r['system_demand'],1),consensus_demand=d,demand_status=('approved_cpfr' if r['month'] in decisions else ('provisional_unresolved_exception' if abs(r['customer_demand']-r['system_demand'])>0.1*max(r['system_demand'],1) else 'system_working_plan')),opening_inventory=inv,opening_backlog=backlog,capacity=r['capacity'],production=production,fulfilled=fulfilled,closing_inventory=end,closing_backlog=back_end,finance_target_revenue=r['finance_target_revenue'],feasible_revenue=fulfilled*r['unit_price'],production_spend=production*r['unit_production_cost'])
        require(close(inv+production,fulfilled+end),'S&OP stock balance')
        require(close(backlog+d,fulfilled+back_end),'S&OP backlog balance')
        require(production<=r['capacity'],'S&OP capacity')
        rows.append(row); inv=end; backlog=back_end
    return dict(rows=rows,accepted_cpfr=accepted,rejected_cpfr=rejected,total_consensus=sum(r['consensus_demand'] for r in rows),total_fulfilled=sum(r['fulfilled'] for r in rows),ending_backlog=backlog)

def sop(x):
    a=x['december_actual']; require(close(a['opening_inventory']+a['production'],a['fulfilled']+a['closing_inventory']),'December actual does not balance')
    for k in ['opening_inventory','production','fulfilled','closing_inventory','demand','opening_backlog','closing_backlog']: nonneg(a[k],k)
    require(close(a['opening_backlog']+a['demand'],a['fulfilled']+a['closing_backlog']), 'December actual backlog does not balance')
    require(close(a['closing_backlog'],x['rolling']['opening_backlog']), 'rolling opening backlog is not actual closing backlog')
    require(close(a['closing_inventory'],x['rolling']['opening_inventory']),'rolling opening is not actual closing')
    require(x['base']['months'][1]['month']==x['rolling']['months'][0]['month'],'rolling window did not move')
    return {'base':plan_version(x['base']),'rolling':plan_version(x['rolling']), 'december_actual':a}

def kitchen(x):
    require([w['week'] for w in x['weeks']]==list(range(1,len(x['weeks'])+1)), 'kitchen weeks must be consecutive')
    prod_dates=[date.fromisoformat(w['production_date']) for w in x['weeks']]
    require(all(b>a for a,b in zip(prod_dates,prod_dates[1:])), 'kitchen production dates must increase')
    for w in x['weeks']: date.fromisoformat(w['delivery_date'])
    for a in x['tomato_arrivals']: date.fromisoformat(a['date'])
    sauce=x['initial_sauce_kg']; tomato=x['initial_tomato_kg']; spice=x['initial_spice_kg']; seen=set(); rows=[]
    for v in [sauce,tomato,spice]: nonneg(v,'kitchen initial stock')
    raw=x['sauce_bom']; require(raw['tomato_kg_per_good_kg']>0 and raw['spice_kg_per_good_kg']>0,'BOM coefficients must be positive')
    for v in x['dishes'].values(): require(v['sauce_kg']>0,'dish BOM coefficient must be positive')
    for w in x['weeks']:
        require(w['production_date']<=w['delivery_date'],'production after delivery')
        nonneg(w['sauce_capacity_kg'],'sauce capacity')
        arrived=0
        for j,a in enumerate(x['tomato_arrivals']):
            nonneg(a['qty'],'tomato arrival')
            if j not in seen and a['date']<=w['production_date']: arrived+=a['qty']; seen.add(j)
        tomato+=arrived
        for v in w['demand'].values(): integer(v,'dish demand')
        gross=sum(q*x['dishes'][k]['sauce_kg'] for k,q in w['demand'].items())
        start=sauce
        make=min(max(0,gross-sauce),w['sauce_capacity_kg'],tomato/raw['tomato_kg_per_good_kg'],spice/raw['spice_kg_per_good_kg'])
        tomato-=make*raw['tomato_kg_per_good_kg']; spice-=make*raw['spice_kg_per_good_kg']; sauce+=make
        fulfilled={}; lost={}
        for k in ['A','B']:
            q=min(w['demand'][k],math.floor((sauce+1e-8)/x['dishes'][k]['sauce_kg']))
            sauce-=q*x['dishes'][k]['sauce_kg']; fulfilled[k]=q; lost[k]=w['demand'][k]-q
        consumed=sum(q*x['dishes'][k]['sauce_kg'] for k,q in fulfilled.items())
        require(close(start+make,consumed+sauce),'kitchen semi-finished stock balance')
        require(min(tomato,spice,sauce)>-1e-7,'negative kitchen stock')
        rows.append(dict(week=w['week'],production_date=w['production_date'],delivery_date=w['delivery_date'],demand_A=w['demand']['A'],demand_B=w['demand']['B'],gross_sauce_need_kg=gross,opening_sauce_kg=start,tomato_arrival_eligible_kg=arrived,sauce_produced_kg=make,sauce_consumed_kg=consumed,fulfilled_A=fulfilled['A'],fulfilled_B=fulfilled['B'],unserved_A=lost['A'],unserved_B=lost['B'],closing_sauce_kg=max(0,sauce),closing_tomato_kg=tomato,closing_spice_kg=spice))
    return dict(rows=rows,ignored_late_arrivals=[a for j,a in enumerate(x['tomato_arrivals']) if j not in seen],policy='A before B, just-in-time semi-finished production; heuristic; unmet restaurant demand lost, not backlogged')

def manufacturing(x):
    require([w['week'] for w in x['weeks']]==list(range(1,len(x['weeks'])+1)), 'manufacturing weeks must be consecutive')
    for k in ['initial_chips','reserved_chips','initial_cores','initial_resin_kg','initial_shells']: nonneg(x[k],k)
    for k in ['initial_chips','reserved_chips','initial_cores','initial_shells']: integer(x[k],k)
    require(x['reserved_chips']<=x['initial_chips'],'reserved exceeds physical chips')
    require(set(x['priority'])=={'A','B'} and len(x['priority'])==2,'priority must contain A and B once')
    for v in x['finished_to_core'].values(): require(v>0 and int(v)==v,'core BOM must be positive integer')
    require(x['core_to_raw']['chip']==1,'this lab fixes one chip per core')
    require(x['core_to_raw']['resin_kg']>0,'resin BOM must be positive')
    chips=x['initial_chips']-x['reserved_chips']; cores=x['initial_cores']; resin=x['initial_resin_kg']; shells=x['initial_shells']; backlog={'A':0,'B':0}; rows=[]; total_demand=total_produced=full_lines=active_lines=0
    for w in x['weeks']:
        for k in ['chip_arrival','core_capacity','final_capacity']: integer(w[k],k)
        chips+=w['chip_arrival']; final_remaining=w['final_capacity']; core_remaining=w['core_capacity']; produced={}; due={}; begin_chips=chips; begin_cores=cores; new_cores=0
        for k in x['priority']:
            integer(w['demand'][k],'finished demand'); due[k]=w['demand'][k]+backlog[k]; total_demand+=w['demand'][k]
            rate=x['finished_to_core'][k]
            feasible_new=min(chips,math.floor((resin+1e-8)/x['core_to_raw']['resin_kg']),core_remaining)
            q=min(due[k],final_remaining,shells,math.floor((cores+feasible_new)/rate))
            need=max(0,q*rate-cores); chips-=need; resin-=need*x['core_to_raw']['resin_kg']; core_remaining-=need; new_cores+=need; cores+=need-q*rate; shells-=q; final_remaining-=q; produced[k]=q; backlog[k]=due[k]-q
            full_lines+=int(due[k]>0 and q==due[k]); active_lines+=int(due[k]>0); total_produced+=q
        require(close(begin_chips-chips,new_cores),'chip conservation')
        require(close(begin_cores+new_cores,sum(produced[k]*x['finished_to_core'][k] for k in produced)+cores),'core conservation')
        require(min(chips,cores,resin,shells,core_remaining,final_remaining)>=-1e-8,'negative manufacturing resource')
        rows.append(dict(week=w['week'],chip_arrival=w['chip_arrival'],opening_usable_chips=begin_chips,due_A=due['A'],due_B=due['B'],produced_A=produced['A'],produced_B=produced['B'],new_cores=new_cores,closing_chips=chips,closing_cores=cores,closing_shells=shells,backlog_A=backlog['A'],backlog_B=backlog['B'],unconstrained_shell_need=sum(due.values()),released_shell_consumption=sum(produced.values())))
    return dict(rows=rows,total_new_demand=total_demand,total_produced=total_produced,period_unit_completion=ratio(total_produced,total_demand),fully_kitted_due_lines=full_lines,due_lines=active_lines,due_line_completion=ratio(full_lines,active_lines),initial_reserved_chips_untouched=x['reserved_chips'],shell_procurement_sensitivity=dict(assumed_available_shells=10,actual_initial_shells=x['initial_shells'],unconstrained_net_need=max(0,total_demand-10),feasible_plan_net_need=max(0,total_produced-10),caution='Separate what-if, not an actual purchase. Actual initial shells are reported separately; no procurement operation is executed.'),policy=' then '.join(x['priority'])+', no future arrivals borrowed; heuristic, not global APS optimum')

def production(x): return dict(kitchen=kitchen(x['kitchen']),manufacturing=manufacturing(x['manufacturing']))

def network_scenarios(x,kind):
    pairs=[('low','low',.5),('high','high',.5)] if kind=='correlated' else [(a,b,.25) for a in ['low','high'] for b in ['low','high']]
    return [(f'{a}_{b}',p,{'F1':x[a],'F2':x[b]}) for a,b,p in pairs]

def simulate_network(x,placement,demands):
    stock=dict(zip(x['nodes'],placement)); pipe=[]; rows=[]; cum_served=lost=transport=holding=0
    # Downstream first: a received item can move the next edge in the evening,
    # but not arrive before its recorded due day.
    edges=sorted(x['edges'],key=lambda e:0 if e['dest'].startswith('F') else 1)
    for day in range(1,len(x['low'])+1):
        opening=dict(stock); arrived={n:0 for n in stock}; shipped={n:0 for n in stock}; served={n:0 for n in stock}
        for p in pipe:
            if p['due']==day: stock[p['dest']]+=p['qty']; arrived[p['dest']]+=p['qty']
        pipe=[p for p in pipe if p['due']>day]
        today_demand={n:0 for n in stock}; today_lost=0
        for n in ['F1','F2']:
            d=demands[n][day-1]; today_demand[n]=d; served[n]=min(stock[n],d); stock[n]-=served[n]; cum_served+=served[n]; today_lost+=d-served[n]
        lost+=today_lost
        for e in edges:
            src,dst=e['source'],e['dest']; in_bound=sum(p['qty'] for p in pipe if p['dest']==dst)
            need=max(0,x['target'][dst]-stock[dst]-in_bound)
            q=min(stock[src],need); stock[src]-=q; shipped[src]+=q; transport+=q*x['cost']['transport_per_unit_edge']
            if q: pipe.append(dict(source=src,dest=dst,qty=q,due=day+e['lead_days']))
        intransit=sum(p['qty'] for p in pipe); holding+=(sum(stock.values())+intransit)*x['cost']['holding_per_unit_day']
        require(close(sum(stock.values())+intransit+cum_served,x['total_initial']),'network whole-system conservation')
        for n in x['nodes']:
            require(close(opening[n]+arrived[n]-served[n]-shipped[n],stock[n]),'network node conservation')
            rows.append(dict(day=day,node=n,opening=opening[n],arrivals=arrived[n],demand=today_demand[n],served=served[n],lost=today_demand[n]-served[n],shipments=shipped[n],closing=stock[n],inbound_pipeline=sum(p['qty'] for p in pipe if p['dest']==n),system_intransit=intransit,system_cumulative_served=cum_served))
    total_d=sum(sum(v) for v in demands.values())
    return dict(rows=rows,total_demand=total_d,served=cum_served,lost=lost,fill_rate=ratio(cum_served,total_d),holding_cost=holding,transport_cost=transport,shortage_cost=lost*x['cost']['lost_per_unit'],total_cost=holding+transport+lost*x['cost']['lost_per_unit'],ending_onhand=sum(stock.values()),ending_pipeline=sum(p['qty'] for p in pipe))

def compositions(total,n):
    if n==1: yield (total,); return
    for first in range(total+1):
        for tail in compositions(total-first,n-1): yield (first,)+tail

def network(x):
    require(x['nodes']==['CDC','R1','R2','F1','F2'],'expected five ordered nodes')
    integer(x['total_initial'],'network total'); integer(x['placement_step'],'placement step'); require(x['placement_step']>0 and x['total_initial']%x['placement_step']==0,'invalid placement step')
    require(len(x['low'])==len(x['high']) and len(x['low'])>0,'scenario horizons differ')
    for v in x['low']+x['high']: nonneg(v,'network demand')
    for v in x['cost'].values(): nonneg(v,'network cost')
    for e in x['edges']: integer(e['lead_days'],'lead days'); require(e['lead_days']>=1,'lead must be positive')
    for v in x['target'].values(): nonneg(v,'node target')
    for placement in x['placements'].values():
        require(len(placement)==5 and close(sum(placement),x['total_initial']),'unfair initial stock')
        for v in placement: nonneg(v,'placement')
    results={}; ledgers=[]
    for kind in ['independent','correlated']:
        scenarios=network_scenarios(x,kind)
        def evaluate(place,keep=False):
            out={k:0 for k in ['expected_cost','expected_served','expected_demand','expected_lost','expected_holding','expected_transport']}
            for sid,p,ds in scenarios:
                s=simulate_network(x,place,ds)
                for dst,src in [('expected_cost','total_cost'),('expected_served','served'),('expected_demand','total_demand'),('expected_lost','lost'),('expected_holding','holding_cost'),('expected_transport','transport_cost')]: out[dst]+=p*s[src]
                if keep:
                    ledgers.extend(dict(r,dependence=kind,placement=keep,scenario=sid,probability=p) for r in s['rows'])
            out['aggregate_fill_rate']=ratio(out['expected_served'],out['expected_demand']); return out
        fixed={name:evaluate(place,name) for name,place in x['placements'].items()}
        candidates=[]
        for comp in compositions(x['total_initial']//x['placement_step'],5):
            place=[v*x['placement_step'] for v in comp]; score=evaluate(place); candidates.append(dict(placement=place,**score))
        best=min(candidates,key=lambda r:(r['expected_cost'],r['placement']))
        results[kind]=dict(fixed=fixed,grid_candidate_count=len(candidates),grid_best=best,optimality='Exact minimum over discrete initial placements only, conditional on this fixed greedy replenishment policy and specified scenarios. Not MEIO global optimum.')
    results['ledger']=ledgers; return results

def sourcing(x):
    for k in ['demand','due_day','committed_A','increment']: integer(x[k],k)
    require(x['increment']>0 and x['demand']>=x['committed_A'],'invalid order quantity')
    require(close(sum(s['probability'] for s in x['scenarios']),1),'scenario probabilities must sum to 1')
    nonneg(x['shortage_cost'],'shortage cost')
    for s in x['scenarios']:
        require(0<=s['probability']<=1,'invalid probability'); nonneg(s['A_arrival'],'A arrival'); nonneg(s['B_arrival'],'B arrival')
    for spec in x['suppliers'].values():
        for k,v in spec.items(): nonneg(v,k)
    need=x['demand']-x['committed_A']; candidates=[]; A=x['suppliers']['A']; B=x['suppliers']['B']
    for qa in range(0,need+1,x['increment']):
        qb=need-qa
        if qb%x['increment']: continue
        if (qa and qa<A['moq']) or (qb and qb<B['moq']): continue
        if qa+x['committed_A']>A['total_capacity'] or qb>B['total_capacity']: continue
        purchase=qa*A['unit_cost']+qb*B['unit_cost']+bool(qa)*A['fixed_cost']+bool(qb)*B['fixed_cost']
        shortage=ontime=0; scenario_results=[]
        for s in x['scenarios']:
            arrived=(qa+x['committed_A'] if s['A_arrival']<=x['due_day'] else 0)+(qb if s['B_arrival']<=x['due_day'] else 0)
            missing=max(0,x['demand']-arrived); shortage+=s['probability']*missing; ontime+=s['probability']*(missing==0)
            scenario_results.append(dict(scenario=s['id'],on_time_units=arrived,shortage=missing))
        candidates.append(dict(additional_A=qa,additional_B=qb,purchase_and_fixed_cost=purchase,expected_shortage=shortage,probability_complete_on_time=ontime,expected_total_cost=purchase+shortage*x['shortage_cost'],scenarios=scenario_results))
    require(bool(candidates),'no feasible sourcing allocation')
    return dict(candidates=candidates,best=min(candidates,key=lambda r:r['expected_total_cost']),optimality='Exhaustive minimum among all permitted lot-size allocations for fixed release date and given joint scenarios; no proof for continuous orders, other dates, or unmodeled suppliers.')

def cash(x):
    require(x['currency']=='CNY','single-currency CNY lab; do not mix currencies')
    for k in ['opening_cash','opening_inventory_units','unit_cost','unit_price','outbound_per_unit','return_per_unit','salvage_per_unit']: nonneg(x[k],k)
    integer(x['opening_inventory_units'],'opening inventory'); integer(x['horizon_days'],'horizon days'); integer(x['salvage_day'],'salvage day'); require(x['horizon_days']>0,'horizon must be positive')
    require(len({o['id'] for o in x['orders']})==len(x['orders']),'duplicate order id')
    for o in x['orders']:
        for k in ['qty','ship_day','outcome_day']: integer(o[k],k)
        for k in ['collect_day','return_day','resalable_qty']:
            if k in o: integer(o[k],k)
        integer(o['qty'],'order qty'); require(o['outcome'] in ['delivered','refused'],'unknown outcome'); require(o['outcome_day']>=o['ship_day'],'outcome before ship')
        if o['outcome']=='delivered': require(o['collect_day']>=o['outcome_day'],'collection before delivery')
        else: require(o['return_day']>=o['outcome_day'],'return before refusal'); require(0<=o['resalable_qty']<=o['qty'],'invalid saleable return qty'); require(x['salvage_day']>=o['return_day'],'salvage before return')
    cash_balance=x['opening_cash']; stock=x['opening_inventory_units']; transit=0; ar=0; profit=0; rows=[]; damaged=0; total_revenue=0
    for day in range(x['horizon_days']):
        revenue=cogs=outbound=reverse=writeoff=collection=salvage=0
        for o in x['orders']:
            if o['ship_day']==day: stock-=o['qty']; transit+=o['qty']; outbound+=o['qty']*x['outbound_per_unit']
            if o['outcome_day']==day and o['outcome']=='delivered': transit-=o['qty']; revenue+=o['qty']*x['unit_price']; cogs+=o['qty']*x['unit_cost']
            if o['outcome']=='delivered' and o['collect_day']==day: collection+=o['qty']*x['unit_price']
            if o['outcome']=='refused' and o['return_day']==day:
                transit-=o['qty']; stock+=o['resalable_qty']; n=o['qty']-o['resalable_qty']; damaged+=n; writeoff+=n*x['unit_cost']; reverse+=o['qty']*x['return_per_unit']
        if day==x['salvage_day']: salvage=damaged*x['salvage_per_unit']
        ar+=revenue-collection; cash_balance+=collection+salvage-outbound-reverse; profit+=revenue-cogs-outbound-reverse-writeoff+salvage; total_revenue+=revenue
        require(min(stock,transit,ar)>=0,'cash ledger negative quantity or receivable')
        require(close(cash_balance+ar+(stock+transit)*x['unit_cost'],x['opening_cash']+x['opening_inventory_units']*x['unit_cost']+profit),'cash balance sheet identity failed')
        rows.append(dict(day=day,currency=x['currency'],revenue=revenue,COGS=cogs,outbound_fee=outbound,return_fee=reverse,damage_writeoff=writeoff,collections=collection,salvage_cash=salvage,closing_cash=cash_balance,closing_receivables=ar,onhand_units=stock,intransit_units=transit,inventory_at_cost=(stock+transit)*x['unit_cost'],cumulative_profit=profit,net_cash_change=cash_balance-x['opening_cash']))
    return dict(rows=rows,total_revenue=total_revenue,final=rows[-1],notes='Opening inventory was paid before day 0; no accounts payable, tax, refunds, FX, or financing. Delivery recognizes COD revenue; refusal never recognizes revenue. Salved damage has zero carrying value after writeoff.')

def metrics(x):
    require(x['period_days']==len(x['daily']) and x['period_days']>0,'daily ledger length differs from period')
    for k in ['opening_units','unit_cost','list_price','closing_nrv_per_unit']: nonneg(x[k],k)
    stock=x['opening_units']; rows=[]; sales=cogs=rev=waste=receipts=err_sys=err_human=brier=actual=markdown=marked_list=all_list=0
    for i,d in enumerate(x['daily'],1):
        require(d['day']==i,'daily sequence missing or duplicate')
        for k in ['receipts','demand','system_forecast','human_forecast','waste','selling_price']: nonneg(d[k],k)
        require(0<=d['event_probability']<=1,'probability outside [0,1]')
        begin=stock; stock+=d['receipts']; fulfilled=min(stock,d['demand']); stock-=fulfilled; require(d['waste']<=stock,'waste exceeds remaining stock'); stock-=d['waste']
        sold_cost=fulfilled*x['unit_cost']; daily_revenue=fulfilled*d['selling_price']; write_down=stock*max(0,x['unit_cost']-x['closing_nrv_per_unit']) if i==x['period_days'] else 0
        book=stock*x['unit_cost']-write_down; rows.append(dict(day=i,opening_units=begin,receipts=d['receipts'],demand=d['demand'],sales_units=fulfilled,waste_units=d['waste'],closing_units=stock,COGS=sold_cost,revenue=daily_revenue,valuation_write_down=write_down,closing_inventory_gross_cost=stock*x['unit_cost'],closing_inventory_net_book=book,system_forecast=d['system_forecast'],human_forecast=d['human_forecast'],event_probability=d['event_probability'],event_observed=int(d['demand']>=5),override_reason=d['override_reason']))
        sales+=fulfilled; cogs+=sold_cost; rev+=daily_revenue; waste+=d['waste']; receipts+=d['receipts']; actual+=d['demand']; err_sys+=abs(d['demand']-d['system_forecast']); err_human+=abs(d['demand']-d['human_forecast']); brier+=(d['event_probability']-int(d['demand']>=5))**2; all_list+=fulfilled*x['list_price']
        if d['selling_price']<x['list_price']: markdown+=fulfilled*(x['list_price']-d['selling_price']); marked_list+=fulfilled*x['list_price']
        require(close(begin+d['receipts'],fulfilled+d['waste']+stock),'monthly inventory conservation')
    cohort=x['presale_cohort']
    for v in cohort.values(): integer(v,'presale count')
    require(cohort['initial_orders']==sum(cohort[k] for k in ['shipped','natural_cancel','forced_close','not_yet_due']),'presale terminal state mismatch')
    require(cohort['matured_non_cancelled_orders']==cohort['shipped']+cohort['forced_close'],'matured denominator mismatch')
    episodes=x['service_episode']
    for e in episodes:
        require(0<=e['filled']<=e['ordered'] and 0<=e['instock_minutes']<=e['minutes'],'invalid service episode')
    avg_gross=sum(r['closing_inventory_gross_cost'] for r in rows)/x['period_days']; avg_net=sum(r['closing_inventory_net_book'] for r in rows)/x['period_days']
    return dict(rows=rows,summary=dict(sales_units=sales,total_demand=actual,COGS=cogs,revenue=rev,average_inventory_gross_cost=avg_gross,average_inventory_net_book=avg_net,DOI_gross_cost=None if cogs==0 else avg_gross/cogs*x['period_days'],DOI_net_book=None if cogs==0 else avg_net/cogs*x['period_days'],ending_historical_runrate_coverage_days=None if actual==0 else stock/(actual/x['period_days']),waste_units=waste,waste_rate_inflow=ratio(waste,x['opening_units']+receipts),markdown_loss=markdown,markdown_rate_marked_sales=ratio(markdown,marked_list),markdown_rate_all_sales=ratio(markdown,all_list),ending_impairment=rows[-1]['valuation_write_down'],ending_impairment_rate=ratio(rows[-1]['valuation_write_down'],rows[-1]['closing_inventory_gross_cost']),forced_close_rate_original_cohort=ratio(cohort['forced_close'],cohort['initial_orders']),forced_close_rate_matured=ratio(cohort['forced_close'],cohort['matured_non_cancelled_orders']),natural_cancel_rate=ratio(cohort['natural_cancel'],cohort['initial_orders']),WAPE_system=ratio(err_sys,actual),WAPE_human=ratio(err_human,actual),FVA=ratio(err_sys-err_human,actual),Brier=brier/x['period_days'],monthly_unit_fill=ratio(sales,actual)),service_episode_summary=dict(instock_time_rate=ratio(sum(e['instock_minutes'] for e in episodes),sum(e['minutes'] for e in episodes)),complete_order_rate=ratio(sum(e['filled']==e['ordered'] for e in episodes),len(episodes)),unit_fill_rate=ratio(sum(e['filled'] for e in episodes),sum(e['ordered'] for e in episodes))))

RUNNERS={'sop':sop,'production':production,'network':network,'sourcing':sourcing,'cash':cash,'metrics':metrics}
def load_data(path): return {name:json.loads((path/(name+'.json')).read_text()) for name in RUNNERS}
def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=Path(__file__).parent/'data');p.add_argument('--out',type=Path,default=Path(__file__).parent/'outputs');args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    data=load_data(args.data); result={k:fn(data[k]) for k,fn in RUNNERS.items()}
    (args.out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    write_csv(args.out/'sop_base.csv',result['sop']['base']['rows']);write_csv(args.out/'sop_rolling.csv',result['sop']['rolling']['rows']);write_csv(args.out/'kitchen.csv',result['production']['kitchen']['rows']);write_csv(args.out/'manufacturing.csv',result['production']['manufacturing']['rows']);write_csv(args.out/'network_ledger.csv',result['network']['ledger']);write_csv(args.out/'cash_ledger.csv',result['cash']['rows']);write_csv(args.out/'monthly_kpi_ledger.csv',result['metrics']['rows'])
    write_csv(args.out/'sourcing_candidates.csv',[{k:v for k,v in c.items() if k!='scenarios'} for c in result['sourcing']['candidates']])
    print(json.dumps({'status':'passed','labs':list(result),'network_ledger_rows':len(result['network']['ledger']),'results':str(args.out/'results.json')},ensure_ascii=False))
if __name__=='__main__':main()
