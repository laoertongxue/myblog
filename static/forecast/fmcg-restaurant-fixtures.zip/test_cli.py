"""Strict command-line contract: typos must fail before calculations or writes."""
import subprocess,sys,tempfile,shutil
from pathlib import Path
SOURCE=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as temp:
    folder=Path(temp)/'fixtures'
    shutil.copytree(SOURCE,folder)
    output=folder/'results_from_csv.json'
    for bad in ('–self-test','—self-test','--self-tes','--unknown','--self-test=1'):
        output.unlink(missing_ok=True)
        result=subprocess.run([sys.executable,str(folder/'run_cases.py'),bad],text=True,capture_output=True)
        assert result.returncode==2,(bad,result.returncode,result.stdout,result.stderr)
        assert 'error:' in result.stderr
        assert 'PASS:' not in result.stdout
        assert not output.exists(),(bad,'ran calculations despite invalid argument')
    for flags in ([],['--self-test']):
        result=subprocess.run([sys.executable,str(folder/'run_cases.py'),*flags],text=True,capture_output=True)
        assert result.returncode==0,(flags,result.stderr)
        assert 'PASS: all ten case answers' in result.stdout
        assert ('PASS: nine invalid' in result.stdout)==bool(flags)
        assert output.exists()
print('PASS CLI: five malformed flags rejected with exit 2 before output writes; normal and ASCII --self-test runs passed.')
