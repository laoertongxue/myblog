"""Read the delivered CSV inputs; calculate and check all ten cases."""
import csv,json,math,sys,copy,argparse
from pathlib import Path
from datetime import datetime
P=Path(__file__).resolve().parent

def rows(name):
    return list(csv.DictReader((P/name).open()))
def n(row,key):
    value=float(row[key])
    if not math.isfinite(value):raise ValueError('Nonfinite input: '+key)
    return value
def weather(row,p):
    if datetime.fromisoformat(row['forecast_issued_at'])>datetime.fromisoformat(row['prediction_origin']):
        raise ValueError('Weather leakage: issued after prediction origin')
    w=n(row,'weekend_flag');assert w in (0,1)
    return p['intercept']+p['temperature_coef']*(n(row,'forecast_temperature_C')-p['reference_temperature'])+p['weekend_coef']*w

def calculate(overrides=None):
    originals=globals()['rows']
    overrides=overrides or {}
    rows=lambda name: copy.deepcopy(overrides[name]) if name in overrides else originals(name)
    params=json.loads((P/'model_parameters.json').read_text());out={}
    b=rows('f1_baseline.csv');hist=rows('f1_promo_history.csv')
    assert all(n(r,'promotion')==0 and n(r,'stockout')==0 for r in b)
    base=sum(n(r,'sales_bags') for r in b)/len(b)
    uplift=sum(n(r,'uplift_rate') for r in hist)/len(hist)
    out['F1_event_forecast']={'baseline':base,'mean_uplift':uplift,'forecast':base*(1+uplift)}
    out['F1']=[base*(1+u) for u in params['F1']['sensitivity_uplift']]
    r=rows('f2_postpromo_inputs.csv')[0];base=n(r,'baseline_week_bottles');dip=n(r,'increment_bottles')*n(r,'displacement_rate')
    f=[max(0,base-dip*n(r,k)) for k in ('week1_share','week2_share')]
    out['F2']=f+[max(0,sum(f)+n(r,'target_buffer')-n(r,'inventory')-n(r,'confirmed_receipt'))]
    out['F3']=[r and n(r,'z')*math.sqrt(n(r,'sigma_A_cases')**2+n(r,'sigma_B_cases')**2+2*n(r,'correlation')*n(r,'sigma_A_cases')*n(r,'sigma_B_cases')) for r in rows('f3_regions.csv')]
    rr=rows('f4_hierarchy.csv')
    if any(n(r,'national_total')<0 or n(r,'raw_forecast_units')<0 for r in rr):raise ValueError('F4 forecasts must be nonnegative')
    if any(not n(r,'national_total').is_integer() for r in rr):raise ValueError('F4 national total must be integer')
    total=int(n(rr[0],'national_total'));assert all(n(r,'national_total')==total for r in rr);s=sum(n(r,'raw_forecast_units') for r in rr);assert s>0
    raw=[total*n(r,'raw_forecast_units')/s for r in rr];q=[math.floor(v) for v in raw]
    for i in sorted(range(len(rr)),key=lambda i:(-(raw[i]-q[i]),rr[i]['warehouse']))[:total-sum(q)]:q[i]+=1
    out['F4']=q+[max(0,q[i]-n(r,'available_units')-n(r,'confirmed_receipt_units')) for i,r in enumerate(rr)]
    p=params['F5'];out['F5']=[max(0,p['intercept']+p['self_price_coef']*(n(r,'price_A_yuan')-p['reference_A'])+p['cross_price_coef']*(n(r,'price_B_yuan')-p['reference_B'])) for r in rows('f5_prices.csv')]
    cups={r['product']:n(r,'forecast_cups') for r in rows('r1_cup_forecast.csv')}
    bom=rows('r1_bom_excerpt.csv')
    if any(not 0<=n(r,'loss_fraction_of_input')<1 for r in bom):raise ValueError('R1 loss fraction must be in [0,1)')
    net=sum(cups[r['product']]*n(r,'net_kg_per_cup') for r in bom)
    gross=sum(cups[r['product']]*n(r,'net_kg_per_cup')/(1-n(r,'loss_fraction_of_input')) for r in bom)
    r=rows('r1_inventory.csv')[0];available=n(r,'usable_kg')+n(r,'receipt_before_open_kg');pack=n(r,'pack_kg');boxes=math.ceil(max(0,gross-available)/pack)
    out['R1']=[net,gross,boxes,available+boxes*pack-gross]
    out['R2']=[weather(r,params['R2']) for r in rows('r2_weather_asof.csv')]
    analogs=rows('r3_analogs.csv');assert math.isclose(sum(n(r,'preassigned_weight') for r in analogs),1)
    mult=sum(n(r,'multiplier')*n(r,'preassigned_weight') for r in analogs);r=rows('r3_packaging.csv')[0]
    base=n(r,'baseline_cups');existing=n(r,'existing_sleeves');pack=n(r,'units_per_box');high=max(n(x,'multiplier') for x in analogs)
    out['R3']=[mult,base*mult,math.ceil(max(0,base*mult-existing)/pack),math.ceil(max(0,base*high-existing)/pack)]
    rr=rows('r4_intraday.csv')
    if any(not 0<n(r,'share_until_11')<=1 for r in rr):raise ValueError('R4 elapsed sales share must be in (0,1]')
    if any(n(r,'central_supply_total_cup_equiv')<0 for r in rr):raise ValueError('R4 supply must be nonnegative')
    if len({n(r,'central_supply_total_cup_equiv') for r in rr})!=1:raise ValueError('R4 inconsistent central supply')
    full=[n(r,'sales_until_11_cups')/n(r,'share_until_11') for r in rr]
    gaps=[max(0,full[i]-n(r,'sales_until_11_cups')-n(r,'remaining_capacity_cup_equiv')) for i,r in enumerate(rr)]
    supply=n(rr[0],'central_supply_total_cup_equiv');g=sum(gaps);allocated=[min(supply,g)*v/g if g else 0 for v in gaps]
    out['R4']=full+allocated
    r=rows('r5_constraints.csv')[0];demand=rows('r5_demand_scenarios.csv');assert math.isclose(sum(n(x,'probability') for x in demand),1)
    out['R5']=[sum(n(x,'probability')*(n(r,'shortage_cost_yuan')*max(n(x,'demand_portions')-q,0)+n(r,'leftover_cost_yuan')*max(q-n(x,'demand_portions'),0)) for x in demand) for q in params['R5']['candidate_quantities']]
    capacity=n(r,'capacity_portions')
    if capacity<0:raise ValueError('R5 capacity must be nonnegative')
    candidates=params['R5']['candidate_quantities']
    feasible=[q for q in candidates if 0<=q<=capacity]
    costs=dict(zip(candidates,out['R5']))
    selected=min(feasible,key=lambda q:(costs[q],q)) if feasible else None
    out['R5_decision']={'capacity':capacity,'feasible_quantities':feasible,'rejected_quantities':[q for q in candidates if q not in feasible],'selected_quantity':selected,'selected_expected_cost':costs[selected] if selected is not None else None,'status':'feasible' if feasible else 'no_feasible_candidate'}
    return out

def main(argv=None):
    parser=argparse.ArgumentParser(description='Calculate simulated tutorial cases; use ASCII --self-test for fault-injection tests.',allow_abbrev=False)
    parser.add_argument('--self-test',action='store_true',help='Run input mutation and boundary checks after calculations.')
    args=parser.parse_args(argv)
    out=calculate();expected=json.loads((P/'expected_answers.json').read_text())
    for case,target in expected.items():
        answer=out[case]
        assert len(answer)==len(target)
        for x,y in zip(answer,expected[case]):assert math.isclose(x,y,abs_tol=1e-6,rel_tol=1e-8),(case,x,y)
    (P/'results_from_csv.json').write_text(json.dumps(out,indent=2))
    if args.self_test:
        r=rows('r2_weather_asof.csv')[0];p=json.loads((P/'model_parameters.json').read_text())['R2'];first=weather(r,p)
        changed=copy.deepcopy(r);changed['forecast_temperature_C']=str(n(r,'forecast_temperature_C')+1)
        assert math.isclose(weather(changed,p)-first,p['temperature_coef'])
        late=copy.deepcopy(r);late['forecast_issued_at']='2099-01-01T00:00:00+08:00'
        try:weather(late,p)
        except ValueError:pass
        else:raise AssertionError('Leakage not blocked')
        def inject_reject(filename,field,bad):
            mutated=rows(filename);mutated[0][field]=str(bad)
            try:calculate({filename:mutated})
            except ValueError:return
            raise AssertionError((filename,field,bad,'invalid value accepted'))
        for field in ('national_total','raw_forecast_units'):
            inject_reject('f4_hierarchy.csv',field,-1)
        for bad in (0,-.1,1.1,2):inject_reject('r4_intraday.csv','share_until_11',bad)
        for bad in (-.01,1,1.1):inject_reject('r1_bom_excerpt.csv','loss_fraction_of_input',bad)
        changed_sales=rows('f1_baseline.csv');changed_sales[0]['sales_bags']='120'
        changed_f1=calculate({'f1_baseline.csv':changed_sales})
        assert math.isclose(changed_f1['F1_event_forecast']['forecast'],165)
        assert math.isclose(out['F1_event_forecast']['forecast'],150)
        assert out['R5_decision']['feasible_quantities']==[80,100,110]
        assert out['R5_decision']['selected_quantity']==100
        changed=rows('r5_constraints.csv');changed[0]['capacity_portions']='90'
        limited=calculate({'r5_constraints.csv':changed})['R5_decision']
        assert limited['feasible_quantities']==[80] and limited['selected_quantity']==80 and limited['selected_expected_cost']==120
        changed[0]['capacity_portions']='70'
        none=calculate({'r5_constraints.csv':changed})['R5_decision']
        assert none['status']=='no_feasible_candidate' and none['selected_quantity'] is None
        changed[0]['capacity_portions']='60'
        assert calculate({'r5_constraints.csv':changed})['R5_decision']['selected_quantity'] is None
        print('PASS: F1 sales 90 to 120 changes event forecast 150 to 165 without a production assertion.')
        print('PASS: nine invalid F4/R4/R1 injections rejected; R5 capacity 110/90/70 changes feasible candidates and decisions.')
        print('PASS: CSV value perturbation changes forecast; late weather record blocked.')
    print('PASS: all ten case answers calculated from supplied CSV/JSON inputs.')

if __name__=='__main__':
    main()
