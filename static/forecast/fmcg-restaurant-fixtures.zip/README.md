# 十个行业案例输入包（修订版）

全部为独立模拟手算截面，不包含180天训练面板或禾味2门店×8原料完整表。R1明确只做椰浆一种原料、两个成品。

运行 `python run_cases.py --self-test`。脚本实际读取下列CSV与model_parameters.json，生成results_from_csv.json并对照expected_answers.json。另测试温度输入改变会改变输出、预测时点后的天气信息被拒绝。只需Python标准库。

verify_answers.py保留为独立公式交叉校验，不应被当作CSV加载器。完整作业还需学习者自行输出正文要求的图表、结论与逐步计算表。参数JSON提供已冻结的教学系数；不冒称真实拟合。

## 输入文件、行数与完整字段

- f1_baseline.csv：3行；字段：comparable_day, sales_bags, promotion, stockout。
- f1_promo_history.csv：2行；字段：event, uplift_rate。
- f2_postpromo_inputs.csv：1行；字段：baseline_week_bottles, increment_bottles, displacement_rate, week1_share, week2_share, inventory, confirmed_receipt, target_buffer。
- f3_regions.csv：3行；字段：scenario, sigma_A_cases, sigma_B_cases, correlation, z。
- f4_hierarchy.csv：3行；字段：warehouse, raw_forecast_units, available_units, confirmed_receipt_units, national_total。
- f5_prices.csv：4行；字段：scenario, price_A_yuan, price_B_yuan。
- r1_bom_excerpt.csv：2行；字段：product, material, net_kg_per_cup, loss_fraction_of_input。
- r1_cup_forecast.csv：2行；字段：store, product, forecast_cups。
- r1_inventory.csv：1行；字段：store, material, usable_kg, receipt_before_open_kg, pack_kg。
- r2_weather_asof.csv：4行；字段：scenario, forecast_issued_at, prediction_origin, target_date, forecast_temperature_C, weekend_flag。
- r3_analogs.csv：2行；字段：historical_event, multiplier, preassigned_weight。
- r3_packaging.csv：1行；字段：baseline_cups, existing_sleeves, units_per_box, lead_days。
- r4_intraday.csv：2行；字段：store, sales_until_11_cups, share_until_11, remaining_capacity_cup_equiv, central_supply_total_cup_equiv。
- r5_constraints.csv：1行；字段：shortage_cost_yuan, leftover_cost_yuan, capacity_portions。
- r5_demand_scenarios.csv：3行；字段：demand_portions, probability。

日期统一带UTC+08:00。r2_weather_asof.csv的发布时间早于预测起点、目标日期晚于预测起点。未来信息反例由--self-test在内存构造并拦截。

F1三行历史可比日不是连续日；F2透支系数为预先给定，未交历史拟合数据。F3标准差与相关性为场景参数。F4全国总量字段虽重复列出，但只能取一次，不得汇总三次。R4中央供给字段也是同一总量，不得按门店加总。R3活动权重在本例给定，不能凭当前活动结果重估。

R1单位为千克，配方损耗按投入量比例定义；R5份、F1袋、F2瓶、F3箱、F4件不可混加。模拟结果不证明经营效益。

## 已执行边界测试

--self-test将输入复制后故障注入，不改原CSV：F4负全国总量、负分仓量；R4比例0、-0.1、1.1；R1损耗-0.01、1、1.1，全部要求ValueError。R5容量110时可行80/100/110、选100；改为90时仅80可行、期望成本120；改为70时输出no_feasible_candidate且不选虚假方案。results_from_csv.json包含R5_decision，明确可行/拒绝候选、选择、成本及状态。所有数值字段拒绝NaN和无穷。

F1计算不包含固定答案断言：把首行销量90改成120后，活动预测从150变165；该变异已在self-test执行。R4另测试比例2被拒绝，R5另测试容量60返回无可行候选。固定答案只在主程序验收默认数据时比较。

## 命令行严格校验

运行 `python run_cases.py --self-test` 时，必须使用两个ASCII减号。程序使用argparse且禁止缩写：未知参数、en dash/em dash、漏字或错误赋值都会以退出码2报错，并在读取计算数据和写结果之前停止。普通运行仅计算十例，不声称执行边界自测。

运行 `python test_cli.py` 检查五类错误参数不产生PASS或结果文件，并验证普通运行与正确--self-test的不同输出。所有测试只在临时副本中执行，不改原始输入。
