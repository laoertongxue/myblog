"""Independent deterministic checks for ten simulated tutorial cases; no external packages."""
import math
import json
from pathlib import Path
out={}
def check(name, actual, expected):
    assert len(actual)==len(expected)
    for a,b in zip(actual,expected):
        assert math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-6),(name,a,b)
    out[name]=actual
check('F1',[100*(1+x) for x in (.3,.5,.7)],[130,150,170])
check('F2',[700-300*.4*.75,700-300*.4*.25,1280+100-800-200],[610,670,380])
check('F3',[math.sqrt(400+400+2*r*20*20) for r in (0,.5,1)],[28.284271247461902,34.64101615137755,40])
raw=[2000*v/2100 for v in (1000,600,500)]
rounded=[math.floor(v) for v in raw]
for i in sorted(range(3),key=lambda i:(-(raw[i]-rounded[i]),i))[:2000-sum(rounded)]:rounded[i]+=1
check('F4',rounded+[rounded[i]-v for i,v in enumerate((500,300,300))],[952,572,476,452,272,176])
check('F5',[100-8*(a-10)+5*(b-10) for a,b in ((10,10),(11,10),(10,12),(11,12))],[100,92,110,102])
net=100*.12+50*.08;gross=net/.98;boxes=math.ceil((gross-7)/4)
check('R1',[net,gross,boxes,7+boxes*4-gross],[16,16.3265306122449,3,2.6734693877551026])
check('R2',[80+5*(t-20)+20*w for t,w in ((20,0),(24,0),(20,1),(24,1))],[80,100,100,120])
check('R3',[.75*2+.25*3,200*2.25,math.ceil((450-50)/100),math.ceil((600-50)/100)],[2.25,450,4,6])
check('R4',[40/.4,20/.4,40*40/50,40*10/50],[100,50,32,8])
check('R5',[sum(p*(6*max(d-q,0)+2*max(q-d,0)) for d,p in ((80,.25),(100,.5),(120,.25))) for q in (80,100,110,120)],[120,40,40,40])
Path(__file__).with_name('verified_answers.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('PASS: all ten simulated case answer sets; exact integer constraints and floating tolerance checked.')
