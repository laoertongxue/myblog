from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
ROOT=Path(__file__).parent
OUT=ROOT/'images'
import os
font=os.environ.get('CJK_FONT_PATH','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if not Path(font).exists():
 raise SystemExit('请用 CJK_FONT_PATH 指定本机可用中文字体文件；此脚本仅用于重绘文章PNG/SVG，核心实验不需要它。')
plt.rcParams.update({'font.family':FontProperties(fname=font).get_name(),'font.sans-serif':[FontProperties(fname=font).get_name()], 'axes.unicode_minus':False,'font.size':12,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.edgecolor':'black','text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black'})
def save(fig,name):
 fig.savefig(OUT/(name+'.png'),dpi=180,bbox_inches='tight',facecolor='white')
 fig.savefig(OUT/(name+'.svg'),bbox_inches='tight',facecolor='white')
 plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(11,4.5),sharey=True)
for ax,title,x,y in zip(axs,['平稳情景','波动情景'],[[20],[10,30]],[[100],[50,50]]):
 ax.bar(x,y,width=5,color='white',edgecolor='black',linewidth=1.8,hatch='///')
 ax.set(xlim=(0,40),ylim=(0,110),xticks=[0,10,20,30,40],xlabel='需求（公斤）',title=title)
 ax.axvline(20,color='black',linestyle='--',linewidth=1)
 for a,b in zip(x,y):ax.text(a,b+2,f'{b}%',ha='center')
 ax.text(.97,.86,'均值 20公斤',transform=ax.transAxes,ha='right',fontsize=11)
axs[0].set_ylabel('概率（%）')
fig.suptitle('均值相同，尾部需求可以不同',fontsize=18,y=1.02)
fig.text(.5,-.04,'教学指定的离散分布；虚线表示均值，不是另一种可能需求。',ha='center',fontsize=11)
fig.tight_layout();save(fig,'01-distribution')
fig,axs=plt.subplots(1,2,figsize=(11,4.5))
axs[0].bar(['创建时','第a天末','第b天末'],[100,72,54],color=['white','.75','.4'],edgecolor='black',hatch='//')
axs[0].set(ylim=(0,115),ylabel='相对初始订单的留存概率（%）',title='同一条假定留存曲线')
for i,v in enumerate([100,72,54]):axs[0].text(i,v+3,f'{v}%',ha='center')
axs[1].bar(['当前80单','未来期望60单'],[100,75],color=['white','.4'],edgecolor='black',hatch='//')
axs[1].set(ylim=(0,115),ylabel='给定已撑过a天后的留存概率（%）',title='把当前待发订单作为新分母')
for i,v in enumerate([100,75]):axs[1].text(i,v+3,f'{v}%',ha='center')
fig.suptitle('条件留存 54% ÷ 72% = 75%',fontsize=18,y=1.03)
fig.text(.5,-.045,'独立手算假设：无发货、同一可比组；80 × 75% = 60单期望，不是执行数量。',ha='center',fontsize=11)
fig.tight_layout();save(fig,'02-conditional-survival')
import csv
rows=list(csv.DictReader((ROOT/'practice/outputs/hewei_metrics.csv').open(encoding='utf-8-sig')))
keys=[f'{s}/SKU{i:02d}' for s in ['A','B'] for i in range(1,9)]
fig,ax=plt.subplots(figsize=(11,7))
for model,marker,offset,label in [('pooled_residual','o',-.15,'统一误差分布'),('sku_residual','s',.15,'按SKU误差分布')]:
 vals=[100*float(next(r for r in rows if r['model']==model and r['group']=='series='+k)['central80_coverage']) for k in keys]
 ax.scatter(vals,[i+offset for i in range(16)],s=52,facecolors='white' if marker=='o' else 'black',edgecolors='black',marker=marker,label=label,zorder=3)
ax.axvline(80,color='black',linestyle='--',lw=1,label='名义80%')
ax.set(yticks=list(range(16)),yticklabels=keys,xlim=(0,105),xlabel='P10至P90区间覆盖率（%）',title='总体接近80%，不代表每条序列都可靠')
ax.invert_yaxis();ax.grid(axis='x',color='.88',lw=.7);ax.legend(loc='lower left',frameon=False)
fig.text(.5,.01,'全部16条序列，每条28个后期测试日；固定种子20261111，仅教学模拟。',ha='center',fontsize=11)
fig.tight_layout(rect=[0,.04,1,1]);save(fig,'03-hewei-coverage')
rows=list(csv.DictReader((ROOT/'practice/outputs/apparel_horizon_metrics.csv').open(encoding='utf-8-sig')))
fig,ax=plt.subplots(figsize=(8,6))
ax.plot([0,65],[0,65],linestyle='--',color='.4',lw=1,label='预测比例 = 实际频率')
for model,marker,label in [('pooled_age','o','总体年龄风险'),('segment_age_shrunk','s','分组年龄收缩')]:
 rr=[r for r in rows if r['model']==model and r['current_age']=='7' and r['group']!='ALL']
 x=[float(r['mean_pred_cancel_by14'])*100 for r in rr];y=[float(r['observed_cancel_by14'])*100 for r in rr]
 ax.scatter(x,y,s=100,marker=marker,facecolors='white' if marker=='o' else 'black',edgecolors='black',label=label,zorder=4)
 for r,a,b in zip(rr,x,y):
  if model=='segment_age_shrunk':ax.annotate(f"{r['group']}  n={r['n_orders']}",(a,b),xytext=(-5,14),textcoords='offset points',fontsize=11)
ax.set(xlim=(0,65),ylim=(0,65),xlabel='平均预测随后取消概率（%）',ylabel='第8至14日实际取消频率（%）',title='第7日有效队列的分组校准')
ax.set_aspect('equal');ax.legend(loc='lower right',frameon=False,fontsize=10)
fig.text(.5,.01,'同一1,680单，按G1/G2分组；固定种子20261112，仅教学模拟。',ha='center',fontsize=10)
fig.tight_layout(rect=[0,.04,1,1]);save(fig,'04-apparel-calibration')
