# 第04篇交付包

## 先看哪份

- 第04篇_离线阅读.html：完整图文阅读版，4幅图已内嵌，单独复制也可离线阅读。目录可跳转，表格可横向滚动。
- 第04篇_文章源稿.md：可编辑Markdown正文，图片链接使用同目录images。
- images：4幅正文黑白PNG及可编辑SVG源文件，另附网站封面PNG/SVG。
- practice：独立模拟输入、完整Python代码、测试、结果表、中文数据字典与运行报告。
- 复核与范围说明.txt：本次核验结论和仍然存在的限制。

本包为12lab.cn第04篇配套发布资料，仅供学习与复核，不生成真实采购、排产或订单动作。

在线文章：https://12lab.cn/topics/forecasting/04-probability-and-presale/

## 运行实验

Python 3.10或以上，无第三方依赖，无网络请求。

进入practice目录，再执行：

    python3 run.py
    python3 -m unittest discover -s tests -v

Windows可将python3替换为py。默认保留输入，覆盖程序在outputs/与figures/中的同名输出。若需要重建模拟输入，使用python3 run.py --regenerate；它会覆盖data/中的两个同名CSV。先保留自己的改动。

实际运行协议、种子、字段和能力边界请看practice/README.md、DATA_DICTIONARY.md与REPORT_zh.md。修改代码或输入后，正文与静态报告不会自动更新，需要重新核对，不能继续引用旧成绩。

## 文章图重绘

核心实验不依赖图形库，practice/figures中的SVG由标准库直接生成。若要重新绘制文章的四幅PNG/SVG，可选运行make_article_figures.py，需要Matplotlib及可用中文字体。可用环境变量CJK_FONT_PATH指定字体文件。图片数据读取practice/outputs；任何实验修改后应先跑run.py再重绘。SVG也可直接编辑，但手工改图不能代替更新数据。

## 内容边界

禾味为虚构2店8食材SKU，服装案例匿名，数据全为模拟。测试结果是固定种子下的教学结果，不是真实收益或未来保证。服装主实验在14个完整等待日内不发货，不识别信息性发货删失的反事实。概率、期望和执行数量分开解释。

校验和见SHA256SUMS.txt，可用于检查解压文件是否完整。该清单不包含自己。
