#!/usr/bin/env python3
"""第四篇教学实验。Python >= 3.10；仅标准库；所有数据均为模拟。"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import random
import statistics
from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_CEILING
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TZ = timezone(timedelta(hours=8))
SEED = 20261111
LEVELS = (0.1, 0.5, 0.9)
SKUS = tuple(f'SKU{i:02d}' for i in range(1, 9))
GROUPS = ('G1', 'G2')
M = 20.0  # 在看模拟结果前固定，不用验证/测试集选择。
HORIZON = 14


def stamp(d: date, hour: int = 18) -> datetime:
    return datetime.combine(d, time(hour), TZ)


def dt(s: str) -> datetime:
    value = datetime.fromisoformat(s)
    if value.utcoffset() is None:
        raise ValueError('时间必须带时区')
    return value


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError('不得静默写空表')
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def quantile(values: list[float], tau: float) -> float:
    """左连续经验逆CDF：排序后第 ceil(n*tau) 个，不插值。"""
    if not values or not 0 < tau <= 1:
        raise ValueError('经验分位数需要非空样本和 0<tau<=1')
    rank = int((Decimal(len(values)) * Decimal(str(tau))).to_integral_value(rounding=ROUND_CEILING))
    return sorted(values)[rank - 1]


def pinball(y: float, q: float, tau: float) -> float:
    if not 0 <= tau <= 1:
        raise ValueError('tau超出[0,1]')
    e = y - q
    return tau * e if e >= 0 else (1 - tau) * -e


def brier(probabilities: list[float], outcomes: list[int]) -> float:
    if not probabilities or len(probabilities) != len(outcomes):
        raise ValueError('Brier需要同长非空数组')
    if any(not 0 <= p <= 1 for p in probabilities) or any(y not in (0, 1) for y in outcomes):
        raise ValueError('概率或标签非法')
    return statistics.fmean((p - y) ** 2 for p, y in zip(probabilities, outcomes))


def demand_split(index: int) -> str:
    if 0 <= index < 56:
        return 'train'
    if index in (56, 85):
        return 'gap'
    if 57 <= index < 85:
        return 'calibration'
    if 86 <= index < 114:
        return 'test'
    raise ValueError('需求日期超出设计范围')


def demand_schedule() -> dict:
    start = date(2026, 1, 5)
    return {'start': start, 'point_frozen_at': stamp(start + timedelta(days=56)),
            'quantiles_frozen_at': stamp(start + timedelta(days=85))}


def generate_demand(seed: int = SEED) -> list[dict]:
    rng = random.Random(seed)
    start = demand_schedule()['start']
    rows = []
    bases = (23, 32, 21, 18, 13, 11, 9, 7)
    scales = (1.2, 1.5, 2.0, 2.6, 3.1, 3.8, 4.6, 5.4)
    for index in range(114):
        day = start + timedelta(days=index)
        weekend = int(day.weekday() >= 5)
        shared = rng.gauss(0, 0.65)
        for store in ('A', 'B'):
            for j, sku in enumerate(SKUS):
                # 此规则仅供教学与审计，绝不作为模型输入。后期B店SKU08发生模拟漂移。
                demand = bases[j] + (2 if store == 'B' else 0) + 3.0 * weekend
                demand += shared + rng.gauss(0, scales[j])
                demand += (scales[j] * 2.5 if rng.random() < 0.09 else 0)
                demand += (4.0 if index >= 86 and store == 'B' and sku == 'SKU08' else 0)
                rows.append({'date': day.isoformat(), 'store': store, 'sku': sku,
                             'weekend': weekend, 'target_kg': round(max(0, demand), 2),
                             'forecast_at': stamp(day - timedelta(days=1)).isoformat(),
                             'calendar_available_at': stamp(day - timedelta(days=365), 0).isoformat(),
                             'label_available_at': stamp(day + timedelta(days=1), 9).isoformat(),
                             'split': demand_split(index)})
    return rows


def validate_demand(rows: list[dict]) -> None:
    if len(rows) != 114 * 16:
        raise ValueError('需求主样本必须为114天×2店×8SKU')
    seen = set()
    start = demand_schedule()['start']
    for r in rows:
        day = date.fromisoformat(r['date'])
        key = (r['date'], r['store'], r['sku'])
        if key in seen or r['store'] not in ('A', 'B') or r['sku'] not in SKUS:
            raise ValueError('需求主键重复或类别非法')
        seen.add(key)
        if r['split'] != demand_split((day - start).days):
            raise ValueError('时间切分被篡改')
        if int(r['weekend']) != int(day.weekday() >= 5):
            raise ValueError('星期字段错误')
        if dt(r['forecast_at']) != stamp(day - timedelta(days=1)):
            raise ValueError('预测起点错误')
        if dt(r['calendar_available_at']) > dt(r['forecast_at']):
            raise ValueError('日历特征晚于预测截止点')
        if dt(r['label_available_at']) != stamp(day + timedelta(days=1), 9):
            raise ValueError('标签成熟时间必须为目标日次日09点')
        if not math.isfinite(float(r['target_kg'])) or float(r['target_kg']) < 0:
            raise ValueError('需求必须为有限非负数')


def fit_point(rows: list[dict], cutoff: datetime) -> dict:
    buckets = defaultdict(list)
    selected = [r for r in rows if r['split'] == 'train']
    if not selected:
        raise ValueError('训练集为空')
    for r in selected:
        if dt(r['label_available_at']) > cutoff:
            raise ValueError('点模型读取了未成熟标签')
        buckets[(r['store'], r['sku'], int(r['weekend']))].append(float(r['target_kg']))
    return {key: statistics.fmean(values) for key, values in buckets.items()}


def point_predict(model: dict, r: dict) -> float:
    key = (r['store'], r['sku'], int(r['weekend']))
    if key not in model:
        raise ValueError('未知店货日历组合，拒绝外推')
    if dt(r['calendar_available_at']) > dt(r['forecast_at']):
        raise ValueError('预测特征在截止点后才可用')
    return model[key]


def fit_residuals(rows: list[dict], point: dict, point_cutoff: datetime, quantile_cutoff: datetime) -> dict:
    pools = defaultdict(list)
    selected = [r for r in rows if r['split'] == 'calibration']
    if not selected:
        raise ValueError('校准集为空')
    for r in selected:
        if dt(r['forecast_at']) < point_cutoff or dt(r['label_available_at']) > quantile_cutoff:
            raise ValueError('校准时序或成熟条件不合法')
        residual = float(r['target_kg']) - point_predict(point, r)
        pools['ALL'].append(residual)
        pools[r['sku']].append(residual)
    return {key: [quantile(values, tau) for tau in LEVELS] for key, values in pools.items()}


def demand_predictions(rows: list[dict], point: dict, residuals: dict, cutoff: datetime) -> list[dict]:
    result = []
    for r in rows:
        if r['split'] != 'test':
            continue
        if dt(r['forecast_at']) < cutoff:
            raise ValueError('测试预测起点早于分位数冻结时间')
        base = point_predict(point, r)
        for model in ('point_degenerate', 'pooled_residual', 'sku_residual'):
            offsets = [0, 0, 0] if model == 'point_degenerate' else residuals['ALL' if model == 'pooled_residual' else r['sku']]
            raw = [base + offset for offset in offsets]
            qs = [max(0, value) for value in raw]
            result.append({'model': model, 'date': r['date'], 'store': r['store'], 'sku': r['sku'],
                           'forecast_at': r['forecast_at'], 'weekend': int(r['weekend']), 'point_mean': base,
                           'raw_q10': raw[0], 'raw_q50': raw[1], 'raw_q90': raw[2],
                           'clipped_q10': int(raw[0] < 0), 'clipped_q50': int(raw[1] < 0), 'clipped_q90': int(raw[2] < 0),
                           'q10': qs[0], 'q50': qs[1], 'q90': qs[2], 'actual_kg': float(r['target_kg'])})
    return result


def demand_metrics(preds: list[dict]) -> list[dict]:
    buckets = defaultdict(list)
    for r in preds:
        for group in ('ALL', 'sku=' + r['sku'], 'store=' + r['store'], 'series=' + r['store'] + '/' + r['sku'], 'weekend=' + str(r['weekend'])):
            buckets[(r['model'], group)].append(r)
    out = []
    for (model, group), rows in sorted(buckets.items()):
        n = len(rows)
        result = {'model': model, 'group': group, 'n': n,
                  'mae_point_mean_kg': statistics.fmean(abs(r['actual_kg'] - r['point_mean']) for r in rows)}
        for level, col in zip(LEVELS, ('q10', 'q50', 'q90')):
            result['coverage_' + col] = sum(r['actual_kg'] <= r[col] for r in rows) / n
            result['pinball_' + col + '_kg'] = statistics.fmean(pinball(r['actual_kg'], r[col], level) for r in rows)
        result['central80_coverage'] = sum(r['q10'] <= r['actual_kg'] <= r['q90'] for r in rows) / n
        result['central80_mean_width_kg'] = statistics.fmean(r['q90'] - r['q10'] for r in rows)
        result['mean_three_pinball_kg'] = statistics.fmean(result['pinball_' + c + '_kg'] for c in ('q10', 'q50', 'q90'))
        result['below_0_8_descriptive_only'] = int(result['central80_coverage'] < 0.8)
        out.append(result)
    return out


def apparel_schedule() -> dict:
    start = date(2026, 1, 1)
    return {'start': start, 'frozen_at': stamp(start + timedelta(days=42)),
            'evaluation_at': stamp(start + timedelta(days=86))}


def generate_orders(seed: int = SEED + 1) -> list[dict]:
    rng = random.Random(seed)
    start = apparel_schedule()['start']
    rows = []
    for cohort in range(71):
        created = stamp(start + timedelta(days=cohort), 12)
        split = 'train' if cohort < 28 else ('gap' if cohort < 43 else 'test')
        for j in range(80):
            group = 'G1' if rng.random() < 0.6 else 'G2'
            cancel_age = 0
            for age in range(1, HORIZON + 1):
                hazard = (0.045 if age <= 3 else 0.015 if age <= 9 else 0.025)
                if group == 'G2':
                    hazard += 0.035
                if rng.random() < hazard:
                    cancel_age = age
                    break
            canceled_at = created + timedelta(days=cancel_age - 1, hours=18) if cancel_age else None
            rows.append({'order_id': f'O{cohort * 80 + j + 1:05d}', 'cohort_day': cohort,
                         'created_at': created.isoformat(), 'group': group, 'quantity_units': rng.randint(1, 3),
                         'group_available_at': created.isoformat(), 'cancel_age': cancel_age,
                         'cancel_at': canceled_at.isoformat() if canceled_at else '',
                         'ship_at': '', 'horizon_end_at': (created + timedelta(days=14)).isoformat(),
                         'label_available_at': (created + timedelta(days=14, hours=21)).isoformat(),
                         'split': split})
    return rows


def validate_orders(orders: list[dict]) -> None:
    if len(orders) != 71 * 80:
        raise ValueError('订单固定教学夹具必须为71队列日×80单=5680行')
    seen = set()
    cohort_counts = defaultdict(int)
    start = apparel_schedule()['start']
    for r in orders:
        order_id = r['order_id']
        if not isinstance(order_id, str) or not order_id.strip() or order_id != order_id.strip():
            raise ValueError('订单ID必须非空且不能带首尾空白')
        if order_id in seen:
            raise ValueError('订单主键重复')
        seen.add(order_id)
        created = dt(r['created_at'])
        if created != stamp(created.date(), 12):
            raise ValueError('固定教学队列必须在北京时间12:00创建')
        cohort = (created.date() - start).days
        expected_split = 'train' if cohort < 28 else ('gap' if cohort < 43 else 'test')
        if not 0 <= cohort <= 70 or r['split'] != expected_split or int(r['cohort_day']) != cohort:
            raise ValueError('订单切分被篡改')
        cohort_counts[cohort] += 1
        quantity = r['quantity_units']
        valid_quantity = ((type(quantity) is int and quantity in (1, 2, 3)) or
                          (type(quantity) is str and quantity in ('1', '2', '3')))
        if r['group'] not in GROUPS or not valid_quantity:
            raise ValueError('订单组必须为G1/G2，件数必须为严格整数1、2或3')
        if dt(r['group_available_at']) > created:
            raise ValueError('分组在下单时尚不可用')
        if r['ship_at']:
            raise ValueError('主实验14日内不得发货；有发货请另建竞争退出模型')
        age = int(r['cancel_age'])
        if not 0 <= age <= 14:
            raise ValueError('取消年龄越界')
        expected_cancel = (created + timedelta(days=age - 1, hours=18)).isoformat() if age else ''
        if r['cancel_at'] != expected_cancel:
            raise ValueError('取消事件时间与年龄不一致')
        if dt(r['horizon_end_at']) != created + timedelta(days=14):
            raise ValueError('观察期错误')
        if dt(r['label_available_at']) != created + timedelta(days=14, hours=21):
            raise ValueError('结局成熟时间错误')
    if dict(cohort_counts) != {day: 80 for day in range(71)}:
        raise ValueError('每个创建队列日必须恰好80单')


def build_risk_table(orders: list[dict], cutoff: datetime) -> list[dict]:
    train = [r for r in orders if r['split'] == 'train']
    if not train or any(dt(r['label_available_at']) > cutoff for r in train):
        raise ValueError('训练队列为空或14日结局尚未全部成熟')
    result = []
    for group in ('ALL',) + GROUPS:
        chosen = [r for r in train if group == 'ALL' or r['group'] == group]
        for age in range(1, 15):
            risk = [r for r in chosen if int(r['cancel_age']) == 0 or int(r['cancel_age']) >= age]
            cancels = sum(int(r['cancel_age']) == age for r in risk)
            result.append({'group': group, 'age': age, 'risk_orders': len(risk), 'canceled_orders': cancels,
                           'shipped_orders': 0, 'remaining_orders': len(risk) - cancels,
                           'risk_units': sum(int(r['quantity_units']) for r in risk),
                           'canceled_units': sum(int(r['quantity_units']) for r in risk if int(r['cancel_age']) == age),
                           'raw_hazard': cancels / len(risk) if risk else None})
    return result


def fit_hazards(risk: list[dict], m: float = M) -> dict:
    if m < 0:
        raise ValueError('先验强度不能为负')
    table = {(r['group'], int(r['age'])): r for r in risk}
    result = {'pooled_age': {}, 'segment_age_shrunk': {}}
    for group in GROUPS:
        result['pooled_age'][group] = []
        result['segment_age_shrunk'][group] = []
        for age in range(1, 15):
            pooled, own = table['ALL', age], table[group, age]
            r0, c0 = int(pooled['risk_orders']), int(pooled['canceled_orders'])
            rg, cg = int(own['risk_orders']), int(own['canceled_orders'])
            if min(r0, rg, c0, cg) < 0 or c0 > r0 or cg > rg:
                raise ValueError('风险集与事件计数不合法')
            h0 = c0 / r0 if r0 else None
            hg = (cg + m * h0) / (rg + m) if h0 is not None and rg > 0 else None
            result['pooled_age'][group].append(h0)
            result['segment_age_shrunk'][group].append(hg)
    return result


def survival(hazards: list[float | None]) -> list[float | None]:
    values: list[float | None] = [1.0]
    for h in hazards:
        if h is not None and not 0 <= h <= 1:
            raise ValueError('hazard超出[0,1]')
        values.append(values[-1] * (1 - h) if values[-1] is not None and h is not None else None)
    return values


def conditional_survival(hazards: list[float | None], a: int, b: int) -> float:
    if not 0 <= a <= b <= len(hazards):
        raise ValueError('请求超出已支持年龄范围，拒绝外推')
    s = survival(hazards)
    if s[a] is None or s[b] is None or s[a] <= 0:
        raise ValueError('条件分母为零或历史没有支持，拒绝给出概率')
    return s[b] / s[a]


def predict_apparel(orders: list[dict], models: dict, frozen_at: datetime, evaluation_at: datetime) -> tuple[list[dict], list[dict]]:
    horizon, daily = [], []
    for r in orders:
        if r['split'] != 'test':
            continue
        created = dt(r['created_at'])
        if created < frozen_at or dt(r['group_available_at']) > created:
            raise ValueError('订单预测出现未来特征或模型冻结过晚')
        if dt(r['label_available_at']) > evaluation_at:
            raise ValueError('测试结局尚未成熟，不得把未完结订单记0')
        canceled = int(r['cancel_age'])
        for model, groups in models.items():
            if r['group'] not in groups:
                raise ValueError('未知分组，拒绝预测')
            hazards = groups[r['group']]
            for a in (0, 7):
                if canceled and canceled <= a:
                    continue
                retain = conditional_survival(hazards, a, 14)
                horizon.append({'model': model, 'order_id': r['order_id'], 'group': r['group'],
                                'quantity_units': int(r['quantity_units']), 'current_age': a, 'target_age': 14,
                                'forecast_at': (created + timedelta(days=a)).isoformat(),
                                'prob_cancel_before14': 1 - retain, 'prob_remaining14': retain,
                                'actual_cancel_after_score': int(canceled > a),
                                'actual_remaining14': int(canceled == 0)})
            for age, h in enumerate(hazards, 1):
                if canceled and canceled < age:
                    continue
                if h is None:
                    raise ValueError('无支持hazard')
                daily.append({'model': model, 'order_id': r['order_id'], 'group': r['group'], 'age': age,
                              'quantity_units': int(r['quantity_units']), 'prob_cancel_today': h, 'actual_cancel_today': int(canceled == age)})
    return horizon, daily


def apparel_metrics(preds: list[dict], daily: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    buckets, bins = defaultdict(list), defaultdict(list)
    for r in preds:
        for group in ('ALL', r['group']):
            buckets[r['model'], r['current_age'], group].append(r)
        # 事先固定宽0.1分箱；不据测试结果移动边界。
        bin_id = min(9, int(r['prob_cancel_before14'] * 10))
        bins[r['model'], r['current_age'], bin_id].append(r)
    summaries, calibration, counts = [], [], []
    for (model, age, group), rows in sorted(buckets.items()):
        probs = [r['prob_cancel_before14'] for r in rows]
        labels = [r['actual_cancel_after_score'] for r in rows]
        summaries.append({'model': model, 'current_age': age, 'group': group, 'n_orders': len(rows),
                          'brier_cancel_by14': brier(probs, labels),
                          'mean_pred_cancel_by14': statistics.fmean(probs),
                          'observed_cancel_by14': statistics.fmean(labels)})
        counts.append({'model': model, 'current_age': age, 'group': group, 'current_orders': len(rows),
                       'expected_remaining14': sum(r['prob_remaining14'] for r in rows),
                       'actual_remaining14': sum(r['actual_remaining14'] for r in rows),
                       'current_units': sum(r['quantity_units'] for r in rows),
                       'expected_remaining_units14': sum(r['quantity_units'] * r['prob_remaining14'] for r in rows),
                       'actual_remaining_units14': sum(r['quantity_units'] * r['actual_remaining14'] for r in rows)})
    for (model, age, bid), rows in sorted(bins.items()):
        calibration.append({'model': model, 'current_age': age, 'bin_low': bid / 10, 'bin_high': (bid + 1) / 10,
                            'n': len(rows), 'mean_prediction': statistics.fmean(r['prob_cancel_before14'] for r in rows),
                            'observed_frequency': statistics.fmean(r['actual_cancel_after_score'] for r in rows)})
    return summaries, calibration, counts


def shipping_example() -> list[dict]:
    risk, result = 100, []
    for age, canceled, shipped in ((1, 10, 20), (2, 7, 0)):
        if canceled + shipped > risk:
            raise ValueError('取消与发货超出风险集')
        result.append({'age': age, 'risk_start': risk, 'canceled': canceled, 'shipped_at_end': shipped,
                       'cancel_hazard': canceled / risk, 'risk_end': risk - canceled - shipped})
        risk -= canceled + shipped
    return result


def hand_calculations() -> dict:
    return {'not_experiment_output': True, 'brier_four': brier([.8, .2, .6, .4], [1, 0, 0, 1]),
            'brier_constant_half': .25, 'p90_under_by20_loss': pinball(100, 80, .9),
            'p90_over_by20_loss': pinball(100, 120, .9), 'two_day_no_shipping_survival': .9 * .9,
            'conditional_remaining_orders': 80 * .54 / .72, 'shrunk_hazard_example': (1 + 8 * .1) / (2 + 8),
            'discrete_values': [0, 0, 0, 0, 0, 0, 0, 0, 0, 100],
            'discrete_mean': 10, 'discrete_p50': 0, 'discrete_p90': 0,
            'discrete_central80_inclusive_coverage': .9}


def line_svg(path: Path, title: str, xlabel: str, ylabel: str, curves: list[dict], xmax: float, ymax: float) -> None:
    """手写SVG，无图库；只用黑/白与线型。"""
    from html import escape
    w, h, left, top, pw, ph = 800, 500, 90, 70, 650, 330
    elements = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img"><title>{escape(title)}</title>',
                '<rect width="800" height="500" fill="white"/>',
                '<style>text{font:14px sans-serif;fill:black}path,line,polyline,circle{stroke:black;fill:none}</style>',
                f'<text x="90" y="30" font-size="19">{escape(title)}</text>',
                f'<path d="M {left},{top} V {top + ph} H {left + pw}" stroke-width="1.5"/>']
    for i in range(6):
        xv, yv = xmax * i / 5, ymax * i / 5
        elements.append(f'<text x="{left + pw * i / 5}" y="425" text-anchor="middle">{xv:.2g}</text>')
        elements.append(f'<text x="78" y="{top + ph - ph * i / 5 + 5}" text-anchor="end">{yv:.2g}</text>')
    elements += [f'<text x="400" y="460">{escape(xlabel)}</text>', f'<text x="10" y="55">{escape(ylabel)}</text>']
    for i, curve in enumerate(curves):
        dash = curve.get('dash', '')
        points = ' '.join(f'{left + x / xmax * pw:.2f},{top + ph - y / ymax * ph:.2f}' for x, y in curve['points'])
        elements.append(f'<polyline points="{points}" stroke-width="2" stroke-dasharray="{dash}"/>')
        elements.append(f'<line x1="{100 + i * 210}" x2="{130 + i * 210}" y1="485" y2="485" stroke-width="2" stroke-dasharray="{dash}"/>')
        elements.append(f'<text x="{135 + i * 210}" y="490">{escape(curve["name"])}</text>')
    elements.append('</svg>')
    path.write_text('\n'.join(elements), encoding='utf-8')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--regenerate', action='store_true', help='重建模拟输入；会覆盖data目录中本程序的两个同名CSV')
    args = parser.parse_args()
    data, out, figs = ROOT / 'data', ROOT / 'outputs', ROOT / 'figures'
    for p in (data, out, figs):
        p.mkdir(exist_ok=True)
    if args.regenerate or not (data / 'hewei_daily.csv').exists():
        write_csv(data / 'hewei_daily.csv', generate_demand())
    if args.regenerate or not (data / 'apparel_orders.csv').exists():
        write_csv(data / 'apparel_orders.csv', generate_orders())
    demand, orders = read_csv(data / 'hewei_daily.csv'), read_csv(data / 'apparel_orders.csv')
    validate_demand(demand)
    validate_orders(orders)
    ds, aps = demand_schedule(), apparel_schedule()
    point = fit_point(demand, ds['point_frozen_at'])
    residuals = fit_residuals(demand, point, ds['point_frozen_at'], ds['quantiles_frozen_at'])
    dp = demand_predictions(demand, point, residuals, ds['quantiles_frozen_at'])
    dm = demand_metrics(dp)
    write_csv(out / 'hewei_predictions.csv', dp)
    write_csv(out / 'hewei_metrics.csv', dm)
    write_csv(out / 'hewei_point_parameters.csv', [{'store': k[0], 'sku': k[1], 'weekend': k[2], 'fitted_mean_kg': v} for k, v in sorted(point.items())])
    write_csv(out / 'hewei_residual_quantiles.csv', [{'pool': k, 'n_calibration': 448 if k == 'ALL' else 56, 'r10': v[0], 'r50': v[1], 'r90': v[2]} for k, v in residuals.items()])
    risk = build_risk_table(orders, aps['frozen_at'])
    models = fit_hazards(risk)
    hp, daily = predict_apparel(orders, models, aps['frozen_at'], aps['evaluation_at'])
    hm, calibration, counts = apparel_metrics(hp, daily)
    write_csv(out / 'apparel_training_risk_table.csv', risk)
    write_csv(out / 'apparel_horizon_predictions.csv', hp)
    write_csv(out / 'apparel_daily_predictions.csv', daily)
    write_csv(out / 'apparel_horizon_metrics.csv', hm)
    write_csv(out / 'apparel_calibration_bins.csv', calibration)
    write_csv(out / 'apparel_conditional_counts.csv', counts)
    survival_rows, new_batch = [], []
    for model, groups in models.items():
        for group, hazards in groups.items():
            s = survival(hazards)
            for age in range(15):
                survival_rows.append({'model': model, 'group': group, 'age': age,
                                      'hazard': hazards[age - 1] if age else '', 'survival': s[age]})
            new_batch.append({'model': model, 'group': group, 'assumed_new_orders': 100,
                              'expected_remaining14': 100 * s[14], 'is_quantile': False})
    write_csv(out / 'apparel_survival.csv', survival_rows)
    write_csv(out / 'apparel_new_batch_mean.csv', new_batch)
    write_csv(out / 'shipping_hand_example.csv', shipping_example())
    daily_summary = []
    for model in models:
        chosen = [r for r in daily if r['model'] == model]
        daily_summary.append({'model': model, 'n_order_days': len(chosen),
                              'brier_daily_hazard': brier([r['prob_cancel_today'] for r in chosen], [r['actual_cancel_today'] for r in chosen])})
    write_csv(out / 'apparel_daily_metrics.csv', daily_summary)
    summary = {'simulation_only': True, 'seed_hewei': SEED, 'seed_apparel': SEED + 1,
               'python_requirement': '3.10+', 'third_party_dependencies': [],
               'hewei_schedule': {k: str(v) for k, v in ds.items()},
               'apparel_schedule': {k: str(v) for k, v in aps.items()},
               'hewei_rows': len(demand), 'hewei_clipped_predictions': sum(any(r[k] for k in ('clipped_q10', 'clipped_q50', 'clipped_q90')) for r in dp), 'hewei_overall': [r for r in dm if r['group'] == 'ALL'],
               'hewei_lowest_series_coverage': {model: min((r for r in dm if r['model'] == model and r['group'].startswith('series=')), key=lambda r: r['central80_coverage']) for model in ('pooled_residual', 'sku_residual')},
               'apparel_rows': len(orders), 'apparel_shrinkage_m_fixed': M,
               'apparel_horizon_overall': [r for r in hm if r['group'] == 'ALL'],
               'apparel_daily': daily_summary, 'hand_calculations_separate': hand_calculations(),
               'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.glob('*.csv'))}}
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    line_svg(figs / 'hewei_quantile_coverage.svg', 'Hewei: held-out quantile coverage', 'Nominal quantile', 'Observed <= q',
             [{'name': 'Nominal', 'dash': '3 4', 'points': [(0, 0), (1, 1)]}] +
             [{'name': name, 'dash': dash, 'points': list(zip(LEVELS, [r['coverage_' + col] for col in ('q10', 'q50', 'q90')]))}
              for name, dash in (('Pooled', ''), ('SKU', '9 4'))
              for r in dm if r['group'] == 'ALL' and r['model'] == ('pooled_residual' if name == 'Pooled' else 'sku_residual')], 1, 1)
    line_svg(figs / 'apparel_survival.svg', 'Apparel: fitted survival, no shipping in days 1-14', 'Age (days)', 'S(age)',
             [{'name': label, 'dash': dash, 'points': list(enumerate(survival(models[model][group])))}
              for model, group, label, dash in [('pooled_age', 'G1', 'Pooled', ''), ('segment_age_shrunk', 'G1', 'G1', '8 4'), ('segment_age_shrunk', 'G2', 'G2', '2 4')]], 14, 1)
    print(json.dumps({'hewei_overall': summary['hewei_overall'], 'apparel_horizon_overall': summary['apparel_horizon_overall'], 'apparel_daily': daily_summary}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
