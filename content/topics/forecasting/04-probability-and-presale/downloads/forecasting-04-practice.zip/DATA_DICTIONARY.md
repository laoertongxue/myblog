# 字段与输出字典

所有时间戳使用ISO 8601并含`+08:00`。空白与0不同：取消年龄0明确定义为14日完整观察期内没有取消，绝不表示未完结；空白取消时间对应已完成观察但未取消。输入另设成熟时间，模型和评分必须先检查。

## data/hewei_daily.csv

|字段|定义|
|---|---|
|date, store, sku|主键；目标营业自然日、A/B店、SKU01—SKU08；SKU01延续鸡腿肉标签，其余编号不影响单位|
|weekend|目标日是否星期六/日，0/1；由日历直接可知，不是标签估计出来|
|target_kg|实际净耗用公斤数，非负，完整无缺货教学条件|
|forecast_at|目标日前一日18:00，单日预测发出时点|
|calendar_available_at|日历信息可见时间，设置为目标日前365日00:00，必须不晚于forecast_at|
|label_available_at|目标日次日09:00；数据落在哪一天与何时已知严格分开|
|split|train/gap/calibration/test，由日期确定并校验，不能把未来行重新标成训练行|

## data/apparel_orders.csv

|字段|定义|
|---|---|
|order_id|非空唯一字符串编号，不接受首尾空白|
|cohort_day|从2026-01-01起的创建日编号0—70|
|created_at|创建时点，每天12:00|
|group|G1/G2，虚构的创建时已知订单分组|
|quantity_units|严格整数1—3，非法格式、非整数和越界值拒绝，用于守恒核验及按逐单保留概率汇总预计件数；概率目标仍为整单取消|
|group_available_at|分组首次可见时点，本例等于创建时点|
|cancel_age|1—14表示该年龄区间取消；0表示14日完整观察内未取消|
|cancel_at|取消事件时间；未取消时为空；不作为预测特征|
|ship_at|主实验始终为空；加入发货将报错，不能混用到无发货生存目标|
|horizon_end_at|创建时刻+14个24小时|
|label_available_at|创建时刻+14天21小时，即观察窗结束后的次日09:00|
|split|train/gap/test，由创建日期确定；所有训练队列需完整成熟|

## outputs/

- `hewei_point_parameters.csv`：32个训练点均值，只有train标签参与。
- `hewei_residual_quantiles.csv`：总体与SKU校准池的样本数、三个经验残差分位数，只有calibration标签参与。
- `hewei_predictions.csv`：3种方法×448条测试目标，含实际值供事后评分；`actual_kg`不参与预测。另含raw_q10/raw_q50/raw_q90和各clipped_q标记，明确记录非负截断；本次原始分位数全部非负，没有触发截断。
- `hewei_metrics.csv`：ALL、SKU、店、店/SKU、平日/周末各层级；每层都附n。分组层级重复覆盖同一批目标，不可把所有行的n再次相加。
- `apparel_training_risk_table.csv`：总体与两组、年龄1—14风险集，原始hazard；订单和件数计数不可混作分母。
- `apparel_survival.csv`：每模型每组各15个年龄点，包括S(0)=1，age=0的hazard为空。
- `apparel_horizon_predictions.csv`：年龄0及仍存活到7日的订单，含quantity_units、预测至14日的取消/保留概率与成熟后标签；同一订单会出现在两个不同预测起点，不可当独立订单重复统计。
- `apparel_horizon_metrics.csv`：固定当前年龄、固定目标年龄、相同订单集合上的Brier、概率均值与实际频率。
- `apparel_daily_predictions.csv`：每天开始尚未取消的订单日，预测当天hazard与观察事件；无发货。相同订单可贡献多天，不能把24124行当24124张独立订单。
- `apparel_daily_metrics.csv`：当天hazard Brier的辅助诊断，不与跨7天结局Brier直接排序。
- `apparel_calibration_bins.csv`：事先固定0.1宽度分箱，左闭右开；最后一箱包含1。只输出有样本的箱，附n。
- `apparel_conditional_counts.csv`：测试队列在年龄0、7已知订单数，至14日预计保留与实际保留订单数，并含current_units、expected_remaining_units14和actual_remaining_units14；预计件数为逐单件数×保留概率的加总，允许小数，因为是期望。
- `apparel_new_batch_mean.csv`：假设各组新进100单，100×S(14)；`is_quantile=False`。不预测新单产生量。
- `shipping_hand_example.csv`：100单、10取消、20发货、再7取消的独立手算事件账，不是模拟主样本结果。
- `summary.json`：种子、时间、核心精确结果、输入SHA-256；`hand_calculations_separate`全部是独立手算，不得混成实际实验指标。
- `console.json`：随包保留的一次控制台结果；如手动改输入并运行，可用重定向重新生成。
- `reproducibility_check.json`：本次在Python 3.12.14相同环境再次生成运行，19个输入/输出CSV、summary JSON和SVG的SHA-256一致；不包含因运行耗时而改变的日志。
- `test_log.txt`：随包保留的一次测试结果；重新测试可覆盖此日志。

## figures/

- `hewei_quantile_coverage.svg`：统一与SKU残差分位数的测试覆盖，点对应τ=0.1、0.5、0.9，直线为名义参考；不是校准保证。
- `apparel_survival.svg`：训练拟合的总体及G1/G2收缩S(age)，非真实行业存活规律。标题明确14日不发货。

二图使用纯黑白和线型区分，可直接在浏览器打开，无须联网。
