"""可运行的反例、变异检查与数学不变量，不把模拟排名当测试。"""
import copy
import sys
import unittest
from datetime import timedelta
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import run as ex


class ExperimentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.demand = ex.generate_demand()
        cls.orders = ex.generate_orders()
        cls.ds, cls.aps = ex.demand_schedule(), ex.apparel_schedule()
        cls.point = ex.fit_point(cls.demand, cls.ds['point_frozen_at'])
        cls.qs = ex.fit_residuals(cls.demand, cls.point, cls.ds['point_frozen_at'], cls.ds['quantiles_frozen_at'])
        cls.risk = ex.build_risk_table(cls.orders, cls.aps['frozen_at'])
        cls.models = ex.fit_hazards(cls.risk)

    def test_determinism_and_row_counts(self):
        self.assertEqual(self.demand, ex.generate_demand())
        self.assertEqual(self.orders, ex.generate_orders())
        self.assertEqual(len(self.demand), 1824)
        self.assertEqual(len(self.orders), 5680)
        self.assertEqual({split: sum(r['split'] == split for r in self.demand) for split in ('train', 'gap', 'calibration', 'test')},
                         {'train': 896, 'gap': 32, 'calibration': 448, 'test': 448})
        self.assertEqual({split: sum(r['split'] == split for r in self.orders) for split in ('train', 'gap', 'test')},
                         {'train': 2240, 'gap': 1200, 'test': 2240})
        ex.validate_demand(self.demand)
        ex.validate_orders(self.orders)

    def test_hand_calculations(self):
        hand = ex.hand_calculations()
        for key, expected in [('brier_four', .2), ('conditional_remaining_orders', 60), ('shrunk_hazard_example', .18),
                              ('two_day_no_shipping_survival', .81), ('p90_under_by20_loss', 18), ('p90_over_by20_loss', 2)]:
            self.assertAlmostEqual(hand[key], expected)
        self.assertEqual(ex.quantile([0] * 9 + [100], .9), 0)
        self.assertAlmostEqual(sum(y <= 0 for y in [0] * 9 + [100]) / 10, .9)

    def test_nearest_rank_decimal_boundary(self):
        values = list(range(1, 101))
        # float的100*.14略大于14，不能因此误取第15个。
        self.assertEqual(ex.quantile(values, .14), 14)
        for tau, expected in ((.01, 1), (.1, 10), (.29, 29), (.5, 50), (.9, 90), (1, 100)):
            self.assertEqual(ex.quantile(values, tau), expected)
        self.assertEqual(ex.quantile([7], .0001), 7)
        self.assertEqual(ex.quantile([7], 1), 7)
        for tau in (0, -.1, 1.01, float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                ex.quantile(values, tau)
        with self.assertRaises(ValueError):
            ex.quantile([], .5)

    def test_actual_csv_inputs_pass_full_validation(self):
        demand = ex.read_csv(ex.ROOT / 'data' / 'hewei_daily.csv')
        orders = ex.read_csv(ex.ROOT / 'data' / 'apparel_orders.csv')
        ex.validate_demand(demand)
        ex.validate_orders(orders)

    def test_order_fixture_rows_ids_and_quantities(self):
        with self.assertRaises(ValueError):
            ex.validate_orders(self.orders[:-1])
        for invalid in ('', '   ', ' leading', 'trailing '):
            changed = copy.deepcopy(self.orders)
            changed[0]['order_id'] = invalid
            with self.subTest(order_id=repr(invalid)), self.assertRaises(ValueError):
                ex.validate_orders(changed)
        changed = copy.deepcopy(self.orders)
        changed[1]['order_id'] = changed[0]['order_id']
        with self.assertRaises(ValueError):
            ex.validate_orders(changed)
        for invalid in (999, 0, -1, 1.5, 1.0, True, '', '1.5', '1.0', '999', 'abc', ' 1', '01'):
            changed = copy.deepcopy(self.orders)
            changed[0]['quantity_units'] = invalid
            with self.subTest(quantity=repr(invalid)), self.assertRaises(ValueError):
                ex.validate_orders(changed)
        # 联动改动所有时点仍不能把固定12点队列移成13点。
        changed = copy.deepcopy(self.orders)
        for field in ('created_at', 'group_available_at', 'cancel_at', 'horizon_end_at', 'label_available_at'):
            if changed[0][field]:
                changed[0][field] = (ex.dt(changed[0][field]) + timedelta(hours=1)).isoformat()
        with self.assertRaises(ValueError):
            ex.validate_orders(changed)
        # 总行数、唯一ID都合法，也不能用81/79单队列蒙混过去。
        changed = copy.deepcopy(self.orders)
        changed[80] = copy.deepcopy(changed[0])
        changed[80]['order_id'] = 'EXTRA_UNIQUE'
        with self.assertRaises(ValueError):
            ex.validate_orders(changed)

    def test_probability_endpoints(self):
        self.assertEqual(ex.brier([0, 1], [0, 1]), 0)
        self.assertEqual(ex.brier([1, 0], [0, 1]), 1)
        self.assertEqual(ex.survival([0, 1, 0]), [1, 1, 0, 0])
        self.assertEqual(ex.conditional_survival([0, 1], 0, 2), 0)
        with self.assertRaises(ValueError):
            ex.conditional_survival([0, 1], 2, 2)
        for probs, labels in (([-.1], [0]), ([1.1], [1]), ([.5], [2]), ([], [])):
            with self.assertRaises(ValueError):
                ex.brier(probs, labels)

    def test_demand_future_labels_cannot_change_fit(self):
        changed = copy.deepcopy(self.demand)
        for r in changed:
            if r['split'] in ('gap', 'test'):
                r['target_kg'] = 99999
        self.assertEqual(ex.fit_point(changed, self.ds['point_frozen_at']), self.point)
        self.assertEqual(ex.fit_residuals(changed, self.point, self.ds['point_frozen_at'], self.ds['quantiles_frozen_at']), self.qs)
        before = ex.demand_predictions(self.demand, self.point, self.qs, self.ds['quantiles_frozen_at'])
        after = ex.demand_predictions(changed, self.point, self.qs, self.ds['quantiles_frozen_at'])
        self.assertEqual([{k: v for k, v in r.items() if k != 'actual_kg'} for r in before],
                         [{k: v for k, v in r.items() if k != 'actual_kg'} for r in after])

    def test_demand_positive_controls(self):
        changed = copy.deepcopy(self.demand)
        changed[0]['target_kg'] += 10
        self.assertNotEqual(ex.fit_point(changed, self.ds['point_frozen_at']), self.point)
        changed = copy.deepcopy(self.demand)
        for r in changed:
            if r['split'] == 'calibration':
                r['target_kg'] += 10
        self.assertEqual(ex.fit_point(changed, self.ds['point_frozen_at']), self.point)
        self.assertNotEqual(ex.fit_residuals(changed, self.point, self.ds['point_frozen_at'], self.ds['quantiles_frozen_at']), self.qs)

    def test_maturity_gaps_are_required(self):
        with self.assertRaises(ValueError):
            ex.fit_point(self.demand, self.ds['point_frozen_at'] - timedelta(days=1))
        with self.assertRaises(ValueError):
            ex.fit_residuals(self.demand, self.point, self.ds['point_frozen_at'], self.ds['quantiles_frozen_at'] - timedelta(days=1))
        with self.assertRaises(ValueError):
            ex.build_risk_table(self.orders, self.aps['frozen_at'] - timedelta(days=1))
        with self.assertRaises(ValueError):
            ex.predict_apparel(self.orders, self.models, self.aps['frozen_at'], self.aps['evaluation_at'] - timedelta(days=2))

    def test_late_features_rejected(self):
        r = copy.deepcopy(next(r for r in self.demand if r['split'] == 'test'))
        r['calendar_available_at'] = (ex.dt(r['forecast_at']) + timedelta(seconds=1)).isoformat()
        with self.assertRaises(ValueError):
            ex.point_predict(self.point, r)
        orders = copy.deepcopy(self.orders)
        orders[-1]['group_available_at'] = (ex.dt(orders[-1]['created_at']) + timedelta(seconds=1)).isoformat()
        with self.assertRaises(ValueError):
            ex.validate_orders(orders)

    def test_temporal_partition_cannot_be_relabelled(self):
        changed = copy.deepcopy(self.demand)
        changed[-1]['split'] = 'train'
        with self.assertRaises(ValueError):
            ex.validate_demand(changed)
        changed = copy.deepcopy(self.orders)
        changed[-1]['split'] = 'train'
        with self.assertRaises(ValueError):
            ex.validate_orders(changed)

    def test_quantile_order_nonnegative_and_metric_denominators(self):
        preds = ex.demand_predictions(self.demand, self.point, self.qs, self.ds['quantiles_frozen_at'])
        for r in preds:
            self.assertLessEqual(0, r['q10'])
            self.assertLessEqual(r['q10'], r['q50'])
            self.assertLessEqual(r['q50'], r['q90'])
        ms = ex.demand_metrics(preds)
        overall = [r for r in ms if r['group'] == 'ALL']
        self.assertEqual([r['n'] for r in overall], [448] * 3)
        for r in overall:
            self.assertTrue(0 <= r['central80_coverage'] <= 1)
            self.assertGreaterEqual(r['central80_mean_width_kg'], 0)
        # 零宽区间不等于80%区间。覆盖率含等号，不能用F(P90)-F(P10)替代。
        fake = [{'model': 'tie', 'date': 'x', 'store': 'A', 'sku': 'SKU01', 'point_mean': 0, 'weekend': 0,
                 'q10': 0, 'q50': 0, 'q90': 0, 'actual_kg': 0}]
        self.assertEqual(ex.demand_metrics(fake)[0]['central80_coverage'], 1)

    def test_raw_quantiles_and_clipping(self):
        preds = ex.demand_predictions(self.demand, self.point, self.qs, self.ds['quantiles_frozen_at'])
        for r in preds:
            for col in ('q10', 'q50', 'q90'):
                self.assertEqual(r[col], max(0, r['raw_' + col]))
                self.assertEqual(r['clipped_' + col], int(r['raw_' + col] < 0))
        self.assertEqual(sum(r['clipped_q10'] + r['clipped_q50'] + r['clipped_q90'] for r in preds), 0)
        negative = {key: [-1000, -999, -998] for key in self.qs}
        forced = ex.demand_predictions(self.demand, self.point, negative, self.ds['quantiles_frozen_at'])
        for r in forced:
            if r['model'] != 'point_degenerate':
                self.assertLess(r['raw_q90'], 0)
                self.assertEqual((r['q10'], r['q50'], r['q90']), (0, 0, 0))
                self.assertEqual((r['clipped_q10'], r['clipped_q50'], r['clipped_q90']), (1, 1, 1))

    def test_expected_units_use_each_order_quantity(self):
        horizon, daily = ex.predict_apparel(self.orders, self.models, self.aps['frozen_at'], self.aps['evaluation_at'])
        _, _, counts = ex.apparel_metrics(horizon, daily)
        for c in counts:
            selected = [r for r in horizon if r['model'] == c['model'] and r['current_age'] == c['current_age']
                        and (c['group'] == 'ALL' or r['group'] == c['group'])]
            self.assertEqual(c['current_units'], sum(r['quantity_units'] for r in selected))
            self.assertAlmostEqual(c['expected_remaining_units14'], sum(r['quantity_units'] * r['prob_remaining14'] for r in selected))
            self.assertEqual(c['actual_remaining_units14'], sum(r['quantity_units'] * r['actual_remaining14'] for r in selected))
            self.assertLessEqual(c['actual_remaining_units14'], c['current_units'])
            self.assertLessEqual(c['expected_remaining_units14'], c['current_units'])
        doubled = copy.deepcopy(self.orders)
        for r in doubled:
            r['quantity_units'] *= 2
        hp2, daily2 = ex.predict_apparel(doubled, self.models, self.aps['frozen_at'], self.aps['evaluation_at'])
        _, _, c2 = ex.apparel_metrics(hp2, daily2)
        for before, after in zip(counts, c2):
            self.assertEqual(before['expected_remaining14'], after['expected_remaining14'])
            self.assertAlmostEqual(2 * before['expected_remaining_units14'], after['expected_remaining_units14'])

    def test_order_and_unit_conservation(self):
        for group in ('ALL',) + ex.GROUPS:
            rows = [r for r in self.risk if r['group'] == group]
            for current, following in zip(rows, rows[1:]):
                self.assertEqual(current['remaining_orders'], following['risk_orders'])
                self.assertEqual(current['risk_units'] - current['canceled_units'], following['risk_units'])
            for r in rows:
                self.assertTrue(0 <= r['canceled_orders'] + r['shipped_orders'] <= r['risk_orders'])
        train = [r for r in self.orders if r['split'] == 'train']
        self.assertEqual(sum(int(r['cancel_age']) > 0 for r in train) + sum(int(r['cancel_age']) == 0 for r in train), 2240)

    def test_apparel_future_labels_do_not_fit_or_score_features(self):
        changed = copy.deepcopy(self.orders)
        for r in changed:
            if r['split'] in ('gap', 'test') and (not r['cancel_age'] or r['cancel_age'] > 7):
                r['cancel_age'] = 14 if r['cancel_age'] == 0 else 0
                r['cancel_at'] = (ex.dt(r['created_at']) + timedelta(days=13, hours=18)).isoformat() if r['cancel_age'] else ''
        ex.validate_orders(changed)
        self.assertEqual(ex.build_risk_table(changed, self.aps['frozen_at']), self.risk)
        before, _ = ex.predict_apparel(self.orders, self.models, self.aps['frozen_at'], self.aps['evaluation_at'])
        after, _ = ex.predict_apparel(changed, self.models, self.aps['frozen_at'], self.aps['evaluation_at'])
        keep = ('model', 'order_id', 'group', 'current_age', 'prob_cancel_before14', 'prob_remaining14')
        self.assertEqual([{k: r[k] for k in keep} for r in before], [{k: r[k] for k in keep} for r in after])
        self.assertNotEqual([r['actual_cancel_after_score'] for r in before], [r['actual_cancel_after_score'] for r in after])

    def test_apparel_training_positive_control(self):
        changed = copy.deepcopy(self.orders)
        chosen = next(r for r in changed if r['split'] == 'train' and r['cancel_age'] == 0)
        chosen['cancel_age'] = 1
        chosen['cancel_at'] = (ex.dt(chosen['created_at']) + timedelta(hours=18)).isoformat()
        ex.validate_orders(changed)
        self.assertNotEqual(ex.fit_hazards(ex.build_risk_table(changed, self.aps['frozen_at'])), self.models)

    def test_survival_monotonic_and_conditional_ratio(self):
        for groups in self.models.values():
            for hs in groups.values():
                s = ex.survival(hs)
                self.assertEqual(s[0], 1)
                self.assertTrue(all(0 <= x <= 1 for x in s))
                self.assertTrue(all(a >= b for a, b in zip(s, s[1:])))
                self.assertAlmostEqual(ex.conditional_survival(hs, 7, 14), s[14] / s[7])
                self.assertAlmostEqual(ex.conditional_survival(hs, 7, 14), math_product(1 - h for h in hs[7:14]))

    def test_fixed_risk_sets_for_comparison(self):
        horizon, daily = ex.predict_apparel(self.orders, self.models, self.aps['frozen_at'], self.aps['evaluation_at'])
        for age in (0, 7):
            eligible = [{(r['order_id'], r['actual_cancel_after_score']) for r in horizon if r['model'] == m and r['current_age'] == age} for m in self.models]
            self.assertEqual(eligible[0], eligible[1])
            self.assertEqual(len(eligible[0]), 2240 if age == 0 else 1680)
        risksets = [{(r['order_id'], r['age'], r['actual_cancel_today']) for r in daily if r['model'] == m} for m in self.models]
        self.assertEqual(risksets[0], risksets[1])
        self.assertEqual(len(risksets[0]), 24124)

    def test_zero_support_and_unknown_horizon_refused(self):
        altered = copy.deepcopy(self.risk)
        for r in altered:
            if r['group'] == 'G2' and r['age'] == 14:
                r['risk_orders'], r['canceled_orders'] = 0, 0
        hs = ex.fit_hazards(altered)['segment_age_shrunk']['G2']
        self.assertIsNone(hs[13])
        with self.assertRaises(ValueError):
            ex.conditional_survival(hs, 7, 14)
        with self.assertRaises(ValueError):
            ex.conditional_survival(self.models['pooled_age']['G1'], 7, 60)

    def test_shrinkage_identity_and_no_new_hyperparameter_fit(self):
        m = ex.M
        self.assertEqual(m, 20)
        table = {(r['group'], r['age']): r for r in self.risk}
        for g in ex.GROUPS:
            for age in range(1, 15):
                own, pool = table[g, age], table['ALL', age]
                w = own['risk_orders'] / (own['risk_orders'] + m)
                expected = w * own['raw_hazard'] + (1 - w) * pool['raw_hazard']
                self.assertAlmostEqual(self.models['segment_age_shrunk'][g][age - 1], expected)

    def test_shipping_competing_exits_are_separate(self):
        first, second = ex.shipping_example()
        self.assertEqual(first['risk_end'], 70)
        self.assertEqual(second['cancel_hazard'], .1)
        self.assertEqual(second['risk_end'], 63)
        self.assertNotEqual(100 * .9 * .9, second['risk_end'])
        changed = copy.deepcopy(self.orders)
        changed[0]['ship_at'] = changed[0]['created_at']
        with self.assertRaises(ValueError):
            ex.validate_orders(changed)


def math_product(values):
    product = 1
    for value in values:
        product *= value
    return product


if __name__ == '__main__':
    unittest.main(verbosity=2)
