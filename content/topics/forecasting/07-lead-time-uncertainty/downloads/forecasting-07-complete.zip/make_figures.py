from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import FancyBboxPatch
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'images';OUT.mkdir(parents=True,exist_ok=True)
FONT=os.environ.get('CJK_FONT_PATH','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if not Path(FONT).is_file():raise SystemExit('请用 CJK_FONT_PATH 指定中文字体文件')
plt.rcParams.update({'font.family':FontProperties(fname=FONT).get_name(),'svg.fonttype':'none','axes.unicode_minus':False,'font.size':18})
def base(w,h,title,sub):
 f=plt.figure(figsize=(w/100,h/100),dpi=100,facecolor='white');a=f.add_axes([0,0,1,1]);a.set(xlim=(0,w),ylim=(h,0));a.axis('off');a.text(36,62,title,fontsize=25,weight='bold');a.text(36,105,sub,fontsize=15,color='.25');return f,a

def box(a,x,y,w,h,txt,fs=20):
 a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=10',facecolor='.96',edgecolor='.25',linewidth=1.5));a.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=fs,linespacing=1.7)
def arrow(a,x,y,z):a.annotate('',xy=(x,z),xytext=(x,y),arrowprops={'arrowstyle':'->','color':'black','lw':2})
def save(f,n):
 f.savefig(OUT/(n+'.png'),dpi=100);f.savefig(OUT/(n+'.svg'));plt.close(f)
f,a=base(900,383,'平均四天到货，为何仍会缺货','供应链预测与计划 · 第07篇 · 全部为教学模拟')
for x,t in [(36,'日需求\n会波动'),(324,'等待日数\n会波动'),(612,'保护库存\n看分布')]:box(a,x,157,250,145,t,23)
a.text(36,350,'先说清何时可用，再计算需要保护多少。',fontsize=19);save(f,'00-cover')
f,a=base(900,560,'交期不是一个模糊的日期','本文L＝到货可用前，必须覆盖的完整需求日数')
box(a,36,150,170,125,'第0日末\n当前时点',20)
box(a,230,150,390,125,'第1至第L日\n消耗现有可用库存S',20)
box(a,644,150,220,125,'第L+1日初\n新货可用',20)
box(a,36,330,828,130,'累计需求 Y = D1 + D2 + … + D_L\n前L天无其他补给；未满足即失销',21)
a.text(36,515,'S是保护段初始可用量，不直接等于本次采购量。',fontsize=18);save(f,'01-timeline')
f,a=base(900,620,'为什么方差是116，而不是16','日需求8/12公斤各半；交期3/5天各半；相互独立')
box(a,36,150,390,140,'3天组：均值30\n组内方差12',22)
box(a,474,150,390,140,'5天组：均值50\n组内方差20',22)
box(a,36,335,828,160,'组内平均：(12 + 20) ÷ 2 = 16\n组间波动：[(30−40)² + (50−40)²] ÷ 2 = 100',21)
a.text(36,558,'总方差 = 16 + 100 = 116 公斤²',fontsize=24,weight='bold');save(f,'02-variance')
f,a=base(900,600,'首次到货，不等于已经收齐','匿名服装企业 · 100米面料订单 · 全部模拟')
for x,t in [(36,'第3天\n收到40米'),(324,'第5天\n观察截止'),(612,'第8天\n再收60米')]:box(a,x,157,250,145,t,22)
box(a,36,350,828,145,'站在第5天：首次到货时间已知为3天\n收齐时间仍未知；只知道已经等了5天',21)
a.text(36,553,'第8天事件不能提前泄漏进第5天的特征或标签。',fontsize=20);save(f,'03-po')
