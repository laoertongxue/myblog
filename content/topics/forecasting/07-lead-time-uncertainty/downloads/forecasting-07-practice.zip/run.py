"""Exact finite-scenario teaching model; Python standard library only."""
from fractions import Fraction as F
from itertools import product
from datetime import date
from pathlib import Path
import argparse, csv, json, hashlib

ROOT = Path(__file__).resolve().parent

def integer(x, name, lo=0, hi=100000):
    if type(x) is not int or not lo <= x <= hi:
        raise ValueError(f'{name}: expected integer in [{lo},{hi}]')
    return x

def validate_config(c):
    if c.get('schema_version') != 1 or type(c.get('schema_version')) is not int:
        raise ValueError('schema_version must be 1')
    if c.get('unit') != 'kg': raise ValueError('unit must be kg')
    d, l, s = c.get('daily_demand'), c.get('lead_times'), c.get('thresholds')
    for name, x in [('daily_demand', d), ('lead_times',l)]:
        if not isinstance(x,list) or len(x)!=2: raise ValueError(name+' needs two values')
    for x in d: integer(x,'demand')
    for x in l: integer(x,'lead time',1,8)
    if not d[0]<d[1] or not l[0]<l[1]: raise ValueError('two demand/leadtime values must be strictly increasing')
    if not isinstance(s,list) or not 1<=len(s)<=30: raise ValueError('thresholds need 1..30 values')
    for x in s: integer(x,'threshold')
    if len(set(s))!=len(s): raise ValueError('thresholds must be unique')
    return d,l,s

def scenario_rows(c):
    d,ls,_=validate_config(c)
    rows=[]
    # Equal probability for each lead time; IID demand conditional on independent L.
    for l in ls:
        for seq in product(d,repeat=l):
            rows.append({'case':'independent','lead_time':l,'path':seq,'prob':F(1,2**(l+1)),'total':sum(seq)})
    # Exactly the same unconditional IID length-Lmax demand-vector law and L marginal.
    # Only the coupling changes: first-day low demand -> short L, high -> long L.
    for seq in product(d,repeat=max(ls)):
        l=ls[0] if seq[0]==d[0] else ls[1]
        rows.append({'case':'paired_dependence','lead_time':l,'path':seq,'prob':F(1,2**max(ls)),'total':sum(seq[:l])})
    # Deliberately stronger common-shock scenario, not a controlled correlation experiment.
    for x,l in zip(d,ls):
        rows.append({'case':'common_shock','lead_time':l,'path':(x,)*l,'prob':F(1,2),'total':x*l})
    return rows

def quantile(rows,p):
    if not isinstance(p,F) or not 0<p<=1: raise ValueError('quantile p must be Fraction in (0,1]')
    acc=F(0)
    for r in sorted(rows,key=lambda x:x['total']):
        acc+=r['prob']
        if acc>=p: return r['total']
    raise ValueError('probabilities do not sum to 1')

def metrics(rows,threshold):
    integer(threshold,'threshold')
    total_p=sum((r['prob'] for r in rows),F(0))
    if total_p!=1: raise ValueError('probabilities must sum to one')
    mean=sum((r['prob']*r['total'] for r in rows),F(0))
    variance=sum((r['prob']*(r['total']-mean)**2 for r in rows),F(0))
    covered=sum((r['prob'] for r in rows if r['total']<=threshold),F(0))
    lost=sum((r['prob']*max(0,r['total']-threshold) for r in rows),F(0))
    return dict(mean=mean,variance=variance,threshold=threshold,coverage=covered,expected_lost=lost,
                quantity_fill=None if mean==0 else (mean-lost)/mean,
                p50=quantile(rows,F(1,2)),p90=quantile(rows,F(9,10)),p95=quantile(rows,F(19,20)))

def read_csv(p,fields):
    with p.open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=fields: raise ValueError(f'{p.name}: wrong CSV columns')
        rows=list(reader)
    if any(None in r or any(v is None for v in r.values()) for r in rows): raise ValueError('malformed CSV')
    return rows

def parse_date(s):
    try:
        dt=date.fromisoformat(s)
        if dt.isoformat()!=s: raise ValueError()
        return dt
    except (ValueError,TypeError): raise ValueError('date must be YYYY-MM-DD') from None

def quantity(s):
    try:
        x=int(s)
        if str(x)!=s: raise ValueError()
    except (ValueError,TypeError): raise ValueError('quantity must be a canonical integer') from None
    return integer(x,'quantity',1,1000000)

def order_snapshot(orders,receipts,cutoff):
    cutoff=parse_date(cutoff)
    indexed={}
    for o in orders:
        oid=o['order_id']
        if not oid or oid.strip()!=oid or oid in indexed: raise ValueError('empty, padded or duplicate order ID')
        if o['unit']!='m': raise ValueError('apparel unit must be m')
        indexed[oid]={'created':parse_date(o['created_date']),'quantity':quantity(o['ordered_qty'])}
    if not indexed: raise ValueError('orders must not be empty')
    events={x:[] for x in indexed}; seen=set()
    for r in receipts:
        rid=r['receipt_id']; oid=r['order_id']
        if not rid or rid.strip()!=rid or rid in seen: raise ValueError('empty, padded or duplicate receipt ID')
        seen.add(rid)
        if oid not in indexed: raise ValueError('unknown order')
        day=parse_date(r['receipt_date']); qty=quantity(r['accepted_qty'])
        if day<indexed[oid]['created']: raise ValueError('receipt before creation')
        # Future events are unavailable to this snapshot; no future label is read into it.
        if day<=cutoff: events[oid].append((day,rid,qty))
    output=[]
    for oid,o in sorted(indexed.items()):
        if o['created']>cutoff: continue
        received=0; first=None; full=None
        for day,rid,q in sorted(events[oid]):
            received+=q
            if received>o['quantity']: raise ValueError('accepted receipts exceed ordered quantity')
            if first is None: first=day
            if received==o['quantity']: full=day
        age=(cutoff-o['created']).days
        output.append(dict(order_id=oid,created_date=o['created'].isoformat(),cutoff_date=cutoff.isoformat(),unit='m',ordered_qty=o['quantity'],accepted_qty=received,
            first_receipt_event=int(first is not None),first_receipt_days=(first-o['created']).days if first else '',
            first_receipt_duration_or_censor_days=(first-o['created']).days if first else age,
            complete_event=int(full is not None),complete_days=(full-o['created']).days if full else '',
            complete_duration_or_censor_days=(full-o['created']).days if full else age,
            observation_age_days=age))
    return output

def serial(v):
    if isinstance(v,F): return str(v)
    if isinstance(v,tuple): return '|'.join(map(str,v))
    if v is None: return ''
    return v

def write_csv(path,rows):
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader()
        w.writerows({k:serial(v) for k,v in r.items()} for r in rows)

def execute(input_dir,output_dir):
    input_dir=Path(input_dir).resolve(); output_dir=Path(output_dir).resolve()
    if output_dir==input_dir or input_dir in output_dir.parents: raise ValueError('output directory cannot be within input directory')
    c=json.loads((input_dir/'scenarios.json').read_text(encoding='utf-8'))
    rows=scenario_rows(c);results=[]; summary={}
    for name in ('independent','paired_dependence','common_shock'):
        subset=[r for r in rows if r['case']==name]
        for s in c['thresholds']: results.append(dict(case=name,**metrics(subset,s)))
        m=metrics(subset,c['thresholds'][0]); summary[name]={k:serial(v) for k,v in m.items() if k in ('mean','variance','p50','p90','p95')};summary[name]['path_rows']=len(subset)
    orders=read_csv(input_dir/'orders.csv',['order_id','created_date','ordered_qty','unit'])
    receipts=read_csv(input_dir/'receipts.csv',['receipt_id','order_id','receipt_date','accepted_qty'])
    obs=json.loads((input_dir/'observation.json').read_text(encoding='utf-8'))
    snapshot=order_snapshot(orders,receipts,obs['cutoff_date'])
    if not snapshot: raise ValueError('no observed orders at cutoff')
    finished=[x['complete_days'] for x in snapshot if x['complete_event']]
    first=[x['first_receipt_days'] for x in snapshot if x['first_receipt_event']]
    summary['apparel']={'cutoff':obs['cutoff_date'],'orders':len(snapshot),'completed':len(finished),'right_censored':len(snapshot)-len(finished),
        'complete_case_only_mean_days':serial(F(sum(finished),len(finished))) if finished else None,
        'first_receipt_observed_only_mean_days':serial(F(sum(first),len(first))) if first else None,
        'warning':'Completed-case average is descriptive, not an estimate of all-order mean lead time; pending durations are lower bounds, not completed labels.'}
    summary['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(input_dir.iterdir()) if p.is_file()}
    output_dir.mkdir(parents=True,exist_ok=True)
    write_csv(output_dir/'scenarios.csv',rows);write_csv(output_dir/'metrics.csv',results);write_csv(output_dir/'order_snapshot.csv',snapshot)
    (output_dir/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return summary

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--input-dir',type=Path,default=ROOT/'inputs');parser.add_argument('--output-dir',type=Path,default=ROOT/'outputs')
    args=parser.parse_args()
    try: result=execute(args.input_dir,args.output_dir)
    except (ValueError,KeyError,TypeError,OSError) as e: parser.exit(2,f'Input or output error: {e}\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
