import unittest, tempfile, json, copy, random
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from run import ROOT, scenario_rows, metrics, quantile, validate_config, order_snapshot, read_csv, execute

class LeadtimeTests(unittest.TestCase):
    def setUp(self):
        self.c=json.loads((ROOT/'inputs/scenarios.json').read_text())
        self.rows=scenario_rows(self.c)
        self.ind=[r for r in self.rows if r['case']=='independent']
        self.dep=[r for r in self.rows if r['case']=='paired_dependence']
        self.orders=read_csv(ROOT/'inputs/orders.csv',['order_id','created_date','ordered_qty','unit'])
        self.receipts=read_csv(ROOT/'inputs/receipts.csv',['receipt_id','order_id','receipt_date','accepted_qty'])
    def snapshot(self): return order_snapshot(self.orders,self.receipts,'2026-01-15')
    def test_path_count(self): self.assertEqual(len(self.ind),40)
    def test_probability(self):
        for case in ['independent','paired_dependence','common_shock']:
            self.assertEqual(sum(r['prob'] for r in self.rows if r['case']==case),1)
    def test_independent_moments(self):
        m=metrics(self.ind,52);self.assertEqual((m['mean'],m['variance']),(40,116))
    def test_quantiles(self): self.assertEqual([quantile(self.ind,F(i,100)) for i in [50,90,95]],[36,52,56])
    def test_boundary_quantile(self): self.assertEqual(quantile(self.ind,F(1,2)),36)
    def test_quantile_100(self): self.assertEqual(quantile(self.ind,F(1)),60)
    def test_quantile_invalid(self):
        for p in [F(0),F(-1),F(2),0.95]:
            with self.assertRaises(ValueError): quantile(self.ind,p)
    def test_threshold_52(self):
        m=metrics(self.ind,52);self.assertEqual(m['coverage'],F(29,32));self.assertEqual(m['expected_lost'],F(7,16));self.assertEqual(m['quantity_fill'],F(633,640))
    def test_threshold_56(self): self.assertEqual(metrics(self.ind,56)['coverage'],F(63,64))
    def test_monotonic(self):
        for case in ['independent','paired_dependence','common_shock']:
            r=[x for x in self.rows if x['case']==case]
            vals=[metrics(r,s) for s in range(65)]
            self.assertEqual([x['coverage'] for x in vals],sorted(x['coverage'] for x in vals))
            self.assertEqual([x['expected_lost'] for x in vals],sorted((x['expected_lost'] for x in vals),reverse=True))
    def test_paired_marginals(self):
        self.assertEqual(len(self.dep),32)
        for l in [3,5]:self.assertEqual(sum(r['prob'] for r in self.dep if r['lead_time']==l),F(1,2))
        for j in range(5):self.assertEqual(sum(r['prob'] for r in self.dep if r['path'][j]==8),F(1,2))
        self.assertEqual({r['path'] for r in self.dep},set(product([8,12],repeat=5)))
    def test_paired_moments(self):
        m=metrics(self.dep,52);self.assertEqual((m['mean'],m['variance'],m['coverage']),(40,156,F(27,32)))
    def test_common_shock(self):
        m=metrics([r for r in self.rows if r['case']=='common_shock'],58)
        self.assertEqual((m['mean'],m['variance'],m['coverage'],m['expected_lost']),(42,324,F(1,2),1))
    def test_config_bool(self):
        self.c['daily_demand'][0]=True
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_config_equal_demands(self):
        self.c['daily_demand']=[8,8]
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_config_negative(self):
        self.c['daily_demand'][0]=-1
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_config_explosion_bound(self):
        self.c['lead_times']=[3,30]
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_config_leadtime_zero(self):
        self.c['lead_times']=[0,5]
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_config_units(self):
        self.c['unit']='m'
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_config_threshold_duplicate(self):
        self.c['thresholds']=[40,40]
        with self.assertRaises(ValueError): scenario_rows(self.c)
    def test_snapshot_counts(self):
        s=self.snapshot();self.assertEqual(len(s),8);self.assertEqual(sum(x['complete_event'] for x in s),5)
    def test_first_vs_full(self):
        x=self.snapshot()[0];self.assertEqual((x['first_receipt_days'],x['complete_days']),(3,8))
    def test_partial_censor(self):
        x=self.snapshot()[4];self.assertEqual((x['accepted_qty'],x['complete_event'],x['complete_days'],x['complete_duration_or_censor_days']),(20,0,'',10))
    def test_no_receipt_censor(self):
        x=self.snapshot()[6];self.assertEqual((x['first_receipt_event'],x['first_receipt_duration_or_censor_days'],x['complete_duration_or_censor_days']),(0,8,8))
    def test_future_event_no_leak(self):
        before=self.snapshot();self.receipts.append(dict(receipt_id='FUTURE',order_id='SIM-PO05',receipt_date='2026-01-18',accepted_qty='80'));self.assertEqual(before,self.snapshot())
        later=order_snapshot(self.orders,self.receipts,'2026-01-18');self.assertEqual(later[4]['complete_days'],13)
    def test_future_order_no_leak(self):
        before=self.snapshot();self.orders.append(dict(order_id='FUTURE',created_date='2026-01-18',ordered_qty='100',unit='m'));self.assertEqual(before,self.snapshot())
    def test_cutoff_inclusive(self):
        self.receipts.append(dict(receipt_id='TODAY',order_id='SIM-PO05',receipt_date='2026-01-15',accepted_qty='80'));self.assertEqual(self.snapshot()[4]['complete_days'],10)
    def test_receipts_order_independent(self):
        before=self.snapshot();self.receipts.reverse();self.assertEqual(before,self.snapshot())
    def test_duplicate_id(self):
        self.orders.append(self.orders[0])
        with self.assertRaises(ValueError): self.snapshot()
    def test_receipt_duplicate(self):
        self.receipts.append(self.receipts[0])
        with self.assertRaises(ValueError): self.snapshot()
    def test_over_received(self):
        self.receipts[0]['accepted_qty']='101'
        with self.assertRaises(ValueError):self.snapshot()
    def test_date_before_order(self):
        self.receipts[0]['receipt_date']='2025-12-31'
        with self.assertRaises(ValueError):self.snapshot()
    def test_invalid_date(self):
        self.orders[0]['created_date']='2026-02-31'
        with self.assertRaises(ValueError):self.snapshot()
    def test_zero_quantity(self):
        self.receipts[0]['accepted_qty']='0'
        with self.assertRaises(ValueError):self.snapshot()
    def test_unknown_order(self):
        self.receipts[0]['order_id']='missing'
        with self.assertRaises(ValueError):self.snapshot()
    def test_wrong_order_unit(self):
        self.orders[0]['unit']='kg'
        with self.assertRaises(ValueError):self.snapshot()
    def test_deterministic_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            a,b=Path(td)/'a',Path(td)/'b';execute(ROOT/'inputs',a);execute(ROOT/'inputs',b)
            self.assertEqual({p.name:p.read_bytes() for p in a.iterdir()},{p.name:p.read_bytes() for p in b.iterdir()})
    def test_input_overwrite_guard(self):
        with self.assertRaises(ValueError):execute(ROOT/'inputs',ROOT/'inputs')
    def test_random_independent_formula(self):
        rng=random.Random(2026)
        for _ in range(50):
            low=rng.randrange(0,10); high=low+rng.randrange(1,10); a=rng.randrange(1,4); b=a+rng.randrange(1,4)
            c=dict(self.c,daily_demand=[low,high],lead_times=[a,b])
            rows=[r for r in scenario_rows(c) if r['case']=='independent'];m=metrics(rows,10)
            mu=F(low+high,2);var=F((high-low)**2,4)
            self.assertEqual(m['mean'],F(a+b,2)*mu)
            self.assertEqual(m['variance'],F(a+b,2)*var+mu**2*F((b-a)**2,4))

if __name__=='__main__': unittest.main()
