# 数据字典

所有企业、订单及数值模拟；正文的公斤与本表服装米单位不可相加。

## 输入
- scenarios.schema_version：固定1；unit固定kg。
- daily_demand：两个等概率日需求值；非负整数。
- lead_times：两个等概率完整需求日数；1—8。
- thresholds：待比较的保护段初始可用量S，kg。
- orders.order_id：唯一非空模拟订单号。
- created_date：下单日期，YYYY-MM-DD。
- ordered_qty：正整数订货量；unit固定m。
- receipts.receipt_id：唯一非空模拟收货事件号。
- receipts.order_id：关联已存在订单。
- receipt_date：验收可用日期，不早于下单。
- accepted_qty：本次可用收货米数，正整数；不是累计值。
- observation.cutoff_date：快照截至当日日终。

## 情景和指标
- case：independent、paired_dependence、common_shock。
- lead_time：该情景覆盖日数L。
- path：用竖线分隔日需求；paired记录完整五日向量，total仅加前L天。
- prob：该行概率，精确分数字符串；不能将所有行等权平均。
- total：前L天累计需求，kg。
- mean、variance：累计需求均值kg、总体方差kg²，不是样本方差。
- threshold：初始可用量S，kg。
- coverage：P(total≤S)，无量纲。
- expected_lost：E[max(total−S,0)]，kg。
- quantity_fill：1−expected_lost/mean，均值0时空值。
- p50、p90、p95：左连续逆CDF口径的最小达到概率阈值需求值，kg。

## 订单快照
- accepted_qty：截至日终累计已验收可用数量m。
- first_receipt_event：截至截止日是否已观察首次收货，1/0。
- first_receipt_days：已观察时的日期差，未观察则空值。
- first_receipt_duration_or_censor_days：已观察时长或截至日观察年龄。
- complete_event：是否已收齐，1/0；0意味着右删失，不意味着永不收齐。
- complete_days：收齐日期减下单日期；未收齐为空值。
- complete_duration_or_censor_days：收齐时长或未收齐订单截至日年龄。
- observation_age_days：截止日减下单日期；已完结订单也保留同一口径。

摘要中complete_case_only_mean_days与first_receipt_observed_only_mean_days均仅为对应已发生事件样本的描述性平均，不是全部订单期望交期。
